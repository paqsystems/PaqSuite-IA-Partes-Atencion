import { resolveRequestUrl } from '../mobile/resolveApiBaseUrl';
import { buildPlatformHeaders, type BuildPlatformHeadersInput } from './headers';
import {
  parseEnvelope,
  transportI18nKey,
  type ApiClientResult,
  type PaqSuiteEnvelope,
} from './parseEnvelope';

export type { ApiClientResult, PaqSuiteEnvelope } from './parseEnvelope';
export {
  isEnvelope,
  parseEnvelope,
  transportI18nKey,
} from './parseEnvelope';

export type ApiRequestOptions = RequestInit & {
  platform?: BuildPlatformHeadersInput;
  skipPlatformHeaders?: boolean;
  /** Si true, no invoca el handler global ante HTTP 401 (p. ej. login). */
  skipUnauthorizedHandler?: boolean;
};

export type ApiUnauthorizedHandler = (context: {
  httpStatus: number;
  path: string;
}) => void;

let unauthorizedHandler: ApiUnauthorizedHandler | undefined;

/** Registra callback opcional para HTTP 401 (sesión expirada / no autorizado). */
export function setApiUnauthorizedHandler(
  handler: ApiUnauthorizedHandler | undefined
): void {
  unauthorizedHandler = handler;
}

function notifyUnauthorized(
  httpStatus: number,
  path: string,
  skip?: boolean
): void {
  if (skip || httpStatus !== 401 || !unauthorizedHandler) {
    return;
  }
  unauthorizedHandler({ httpStatus, path });
}

function transportError(
  httpStatus?: number,
  cause?: unknown
): ApiClientResult<never> {
  return {
    kind: 'transportError',
    httpStatus,
    i18nKey: transportI18nKey,
    cause,
  };
}

function classifyEnvelope<T>(
  httpStatus: number,
  envelope: PaqSuiteEnvelope<T>
): ApiClientResult<T> {
  if (envelope.error !== 0 || httpStatus >= 400) {
    return {
      kind: 'envelopeError',
      httpStatus,
      envelope: envelope as PaqSuiteEnvelope<unknown>,
    };
  }

  return {
    kind: 'ok',
    httpStatus,
    envelope,
  };
}

/**
 * Cliente HTTP con envelope PaqSuite (SPEC-001-20).
 * Breaking: retorna ApiClientResult (no Promise&lt;PaqSuiteEnvelope&gt;).
 * No lanza por contrato/transporte; red también → transportError.
 */
export async function apiRequest<T>(
  path: string,
  options: ApiRequestOptions = {}
): Promise<ApiClientResult<T>> {
  const headers = new Headers(options.headers ?? {});

  if (!options.skipPlatformHeaders && options.platform) {
    const platformHeaders = buildPlatformHeaders(options.platform);
    Object.entries(platformHeaders).forEach(([name, value]) => {
      headers.set(name, value);
    });
  }

  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json');
  }

  // Fuerza envelope JSON en 401/errores API (evita HTML "Route [login] not defined").
  if (!headers.has('Accept')) {
    headers.set('Accept', 'application/json');
  }

  const requestUrl = resolveRequestUrl(path);

  let response: Response;
  try {
    response = await fetch(requestUrl, {
      ...options,
      headers,
    });
  } catch (cause) {
    return transportError(undefined, cause);
  }

  let rawText: string;
  try {
    rawText = await response.text();
  } catch (cause) {
    return transportError(response.status, cause);
  }

  let parsed: unknown;
  try {
    parsed = rawText === '' ? null : JSON.parse(rawText);
  } catch (cause) {
    return transportError(response.status, cause);
  }

  const envelope = parseEnvelope(parsed);
  if (!envelope) {
    const result = transportError(response.status, parsed);
    notifyUnauthorized(response.status, path, options.skipUnauthorizedHandler);
    return result;
  }

  const result = classifyEnvelope(response.status, envelope as PaqSuiteEnvelope<T>);
  notifyUnauthorized(response.status, path, options.skipUnauthorizedHandler);
  return result;
}
