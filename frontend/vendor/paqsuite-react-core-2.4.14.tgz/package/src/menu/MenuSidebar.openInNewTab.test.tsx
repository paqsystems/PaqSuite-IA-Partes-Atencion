/**
 * @vitest-environment jsdom
 */
import { cleanup, render, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { MenuNode } from './menuTypes';

const { apiRequest, openMenuProcess } = vi.hoisted(() => ({
  apiRequest: vi.fn(),
  openMenuProcess: vi.fn(),
}));

vi.mock('../http/apiClient', () => ({
  apiRequest,
}));

vi.mock('../userMenu/openMenuProcess', () => ({
  openMenuProcess,
}));

vi.mock('./MenuToolbarControls', () => ({
  MenuToolbarControls: () => <div data-testid="menuToolbar" />,
  defaultMenuToolbarLabels: {},
}));

vi.mock('devextreme-react/load-panel', () => ({
  default: () => null,
}));

vi.mock('devextreme-react/text-box', () => ({
  default: () => null,
}));

vi.mock('devextreme-react/button', () => ({
  default: () => null,
}));

let lastTreeViewProps: {
  onItemClick?: (event: { itemData?: unknown }) => void;
} | null = null;

vi.mock('devextreme-react/tree-view', () => ({
  default: (props: { onItemClick?: (event: { itemData?: unknown }) => void }) => {
    lastTreeViewProps = props;
    return <div data-testid="menuSidebarTree" />;
  },
}));

import { MenuSidebar } from './MenuSidebar';

const platform = { cliente: 'DEMO', tenancy: 'single' as const };

const processNode: MenuNode = {
  id: 10100,
  menuKey: 'demo-proceso',
  text: 'Proceso demo',
  labelKey: null,
  routeName: '/demo-proceso',
  nodeType: 'process',
  procedimiento: null,
  order: 10100,
  iconName: null,
  processType: null,
  permissions: null,
  children: [],
};

describe('MenuSidebar openInNewTab', () => {
  beforeEach(() => {
    lastTreeViewProps = null;
    apiRequest.mockResolvedValue({
      kind: 'ok',
      envelope: { error: 0, respuesta: 'ok', resultado: { items: [processNode] } },
    });
    openMenuProcess.mockReset();
  });

  afterEach(() => {
    cleanup();
    vi.clearAllMocks();
  });

  it('delega clic de proceso en openMenuProcess con la preferencia recibida', async () => {
    const onNavigate = vi.fn();

    render(
      <MenuSidebar
        platform={platform}
        accessToken="token-test"
        openInNewTab={true}
        onNavigate={onNavigate}
      />,
    );

    await waitFor(() => {
      expect(lastTreeViewProps?.onItemClick).toBeTypeOf('function');
    });

    lastTreeViewProps?.onItemClick?.({
      itemData: {
        menuKey: 'demo-proceso',
        nodeType: 'process',
        routeName: '/demo-proceso',
        text: 'Proceso demo',
        id: 10100,
      },
    });

    expect(openMenuProcess).toHaveBeenCalledWith({
      url: '/demo-proceso',
      openInNewTab: true,
      isNativeApp: false,
      navigate: expect.any(Function),
    });

    const navigateArg = openMenuProcess.mock.calls[0][0].navigate as (url: string) => void;
    navigateArg('/demo-proceso');
    expect(onNavigate).toHaveBeenCalledWith('/demo-proceso');
  });
});
