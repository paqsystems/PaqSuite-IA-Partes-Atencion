import { describe, expect, it } from 'vitest';
import { localizeMenuTree, resolveMenuCaption } from './menuDisplay';
import type { MenuNode } from './menuTypes';

const t = (key: string) => {
  const catalog: Record<string, string> = {
    'menu.sales': 'Sales',
    'menu.sales.orders': 'Orders',
  };
  return catalog[key] ?? key;
};

describe('menuDisplay', () => {
  it('resolveMenuCaption falls back to text when labelKey is missing', () => {
    expect(resolveMenuCaption({ labelKey: null, text: 'Archivos' }, t)).toBe('Archivos');
  });

  it('resolveMenuCaption uses translation when labelKey exists', () => {
    expect(resolveMenuCaption({ labelKey: 'menu.sales', text: 'Ventas' }, t)).toBe('Sales');
  });

  it('localizeMenuTree translates nested levels recursively', () => {
    const tree: MenuNode[] = [
      {
        id: 10000,
        menuKey: 'sales',
        labelKey: 'menu.sales',
        text: 'Ventas',
        routeName: null,
        procedimiento: null,
        order: 1,
        nodeType: 'group',
        iconName: null,
        processType: null,
        permissions: null,
        children: [
          {
            id: 10100,
            menuKey: 'sales.orders',
            labelKey: 'menu.sales.orders',
            text: 'Pedidos',
            routeName: '/orders',
            procedimiento: null,
            order: 1,
            nodeType: 'process',
            iconName: null,
            processType: null,
            permissions: null,
            children: [],
          },
        ],
      },
    ];

    const localized = localizeMenuTree(tree, t);
    expect(localized[0]?.text).toBe('Sales');
    expect(localized[0]?.children[0]?.text).toBe('Orders');
  });
});
