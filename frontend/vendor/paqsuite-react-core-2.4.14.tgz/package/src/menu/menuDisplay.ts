import type { MenuNode } from './menuTypes';

function translateOrFallback(key: string, fallback: string, t: (key: string) => string): string {
  const translated = t(key);
  return translated !== key && translated.trim() !== '' ? translated : fallback;
}

/**
 * Caption i18n de un nodo de menú: `labelKey` con fallback a `text` (GEN-02 / SPEC-001-07).
 */
export function resolveMenuCaption(
  node: Pick<MenuNode, 'labelKey' | 'text'>,
  t: (key: string) => string,
): string {
  const key = node.labelKey?.trim();
  if (!key) {
    return node.text;
  }
  return translateOrFallback(key, node.text, t);
}

/**
 * Aplica `resolveMenuCaption` recursivamente a todo el árbol de menú.
 */
export function localizeMenuTree(nodes: MenuNode[], t: (key: string) => string): MenuNode[] {
  return nodes.map((node) => ({
    ...node,
    text: resolveMenuCaption(node, t),
    children: localizeMenuTree(node.children ?? [], t),
  }));
}
