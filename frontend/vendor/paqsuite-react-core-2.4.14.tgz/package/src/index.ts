export {
  apiRequest,
  isEnvelope,
  parseEnvelope,
  setApiUnauthorizedHandler,
  transportI18nKey,
  type ApiClientResult,
  type ApiRequestOptions,
  type ApiUnauthorizedHandler,
  type PaqSuiteEnvelope,
} from './http/apiClient';

export {
  buildPlatformHeaders,
  clienteHeaderName,
  companyHeaderName,
  type BuildPlatformHeadersInput,
  type PaqSuiteDb,
  type PaqSuiteTenancy,
} from './http/headers';

export {
  bootstrapClienteFromWindow,
  isDevOrNonCanonicalHostname,
  normalizeClienteCode,
  paqClienteCookieName,
  paqClienteSessionKey,
  persistClienteCode,
  queryClienteFromSearch,
  readPersistedClienteCode,
  resolveClienteCode,
  type BootstrapClienteFromWindowInput,
  type ClientePersistence,
  type ResolveClienteCodeInput,
} from './tenancy/clienteBridge';

export {
  defaultClienteLogoFileName,
  resolveClienteDefaultLogoUrl,
  resolveClienteLogoUrl,
  type ResolveClienteLogoUrlInput,
} from './tenancy/clienteBranding';

export {
  blockedNoCompanyI18nKey,
  postLoginHomePath,
  postLoginSelectorPath,
  resolveEmpresaGate,
  type EmpresaGateResult,
  type EmpresaPermiso,
} from './tenancy/resolveEmpresaGate';

export {
  clearCompanyChangeHandlers,
  notifyCompanyChange,
  registerOnCompanyChange,
  type CompanyChangeHandler,
} from './tenancy/companyChange';

export {
  applyEmpresaAppearance,
  type ApplyEmpresaAppearanceTarget,
  type EmpresaAppearance,
} from './tenancy/applyEmpresaAppearance';

export {
  MenuSidebar,
  defaultMenuSidebarLabels,
  type MenuSidebarProps,
  type MenuSidebarLabels,
} from './menu/MenuSidebar';

export {
  MenuToolbarControls,
  defaultMenuToolbarLabels,
  type MenuToolbarControlsProps,
  type MenuToolbarControlsLabels,
} from './menu/MenuToolbarControls';

export { useMenuPresentation } from './menu/useMenuPresentation';

export {
  defaultMenuPresentationState,
  readMenuPresentationState,
  writeMenuPresentationState,
  type MenuDisplayMode,
  type MenuPresentationState,
} from './menu/menuPresentationStorage';

export { foldMenuSearchText, menuSearchMatches } from './menu/menuSearchAccentFold';
export { filterMenuBySearch } from './menu/filterMenuBySearch';
export { localizeMenuTree, resolveMenuCaption } from './menu/menuDisplay';
export {
  flattenOperationalMenu,
  collectAllGroupMenuKeys,
} from './menu/flattenOperationalMenu';

export {
  filterMenuForMobile,
  isMenuKeyAllowedOnMobile,
} from './menu/mobileMenuPolicy';

export type {
  MenuNode,
  MenuPermissions,
  MenuResultado,
} from './menu/menuTypes';

export {
  MenuAuthProvider,
  useMenuAuth,
  useMenuProcessPermissions,
  findMenuProcessByRoute,
  type MenuAuthContextValue,
} from './menu/MenuAuthContext';

export {
  ProcessDataGrid,
  type ProcessDataGridProps,
} from './ui/grid/ProcessDataGrid';
export { processGridToolbarConvention } from './ui/grid/processGridToolbarConvention';
export {
  resolveAllowedGridSummaryTypes,
  normalizeGridColumnDataKind,
  inferGridColumnDataType,
  toggleGridTotalItem,
  isGridTotalItemActive,
  enrichGridTotalItems,
  DEFAULT_GRID_SUMMARY_TYPE_LABELS,
  type GridSummaryType,
  type GridColumnDataKind,
  type ProcessGridTotalItem,
} from './ui/grid/gridSummaryTypes';
export {
  listGridLayouts,
  getActiveGridLayout,
  setActiveGridLayout,
  createGridLayout,
  updateGridLayout,
  deleteGridLayout,
  formatGridLayoutDisplayName,
  GRID_LAYOUT_ORIGINAL_VALUE,
  type GridLayoutListItem,
  type GridLayoutActiveDto,
} from './ui/grid/gridLayoutsClient';
export {
  useGridLayouts,
  type UseGridLayoutsArgs,
  type UseGridLayoutsResult,
  type GridLayoutSelectItem,
} from './ui/grid/useGridLayouts';
export {
  GridLayoutsToolbarControls,
  GridLayoutSaveAsDialog,
  defaultGridLayoutsToolbarLabels,
  type GridLayoutsToolbarLabels,
} from './ui/grid/GridLayoutsToolbarControls';

// --- Experiencia mobile (GEN-22) ---

export { isNativeApp } from './mobile/isNativeApp';
export { preferenceKeys, type PreferenceKey } from './mobile/preferenceKeys';
export {
  setPreferencesAdapter,
  getPreferencesAdapter,
  preferencesGet,
  preferencesSet,
  preferencesRemove,
  resetPreferencesMemory,
  type PreferencesAdapter,
} from './mobile/preferencesStorage';
export {
  normalizeApiBaseUrl,
  isAbsoluteHttpUrl,
  resolveApiBaseUrl,
  applyWebApiBaseUrlFromEnv,
  resolveRequestUrl,
  setCachedApiBaseUrlOverride,
  getCachedApiBaseUrlOverride,
  setCachedResolvedApiBaseUrl,
  getCachedResolvedApiBaseUrl,
  type ResolveApiBaseUrlInput,
} from './mobile/resolveApiBaseUrl';
export {
  readNativeAuthSnapshot,
  writeNativeAuthSnapshot,
  clearNativeAuthSnapshot,
  readApiBaseUrlOverride,
  writeApiBaseUrlOverride,
  clearApiBaseUrlOverride,
  hydrateApiBaseUrlCache,
  bootstrapApiBaseUrl,
  migrateLocalStorageSessionIfNeeded,
  type NativeAuthSnapshot,
  type BootstrapApiBaseUrlInput,
} from './mobile/nativeSessionStorage';
export {
  MobileConfigPanel,
  type MobileConfigPanelProps,
} from './mobile/MobileConfigPanel';
export {
  genMobileExclusions,
  matchesAllowlistEntry,
  isExcludedByGenCatalog,
  type GenMobileExclusion,
} from './mobile/policy/genMobileExclusions';
export {
  isPivotMenuItem,
  mobileExclusionPivotI18nKey,
  resolveMobileExclusionI18nKey,
  type PivotMenuItemLike,
} from './mobile/policy/isPivotMenuItem';
export {
  createMobilePolicy,
  isMobileRouteAllowed,
  isInAllowlist,
  filterMenuItemsForMobile,
  type MobilePolicy,
  type MobileMenuItemLike,
} from './mobile/policy/mobileRoutePolicy';
export {
  MobileMenuShell,
  type MobileMenuShellProps,
  type MobileMenuShellItem,
  type MobileMenuShellVariant,
} from './mobile/MobileMenuShell';
export {
  MobileRouteGuard,
  type MobileRouteGuardProps,
} from './mobile/MobileRouteGuard';
export type {
  KardexItem,
  KardexField,
  KardexStatus,
} from './mobile/kardex/types';
export {
  ConsultaKardexList,
  type ConsultaKardexListProps,
} from './mobile/kardex/ConsultaKardexList';
export {
  setMobilePushBridge,
  getMobilePushBridge,
  registerMobilePushHandlers,
  hasAskedPushPermission,
  markPushPermissionAsked,
  resolveDefaultPushPlatform,
  shouldAttemptPushOptIn,
  shouldPromptPushOptIn,
  shouldPostDeviceToken,
  type MobilePushBridge,
  type PushPlatform,
} from './mobile/push/pushBridge';
export {
  useMobilePushOptIn,
  type UseMobilePushOptInArgs,
  type UseMobilePushOptInResult,
} from './mobile/push/useMobilePushOptIn';
export {
  evaluateMobileConfigSaveGate,
  buildMobileHealthUrl,
} from './mobile/mobileConfigRules';
export {
  filterKardexItems,
  sliceKardexPage,
} from './mobile/kardex/kardexHelpers';

// --- i18n (GEN-02) ---

export {
  supportedLocales,
  isSupportedLocale,
  type LocaleCode,
} from './i18n/localeCatalog';

export { normalizeLocale } from './i18n/normalizeLocale';

export {
  clearGuestLocale,
  getGuestLocale,
  guestLocaleStorageKey,
  setGuestLocale,
} from './i18n/guestLocaleStorage';

export { formatDate, formatDecimalNumber, formatNumber } from './i18n/formatters';

export { syncDevExtremeLocale } from './i18n/syncDevExtremeLocale';

export { loginI18nCatalogs, translateLogin } from './i18n/loginI18n';

export {
  buildGridLayoutsToolbarLabels,
  buildGridSummaryTypeLabels,
  frameworkGridI18nKeys,
  gridDevExtremeMessagesForLocale,
  gridI18nCatalogs,
  gridSummaryTypeI18nKeys,
  resolveGridLayoutErrorMessage,
  translateGrid,
  type FrameworkGridI18nKey,
  type GridTranslateFn,
} from './i18n/gridI18n';

export { registerGridI18nResources } from './i18n/registerGridI18nResources';

export { useGridI18n, type UseGridI18nOptions, type UseGridI18nResult } from './i18n/useGridI18n';

export {
  agentGatewayMisconfiguredI18nKey,
  agentOfflineI18nKey,
  envelopeI18nCatalogs,
  frameworkEnvelopeI18nKeys,
  translateEnvelopeRespuesta,
} from './i18n/envelopeI18n';

export {
  resolveApiClientMessage,
  type ResolveApiClientMessageOptions,
} from './i18n/resolveApiClientMessage';

export {
  LanguageSelector,
  type LanguageSelectorProps,
} from './i18n/LanguageSelector';

// --- UI shell / auth / states (GEN-01) ---

export {
  authClassNames,
  processClassNames,
  shellClassNames,
  stateClassNames,
  authLayoutCssPath,
  shellLayoutCssPath,
  tokensCssPath,
  tokensCssText,
} from './ui/tokens';

export {
  AuthPageLayout,
  type AuthPageLayoutProps,
} from './ui/auth/AuthPageLayout';

export {
  AuthLoginLayout,
  type AuthLoginLayoutProps,
} from './ui/auth/AuthLoginLayout';

export {
  AuthCardLayout,
  type AuthCardLayoutProps,
} from './ui/auth/AuthCardLayout';

export {
  resolveAuthHeroConfig,
  readViteAuthHeroEnv,
  type AuthHeroConfig,
  type ResolveAuthHeroConfigInput,
} from './ui/auth/authHeroConfig';

export {
  ShellLayout,
  type ShellFooterInfo,
  type ShellLayoutProps,
} from './ui/shell/ShellLayout';

export { ClienteLogo, type ClienteLogoProps } from './ui/branding/ClienteLogo';
export { ShellBrand, type ShellBrandProps } from './ui/branding/ShellBrand';

export {
  ProcessPageLayout,
  type ProcessPageLayoutProps,
} from './ui/process/ProcessPageLayout';

export {
  resolveFormSurface,
  type FormSurface,
} from './ui/process/resolveFormSurface';

export { EmptyState, type EmptyStateProps } from './ui/states/EmptyState';
export { ErrorState, type ErrorStateProps } from './ui/states/ErrorState';
export { LoadingOverlay, type LoadingOverlayProps } from './ui/states/LoadingOverlay';

// --- Empresas (GEN-05) ---

export {
  activeCompanyStorageKey,
  clearActiveEmpresaId,
  getActiveEmpresaId,
  setActiveEmpresaId,
} from './tenancy/empresaStorage';

export {
  changeActiveEmpresa,
  type ChangeActiveEmpresaInput,
} from './tenancy/changeActiveEmpresa';

export {
  EmpresaSelectorPage,
  type EmpresaSelectorItem,
  type EmpresaSelectorPageProps,
} from './tenancy/EmpresaSelectorPage';

// --- Avatar / menú de usuario (GEN-08) ---

export {
  UserAvatarMenu,
  type UserAvatarMenuProps,
} from './userMenu/UserAvatarMenu';

export {
  openMenuProcess,
  type OpenMenuProcessInput,
} from './userMenu/openMenuProcess';

export { openExternalUrl } from './userMenu/openExternalUrl';

// --- Dashboard (GEN-09) ---

export {
  clearWidgets,
  listWidgets,
  registerWidget,
  type DashboardWidget,
} from './dashboard/dashboardRegistry';

export {
  DashboardContainer,
  type DashboardContainerProps,
} from './dashboard/DashboardContainer';

// --- Grid MVP sin DevExtreme (GEN-11) ---

export {
  resolveGridPageSizes,
  type GridPageSizeParamKey,
  type GridPageSizeParams,
} from './ui/grid/pageSizes';

export {
  applyState as applyGridState,
  captureState as captureGridState,
  type GridColumnState,
  type GridState,
  type GridStateTarget,
} from './ui/grid/gridState';

export {
  GridRefreshButton,
  type GridRefreshButtonProps,
} from './ui/grid/GridRefreshButton';

export {
  GridExportButton,
  type GridExportButtonProps,
} from './ui/grid/GridExportButton';

export {
  buildGridExportFileName,
  defaultGridExportMode,
  exportDataGridExcel,
  hasGridExportableData,
  type ExportDataGridExcelInput,
  type GridExportMode,
} from './ui/grid/exportDataGridExcel';

export {
  DataGridDx,
  type DataGridColumn,
  type DataGridDxHandle,
  type DataGridDxProps,
} from './ui/grid/DataGridDx';

// --- GEN-12 pivots (catálogo) ---

export {
  fetchPivotCatalog,
  pivotsCatalogBasePath,
  type PivotCampoCatalogDto,
  type PivotCampoDataType,
  type PivotConsultaCatalogDto,
  type PivotSummaryType,
} from './ui/pivot/pivotCatalogClient';

export {
  applyPivotPlantilla,
  listPivotPlantillas,
  listPivotValidaciones,
  type PivotPlantillaListItem,
  type PivotValidacionRule,
} from './ui/pivot/pivotPlantillasClient';

export {
  validatePivotStateClient,
  type PivotStateValidationError,
} from './ui/pivot/validatePivotStateClient';

export {
  createPivotLayout,
  deletePivotLayout,
  formatPivotLayoutDisplayName,
  getActivePivotLayout,
  listPivotLayouts,
  PIVOT_LAYOUT_ORIGINAL_VALUE,
  setActivePivotLayout,
  updatePivotLayout,
  type PivotLayoutActiveDto,
  type PivotLayoutListItem,
} from './ui/pivot/pivotLayoutsClient';

export {
  usePivotLayouts,
  type PivotLayoutSelectItem,
  type UsePivotLayoutsArgs,
  type UsePivotLayoutsResult,
} from './ui/pivot/usePivotLayouts';

export {
  defaultPivotLayoutsToolbarLabels,
  PivotLayoutSaveAsDialog,
  PivotLayoutsToolbarControls,
  type PivotLayoutsToolbarLabels,
} from './ui/pivot/PivotLayoutsToolbarControls';

export {
  PivotLayoutsBar,
  type PivotLayoutsBarProps,
} from './ui/pivot/PivotLayoutsBar';

export {
  enrichPivotFieldsWithDateFormat,
  enrichPivotFieldsWithNumericFormat,
  formatPivotDateCellText,
  formatPivotNumericCellText,
  isPivotDateDataType,
  isPivotNumericDataType,
  mapCatalogToPivotFields,
  resolveAllowedSummaryTypes,
  resolveDefaultSummaryType,
  type MapCatalogToPivotFieldsOptions,
  type PivotFieldConfig,
} from './ui/pivot/mapCatalogToPivotFields';

export { applyPivotState, capturePivotState } from './ui/pivot/pivotState';

export {
  getPivotLocalizedUiTexts,
  type PivotFieldChooserTexts,
  type PivotFieldPanelTexts,
  type PivotLocalizedUiTexts,
} from './ui/pivot/pivotLocalizedUiTexts';

export {
  PivotViewToggle,
  type PivotViewMode,
  type PivotViewToggleProps,
} from './ui/pivot/PivotViewToggle';

export {
  PivotRefreshButton,
  type PivotRefreshButtonProps,
} from './ui/pivot/PivotRefreshButton';

export {
  PivotGridBlock,
  type PivotGridBlockHandle,
  type PivotGridBlockProps,
} from './ui/pivot/PivotGridBlock';

export {
  ConsultaGrillaPivotShell,
  type ConsultaGrillaPivotShellProps,
} from './ui/pivot/ConsultaGrillaPivotShell';

export {
  PivotExportButton,
  type PivotExportButtonProps,
} from './ui/pivot/PivotExportButton';

export {
  buildPivotExportFileName,
  defaultPivotExportMode,
  exportPivotGridExcel,
  hasPivotExportableData,
  type ExportPivotGridExcelInput,
  type PivotExportMode,
} from './ui/pivot/exportPivotGridExcel';

// --- Capacidades: Provider IA (GEN-16) ---

export * from './features/llmCredentials/types';
export * from './features/llmCredentials/llmCredentialsClient';
export * from './features/llmCredentials/resolveActiveCredential';
export * from './features/llmCredentials/activeCredentialPreference';
export * from './features/llmCredentials/useLlmCredentialSelection';
export * from './features/llmCredentials/formHelpers';
export {
  defaultLlmProviderCatalog,
} from './features/llmCredentials/defaultLlmProviderCatalog';
export { LlmActiveCredentialSelect } from './features/llmCredentials/LlmActiveCredentialSelect';
export { LlmCredentialFormPopup } from './features/llmCredentials/LlmCredentialFormPopup';
export { LlmPreferencesPanel } from './features/llmCredentials/LlmPreferencesPanel';
export { createLlmPreferencesModalController } from './features/llmCredentials/openLlmPreferencesModal';

// --- Capacidades: Smart Capture (GEN-03) ---

export * from './features/smartCapture/types';
export * from './features/smartCapture/resolveModality';
export * from './features/smartCapture/buildSmartCaptureTurnRequest';
export * from './features/smartCapture/postSmartCaptureTurn';
export * from './features/smartCapture/imageValidation';
export * from './features/smartCapture/applySmartCaptureActions';
export {
  SMART_CAPTURE_MAX_OPTIONS,
  useSmartCapturePendingChoice,
} from './features/smartCapture/useSmartCapturePendingChoice';
export type {
  SmartCaptureDeferredCause,
  SmartCaptureDeferredItem,
} from './features/smartCapture/useSmartCapturePendingChoice';
export { useWebSpeechDictation } from './features/smartCapture/useWebSpeechDictation';
export {
  SmartCapturePanel,
  type SmartCaptureCredential,
  type SmartCapturePanelProps,
  type SmartCaptureThreadMessage,
} from './features/smartCapture/SmartCapturePanel';

// --- Capacidades: Chat / ayuda externa (GEN-21) ---

export * from './features/chatAssistant/types';
export * from './features/chatAssistant/buildChatAssistantTurnRequest';
export * from './features/chatAssistant/postChatAssistantTurn';
export * from './features/chatAssistant/externalHelp';
export { ChatAssistantThread } from './features/chatAssistant/ChatAssistantThread';
export { ChatAssistantPage } from './features/chatAssistant/ChatAssistantPage';
export {
  ExternalHelpRedirectPage,
  type ExternalHelpRedirectPageProps,
} from './features/chatAssistant/ExternalHelpRedirectPage';

// --- Capacidades: Tareas programadas (GEN-13) ---

export * from './features/tasks/types';
export * from './features/tasks/semaphoreMap';
export * from './features/tasks/tasksClient';
export { TaskProcessesPage } from './features/tasks/TaskProcessesPage';
export { TaskDefinitionsPage } from './features/tasks/TaskDefinitionsPage';
export { TaskDefinitionFormPage } from './features/tasks/TaskDefinitionFormPage';
export { TaskAutomationsMonitorPage } from './features/tasks/TaskAutomationsMonitorPage';
export { TaskExecutionsPage } from './features/tasks/TaskExecutionsPage';
export { translateTareasProgramadas } from './features/tasks/tasksI18n';

// --- Capacidades: Auditoría y notificaciones (GEN-17) ---

export * from './features/audit/types';
export * from './features/audit/auditSourcePermission';
export * from './features/audit/auditEventsClient';
export { useAuditEventsQuery } from './features/audit/useAuditEventsQuery';
export { AuditEventsPage } from './features/audit/AuditEventsPage';
export * from './features/notifications/types';
export * from './features/notifications/pollingInterval';
export * from './features/notifications/notificationsClient';
export { useNotificationsPolling } from './features/notifications/useNotificationsPolling';
export { NotificationsBell } from './features/notifications/NotificationsBell';

// --- Capacidades: Importaciones Excel (GEN-14) ---

export * from './features/excelImport/types';
export * from './features/excelImport/excelImportApiClient';
export * from './features/excelImport/excelImportPolicy';
export { useExcelImport } from './features/excelImport/useExcelImport';
export { ExcelImportToolbar } from './features/excelImport/ExcelImportToolbar';
export { ExcelImportModal } from './features/excelImport/ExcelImportModal';
export { ExcelImportErrorsGrid } from './features/excelImport/ExcelImportErrorsGrid';
export { downloadBlob } from './features/excelImport/downloadBlob';

// --- Capacidades: Emisiones / reportes (GEN-15) ---

export * from './features/emissions/types';
export * from './features/emissions/emissionApiClient';
export * from './features/emissions/emissionDesignApi';
export * from './features/emissions/emissionPolicy';
export * from './features/emissions/emissionDesignProcessSelection';
export * from './features/emissions/normalizeEmissionReportCode';
export * from './features/emissions/parseDxReportSavedArgs';
export { useEmission } from './features/emissions/useEmission';
export { EmissionDialog } from './features/emissions/EmissionDialog';
export { EmissionReportDesignerPage } from './features/emissions/EmissionReportDesignerPage';
export {
  deliverEmissionJobArtifact,
  emissionJobFileName,
} from './features/emissions/deliverEmissionJobArtifact';
export { printPdfBlob } from './features/emissions/printPdfBlob';
/** @deprecated Preferir EmissionReportDesignerPage (ciclo 2026-08). */
export { ReportDesignerHost, type ReportDesignerContext, type DxReportSavedEvent } from './features/emissions/ReportDesignerHost';

// --- Capacidades: Grupos empresarios (GEN-23) ---

export * from './features/gruposEmpresarios/types';
export * from './features/gruposEmpresarios/gruposEmpresariosApi';
export { GruposEmpresariosPage } from './features/gruposEmpresarios/GruposEmpresariosPage';
export { GruposEmpresariosMembersGrid } from './features/gruposEmpresarios/GruposEmpresariosMembersGrid';
export { GrupoEmpresarioFormPopup } from './features/gruposEmpresarios/GrupoEmpresarioFormPopup';
export { EmissionGrupoEmpresarioSelect } from './features/gruposEmpresarios/EmissionGrupoEmpresarioSelect';

export { NotificationServiceAdminPage } from './features/notificationService/NotificationServiceAdminPage';
export { NotificationServiceMonitorPage } from './features/notificationService/NotificationServiceMonitorPage';
export * from './features/notificationService/notificationServiceApi';

export { ArcaConfigPage } from './features/arca/ArcaConfigPage';
export { ArcaHomologacionPage } from './features/arca/ArcaHomologacionPage';
export * from './features/arca/arcaApiClient';
export * from './features/arca/arcaTypes';
export { arcaI18nEn, arcaI18nEs, translateArca } from './features/arca/arcaI18n';
export { buildArcaFacturaAFixture } from './features/arca/arcaFixtureFacturaA';
export {
  buildArcaCaeaInformeFixture,
  postArcaCaeaInformeFixture,
} from './features/arca/arcaFixtureCaeaInforme';

export * from './features/parametros/types';
export * from './features/parametros/parametrosApi';
export { ParametrosGeneralesPage } from './features/parametros/ParametrosGeneralesPage';
export { ParametroEditPopup } from './features/parametros/ParametroEditPopup';
export {
  formatParametroValorDisplay,
  mapEnvelopeErrorToI18nKey,
  parametroCaptionI18nKey,
  parametroTextValorI18nKey,
  parametroTooltipI18nKey,
  resolveParametroCaption,
  resolveParametroTextValor,
  resolveParametroTooltip,
} from './features/parametros/parametroDisplay';
