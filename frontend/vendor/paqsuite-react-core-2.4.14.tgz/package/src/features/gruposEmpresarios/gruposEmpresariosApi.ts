import { apiRequest, type ApiClientResult, type ApiRequestOptions } from '../../http/apiClient';
import type {
  GrupoEmpresarioDetalle,
  GrupoEmpresarioListResult,
  GrupoEmpresarioOpcion,
  GrupoEmpresarioUpsertBody,
} from './types';

export const gruposEmpresariosBasePath = '/api/v1/grupos-empresarios';

export type GruposEmpresariosRequestOptions = Pick<
  ApiRequestOptions,
  'platform' | 'signal' | 'headers'
>;

export function listGruposEmpresarios(
  options: GruposEmpresariosRequestOptions = {}
): Promise<ApiClientResult<GrupoEmpresarioListResult>> {
  return apiRequest<GrupoEmpresarioListResult>(gruposEmpresariosBasePath, {
    method: 'GET',
    ...options,
  });
}

export function getGrupoEmpresario(
  id: number,
  options: GruposEmpresariosRequestOptions = {}
): Promise<ApiClientResult<{ item: GrupoEmpresarioDetalle }>> {
  return apiRequest<{ item: GrupoEmpresarioDetalle }>(`${gruposEmpresariosBasePath}/${id}`, {
    method: 'GET',
    ...options,
  });
}

export function createGrupoEmpresario(
  body: GrupoEmpresarioUpsertBody,
  options: GruposEmpresariosRequestOptions = {}
): Promise<ApiClientResult<{ item: GrupoEmpresarioDetalle }>> {
  return apiRequest<{ item: GrupoEmpresarioDetalle }>(gruposEmpresariosBasePath, {
    method: 'POST',
    body: JSON.stringify(body),
    ...options,
  });
}

export function updateGrupoEmpresario(
  id: number,
  body: GrupoEmpresarioUpsertBody,
  options: GruposEmpresariosRequestOptions = {}
): Promise<ApiClientResult<{ item: GrupoEmpresarioDetalle }>> {
  return apiRequest<{ item: GrupoEmpresarioDetalle }>(`${gruposEmpresariosBasePath}/${id}`, {
    method: 'PUT',
    body: JSON.stringify(body),
    ...options,
  });
}

export function deleteGrupoEmpresario(
  id: number,
  options: GruposEmpresariosRequestOptions = {}
): Promise<ApiClientResult<Record<string, unknown>>> {
  return apiRequest<Record<string, unknown>>(`${gruposEmpresariosBasePath}/${id}`, {
    method: 'DELETE',
    ...options,
  });
}

export function listGrupoEmpresarioOpciones(
  options: GruposEmpresariosRequestOptions = {}
): Promise<ApiClientResult<{ items: GrupoEmpresarioOpcion[] }>> {
  return apiRequest<{ items: GrupoEmpresarioOpcion[] }>(`${gruposEmpresariosBasePath}/opciones`, {
    method: 'GET',
    ...options,
  });
}
