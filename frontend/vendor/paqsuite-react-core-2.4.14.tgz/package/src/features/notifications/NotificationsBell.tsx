import { useCallback, useEffect, useMemo, useState } from 'react';
import Button from 'devextreme-react/button';
import Popover from 'devextreme-react/popover';
import List from 'devextreme-react/list';
import type { BuildPlatformHeadersInput } from '../../http/headers';
import { markNotificationRead } from './notificationsClient';
import { useNotificationsPolling } from './useNotificationsPolling';
import type { NotificationDto } from './types';

export type NotificationsBellProps = {
  /** Toast del host al detectar nuevos unread (poll). */
  onNewUnread?: (delta: number) => void;
  /** Notifica el badge actual al shell (p. ej. push opt-in mobile). */
  onUnreadCountChange?: (unreadCount: number) => void;
  onOpenLink?: (linkUrl: string) => void;
  t?: (key: string) => string;
  platform?: BuildPlatformHeadersInput;
  accessToken?: string | null;
};

/**
 * Campana de notificaciones con badge y bandeja (Popover + List DX). Polling
 * adaptativo; mark-read al abrir un ítem (GEN-17 notificaciones).
 */
export function NotificationsBell({
  onNewUnread,
  onUnreadCountChange,
  onOpenLink,
  t,
  platform,
  accessToken,
}: NotificationsBellProps) {
  const translate = t ?? ((key: string) => key);
  const { notifications, unreadCount, refresh } = useNotificationsPolling({
    onNewUnread,
    platform,
    accessToken,
  });
  const [open, setOpen] = useState(false);
  const bellId = 'paqsuite-notifications-bell';

  useEffect(() => {
    onUnreadCountChange?.(unreadCount);
  }, [onUnreadCountChange, unreadCount]);

  const requestOptions = useMemo(
    () => ({
      platform,
      headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : undefined,
    }),
    [accessToken, platform],
  );

  const handleItemClick = useCallback(
    async (item: NotificationDto) => {
      if (item.status === 'unread') {
        await markNotificationRead(item.id, requestOptions);
        void refresh();
      }
      if (item.linkUrl && onOpenLink) {
        onOpenLink(item.linkUrl);
      }
    },
    [onOpenLink, refresh, requestOptions],
  );

  return (
    <div data-testid="notifications.bell">
      <Button
        id={bellId}
        icon="bell"
        stylingMode="text"
        text={unreadCount > 0 ? String(unreadCount) : undefined}
        onClick={() => setOpen((value) => !value)}
        elementAttr={{
          'data-testid': 'notifications.bellButton',
          'data-unread-count': String(unreadCount),
        }}
      />
      <Popover
        target={`#${bellId}`}
        visible={open}
        onHiding={() => setOpen(false)}
        width={340}
        title={translate('notifications.title')}
        showTitle
      >
        <List
          dataSource={notifications}
          keyExpr="id"
          noDataText={translate('notifications.empty')}
          onItemClick={(event) => {
            const item = event.itemData as NotificationDto | undefined;
            if (item) {
              void handleItemClick(item);
            }
          }}
          itemRender={(item: NotificationDto) => (
            <div data-status={item.status} data-testid="notifications.item">
              <strong>{item.title}</strong>
              <div>{item.body}</div>
            </div>
          )}
          elementAttr={{ 'data-testid': 'notifications.list' }}
        />
      </Popover>
    </div>
  );
}
