import { apiRequest, type ApiClientResult, type ApiRequestOptions } from '../../http/apiClient';
import type {
  NotificationDeviceToken,
  NotificationDto,
  NotificationListQuery,
  NotificationListResult,
} from './types';

export const notificationsPath = '/api/v1/notifications';

type RequestOverrides = Pick<ApiRequestOptions, 'platform' | 'signal' | 'headers'>;

/** Construye la query del listado de notificaciones. */
export function buildNotificationsQuery(query: NotificationListQuery = {}): string {
  const params = new URLSearchParams();
  if (query.status) {
    params.set('status', query.status);
  }
  if (query.page !== undefined) {
    params.set('page', String(query.page));
  }
  if (query.pageSize !== undefined) {
    params.set('pageSize', String(query.pageSize));
  }
  const value = params.toString();
  return value ? `?${value}` : '';
}

/** `GET /api/v1/notifications`. */
export function listNotifications(
  query: NotificationListQuery = {},
  options: RequestOverrides = {},
): Promise<ApiClientResult<NotificationListResult>> {
  return apiRequest<NotificationListResult>(
    `${notificationsPath}${buildNotificationsQuery(query)}`,
    { method: 'GET', ...options },
  );
}

/** `GET /api/v1/notifications/unread-count`. */
export function getUnreadCount(
  options: RequestOverrides = {},
): Promise<ApiClientResult<{ unreadCount: number }>> {
  return apiRequest<{ unreadCount: number }>(`${notificationsPath}/unread-count`, {
    method: 'GET',
    ...options,
  });
}

/** `PATCH /api/v1/notifications/{id}` → `{ status: 'read' }`. */
export function markNotificationRead(
  id: string,
  options: RequestOverrides = {},
): Promise<ApiClientResult<NotificationDto>> {
  return apiRequest<NotificationDto>(`${notificationsPath}/${id}`, {
    method: 'PATCH',
    body: JSON.stringify({ status: 'read' }),
    ...options,
  });
}

/** `POST /api/v1/notifications/mark-read` con lote de ids. */
export function markNotificationsRead(
  ids: string[],
  options: RequestOverrides = {},
): Promise<ApiClientResult<{ updated: number }>> {
  return apiRequest<{ updated: number }>(`${notificationsPath}/mark-read`, {
    method: 'POST',
    body: JSON.stringify({ ids }),
    ...options,
  });
}

/** `POST /api/v1/notifications/device-tokens` (registro push mobile). */
export function registerDeviceToken(
  token: NotificationDeviceToken,
  options: RequestOverrides = {},
): Promise<ApiClientResult<Record<string, unknown>>> {
  return apiRequest<Record<string, unknown>>(`${notificationsPath}/device-tokens`, {
    method: 'POST',
    body: JSON.stringify(token),
    ...options,
  });
}
