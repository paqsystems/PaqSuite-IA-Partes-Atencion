import { useCallback, useEffect, useMemo, useState } from 'react';
import DataGrid, { Column, Paging, Pager, Toolbar, Item as ToolbarItem } from 'devextreme-react/data-grid';
import Button from 'devextreme-react/button';
import type { BuildPlatformHeadersInput } from '../../http/headers';
import {
  listTaskDefinitions,
  patchTaskDefinition,
  runTaskDefinition,
  simulateTaskDefinition,
  type TaskRequestOverrides,
} from './tasksClient';
import { translateTareasProgramadas } from './tasksI18n';
import type { TaskDefinitionDto } from './types';

export type TaskDefinitionsPageProps = {
  /** Navegación a alta / edición (rutas host `.../nueva`, `.../:id/editar`). */
  onNew?: () => void;
  onEdit?: (id: number) => void;
  /** Mapa processId → supportsSimulation (host lo obtiene del catálogo). */
  supportsSimulationByProcessId?: Record<number, boolean>;
  t?: (key: string) => string;
  platform?: BuildPlatformHeadersInput;
  accessToken?: string | null;
};

/**
 * Listado de definiciones de tareas (GEN-13). Grilla DX; el alta/edición se
 * hace en páginas full-page del host (`onNew` / `onEdit`).
 */
export function TaskDefinitionsPage({
  onNew,
  onEdit,
  supportsSimulationByProcessId,
  t,
  platform,
  accessToken,
}: TaskDefinitionsPageProps) {
  const translate = t ?? translateTareasProgramadas;
  const [rows, setRows] = useState<TaskDefinitionDto[]>([]);
  const [busyId, setBusyId] = useState<number | null>(null);

  const requestOptions = useMemo((): TaskRequestOverrides => {
    return {
      platform,
      headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : undefined,
    };
  }, [accessToken, platform]);

  const load = useCallback(async () => {
    const result = await listTaskDefinitions(requestOptions);
    if (result.kind === 'ok') {
      const payload = result.envelope.resultado as { items?: TaskDefinitionDto[] };
      setRows(payload.items ?? []);
    }
  }, [requestOptions]);

  useEffect(() => {
    void load();
  }, [load]);

  const handleRun = useCallback(
    async (id: number) => {
      await runTaskDefinition(id, {}, requestOptions);
      void load();
    },
    [load, requestOptions]
  );

  const handleSimulate = useCallback(
    async (id: number) => {
      await simulateTaskDefinition(id, {}, requestOptions);
      void load();
    },
    [load, requestOptions]
  );

  const handleToggleActive = useCallback(
    async (row: TaskDefinitionDto) => {
      const nextActive = !row.isActive;
      setBusyId(row.id);
      setRows((current) =>
        current.map((item) => (item.id === row.id ? { ...item, isActive: nextActive } : item))
      );
      const result = await patchTaskDefinition(row.id, { isActive: nextActive }, requestOptions);
      setBusyId(null);
      if (result.kind !== 'ok') {
        setRows((current) =>
          current.map((item) => (item.id === row.id ? { ...item, isActive: row.isActive } : item))
        );
      }
    },
    [requestOptions]
  );

  return (
    <div data-testid="tareasProgramadas.definiciones.root">
      <h2 style={{ marginBottom: 12 }}>{translate('tareasProgramadas.definiciones.title')}</h2>
      <DataGrid
        dataSource={rows}
        keyExpr="id"
        showBorders
        columnAutoWidth
        elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.grid' }}
        onRowDblClick={(event) => {
          const row = event.data as TaskDefinitionDto | undefined;
          if (row) {
            onEdit?.(row.id);
          }
        }}
      >
        <Toolbar>
          {onNew ? (
            <ToolbarItem
              location="after"
              widget="dxButton"
              options={{
                icon: 'plus',
                hint: translate('tareasProgramadas.definiciones.new'),
                onClick: () => onNew(),
                elementAttr: { 'data-testid': 'tareasProgramadas.definiciones.new' },
              }}
            />
          ) : null}
        </Toolbar>
        <Paging defaultPageSize={25} />
        <Pager visible showInfo />
        <Column
          dataField="taskTitle"
          caption={translate('tareasProgramadas.definiciones.taskTitle')}
          cellRender={(cell) => {
            const row = cell.data as TaskDefinitionDto;
            const description = (row.taskDescription ?? '').trim();
            return (
              <span title={description || undefined}>{row.taskTitle}</span>
            );
          }}
        />
        <Column dataField="frequencyType" caption={translate('tareasProgramadas.definiciones.frequency')} />
        <Column
          dataField="baseTime"
          caption={translate('tareasProgramadas.definiciones.executionTime')}
          width={110}
          customizeText={(cell) => {
            const raw = String(cell.value ?? '');
            return raw.length >= 5 ? raw.slice(0, 5) : raw;
          }}
        />
        <Column dataField="nextRunAt" caption={translate('tareasProgramadas.definiciones.nextRun')} dataType="datetime" />
        <Column dataField="lastStatusCode" caption={translate('tareasProgramadas.definiciones.lastStatus')} />
        <Column
          dataField="isActive"
          caption={translate('tareasProgramadas.definiciones.active')}
          width={70}
          alignment="center"
          cellRender={(cell) => {
            const row = cell.data as TaskDefinitionDto;
            return (
              <Button
                icon={row.isActive ? 'check' : 'close'}
                type={row.isActive ? 'success' : 'normal'}
                stylingMode="text"
                disabled={busyId === row.id}
                hint={
                  row.isActive
                    ? translate('tareasProgramadas.definiciones.activeYes')
                    : translate('tareasProgramadas.definiciones.activeNo')
                }
                onClick={() => void handleToggleActive(row)}
                elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.toggleActive' }}
              />
            );
          }}
        />
        <Column
          caption={translate('tareasProgramadas.definiciones.actions')}
          width={140}
          cellRender={(cell) => {
            const row = cell.data as TaskDefinitionDto;
            const canSimulate = supportsSimulationByProcessId?.[row.processId] ?? true;
            return (
              <div style={{ display: 'flex', gap: 4 }}>
                <Button
                  icon="edit"
                  stylingMode="text"
                  hint={translate('tareasProgramadas.definiciones.edit')}
                  onClick={() => onEdit?.(row.id)}
                  elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.edit' }}
                />
                <Button
                  icon="runner"
                  stylingMode="text"
                  hint={translate('tareasProgramadas.definiciones.run')}
                  onClick={() => void handleRun(row.id)}
                  elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.run' }}
                />
                {canSimulate ? (
                  <Button
                    icon="eyeopen"
                    stylingMode="text"
                    hint={translate('tareasProgramadas.definiciones.simulate')}
                    onClick={() => void handleSimulate(row.id)}
                    elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.simulate' }}
                  />
                ) : null}
              </div>
            );
          }}
        />
      </DataGrid>
    </div>
  );
}
