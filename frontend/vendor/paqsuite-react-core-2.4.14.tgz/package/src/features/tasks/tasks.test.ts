import { describe, expect, it } from 'vitest';
import { resolveSemaphoreColor, resolveDefinitionSemaphoreColor } from './semaphoreMap';
import { buildTaskExecutionQuery } from './tasksClient';
import {
  emptyTaskDefinitionFormState,
  isoDaysFromMask,
  maskFromIsoDays,
  toTaskDefinitionCreateBody,
  validateTaskDefinitionForm,
  visibleFrequencyFields,
} from './taskDefinitionFormModel';
import {
  coerceParameterDefault,
  isDefinitionParameter,
  parseTaskParameterMetadata,
} from './taskParameterMetadata';
import { unwrapTaskItem } from './unwrapTaskItem';
import type { TaskProcessParameterDto } from './types';

describe('resolveSemaphoreColor', () => {
  it('mapea statusCode → color (C1-13-15)', () => {
    expect(resolveSemaphoreColor('EXITOSA')).toBe('green');
    expect(resolveSemaphoreColor('EXITOSA_CON_OBSERVACIONES')).toBe('yellow');
    expect(resolveSemaphoreColor('FALLIDA')).toBe('red');
    expect(resolveSemaphoreColor('OMITIDA')).toBe('red');
    expect(resolveSemaphoreColor('EN_EJECUCION')).toBe('blue');
  });

  it('sin historial / desconocido → gray', () => {
    expect(resolveSemaphoreColor(null)).toBe('gray');
    expect(resolveSemaphoreColor(undefined)).toBe('gray');
    expect(resolveSemaphoreColor('OTRO')).toBe('gray');
  });
});

describe('resolveDefinitionSemaphoreColor', () => {
  it('inactiva → black aunque última corrida EXITOSA (D-M6)', () => {
    expect(
      resolveDefinitionSemaphoreColor({ isActive: false, lastStatusCode: 'EXITOSA' })
    ).toBe('black');
  });

  it('activa deriva del lastStatusCode', () => {
    expect(
      resolveDefinitionSemaphoreColor({ isActive: true, lastStatusCode: 'EN_EJECUCION' })
    ).toBe('blue');
    expect(resolveDefinitionSemaphoreColor({ isActive: true, lastStatusCode: null })).toBe('gray');
  });
});

describe('buildTaskExecutionQuery', () => {
  it('vacío sin filtros', () => {
    expect(buildTaskExecutionQuery()).toBe('');
    expect(buildTaskExecutionQuery({})).toBe('');
  });

  it('serializa filtros presentes', () => {
    const query = buildTaskExecutionQuery({ definitionId: 5, status: 'FALLIDA' });
    expect(query).toContain('definitionId=5');
    expect(query).toContain('status=FALLIDA');
    expect(query.startsWith('?')).toBe(true);
  });
});

describe('unwrapTaskItem', () => {
  it('acepta { item } y DTO plano', () => {
    expect(unwrapTaskItem({ item: { id: 3 } })).toEqual({ id: 3 });
    expect(unwrapTaskItem({ id: 3 })).toEqual({ id: 3 });
    expect(unwrapTaskItem({ item: undefined })).toBeNull();
  });
});

describe('taskParameterMetadata', () => {
  it('parsea metadataJson string', () => {
    const metadata = parseTaskParameterMetadata(
      '{"appliesToModes":["automatic"],"valueSource":"runtime","autoResolution":"omit"}'
    );
    expect(metadata.appliesToModes).toEqual(['automatic']);
    expect(metadata.valueSource).toBe('runtime');
    expect(metadata.autoResolution).toBe('omit');
  });

  it('excluye runtime / no editable / omit de la definición', () => {
    const base: TaskProcessParameterDto = {
      id: 1,
      parameterCode: 'selectedIds',
      parameterName: 'IDs',
      dataType: 'STRING',
      isRequired: true,
      displayOrder: 1,
      isUserEditable: true,
      isMultivalue: true,
      metadataJson: {
        appliesToModes: ['manual'],
        valueSource: 'runtime',
        autoResolution: 'omit',
      },
    };
    expect(isDefinitionParameter(base)).toBe(false);
    expect(
      isDefinitionParameter({
        ...base,
        parameterCode: 'dias',
        isUserEditable: true,
        metadataJson: {
          appliesToModes: ['automatic', 'manual'],
          valueSource: 'definition',
          autoResolution: 'useDefinitionValue',
        },
      })
    ).toBe(true);
  });

  it('coerce BOOL / INT', () => {
    expect(coerceParameterDefault('BOOL', '1')).toBe(true);
    expect(coerceParameterDefault('INT', '7')).toBe(7);
    expect(coerceParameterDefault('BOOL', null)).toBe(false);
  });
});

describe('taskDefinitionFormModel', () => {
  it('WEEKLY muestra días; CUSTOM no intervalo', () => {
    expect(visibleFrequencyFields('WEEKLY')).toEqual({ interval: true, daysMask: true });
    expect(visibleFrequencyFields('CUSTOM')).toEqual({ interval: false, daysMask: false });
    expect(visibleFrequencyFields('MONTHLY')).toEqual({ interval: true, daysMask: false });
  });

  it('máscara ISO 1–7', () => {
    expect(isoDaysFromMask('1,3,5')).toEqual([1, 3, 5]);
    expect(maskFromIsoDays([5, 1, 1, 3])).toBe('1,3,5');
  });

  it('valida título, proceso, empresas y agenda semanal', () => {
    const state = emptyTaskDefinitionFormState([1]);
    expect(validateTaskDefinitionForm(state, 'single')).toBe(
      'tareasProgramadas.definiciones.validation.processRequired'
    );
    state.processId = 10;
    expect(validateTaskDefinitionForm(state, 'single')).toBe(
      'tareasProgramadas.definiciones.validation.titleRequired'
    );
    state.taskTitle = 'Backup nocturno';
    state.frequencyType = 'WEEKLY';
    expect(validateTaskDefinitionForm(state, 'single')).toBe(
      'tareasProgramadas.definiciones.validation.daysRequired'
    );
    state.frequencyDays = [1, 3];
    expect(validateTaskDefinitionForm(state, 'single')).toBeNull();
  });

  it('arma body DAILY con parámetros y mails', () => {
    const state = emptyTaskDefinitionFormState([1]);
    state.processId = 4;
    state.taskTitle = 'Tarea';
    state.notifyEnabled = true;
    state.notifyEmailsText = 'ops@paq.test, admin@paq.test';
    state.parameterValues = { dias: 7 };
    const body = toTaskDefinitionCreateBody(state);
    expect(body.frequencyType).toBe('DAILY');
    expect(body.frequencyInterval).toBe(1);
    expect(body.companyIds).toEqual([1]);
    expect(body.notifyEmails).toEqual(['ops@paq.test', 'admin@paq.test']);
    expect(body.parameters).toEqual([{ parameterCode: 'dias', value: 7 }]);
  });
});
