/**
 * @vitest-environment jsdom
 */
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { TaskProcessDto } from './types';

const {
  createTaskDefinition,
  listTaskProcesses,
  listTaskProcessParameters,
} = vi.hoisted(() => ({
  createTaskDefinition: vi.fn(),
  listTaskProcesses: vi.fn(),
  listTaskProcessParameters: vi.fn(),
}));

vi.mock('./tasksClient', () => ({
  createTaskDefinition,
  getTaskDefinition: vi.fn(),
  listTaskProcessParameters,
  listTaskProcesses,
  patchTaskDefinition: vi.fn(),
}));

vi.mock('devextreme-react/load-panel', () => ({
  default: () => null,
}));

vi.mock('devextreme-react/select-box', () => ({
  default: (props: {
    value?: unknown;
    dataSource?: unknown[];
    valueExpr?: string;
    elementAttr?: Record<string, string>;
    onValueChanged?: (event: { value: unknown }) => void;
    disabled?: boolean;
  }) => (
    <select
      data-testid={props.elementAttr?.['data-testid']}
      disabled={props.disabled}
      value={props.value === null || props.value === undefined ? '' : String(props.value)}
      onChange={(event) => {
        const raw = event.target.value;
        const numeric = Number(raw);
        props.onValueChanged?.({ value: Number.isNaN(numeric) ? raw : numeric });
      }}
    >
      <option value="">—</option>
      {(props.dataSource ?? []).map((item, index) => {
        const record = item as Record<string, unknown>;
        const optionValue = props.valueExpr ? record[props.valueExpr] : record.value;
        return (
          <option key={String(optionValue ?? index)} value={String(optionValue ?? '')}>
            {String(optionValue ?? index)}
          </option>
        );
      })}
    </select>
  ),
}));

vi.mock('devextreme-react/text-box', () => ({
  default: (props: {
    value?: string;
    elementAttr?: Record<string, string>;
    onValueChanged?: (event: { value: string }) => void;
  }) => (
    <input
      data-testid={props.elementAttr?.['data-testid']}
      value={props.value ?? ''}
      onChange={(event) => props.onValueChanged?.({ value: event.target.value })}
    />
  ),
}));

vi.mock('devextreme-react/text-area', () => ({
  default: () => null,
}));

vi.mock('devextreme-react/number-box', () => ({
  default: (props: { elementAttr?: Record<string, string>; value?: number }) => (
    <input data-testid={props.elementAttr?.['data-testid']} value={props.value ?? ''} readOnly />
  ),
}));

vi.mock('devextreme-react/date-box', () => ({
  default: (props: { elementAttr?: Record<string, string> }) => (
    <input data-testid={props.elementAttr?.['data-testid']} readOnly />
  ),
}));

vi.mock('devextreme-react/switch', () => ({
  default: (props: { elementAttr?: Record<string, string>; value?: boolean }) => (
    <input type="checkbox" data-testid={props.elementAttr?.['data-testid']} checked={Boolean(props.value)} readOnly />
  ),
}));

vi.mock('devextreme-react/check-box', () => ({
  default: (props: {
    text?: string;
    value?: boolean;
    elementAttr?: Record<string, string>;
    onValueChanged?: (event: { value: boolean }) => void;
  }) => (
    <label>
      <input
        type="checkbox"
        data-testid={props.elementAttr?.['data-testid']}
        checked={Boolean(props.value)}
        onChange={(event) => props.onValueChanged?.({ value: event.target.checked })}
      />
      {props.text}
    </label>
  ),
}));

vi.mock('devextreme-react/tag-box', () => ({
  default: (props: { elementAttr?: Record<string, string> }) => (
    <div data-testid={props.elementAttr?.['data-testid']} />
  ),
}));

vi.mock('devextreme-react/button', () => ({
  default: (props: {
    text?: string;
    onClick?: () => void;
    elementAttr?: Record<string, string>;
    disabled?: boolean;
  }) => (
    <button
      type="button"
      data-testid={props.elementAttr?.['data-testid']}
      disabled={props.disabled}
      onClick={props.onClick}
    >
      {props.text}
    </button>
  ),
}));

import { TaskDefinitionFormPage } from './TaskDefinitionFormPage';

const smokeProcess: TaskProcessDto = {
  id: 10,
  processCode: 'SMOKE_ECHO',
  processName: 'Eco',
  moduleCode: 'GEN',
  isActive: true,
  supportsManualExecution: true,
  supportsScheduledExecution: true,
  supportsSimulation: true,
  worksByCompany: true,
  selectionStrategyAuto: 'ALL_PENDING',
  selectionStrategyManual: 'NOT_APPLICABLE',
};

describe('TaskDefinitionFormPage', () => {
  afterEach(() => {
    cleanup();
  });

  beforeEach(() => {
    listTaskProcesses.mockResolvedValue({
      kind: 'ok',
      httpStatus: 200,
      envelope: { error: 0, respuesta: 'ok', resultado: { items: [smokeProcess] } },
    });
    listTaskProcessParameters.mockResolvedValue({
      kind: 'ok',
      httpStatus: 200,
      envelope: { error: 0, respuesta: 'ok', resultado: { items: [] } },
    });
    createTaskDefinition.mockResolvedValue({
      kind: 'ok',
      httpStatus: 201,
      envelope: { error: 0, respuesta: 'ok', resultado: { item: { id: 99 } } },
    });
  });

  it('alta: valida título y no llama API', async () => {
    const onSaved = vi.fn();
    render(
      <TaskDefinitionFormPage
        mode="create"
        tenancyMode="single"
        empresas={[{ id: 1, nombreEmpresa: 'Demo' }]}
        onCancel={() => undefined}
        onSaved={onSaved}
      />
    );

    await waitFor(() => expect(listTaskProcesses).toHaveBeenCalled());
    fireEvent.click(screen.getByTestId('tareasProgramadas.definiciones.save'));
    expect(await screen.findByTestId('tareasProgramadas.definiciones.error')).toBeTruthy();
    expect(createTaskDefinition).not.toHaveBeenCalled();
    expect(onSaved).not.toHaveBeenCalled();
  });

  it('alta: guarda DAILY con empresa MONO', async () => {
    const onSaved = vi.fn();
    render(
      <TaskDefinitionFormPage
        mode="create"
        tenancyMode="single"
        empresas={[{ id: 1, nombreEmpresa: 'Demo' }]}
        onCancel={() => undefined}
        onSaved={onSaved}
      />
    );

    await waitFor(() => expect(listTaskProcesses).toHaveBeenCalled());
    fireEvent.change(screen.getByTestId('tareasProgramadas.definiciones.process'), {
      target: { value: '10' },
    });
    fireEvent.change(screen.getByTestId('tareasProgramadas.definiciones.taskTitle'), {
      target: { value: 'Backup nocturno' },
    });
    fireEvent.click(screen.getByTestId('tareasProgramadas.definiciones.save'));

    await waitFor(() => expect(createTaskDefinition).toHaveBeenCalled());
    const body = createTaskDefinition.mock.calls[0][0] as { processId: number; companyIds: number[]; taskTitle: string };
    expect(body.processId).toBe(10);
    expect(body.companyIds).toEqual([1]);
    expect(body.taskTitle).toBe('Backup nocturno');
    expect(onSaved).toHaveBeenCalledWith(99);
  });

  it('MULTI muestra selector de empresas; MONO no', () => {
    const { rerender } = render(
      <TaskDefinitionFormPage
        mode="create"
        tenancyMode="multi"
        empresas={[
          { id: 1, nombreEmpresa: 'A' },
          { id: 2, nombreEmpresa: 'B' },
        ]}
        onCancel={() => undefined}
        onSaved={() => undefined}
      />
    );
    expect(screen.getByTestId('tareasProgramadas.definiciones.companies')).toBeTruthy();

    rerender(
      <TaskDefinitionFormPage
        mode="create"
        tenancyMode="single"
        empresas={[{ id: 1, nombreEmpresa: 'A' }]}
        onCancel={() => undefined}
        onSaved={() => undefined}
      />
    );
    expect(screen.queryByTestId('tareasProgramadas.definiciones.companies')).toBeNull();
  });
});
