/**
 * @vitest-environment jsdom
 */
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const {
  listTaskDefinitions,
  listTaskProcesses,
  listTaskExecutions,
  getTaskExecutionLogs,
  runTaskDefinition,
  simulateTaskDefinition,
} = vi.hoisted(() => ({
  listTaskDefinitions: vi.fn(),
  listTaskProcesses: vi.fn(),
  listTaskExecutions: vi.fn(),
  getTaskExecutionLogs: vi.fn(),
  runTaskDefinition: vi.fn(),
  simulateTaskDefinition: vi.fn(),
}));

vi.mock('./tasksClient', () => ({
  listTaskDefinitions,
  listTaskProcesses,
  listTaskExecutions,
  getTaskExecutionLogs,
  runTaskDefinition,
  simulateTaskDefinition,
}));

vi.mock('devextreme-react/button', () => ({
  default: (props: {
    text?: string;
    hint?: string;
    disabled?: boolean;
    icon?: string;
    onClick?: () => void;
    elementAttr?: Record<string, string>;
  }) => (
    <button
      type="button"
      data-testid={props.elementAttr?.['data-testid']}
      data-icon={props.icon}
      title={props.hint}
      disabled={props.disabled}
      onClick={props.onClick}
    >
      {props.text ?? props.icon ?? 'btn'}
    </button>
  ),
}));

import { TaskAutomationsMonitorPage } from './TaskAutomationsMonitorPage';

function okEnvelope<T>(resultado: T) {
  return {
    kind: 'ok' as const,
    envelope: { error: 0, respuesta: 'OK', resultado },
  };
}

describe('TaskAutomationsMonitorPage', () => {
  afterEach(() => {
    cleanup();
  });

  beforeEach(() => {
    vi.clearAllMocks();
    listTaskProcesses.mockResolvedValue(
      okEnvelope({
        items: [
          {
            id: 1,
            processCode: 'ECO',
            processName: 'Eco',
            moduleCode: null,
            isActive: true,
            supportsManualExecution: true,
            supportsScheduledExecution: true,
            supportsSimulation: true,
            worksByCompany: false,
            selectionStrategyAuto: null,
            selectionStrategyManual: null,
          },
        ],
      })
    );
    getTaskExecutionLogs.mockResolvedValue(okEnvelope({ items: [] }));
  });

  it('deshabilita Historial sin ejecuciones previas', async () => {
    listTaskDefinitions.mockResolvedValue(
      okEnvelope({
        items: [
          {
            id: 10,
            processId: 1,
            taskTitle: 'Sin corridas',
            taskDescription: '',
            isActive: true,
            frequencyType: 'DAILY',
            baseDate: '2026-09-01',
            baseTime: '03:00',
            companyIds: [1],
            notifyEnabled: false,
            notifyOnError: true,
            notifyOnSuccess: false,
            notifyEmails: [],
            lastRunAt: null,
            lastStatusCode: null,
          },
        ],
      })
    );

    render(<TaskAutomationsMonitorPage />);

    await waitFor(() => {
      expect(
        (screen.getByTestId('tareasProgramadas.monitoreo.historial') as HTMLButtonElement).disabled
      ).toBe(true);
    });
  });

  it('abre historial in-place y permite Volver', async () => {
    listTaskDefinitions.mockResolvedValue(
      okEnvelope({
        items: [
          {
            id: 11,
            processId: 1,
            taskTitle: 'Con historial',
            taskDescription: 'desc',
            isActive: true,
            frequencyType: 'DAILY',
            baseDate: '2026-09-01',
            baseTime: '15:00',
            companyIds: [1],
            notifyEnabled: false,
            notifyOnError: true,
            notifyOnSuccess: false,
            notifyEmails: [],
            lastRunAt: '2026-09-08T15:00:00Z',
            lastStatusCode: 'EXITOSA',
          },
        ],
      })
    );
    listTaskExecutions.mockResolvedValue(
      okEnvelope({
        items: [
          {
            id: 100,
            definitionId: 11,
            companyId: 1,
            statusCode: 'EXITOSA',
            mode: 'MANUAL',
            isSimulation: false,
            message: 'ok',
            startedAt: '2026-09-08T15:00:00Z',
            finishedAt: '2026-09-08T15:01:00Z',
          },
        ],
      })
    );

    render(<TaskAutomationsMonitorPage />);

    await waitFor(() => {
      expect(
        (screen.getByTestId('tareasProgramadas.monitoreo.historial') as HTMLButtonElement).disabled
      ).toBe(false);
    });

    fireEvent.click(screen.getByTestId('tareasProgramadas.monitoreo.historial'));

    await waitFor(() => {
      expect(screen.getByTestId('tareasProgramadas.monitoreo.historialRoot')).toBeTruthy();
    });

    fireEvent.click(screen.getByTestId('tareasProgramadas.monitoreo.back'));

    await waitFor(() => {
      expect(screen.getByTestId('tareasProgramadas.monitoreo.root')).toBeTruthy();
    });
  });

  it('muestra semáforo negro si la definición está inactiva', async () => {
    listTaskDefinitions.mockResolvedValue(
      okEnvelope({
        items: [
          {
            id: 12,
            processId: 1,
            taskTitle: 'Inactiva',
            isActive: false,
            frequencyType: 'DAILY',
            baseDate: '2026-09-01',
            baseTime: '03:00',
            companyIds: [1],
            notifyEnabled: false,
            notifyOnError: true,
            notifyOnSuccess: false,
            notifyEmails: [],
            lastStatusCode: 'EXITOSA',
          },
        ],
      })
    );

    render(<TaskAutomationsMonitorPage />);

    await waitFor(() => {
      expect(screen.getByTestId('tareasProgramadas.monitoreo.semaphore').getAttribute('data-semaphore')).toBe(
        'black'
      );
    });
  });
});
