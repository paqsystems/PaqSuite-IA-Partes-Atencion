import type { TaskProcessParameterDto } from './types';

export type TaskParameterMode = 'manual' | 'automatic' | 'simulation';

export type TaskParameterMetadata = {
  appliesToModes: TaskParameterMode[];
  valueSource: string;
  autoResolution: string | null;
};

const allModes: TaskParameterMode[] = ['manual', 'automatic', 'simulation'];

function asMode(value: unknown): TaskParameterMode | null {
  if (value === 'manual' || value === 'automatic' || value === 'simulation') {
    return value;
  }
  return null;
}

/** Parsea `metadataJson` del catálogo (string JSON u objeto). */
export function parseTaskParameterMetadata(raw: unknown): TaskParameterMetadata {
  let parsed: unknown = raw;
  if (typeof raw === 'string' && raw.trim() !== '') {
    try {
      parsed = JSON.parse(raw) as unknown;
    } catch {
      parsed = {};
    }
  }

  const record =
    parsed !== null && typeof parsed === 'object' ? (parsed as Record<string, unknown>) : {};
  const rawModes = Array.isArray(record.appliesToModes) ? record.appliesToModes : allModes;
  const appliesToModes = rawModes
    .map(asMode)
    .filter((mode): mode is TaskParameterMode => mode !== null);

  return {
    appliesToModes: appliesToModes.length > 0 ? appliesToModes : allModes,
    valueSource: typeof record.valueSource === 'string' ? record.valueSource : 'definition',
    autoResolution: typeof record.autoResolution === 'string' ? record.autoResolution : null,
  };
}

/**
 * Parámetros que se configuran en la definición (agenda), no picking runtime.
 */
export function isDefinitionParameter(parameter: TaskProcessParameterDto): boolean {
  if (!parameter.isUserEditable) {
    return false;
  }
  const metadata = parseTaskParameterMetadata(parameter.metadataJson);
  if (!metadata.appliesToModes.includes('automatic')) {
    return false;
  }
  if (metadata.valueSource === 'runtime') {
    return false;
  }
  if (metadata.autoResolution === 'omit') {
    return false;
  }
  return true;
}

/** Convierte el default de catálogo al tipo de control. */
export function coerceParameterDefault(dataType: string, raw: unknown): unknown {
  if (raw === null || raw === undefined || raw === '') {
    if (dataType === 'BOOL') {
      return false;
    }
    return dataType === 'INT' || dataType === 'DECIMAL' ? null : '';
  }
  if (dataType === 'BOOL') {
    return raw === true || raw === 'true' || raw === '1' || raw === 1;
  }
  if (dataType === 'INT' || dataType === 'DECIMAL') {
    const numeric = Number(raw);
    return Number.isNaN(numeric) ? null : numeric;
  }
  return raw;
}

export function parseAllowedValues(source: string | null | undefined): string[] {
  if (!source || source.trim() === '') {
    return [];
  }
  try {
    const parsed = JSON.parse(source) as unknown;
    if (Array.isArray(parsed)) {
      return parsed.map((item) => String(item));
    }
  } catch {
    return source
      .split(',')
      .map((item) => item.trim())
      .filter((item) => item !== '');
  }
  return [];
}
