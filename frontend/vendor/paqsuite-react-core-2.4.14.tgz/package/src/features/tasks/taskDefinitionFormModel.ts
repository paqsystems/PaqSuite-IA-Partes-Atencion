import type { TaskDefinitionCreateBody, TaskFrequencyType } from './types';

export const isoWeekdayCodes = [1, 2, 3, 4, 5, 6, 7] as const;

export type TaskDefinitionFormState = {
  processId: number | null;
  taskTitle: string;
  taskDescription: string;
  isActive: boolean;
  frequencyType: TaskFrequencyType;
  frequencyInterval: number | null;
  frequencyDays: number[];
  baseDate: string;
  baseTime: string;
  companyIds: number[];
  notifyEnabled: boolean;
  notifyOnError: boolean;
  notifyOnSuccess: boolean;
  notifyEmailsText: string;
  parameterValues: Record<string, unknown>;
};

export type TaskFrequencyFieldVisibility = {
  interval: boolean;
  daysMask: boolean;
};

export function formatYmd(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function defaultScheduleAnchor(now = new Date()): { baseDate: string; baseTime: string } {
  return { baseDate: formatYmd(now), baseTime: '03:00' };
}

export function emptyTaskDefinitionFormState(
  companyIds: number[] = [],
  now = new Date()
): TaskDefinitionFormState {
  const anchor = defaultScheduleAnchor(now);
  return {
    processId: null,
    taskTitle: '',
    taskDescription: '',
    isActive: true,
    frequencyType: 'DAILY',
    frequencyInterval: 1,
    frequencyDays: [],
    baseDate: anchor.baseDate,
    baseTime: anchor.baseTime,
    companyIds,
    notifyEnabled: false,
    notifyOnError: true,
    notifyOnSuccess: false,
    notifyEmailsText: '',
    parameterValues: {},
  };
}

export function visibleFrequencyFields(
  frequencyType: TaskFrequencyType
): TaskFrequencyFieldVisibility {
  switch (frequencyType) {
    case 'HOURLY_INTERVAL':
    case 'DAILY':
      return { interval: true, daysMask: false };
    case 'WEEKLY':
      return { interval: true, daysMask: true };
    case 'MONTHLY':
      return { interval: true, daysMask: false };
    case 'CUSTOM':
      return { interval: false, daysMask: false };
    default:
      return { interval: false, daysMask: false };
  }
}

export function isoDaysFromMask(mask: string | null | undefined): number[] {
  if (!mask) {
    return [];
  }
  return mask
    .split(',')
    .map((token) => Number(token.trim()))
    .filter((day) => day >= 1 && day <= 7);
}

export function maskFromIsoDays(days: number[]): string {
  return [...new Set(days.filter((day) => day >= 1 && day <= 7))].sort((a, b) => a - b).join(',');
}

export function parseNotifyEmails(text: string): string[] {
  return text
    .split(/[,;\s]+/)
    .map((item) => item.trim())
    .filter((item) => item !== '');
}

export function validateTaskDefinitionForm(
  state: TaskDefinitionFormState,
  tenancyMode: 'single' | 'multi'
): string | null {
  if (state.processId === null || state.processId <= 0) {
    return 'tareasProgramadas.definiciones.validation.processRequired';
  }
  if (state.taskTitle.trim() === '') {
    return 'tareasProgramadas.definiciones.validation.titleRequired';
  }
  if (state.baseDate.trim() === '' || state.baseTime.trim() === '') {
    return 'tareasProgramadas.definiciones.validation.scheduleRequired';
  }
  if (state.companyIds.length < 1) {
    return 'tareasProgramadas.definiciones.validation.companyRequired';
  }
  if (tenancyMode === 'single' && state.companyIds.length !== 1) {
    return 'tareasProgramadas.definiciones.validation.monoCompany';
  }

  const fields = visibleFrequencyFields(state.frequencyType);
  if (state.frequencyType === 'HOURLY_INTERVAL' || state.frequencyType === 'DAILY') {
    if (state.frequencyInterval === null || state.frequencyInterval < 1) {
      return 'tareasProgramadas.definiciones.validation.intervalRequired';
    }
  }
  if (state.frequencyType === 'MONTHLY') {
    if (
      state.frequencyInterval === null ||
      state.frequencyInterval < 1 ||
      state.frequencyInterval > 31
    ) {
      return 'tareasProgramadas.definiciones.validation.monthDay';
    }
  }
  if (fields.daysMask && state.frequencyDays.length < 1) {
    return 'tareasProgramadas.definiciones.validation.daysRequired';
  }
  if (state.notifyEnabled && parseNotifyEmails(state.notifyEmailsText).length < 1) {
    return 'tareasProgramadas.definiciones.validation.emailsRequired';
  }
  return null;
}

export function toTaskDefinitionCreateBody(state: TaskDefinitionFormState): TaskDefinitionCreateBody {
  const fields = visibleFrequencyFields(state.frequencyType);
  const parameters = Object.entries(state.parameterValues).map(([parameterCode, value]) => ({
    parameterCode,
    value,
  }));

  const body: TaskDefinitionCreateBody = {
    processId: state.processId as number,
    taskTitle: state.taskTitle.trim(),
    taskDescription: state.taskDescription.trim() || undefined,
    isActive: state.isActive,
    frequencyType: state.frequencyType,
    baseDate: state.baseDate,
    baseTime: state.baseTime,
    companyIds: state.companyIds,
    notifyEnabled: state.notifyEnabled,
    notifyOnError: state.notifyEnabled ? state.notifyOnError : undefined,
    notifyOnSuccess: state.notifyEnabled ? state.notifyOnSuccess : undefined,
    notifyEmails: state.notifyEnabled ? parseNotifyEmails(state.notifyEmailsText) : [],
    parameters,
  };

  if (fields.interval && state.frequencyInterval !== null) {
    body.frequencyInterval = state.frequencyInterval;
  }
  if (fields.daysMask) {
    body.frequencyDaysMask = maskFromIsoDays(state.frequencyDays);
  }

  return body;
}
