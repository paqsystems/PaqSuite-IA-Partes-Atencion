import { useCallback, useEffect, useMemo, useState } from 'react';
import DataGrid, { Column, Paging, Pager } from 'devextreme-react/data-grid';
import Button from 'devextreme-react/button';
import DateBox from 'devextreme-react/date-box';
import NumberBox from 'devextreme-react/number-box';
import Popup from 'devextreme-react/popup';
import type { BuildPlatformHeadersInput } from '../../http/headers';
import {
  getTaskExecution,
  listTaskExecutions,
  purgeTaskExecutions,
  type TaskRequestOverrides,
} from './tasksClient';
import { resolveSemaphoreColor } from './semaphoreMap';
import { translateTareasProgramadas } from './tasksI18n';
import type { TaskExecutionDto, TaskExecutionFilters } from './types';

/** Default GEN / config `taskExecutionRetentionDays` (TR-GEN-13). */
export const defaultTaskExecutionRetentionDays = 90;

export type TaskExecutionsPageProps = {
  filters?: TaskExecutionFilters;
  /** Muestra el botón Purgar (permiso admin del host). */
  canPurge?: boolean;
  /** Días de retención por defecto (host puede leer config). */
  retentionDaysDefault?: number;
  t?: (key: string) => string;
  platform?: BuildPlatformHeadersInput;
  accessToken?: string | null;
};

function startOfDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function daysBetween(from: Date, to: Date): number {
  const ms = startOfDay(to).getTime() - startOfDay(from).getTime();
  return Math.max(1, Math.round(ms / 86_400_000));
}

function dateDaysAgo(days: number, now = new Date()): Date {
  const date = startOfDay(now);
  date.setDate(date.getDate() - days);
  return date;
}

/**
 * Monitor de ejecuciones (GEN-13): grilla DX + semáforo derivado en FE +
 * refresh + detalle en Popup + purga admin con días/fecha.
 */
export function TaskExecutionsPage({
  filters,
  canPurge,
  retentionDaysDefault = defaultTaskExecutionRetentionDays,
  t,
  platform,
  accessToken,
}: TaskExecutionsPageProps) {
  const translate = t ?? translateTareasProgramadas;
  const [rows, setRows] = useState<TaskExecutionDto[]>([]);
  const [detail, setDetail] = useState<TaskExecutionDto | null>(null);
  const [purgeOpen, setPurgeOpen] = useState(false);
  const [olderThanDays, setOlderThanDays] = useState(retentionDaysDefault);
  const [purgeBeforeDate, setPurgeBeforeDate] = useState(() => dateDaysAgo(retentionDaysDefault));
  const [purging, setPurging] = useState(false);
  const [purgeFeedback, setPurgeFeedback] = useState<string | null>(null);

  const requestOptions = useMemo((): TaskRequestOverrides => {
    return {
      platform,
      headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : undefined,
    };
  }, [accessToken, platform]);

  const load = useCallback(async () => {
    const result = await listTaskExecutions(filters, requestOptions);
    if (result.kind === 'ok') {
      setRows(result.envelope.resultado.items ?? []);
    }
  }, [filters, requestOptions]);

  useEffect(() => {
    void load();
  }, [load]);

  const openDetail = useCallback(
    async (id: number) => {
      const result = await getTaskExecution(id, requestOptions);
      if (result.kind === 'ok') {
        const payload = result.envelope.resultado as { item?: TaskExecutionDto } | TaskExecutionDto;
        const item =
          payload && typeof payload === 'object' && 'item' in payload
            ? payload.item ?? null
            : (payload as TaskExecutionDto);
        setDetail(item);
      }
    },
    [requestOptions]
  );

  const openPurge = useCallback(() => {
    setOlderThanDays(retentionDaysDefault);
    setPurgeBeforeDate(dateDaysAgo(retentionDaysDefault));
    setPurgeFeedback(null);
    setPurgeOpen(true);
  }, [retentionDaysDefault]);

  const handleDaysChange = useCallback((days: number) => {
    const safeDays = Number.isFinite(days) && days >= 1 ? Math.floor(days) : 1;
    setOlderThanDays(safeDays);
    setPurgeBeforeDate(dateDaysAgo(safeDays));
  }, []);

  const handleDateChange = useCallback((value: Date | null) => {
    if (!value) {
      return;
    }
    const today = startOfDay(new Date());
    const selected = startOfDay(value);
    if (selected.getTime() >= today.getTime()) {
      setPurgeFeedback(translate('tareasProgramadas.ejecuciones.purgeDateMustBePast'));
      return;
    }
    setPurgeFeedback(null);
    setPurgeBeforeDate(selected);
    setOlderThanDays(daysBetween(selected, today));
  }, [translate]);

  const handlePurge = useCallback(async () => {
    if (olderThanDays < 1) {
      setPurgeFeedback(translate('tareasProgramadas.ejecuciones.purgeDaysInvalid'));
      return;
    }
    setPurging(true);
    setPurgeFeedback(null);
    const result = await purgeTaskExecutions(olderThanDays, requestOptions);
    setPurging(false);
    if (result.kind !== 'ok') {
      setPurgeFeedback(translate('tareasProgramadas.ejecuciones.purgeError'));
      return;
    }
    const deleted = result.envelope.resultado.deletedCount ?? 0;
    setPurgeOpen(false);
    void load();
    setPurgeFeedback(
      translate('tareasProgramadas.ejecuciones.purgeDone').replace('{count}', String(deleted))
    );
  }, [load, olderThanDays, requestOptions, translate]);

  const maxPurgeDate = useMemo(() => {
    const yesterday = startOfDay(new Date());
    yesterday.setDate(yesterday.getDate() - 1);
    return yesterday;
  }, []);

  return (
    <div data-testid="tareasProgramadas.ejecuciones.root">
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 12 }}>
        <h2>{translate('tareasProgramadas.ejecuciones.title')}</h2>
        <Button
          text={translate('tareasProgramadas.ejecuciones.refresh')}
          icon="refresh"
          onClick={() => void load()}
          elementAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.refresh' }}
        />
        {canPurge ? (
          <Button
            text={translate('tareasProgramadas.ejecuciones.purge')}
            onClick={openPurge}
            elementAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.purge' }}
          />
        ) : null}
      </div>

      {purgeFeedback && !purgeOpen ? (
        <p role="status" data-testid="tareasProgramadas.ejecuciones.purgeFeedback">
          {purgeFeedback}
        </p>
      ) : null}

      <DataGrid
        dataSource={rows}
        keyExpr="id"
        showBorders
        columnAutoWidth
        elementAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.grid' }}
        onRowClick={(event) => {
          const row = event.data as TaskExecutionDto | undefined;
          if (row) {
            void openDetail(row.id);
          }
        }}
      >
        <Paging defaultPageSize={25} />
        <Pager visible showInfo />
        <Column
          caption={translate('tareasProgramadas.ejecuciones.semaphore')}
          width={90}
          cellRender={(cell) => {
            const row = cell.data as TaskExecutionDto;
            const color = resolveSemaphoreColor(row.statusCode);
            return (
              <span
                data-semaphore={color}
                style={{
                  display: 'inline-block',
                  width: 12,
                  height: 12,
                  borderRadius: '50%',
                  background: color,
                }}
              />
            );
          }}
        />
        <Column dataField="definitionId" caption={translate('tareasProgramadas.ejecuciones.definition')} />
        <Column dataField="statusCode" caption={translate('tareasProgramadas.ejecuciones.status')} />
        <Column dataField="mode" caption={translate('tareasProgramadas.ejecuciones.mode')} />
        <Column dataField="isSimulation" caption={translate('tareasProgramadas.ejecuciones.simulation')} dataType="boolean" />
        <Column dataField="startedAt" caption={translate('tareasProgramadas.ejecuciones.startedAt')} dataType="datetime" />
        <Column dataField="finishedAt" caption={translate('tareasProgramadas.ejecuciones.finishedAt')} dataType="datetime" />
      </DataGrid>

      <Popup
        visible={detail !== null}
        onHiding={() => setDetail(null)}
        showTitle
        title={translate('tareasProgramadas.ejecuciones.detail')}
        width={520}
        height="auto"
        wrapperAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.detail' }}
      >
        {detail ? (
          <div>
            <p>{`#${detail.id} — ${detail.statusCode}`}</p>
            <p>{`${detail.startedAt ?? '—'} → ${detail.finishedAt ?? '—'}`}</p>
          </div>
        ) : null}
      </Popup>

      <Popup
        visible={purgeOpen}
        onHiding={() => setPurgeOpen(false)}
        showTitle
        title={translate('tareasProgramadas.ejecuciones.purgeTitle')}
        width={440}
        height="auto"
        wrapperAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.purgeDialog' }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <p>{translate('tareasProgramadas.ejecuciones.purgeHelp')}</p>
          <NumberBox
            label={translate('tareasProgramadas.ejecuciones.purgeOlderThanDays')}
            labelMode="floating"
            value={olderThanDays}
            min={1}
            showSpinButtons
            onValueChanged={(event) => handleDaysChange(Number(event.value ?? 1))}
            elementAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.purgeDays' }}
          />
          <DateBox
            label={translate('tareasProgramadas.ejecuciones.purgeBeforeDate')}
            labelMode="floating"
            type="date"
            displayFormat="dd/MM/yyyy"
            useMaskBehavior
            value={purgeBeforeDate}
            max={maxPurgeDate}
            onValueChanged={(event) => handleDateChange((event.value as Date | null) ?? null)}
            elementAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.purgeDate' }}
          />
          {purgeFeedback ? (
            <div role="alert" data-testid="tareasProgramadas.ejecuciones.purgeDialogError">
              {purgeFeedback}
            </div>
          ) : null}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Button
              text={translate('tareasProgramadas.definiciones.cancel')}
              onClick={() => setPurgeOpen(false)}
              elementAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.purgeCancel' }}
            />
            <Button
              text={translate('tareasProgramadas.ejecuciones.purgeConfirmAction')}
              type="danger"
              stylingMode="contained"
              disabled={purging}
              onClick={() => void handlePurge()}
              elementAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.purgeConfirm' }}
            />
          </div>
        </div>
      </Popup>
    </div>
  );
}
