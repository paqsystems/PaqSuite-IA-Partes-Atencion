/**
 * El API GEN-13 envuelve el recurso en `{ item }`; algunos callers tipan el DTO
 * plano. Acepta ambas formas.
 */
export function unwrapTaskItem<T>(payload: T | { item?: T } | null | undefined): T | null {
  if (payload === null || payload === undefined) {
    return null;
  }
  if (typeof payload === 'object' && 'item' in payload) {
    return (payload as { item?: T }).item ?? null;
  }
  return payload as T;
}
