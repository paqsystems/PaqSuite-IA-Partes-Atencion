import type { TaskExecutionStatusCode } from './types';

export type SemaphoreColor = 'green' | 'yellow' | 'red' | 'blue' | 'gray' | 'black';

/**
 * Semáforo derivado en FE a partir de `statusCode` (C1-13-15). Nunca se
 * persiste ni viene del API. Sin historial → `gray`.
 */
export function resolveSemaphoreColor(
  statusCode: TaskExecutionStatusCode | string | null | undefined
): SemaphoreColor {
  switch (statusCode) {
    case 'EXITOSA':
      return 'green';
    case 'EXITOSA_CON_OBSERVACIONES':
      return 'yellow';
    case 'FALLIDA':
    case 'OMITIDA':
      return 'red';
    case 'EN_EJECUCION':
      return 'blue';
    default:
      return 'gray';
  }
}

export type DefinitionSemaphoreInput = {
  isActive: boolean;
  lastStatusCode?: TaskExecutionStatusCode | string | null;
};

/**
 * Semáforo de una definición en Monitoreo (D-M6): inactiva → negro con
 * prioridad sobre el resultado de la última corrida.
 */
export function resolveDefinitionSemaphoreColor(
  input: DefinitionSemaphoreInput
): SemaphoreColor {
  if (!input.isActive) {
    return 'black';
  }
  return resolveSemaphoreColor(input.lastStatusCode);
}

/** Color CSS para el punto de semáforo (black no es color CSS válido de keyword en todos lados). */
export function semaphoreCssColor(color: SemaphoreColor): string {
  return color === 'black' ? '#111111' : color;
}
