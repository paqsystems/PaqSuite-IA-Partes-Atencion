import { useCallback, useEffect, useMemo, useState } from 'react';
import DataGrid, { Column, Paging, Pager } from 'devextreme-react/data-grid';
import Button from 'devextreme-react/button';
import type { BuildPlatformHeadersInput } from '../../http/headers';
import { listTaskProcesses, setTaskProcessActive, type TaskRequestOverrides } from './tasksClient';
import { translateTareasProgramadas } from './tasksI18n';
import type { TaskProcessDto } from './types';

export type TaskProcessesPageProps = {
  t?: (key: string) => string;
  platform?: BuildPlatformHeadersInput;
  accessToken?: string | null;
};

/**
 * Catálogo de procesos programables (GEN-13). Grilla DX de solo lectura del
 * contrato técnico + botón claro Activo/Inactivo. Sin formularios de alta (regla §3).
 */
export function TaskProcessesPage({ t, platform, accessToken }: TaskProcessesPageProps) {
  const translate = t ?? translateTareasProgramadas;
  const [rows, setRows] = useState<TaskProcessDto[]>([]);
  const [busyId, setBusyId] = useState<number | null>(null);

  const requestOptions = useMemo((): TaskRequestOverrides => {
    return {
      platform,
      headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : undefined,
    };
  }, [accessToken, platform]);

  const load = useCallback(async () => {
    const result = await listTaskProcesses(requestOptions);
    if (result.kind === 'ok') {
      setRows(result.envelope.resultado.items ?? []);
    }
  }, [requestOptions]);

  useEffect(() => {
    void load();
  }, [load]);

  const handleToggle = useCallback(
    async (row: TaskProcessDto) => {
      const nextActive = !row.isActive;
      setBusyId(row.id);
      setRows((current) =>
        current.map((item) => (item.id === row.id ? { ...item, isActive: nextActive } : item))
      );
      const result = await setTaskProcessActive(row.id, nextActive, requestOptions);
      setBusyId(null);
      if (result.kind !== 'ok') {
        setRows((current) =>
          current.map((item) => (item.id === row.id ? { ...item, isActive: row.isActive } : item))
        );
      }
    },
    [requestOptions]
  );

  return (
    <div data-testid="tareasProgramadas.procesos.root">
      <h2>{translate('tareasProgramadas.procesos.title')}</h2>
      <DataGrid
        dataSource={rows}
        keyExpr="id"
        showBorders
        columnAutoWidth
        elementAttr={{ 'data-testid': 'tareasProgramadas.procesos.grid' }}
      >
        <Paging defaultPageSize={25} />
        <Pager visible showInfo />
        <Column dataField="processCode" caption={translate('tareasProgramadas.procesos.code')} />
        <Column dataField="processName" caption={translate('tareasProgramadas.procesos.name')} />
        <Column dataField="moduleCode" caption={translate('tareasProgramadas.procesos.module')} />
        <Column
          dataField="isActive"
          caption={translate('tareasProgramadas.procesos.active')}
          width={130}
          cellRender={(cell) => {
            const row = cell.data as TaskProcessDto;
            return (
              <Button
                text={
                  row.isActive
                    ? translate('tareasProgramadas.procesos.activeYes')
                    : translate('tareasProgramadas.procesos.activeNo')
                }
                type={row.isActive ? 'success' : 'normal'}
                stylingMode={row.isActive ? 'contained' : 'outlined'}
                disabled={busyId === row.id}
                hint={translate('tareasProgramadas.procesos.activeToggleHint')}
                onClick={() => void handleToggle(row)}
                elementAttr={{ 'data-testid': 'tareasProgramadas.procesos.toggleActive' }}
              />
            );
          }}
        />
      </DataGrid>
    </div>
  );
}
