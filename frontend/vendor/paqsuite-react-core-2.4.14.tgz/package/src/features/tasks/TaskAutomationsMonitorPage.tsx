import { useCallback, useEffect, useMemo, useState } from 'react';
import Button from 'devextreme-react/button';
import type { BuildPlatformHeadersInput } from '../../http/headers';
import {
  getTaskExecutionLogs,
  listTaskDefinitions,
  listTaskExecutions,
  listTaskProcesses,
  runTaskDefinition,
  simulateTaskDefinition,
  type TaskRequestOverrides,
} from './tasksClient';
import {
  resolveDefinitionSemaphoreColor,
  resolveSemaphoreColor,
  semaphoreCssColor,
  type SemaphoreColor,
} from './semaphoreMap';
import { translateTareasProgramadas } from './tasksI18n';
import type {
  TaskDefinitionDto,
  TaskExecutionDto,
  TaskExecutionLogDto,
  TaskProcessDto,
} from './types';

export type TaskAutomationsMonitorPageProps = {
  supportsSimulationByProcessId?: Record<number, boolean>;
  t?: (key: string) => string;
  platform?: BuildPlatformHeadersInput;
  accessToken?: string | null;
};

function formatDateTime(value: string | null | undefined): string {
  if (!value) {
    return '—';
  }
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value;
  }
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  return `${day}/${month}/${year} ${hours}:${minutes}`;
}

function definitionHasExecutions(definition: TaskDefinitionDto): boolean {
  return Boolean(definition.lastRunAt || definition.lastStatusCode);
}

function SemaphoreDot({
  color,
  testId,
}: {
  color: SemaphoreColor;
  testId?: string;
}) {
  return (
    <span
      data-semaphore={color}
      data-testid={testId}
      style={{
        display: 'inline-block',
        width: 12,
        height: 12,
        borderRadius: '50%',
        background: semaphoreCssColor(color),
        flexShrink: 0,
      }}
    />
  );
}

/**
 * Monitoreo de Automatizaciones (GEN-13 delta UX): master-detail por definición
 * + historial in-place con Volver. Sin purga (admin en Historial/config).
 */
export function TaskAutomationsMonitorPage({
  supportsSimulationByProcessId,
  t,
  platform,
  accessToken,
}: TaskAutomationsMonitorPageProps) {
  const translate = t ?? translateTareasProgramadas;
  const [definitions, setDefinitions] = useState<TaskDefinitionDto[]>([]);
  const [processes, setProcesses] = useState<TaskProcessDto[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [view, setView] = useState<'monitor' | 'historial'>('monitor');
  const [executions, setExecutions] = useState<TaskExecutionDto[]>([]);
  const [selectedExecutionId, setSelectedExecutionId] = useState<number | null>(null);
  const [executionLogs, setExecutionLogs] = useState<TaskExecutionLogDto[]>([]);
  const [busyAction, setBusyAction] = useState(false);

  const requestOptions = useMemo((): TaskRequestOverrides => {
    return {
      platform,
      headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : undefined,
    };
  }, [accessToken, platform]);

  const simulationByProcess = useMemo(() => {
    if (supportsSimulationByProcessId) {
      return supportsSimulationByProcessId;
    }
    const map: Record<number, boolean> = {};
    for (const process of processes) {
      map[process.id] = process.supportsSimulation;
    }
    return map;
  }, [processes, supportsSimulationByProcessId]);

  const loadMonitor = useCallback(async () => {
    const [definitionsResult, processesResult] = await Promise.all([
      listTaskDefinitions(requestOptions),
      listTaskProcesses(requestOptions),
    ]);
    if (definitionsResult.kind === 'ok') {
      const items = definitionsResult.envelope.resultado.items ?? [];
      setDefinitions(items);
      setSelectedId((current) => {
        if (current !== null && items.some((item) => item.id === current)) {
          return current;
        }
        return items[0]?.id ?? null;
      });
    }
    if (processesResult.kind === 'ok') {
      setProcesses(processesResult.envelope.resultado.items ?? []);
    }
  }, [requestOptions]);

  useEffect(() => {
    void loadMonitor();
  }, [loadMonitor]);

  const selectedDefinition = useMemo(
    () => definitions.find((item) => item.id === selectedId) ?? null,
    [definitions, selectedId]
  );

  const loadHistorial = useCallback(
    async (definitionId: number) => {
      const result = await listTaskExecutions({ definitionId }, requestOptions);
      if (result.kind !== 'ok') {
        setExecutions([]);
        setSelectedExecutionId(null);
        return;
      }
      const items = [...(result.envelope.resultado.items ?? [])].sort((left, right) => {
        const leftKey = left.startedAt ?? left.finishedAt ?? '';
        const rightKey = right.startedAt ?? right.finishedAt ?? '';
        return rightKey.localeCompare(leftKey);
      });
      setExecutions(items);
      setSelectedExecutionId(items[0]?.id ?? null);
    },
    [requestOptions]
  );

  useEffect(() => {
    if (view !== 'historial' || selectedId === null) {
      return;
    }
    void loadHistorial(selectedId);
  }, [view, selectedId, loadHistorial]);

  useEffect(() => {
    if (selectedExecutionId === null) {
      setExecutionLogs([]);
      return;
    }
    void getTaskExecutionLogs(selectedExecutionId, requestOptions).then((result) => {
      if (result.kind === 'ok') {
        setExecutionLogs(result.envelope.resultado.items ?? []);
      } else {
        setExecutionLogs([]);
      }
    });
  }, [selectedExecutionId, requestOptions]);

  const selectedExecution = useMemo(
    () => executions.find((item) => item.id === selectedExecutionId) ?? null,
    [executions, selectedExecutionId]
  );

  const handleRun = useCallback(async () => {
    if (!selectedDefinition) {
      return;
    }
    setBusyAction(true);
    await runTaskDefinition(selectedDefinition.id, {}, requestOptions);
    setBusyAction(false);
    await loadMonitor();
  }, [loadMonitor, requestOptions, selectedDefinition]);

  const handleSimulate = useCallback(async () => {
    if (!selectedDefinition) {
      return;
    }
    setBusyAction(true);
    await simulateTaskDefinition(selectedDefinition.id, {}, requestOptions);
    setBusyAction(false);
    await loadMonitor();
  }, [loadMonitor, requestOptions, selectedDefinition]);

  const openHistorial = useCallback(() => {
    if (!selectedDefinition || !definitionHasExecutions(selectedDefinition)) {
      return;
    }
    setView('historial');
  }, [selectedDefinition]);

  const frequencyLabel = selectedDefinition
    ? translate(`tareasProgramadas.definiciones.frequency.${selectedDefinition.frequencyType}`)
    : '';

  if (view === 'historial' && selectedDefinition) {
    return (
      <div data-testid="tareasProgramadas.monitoreo.historialRoot">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
          <Button
            icon="back"
            stylingMode="text"
            hint={translate('tareasProgramadas.monitoreo.back')}
            text={translate('tareasProgramadas.monitoreo.back')}
            onClick={() => {
              setView('monitor');
              void loadMonitor();
            }}
            elementAttr={{ 'data-testid': 'tareasProgramadas.monitoreo.back' }}
          />
          <h2 style={{ margin: 0 }}>
            {translate('tareasProgramadas.monitoreo.historialTitle')}: {selectedDefinition.taskTitle}
          </h2>
        </div>
        <div style={{ display: 'flex', gap: 16, minHeight: 360 }}>
          <div
            style={{
              flex: '0 0 42%',
              border: '1px solid #d0d0d0',
              borderRadius: 4,
              overflow: 'auto',
            }}
            data-testid="tareasProgramadas.monitoreo.historialList"
          >
            {executions.map((execution, index) => {
              const color = resolveSemaphoreColor(execution.statusCode);
              const selected = execution.id === selectedExecutionId;
              return (
                <button
                  key={execution.id}
                  type="button"
                  onClick={() => setSelectedExecutionId(execution.id)}
                  data-testid="tareasProgramadas.monitoreo.historialItem"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 8,
                    width: '100%',
                    textAlign: 'left',
                    padding: '10px 12px',
                    border: 'none',
                    borderBottom: '1px solid #eee',
                    background: selected ? '#dcebff' : 'transparent',
                    cursor: 'pointer',
                  }}
                >
                  <SemaphoreDot color={color} />
                  <span>
                    {formatDateTime(execution.startedAt ?? execution.finishedAt)}
                    {index === 0 ? ` ${translate('tareasProgramadas.monitoreo.mostRecent')}` : ''}
                  </span>
                </button>
              );
            })}
          </div>
          <div
            style={{ flex: 1, border: '1px solid #d0d0d0', borderRadius: 4, padding: 16 }}
            data-testid="tareasProgramadas.monitoreo.historialDetail"
          >
            {selectedExecution ? (
              <>
                <h3 style={{ marginTop: 0, textDecoration: 'underline' }}>
                  {formatDateTime(selectedExecution.startedAt ?? selectedExecution.finishedAt)} hrs
                </h3>
                <p>
                  <strong>{translate('tareasProgramadas.ejecuciones.status')}:</strong>{' '}
                  {selectedExecution.statusCode}
                  {selectedExecution.isSimulation
                    ? ` · ${translate('tareasProgramadas.ejecuciones.simulation')}`
                    : ''}
                </p>
                <p>
                  <strong>{translate('tareasProgramadas.monitoreo.result')}:</strong>
                </p>
                <pre
                  style={{
                    whiteSpace: 'pre-wrap',
                    background: '#f7f7f7',
                    padding: 12,
                    borderRadius: 4,
                    minHeight: 80,
                  }}
                  data-testid="tareasProgramadas.monitoreo.resultText"
                >
                  {selectedExecution.message?.trim() ||
                    translate('tareasProgramadas.monitoreo.noResult')}
                </pre>
                {executionLogs.length > 0 ? (
                  <>
                    <p>
                      <strong>{translate('tareasProgramadas.monitoreo.logs')}:</strong>
                    </p>
                    <ul data-testid="tareasProgramadas.monitoreo.logs">
                      {executionLogs.map((log) => (
                        <li key={log.id}>
                          [{log.level}] {log.message}
                        </li>
                      ))}
                    </ul>
                  </>
                ) : null}
              </>
            ) : (
              <p>{translate('tareasProgramadas.monitoreo.emptySelection')}</p>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div data-testid="tareasProgramadas.monitoreo.root">
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <h2 style={{ margin: 0 }}>{translate('tareasProgramadas.monitoreo.title')}</h2>
        <Button
          icon="refresh"
          stylingMode="text"
          hint={translate('tareasProgramadas.monitoreo.refresh')}
          onClick={() => void loadMonitor()}
          elementAttr={{ 'data-testid': 'tareasProgramadas.monitoreo.refresh' }}
        />
      </div>
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'center',
          gap: '10px 16px',
          marginBottom: 12,
          color: '#666',
          fontSize: 13,
        }}
        data-testid="tareasProgramadas.monitoreo.legend"
      >
        {(
          [
            ['green', 'tareasProgramadas.monitoreo.legend.ok'],
            ['yellow', 'tareasProgramadas.monitoreo.legend.warn'],
            ['red', 'tareasProgramadas.monitoreo.legend.fail'],
            ['blue', 'tareasProgramadas.monitoreo.legend.running'],
            ['black', 'tareasProgramadas.monitoreo.legend.inactive'],
            ['gray', 'tareasProgramadas.monitoreo.legend.none'],
          ] as const
        ).map(([color, labelKey]) => (
          <span key={color} style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <SemaphoreDot color={color} />
            <span>{translate(labelKey)}</span>
          </span>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 16, minHeight: 360 }}>
        <div
          style={{
            flex: '0 0 42%',
            border: '1px solid #d0d0d0',
            borderRadius: 4,
            overflow: 'auto',
          }}
          data-testid="tareasProgramadas.monitoreo.list"
        >
          {definitions.length === 0 ? (
            <p style={{ padding: 12 }}>{translate('tareasProgramadas.monitoreo.emptyList')}</p>
          ) : (
            definitions.map((definition) => {
              const color = resolveDefinitionSemaphoreColor({
                isActive: definition.isActive,
                lastStatusCode: definition.lastStatusCode,
              });
              const selected = definition.id === selectedId;
              return (
                <button
                  key={definition.id}
                  type="button"
                  onClick={() => setSelectedId(definition.id)}
                  data-testid="tareasProgramadas.monitoreo.item"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 8,
                    width: '100%',
                    textAlign: 'left',
                    padding: '10px 12px',
                    border: 'none',
                    borderBottom: '1px solid #eee',
                    background: selected ? '#dcebff' : 'transparent',
                    cursor: 'pointer',
                  }}
                >
                  <SemaphoreDot
                    color={color}
                    testId="tareasProgramadas.monitoreo.semaphore"
                  />
                  <span>{definition.taskTitle}</span>
                </button>
              );
            })
          )}
        </div>
        <div
          style={{ flex: 1, border: '1px solid #d0d0d0', borderRadius: 4, padding: 16 }}
          data-testid="tareasProgramadas.monitoreo.detail"
        >
          {selectedDefinition ? (
            <>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}>
                <h3 style={{ marginTop: 0, flex: 1, textDecoration: 'underline' }}>
                  {selectedDefinition.taskTitle}
                </h3>
                <Button
                  icon="runner"
                  stylingMode="text"
                  hint={translate('tareasProgramadas.monitoreo.run')}
                  disabled={busyAction || !selectedDefinition.isActive}
                  onClick={() => void handleRun()}
                  elementAttr={{ 'data-testid': 'tareasProgramadas.monitoreo.run' }}
                />
                {simulationByProcess[selectedDefinition.processId] ?? true ? (
                  <Button
                    icon="eyeopen"
                    stylingMode="text"
                    hint={translate('tareasProgramadas.monitoreo.simulate')}
                    disabled={busyAction || !selectedDefinition.isActive}
                    onClick={() => void handleSimulate()}
                    elementAttr={{ 'data-testid': 'tareasProgramadas.monitoreo.simulate' }}
                  />
                ) : null}
              </div>
              <p>
                <strong>{translate('tareasProgramadas.monitoreo.description')}:</strong>
              </p>
              <p data-testid="tareasProgramadas.monitoreo.descriptionText">
                {(selectedDefinition.taskDescription ?? '').trim() ||
                  translate('tareasProgramadas.monitoreo.noDescription')}
              </p>
              <p>
                <strong>{translate('tareasProgramadas.monitoreo.frequency')}:</strong>{' '}
                {frequencyLabel}
                {selectedDefinition.baseTime
                  ? ` — ${String(selectedDefinition.baseTime).slice(0, 5)} hrs`
                  : ''}
              </p>
              <p>
                <strong>{translate('tareasProgramadas.monitoreo.lastRun')}:</strong>{' '}
                {formatDateTime(selectedDefinition.lastRunAt)}
              </p>
              <p>
                <strong>{translate('tareasProgramadas.monitoreo.nextRun')}:</strong>{' '}
                {formatDateTime(selectedDefinition.nextRunAt)}
              </p>
              <p>
                <strong>{translate('tareasProgramadas.monitoreo.lastStatus')}:</strong>{' '}
                {selectedDefinition.lastStatusCode ?? '—'}
              </p>
              <div style={{ marginTop: 16 }}>
                <Button
                  text={translate('tareasProgramadas.monitoreo.historial')}
                  stylingMode="contained"
                  type="default"
                  disabled={!definitionHasExecutions(selectedDefinition)}
                  onClick={openHistorial}
                  elementAttr={{ 'data-testid': 'tareasProgramadas.monitoreo.historial' }}
                />
              </div>
            </>
          ) : (
            <p>{translate('tareasProgramadas.monitoreo.emptySelection')}</p>
          )}
        </div>
      </div>
    </div>
  );
}
