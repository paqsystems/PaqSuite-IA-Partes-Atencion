/**
 * Tipos GEN-13 — Tareas programadas: catálogo de procesos, definiciones y
 * monitor de ejecuciones (TR-GEN-13-modulo-catalogo / -definiciones / -monitor).
 */

export type TaskProcessDto = {
  id: number;
  processCode: string;
  processName: string;
  moduleCode: string | null;
  isActive: boolean;
  supportsManualExecution: boolean;
  supportsScheduledExecution: boolean;
  supportsSimulation: boolean;
  worksByCompany: boolean;
  selectionStrategyAuto: string | null;
  selectionStrategyManual: string | null;
};

export type TaskFrequencyType =
  | 'HOURLY_INTERVAL'
  | 'DAILY'
  | 'WEEKLY'
  | 'MONTHLY'
  | 'CUSTOM';

export type TaskDefinitionDto = {
  id: number;
  processId: number;
  taskTitle: string;
  taskDescription?: string | null;
  isActive: boolean;
  frequencyType: TaskFrequencyType;
  frequencyInterval?: number | null;
  frequencyDaysMask?: string | null;
  baseDate: string;
  baseTime: string;
  nextRunAt?: string | null;
  lastRunAt?: string | null;
  lastStatusCode?: string | null;
  companyIds: number[];
  parameters?: TaskDefinitionParameterValue[];
  notifyEnabled: boolean;
  notifyOnError: boolean;
  notifyOnSuccess: boolean;
  notifyEmails: string[];
};

export type TaskProcessParameterDto = {
  id: number;
  parameterCode: string;
  parameterName: string;
  parameterDescription?: string | null;
  dataType: string;
  uiControlType?: string | null;
  isRequired: boolean;
  defaultValue?: string | null;
  allowedValuesSource?: string | null;
  displayOrder: number;
  isUserEditable: boolean;
  isMultivalue: boolean;
  metadataJson?: string | Record<string, unknown> | null;
};

export type TaskDefinitionEmpresaOption = {
  id: number;
  nombreEmpresa: string;
};

export type TaskDefinitionParameterValue = {
  parameterCode: string;
  value: unknown;
};

export type TaskDefinitionCreateBody = {
  processId: number;
  taskTitle: string;
  taskDescription?: string;
  isActive?: boolean;
  frequencyType: TaskFrequencyType;
  frequencyInterval?: number;
  frequencyDaysMask?: string;
  baseDate: string;
  baseTime: string;
  companyIds: number[];
  parameters?: TaskDefinitionParameterValue[];
  notifyEnabled?: boolean;
  notifyOnError?: boolean;
  notifyOnSuccess?: boolean;
  notifyEmails?: string[];
};

export type TaskExecutionStatusCode =
  | 'EXITOSA'
  | 'EXITOSA_CON_OBSERVACIONES'
  | 'FALLIDA'
  | 'OMITIDA'
  | 'EN_EJECUCION';

export type TaskExecutionDto = {
  id: number;
  definitionId: number;
  companyId: number | null;
  statusCode: TaskExecutionStatusCode | string;
  mode: string;
  isSimulation: boolean;
  message?: string | null;
  startedAt: string | null;
  finishedAt: string | null;
};

export type TaskExecutionLogDto = {
  id: number;
  executionId: number;
  level: string;
  message: string;
  loggedAt: string;
};

export type TaskExecutionFilters = {
  definitionId?: number;
  companyId?: number;
  status?: string;
  from?: string;
  to?: string;
};
