import { useCallback, useEffect, useMemo, useState } from 'react';
import Button from 'devextreme-react/button';
import CheckBox from 'devextreme-react/check-box';
import DateBox from 'devextreme-react/date-box';
import LoadPanel from 'devextreme-react/load-panel';
import NumberBox from 'devextreme-react/number-box';
import SelectBox from 'devextreme-react/select-box';
import Switch from 'devextreme-react/switch';
import TagBox from 'devextreme-react/tag-box';
import TextArea from 'devextreme-react/text-area';
import TextBox from 'devextreme-react/text-box';
import {
  coerceParameterDefault,
  isDefinitionParameter,
  parseAllowedValues,
} from './taskParameterMetadata';
import {
  emptyTaskDefinitionFormState,
  formatYmd,
  isoDaysFromMask,
  isoWeekdayCodes,
  toTaskDefinitionCreateBody,
  validateTaskDefinitionForm,
  visibleFrequencyFields,
  type TaskDefinitionFormState,
} from './taskDefinitionFormModel';
import type { BuildPlatformHeadersInput } from '../../http/headers';
import {
  createTaskDefinition,
  getTaskDefinition,
  listTaskProcessParameters,
  listTaskProcesses,
  patchTaskDefinition,
  type TaskRequestOverrides,
} from './tasksClient';
import { translateTareasProgramadas } from './tasksI18n';
import type {
  TaskDefinitionDto,
  TaskDefinitionEmpresaOption,
  TaskFrequencyType,
  TaskProcessDto,
  TaskProcessParameterDto,
} from './types';
import { unwrapTaskItem } from './unwrapTaskItem';

export type TaskDefinitionFormPageProps = {
  mode: 'create' | 'edit';
  definitionId?: number;
  tenancyMode?: 'single' | 'multi';
  empresas: TaskDefinitionEmpresaOption[];
  onCancel: () => void;
  onSaved: (id: number) => void;
  t?: (key: string) => string;
  platform?: BuildPlatformHeadersInput;
  accessToken?: string | null;
};

const frequencyTypes: TaskFrequencyType[] = [
  'HOURLY_INTERVAL',
  'DAILY',
  'WEEKLY',
  'MONTHLY',
  'CUSTOM',
];

function intervalLabelKey(frequencyType: TaskFrequencyType): string {
  switch (frequencyType) {
    case 'HOURLY_INTERVAL':
      return 'tareasProgramadas.definiciones.frequencyIntervalHourly';
    case 'DAILY':
      return 'tareasProgramadas.definiciones.frequencyIntervalDaily';
    case 'WEEKLY':
      return 'tareasProgramadas.definiciones.frequencyIntervalWeekly';
    case 'MONTHLY':
      return 'tareasProgramadas.definiciones.frequencyIntervalMonthly';
    default:
      return 'tareasProgramadas.definiciones.frequencyInterval';
  }
}

function parseDateOnly(value: string): Date | undefined {
  if (!value) {
    return undefined;
  }
  const parsed = new Date(`${value}T00:00:00`);
  return Number.isNaN(parsed.getTime()) ? undefined : parsed;
}

function parseTimeOnly(value: string): Date | undefined {
  if (!/^\d{2}:\d{2}/.test(value)) {
    return undefined;
  }
  const [hours, minutes] = value.split(':').map((token) => Number(token));
  const parsed = new Date();
  parsed.setHours(hours, minutes, 0, 0);
  return parsed;
}

function formatHm(date: Date): string {
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
}

/**
 * Alta/edición full-page de definiciones GEN-13 (rutas `/nueva` y `/:id/editar`).
 */
export function TaskDefinitionFormPage({
  mode,
  definitionId,
  tenancyMode = 'single',
  empresas,
  onCancel,
  onSaved,
  t,
  platform,
  accessToken,
}: TaskDefinitionFormPageProps) {
  const translate = t ?? translateTareasProgramadas;
  const requestOptions = useMemo((): TaskRequestOverrides => {
    return {
      platform,
      headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : undefined,
    };
  }, [accessToken, platform]);
  const [form, setForm] = useState<TaskDefinitionFormState>(() =>
    emptyTaskDefinitionFormState(tenancyMode === 'single' && empresas.length === 1 ? [empresas[0].id] : [])
  );
  const [processes, setProcesses] = useState<TaskProcessDto[]>([]);
  const [catalogParameters, setCatalogParameters] = useState<TaskProcessParameterDto[]>([]);
  const [runtime, setRuntime] = useState<{
    nextRunAt?: string | null;
    lastRunAt?: string | null;
    lastStatusCode?: string | null;
  }>({});
  const [loading, setLoading] = useState(mode === 'edit');
  const [saving, setSaving] = useState(false);
  const [errorKey, setErrorKey] = useState<string | null>(null);

  const patchForm = useCallback((partial: Partial<TaskDefinitionFormState>) => {
    setForm((current) => ({ ...current, ...partial }));
  }, []);

  useEffect(() => {
    if (tenancyMode === 'single' && empresas.length === 1 && form.companyIds.length === 0) {
      patchForm({ companyIds: [empresas[0].id] });
    }
  }, [empresas, form.companyIds.length, patchForm, tenancyMode]);

  useEffect(() => {
    void listTaskProcesses(requestOptions).then((result) => {
      if (result.kind === 'ok') {
        const items = result.envelope.resultado.items ?? [];
        setProcesses(
          items.filter((process) => process.isActive && process.supportsScheduledExecution)
        );
      }
    });
  }, [requestOptions]);

  useEffect(() => {
    if (mode !== 'edit' || definitionId === undefined) {
      return;
    }
    setLoading(true);
    void getTaskDefinition(definitionId, requestOptions).then((result) => {
      setLoading(false);
      if (result.kind !== 'ok') {
        setErrorKey('tareasProgramadas.definiciones.loadError');
        return;
      }
      const item = unwrapTaskItem<TaskDefinitionDto>(result.envelope.resultado);
      if (item === null) {
        setErrorKey('tareasProgramadas.definiciones.loadError');
        return;
      }
      const parameterValues: Record<string, unknown> = {};
      for (const parameter of item.parameters ?? []) {
        parameterValues[parameter.parameterCode] = parameter.value;
      }
      setForm({
        processId: item.processId,
        taskTitle: item.taskTitle,
        taskDescription: item.taskDescription ?? '',
        isActive: item.isActive,
        frequencyType: item.frequencyType,
        frequencyInterval: item.frequencyInterval ?? null,
        frequencyDays: isoDaysFromMask(item.frequencyDaysMask),
        baseDate: item.baseDate,
        baseTime: item.baseTime.length >= 5 ? item.baseTime.slice(0, 5) : item.baseTime,
        companyIds: item.companyIds ?? [],
        notifyEnabled: item.notifyEnabled,
        notifyOnError: item.notifyOnError,
        notifyOnSuccess: item.notifyOnSuccess,
        notifyEmailsText: (item.notifyEmails ?? []).join(', '),
        parameterValues,
      });
      setRuntime({
        nextRunAt: item.nextRunAt,
        lastRunAt: item.lastRunAt,
        lastStatusCode: item.lastStatusCode,
      });
    });
  }, [definitionId, mode, requestOptions]);

  useEffect(() => {
    if (form.processId === null) {
      setCatalogParameters([]);
      return;
    }
    void listTaskProcessParameters(form.processId, requestOptions).then((result) => {
      if (result.kind !== 'ok') {
        return;
      }
      const items = (result.envelope.resultado.items ?? []).filter(isDefinitionParameter);
      setCatalogParameters(items);
      setForm((current) => {
        const nextValues = { ...current.parameterValues };
        for (const parameter of items) {
          if (nextValues[parameter.parameterCode] === undefined) {
            nextValues[parameter.parameterCode] = coerceParameterDefault(
              parameter.dataType,
              parameter.defaultValue
            );
          }
        }
        return { ...current, parameterValues: nextValues };
      });
    });
  }, [form.processId, requestOptions]);

  const frequencyItems = useMemo(
    () =>
      frequencyTypes.map((value) => ({
        value,
        text: translate(`tareasProgramadas.definiciones.frequency.${value}`),
      })),
    [translate]
  );

  const fields = visibleFrequencyFields(form.frequencyType);

  const handleSave = async () => {
    setErrorKey(null);
    const validationKey = validateTaskDefinitionForm(form, tenancyMode);
    if (validationKey) {
      setErrorKey(validationKey);
      return;
    }
    setSaving(true);
    const body = toTaskDefinitionCreateBody(form);
    const result =
      mode === 'create'
        ? await createTaskDefinition(body, requestOptions)
        : await patchTaskDefinition(definitionId as number, body, requestOptions);
    setSaving(false);
    if (result.kind !== 'ok') {
      setErrorKey(
        result.kind === 'envelopeError'
          ? result.envelope.respuesta || 'tareasProgramadas.definiciones.saveError'
          : 'tareasProgramadas.definiciones.saveError'
      );
      return;
    }
    const saved = unwrapTaskItem<TaskDefinitionDto>(result.envelope.resultado);
    onSaved(saved?.id ?? definitionId ?? 0);
  };

  const titleKey =
    mode === 'create'
      ? 'tareasProgramadas.definiciones.create'
      : 'tareasProgramadas.definiciones.editPage';

  return (
    <div data-testid="tareasProgramadas.definiciones.form" style={{ maxWidth: 720 }}>
      <LoadPanel visible={loading || saving} />
      <h2>{translate(titleKey)}</h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <SelectBox
          label={translate('tareasProgramadas.definiciones.process')}
          labelMode="floating"
          dataSource={processes}
          valueExpr="id"
          displayExpr="processName"
          value={form.processId}
          disabled={mode === 'edit'}
          onValueChanged={(event) =>
            patchForm({ processId: event.value ? Number(event.value) : null, parameterValues: {} })
          }
          elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.process' }}
        />
        <TextBox
          label={translate('tareasProgramadas.definiciones.taskTitle')}
          labelMode="floating"
          value={form.taskTitle}
          onValueChanged={(event) => patchForm({ taskTitle: String(event.value ?? '') })}
          elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.taskTitle' }}
        />
        <TextArea
          label={translate('tareasProgramadas.definiciones.taskDescription')}
          labelMode="floating"
          value={form.taskDescription}
          onValueChanged={(event) => patchForm({ taskDescription: String(event.value ?? '') })}
          height={72}
          elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.taskDescription' }}
        />
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span>{translate('tareasProgramadas.definiciones.active')}</span>
          <Switch
            value={form.isActive}
            switchedOnText={translate('tareasProgramadas.definiciones.switchOn')}
            switchedOffText={translate('tareasProgramadas.definiciones.switchOff')}
            width={72}
            onValueChanged={(event) => patchForm({ isActive: Boolean(event.value) })}
            elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.isActive' }}
          />
        </div>

        <SelectBox
          label={translate('tareasProgramadas.definiciones.frequencyType')}
          labelMode="floating"
          dataSource={frequencyItems}
          valueExpr="value"
          displayExpr="text"
          value={form.frequencyType}
          onValueChanged={(event) =>
            patchForm({ frequencyType: (event.value as TaskFrequencyType) ?? 'DAILY' })
          }
          elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.frequencyType' }}
        />
        {fields.interval ? (
          <NumberBox
            label={translate(intervalLabelKey(form.frequencyType))}
            labelMode="floating"
            value={form.frequencyInterval ?? undefined}
            min={1}
            max={form.frequencyType === 'MONTHLY' ? 31 : undefined}
            showSpinButtons
            onValueChanged={(event) =>
              patchForm({
                frequencyInterval: event.value === null || event.value === undefined ? null : Number(event.value),
              })
            }
            elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.frequencyInterval' }}
          />
        ) : null}
        {fields.daysMask ? (
          <div data-testid="tareasProgramadas.definiciones.days">
            <div style={{ marginBottom: 4 }}>{translate('tareasProgramadas.definiciones.days')}</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {isoWeekdayCodes.map((day) => (
                <CheckBox
                  key={day}
                  text={translate(`tareasProgramadas.definiciones.day.${day}`)}
                  value={form.frequencyDays.includes(day)}
                  onValueChanged={(event) => {
                    const checked = Boolean(event.value);
                    patchForm({
                      frequencyDays: checked
                        ? [...form.frequencyDays, day]
                        : form.frequencyDays.filter((current) => current !== day),
                    });
                  }}
                  elementAttr={{ 'data-testid': `tareasProgramadas.definiciones.day.${day}` }}
                />
              ))}
            </div>
          </div>
        ) : null}

        <DateBox
          label={translate('tareasProgramadas.definiciones.baseDate')}
          labelMode="floating"
          type="date"
          displayFormat="dd/MM/yyyy"
          useMaskBehavior
          value={parseDateOnly(form.baseDate)}
          onValueChanged={(event) => {
            const value = event.value as Date | null;
            patchForm({ baseDate: value ? formatYmd(value) : '' });
          }}
          elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.baseDate' }}
        />
        <DateBox
          label={translate('tareasProgramadas.definiciones.baseTime')}
          labelMode="floating"
          type="time"
          displayFormat="HH:mm"
          useMaskBehavior
          value={parseTimeOnly(form.baseTime)}
          onValueChanged={(event) => {
            const value = event.value as Date | null;
            patchForm({ baseTime: value ? formatHm(value) : '' });
          }}
          elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.baseTime' }}
        />

        {tenancyMode === 'multi' ? (
          <TagBox
            label={translate('tareasProgramadas.definiciones.companies')}
            labelMode="floating"
            dataSource={empresas}
            valueExpr="id"
            displayExpr="nombreEmpresa"
            value={form.companyIds}
            onValueChanged={(event) =>
              patchForm({
                companyIds: ((event.value as number[] | undefined) ?? []).map((id) => Number(id)),
              })
            }
            elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.companies' }}
          />
        ) : null}

        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span>{translate('tareasProgramadas.definiciones.notifyEnabled')}</span>
          <Switch
            value={form.notifyEnabled}
            switchedOnText={translate('tareasProgramadas.definiciones.switchOn')}
            switchedOffText={translate('tareasProgramadas.definiciones.switchOff')}
            width={72}
            onValueChanged={(event) => patchForm({ notifyEnabled: Boolean(event.value) })}
            elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.notifyEnabled' }}
          />
        </div>
        {form.notifyEnabled ? (
          <>
            <CheckBox
              text={translate('tareasProgramadas.definiciones.notifyOnError')}
              value={form.notifyOnError}
              onValueChanged={(event) => patchForm({ notifyOnError: Boolean(event.value) })}
              elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.notifyOnError' }}
            />
            <CheckBox
              text={translate('tareasProgramadas.definiciones.notifyOnSuccess')}
              value={form.notifyOnSuccess}
              onValueChanged={(event) => patchForm({ notifyOnSuccess: Boolean(event.value) })}
              elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.notifyOnSuccess' }}
            />
            <TextBox
              label={translate('tareasProgramadas.definiciones.notifyEmails')}
              labelMode="floating"
              value={form.notifyEmailsText}
              onValueChanged={(event) => patchForm({ notifyEmailsText: String(event.value ?? '') })}
              elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.notifyEmails' }}
            />
          </>
        ) : null}

        {catalogParameters.length > 0 ? (
          <div data-testid="tareasProgramadas.definiciones.parameters">
            <h3>{translate('tareasProgramadas.definiciones.parameters')}</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {catalogParameters.map((parameter) => (
                <ParameterControl
                  key={parameter.parameterCode}
                  parameter={parameter}
                  value={form.parameterValues[parameter.parameterCode]}
                  onChange={(value) =>
                    patchForm({
                      parameterValues: {
                        ...form.parameterValues,
                        [parameter.parameterCode]: value,
                      },
                    })
                  }
                />
              ))}
            </div>
          </div>
        ) : null}

        {mode === 'edit' ? (
          <div data-testid="tareasProgramadas.definiciones.runtime">
            <p>{`${translate('tareasProgramadas.definiciones.nextRun')}: ${runtime.nextRunAt ?? '—'}`}</p>
            <p>{`${translate('tareasProgramadas.definiciones.lastRun')}: ${runtime.lastRunAt ?? '—'}`}</p>
            <p>{`${translate('tareasProgramadas.definiciones.lastStatus')}: ${runtime.lastStatusCode ?? '—'}`}</p>
          </div>
        ) : null}

        {errorKey ? (
          <div role="alert" data-testid="tareasProgramadas.definiciones.error">
            {translate(errorKey)}
          </div>
        ) : null}

        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <Button
            text={translate('tareasProgramadas.definiciones.cancel')}
            onClick={onCancel}
            elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.cancel' }}
          />
          <Button
            text={translate('tareasProgramadas.definiciones.save')}
            type="default"
            stylingMode="contained"
            disabled={saving}
            onClick={() => void handleSave()}
            elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.save' }}
          />
        </div>
      </div>
    </div>
  );
}

function ParameterControl({
  parameter,
  value,
  onChange,
}: {
  parameter: TaskProcessParameterDto;
  value: unknown;
  onChange: (value: unknown) => void;
}) {
  const testId = `tareasProgramadas.definiciones.parameter.${parameter.parameterCode}`;
  const control = (parameter.uiControlType ?? '').toUpperCase();
  const allowed = parseAllowedValues(parameter.allowedValuesSource);

  if (parameter.dataType === 'BOOL' || control === 'CHECKBOX') {
    return (
      <CheckBox
        text={parameter.parameterName}
        value={Boolean(value)}
        onValueChanged={(event) => onChange(Boolean(event.value))}
        elementAttr={{ 'data-testid': testId }}
      />
    );
  }

  if (control === 'SELECT' || allowed.length > 0) {
    return (
      <SelectBox
        label={parameter.parameterName}
        labelMode="floating"
        dataSource={allowed.map((item) => ({ value: item, text: item }))}
        valueExpr="value"
        displayExpr="text"
        value={value === null || value === undefined ? null : String(value)}
        onValueChanged={(event) => onChange(event.value ?? '')}
        elementAttr={{ 'data-testid': testId }}
      />
    );
  }

  if (parameter.dataType === 'INT' || parameter.dataType === 'DECIMAL' || control === 'NUMBER') {
    return (
      <NumberBox
        label={parameter.parameterName}
        labelMode="floating"
        value={typeof value === 'number' ? value : Number(value ?? 0)}
        onValueChanged={(event) => onChange(event.value ?? null)}
        elementAttr={{ 'data-testid': testId }}
      />
    );
  }

  if (parameter.dataType === 'DATETIME' || control === 'DATEPICKER') {
    return (
      <DateBox
        label={parameter.parameterName}
        labelMode="floating"
        type="datetime"
        displayFormat="dd/MM/yyyy HH:mm"
        useMaskBehavior
        value={typeof value === 'string' && value !== '' ? new Date(value) : undefined}
        onValueChanged={(event) => {
          const date = event.value as Date | null;
          onChange(date ? date.toISOString() : '');
        }}
        elementAttr={{ 'data-testid': testId }}
      />
    );
  }

  return (
    <TextBox
      label={parameter.parameterName}
      labelMode="floating"
      value={value === null || value === undefined ? '' : String(value)}
      onValueChanged={(event) => onChange(String(event.value ?? ''))}
      elementAttr={{ 'data-testid': testId }}
    />
  );
}
