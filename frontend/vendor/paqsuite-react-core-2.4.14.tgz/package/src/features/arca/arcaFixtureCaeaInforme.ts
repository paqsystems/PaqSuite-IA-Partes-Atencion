import { postArcaCaeaInformarComprobantes } from './arcaApiClient';

/**
 * Fixture mínimo para smoke de FECAEARegInformativo (letra C / tipo 11).
 * El Host debe usar un PV CAEA habilitado en AFIP para el tipo correspondiente.
 */
export function buildArcaCaeaInformeFixture(input: {
  caeaCodigo: string;
  periodoAaaamm: string;
  ordenQuincena: 1 | 2;
  puntoVenta?: number;
  numero?: number;
}): Record<string, unknown> {
  const puntoVenta = input.puntoVenta ?? 5;
  const numero = input.numero ?? 1;
  const fecha = new Date().toISOString().slice(0, 10);
  const now = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  const fechaHoraGeneracion =
    `${fecha.replace(/-/g, '')}${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;

  const solicitudId =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID()
      : '550e8400-e29b-41d4-a716-446655440caa';

  return {
    solicitud: {
      solicitudId,
      comprobanteHostId: `caea-c-${String(puntoVenta).padStart(4, '0')}-${numero}`,
      hostCodigo: 'smoke',
    },
    identificacion: {
      clase: 'factura',
      letra: 'C',
      regimenSolicitado: 'caea',
      puntoVenta,
      numero,
      fechaComprobante: fecha,
    },
    emisor: { cuit: '20165285981' },
    receptor: {
      tipoDocumento: 'dni',
      numeroDocumento: '30111222',
      razonSocial: 'Consumidor Final',
      condicionIva: 'consumidorFinal',
    },
    operacion: { concepto: 'bienes' },
    fechas: { fechaComprobante: fecha },
    moneda: { codigo: 'ARS', esMonedaLocal: true },
    importes: {
      netoGravado: '12100.00',
      iva: '0.00',
      total: '12100.00',
      netoNoGravado: '0.00',
      exento: '0.00',
      tributos: '0.00',
    },
    iva: [],
    tributos: [],
    otrosImportes: [],
    comprobantesAsociados: [],
    opcionales: [],
    caea: {
      codigo: input.caeaCodigo,
      periodoAaaamm: input.periodoAaaamm,
      ordenQuincena: input.ordenQuincena,
      fechaHoraGeneracion,
    },
  };
}

export async function postArcaCaeaInformeFixture(
  input: {
    caeaCodigo: string;
    anio: number;
    mes: number;
    quincena: 1 | 2;
    puntoVenta?: number;
    numero?: number;
  },
  options: Parameters<typeof postArcaCaeaInformarComprobantes>[1] = {},
) {
  const periodoAaaamm = `${input.anio}${String(input.mes).padStart(2, '0')}`;
  const comprobante = buildArcaCaeaInformeFixture({
    caeaCodigo: input.caeaCodigo,
    periodoAaaamm,
    ordenQuincena: input.quincena,
    puntoVenta: input.puntoVenta,
    numero: input.numero,
  });

  return postArcaCaeaInformarComprobantes(
    {
      periodo: { anio: input.anio, mes: input.mes, quincena: input.quincena },
      comprobantes: [comprobante],
    },
    options,
  );
}
