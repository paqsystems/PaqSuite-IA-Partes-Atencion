import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));

function read(relativePath: string): string {
  return readFileSync(resolve(here, relativePath), 'utf8');
}

describe('ARCA consola FE boundaries (GEN-32 lote 6)', () => {
  it('exporta las páginas fijas y el cliente HTTP', () => {
    const index = read('../../index.ts');
    expect(index).toContain('ArcaConfigPage');
    expect(index).toContain('ArcaHomologacionPage');
    expect(index).toContain("from './features/arca/arcaApiClient'");
  });

  it('config usa FileUploader DX y password; no input file nativo suelto', () => {
    const page = read('./ArcaConfigPage.tsx');
    expect(page).toContain('data-testid="arcaIntegration.config.root"');
    expect(page).toContain('arcaIntegration.config.save');
    expect(page).toContain('arcaIntegration.config.certificate');
    expect(page).toContain('arcaIntegration.config.passphrase');
    expect(page).toContain('arcaIntegration.config.mode');
    expect(page).toContain('arcaIntegration.config.certificateCrt');
    expect(page).toContain('arcaIntegration.config.certificateKey');
    expect(page).toContain('arcaIntegration.config.passphraseContenedor');
    expect(page).toContain('FileUploader');
    expect(page).toContain('mode="password"');
    expect(page).not.toMatch(/<input\s+type=["']file["']/);
    expect(page).not.toMatch(/\{pkcs12Base64\}/);
    expect(page).not.toContain('window.open');
    expect(page.toLowerCase()).not.toContain('download');
    expect(page).not.toContain('blob:');
  });

  it('homologacion tiene los cuatro tests y el fixture', () => {
    const page = read('./ArcaHomologacionPage.tsx');
    expect(page).toContain('data-testid="arcaIntegration.homologacion.root"');
    expect(page).toContain('arcaIntegration.homologacion.testWsaa');
    expect(page).toContain('arcaIntegration.homologacion.testWsfe');
    expect(page).toContain('arcaIntegration.homologacion.testWsfex');
    expect(page).toContain('arcaIntegration.homologacion.testPadron');
    expect(page).toContain('arcaIntegration.homologacion.autorizarFixture');
    expect(page).not.toContain('window.open');
  });
});
