import { useCallback, useMemo, useState } from 'react';
import Button from 'devextreme-react/button';
import LoadPanel from 'devextreme-react/load-panel';
import type { BuildPlatformHeadersInput } from '../../http/headers';
import {
  getArcaCaea,
  postArcaCaeaInformarSinMovimientos,
  postArcaCaeaObtener,
  postArcaComprobante,
  postArcaConectividad,
} from './arcaApiClient';
import { postArcaCaeaInformeFixture } from './arcaFixtureCaeaInforme';
import { buildArcaFacturaAFixture } from './arcaFixtureFacturaA';
import { translateArca } from './arcaI18n';
import type { ArcaServicio } from './arcaTypes';

export type ArcaHomologacionPageProps = {
  t?: (key: string) => string;
  canOperate?: boolean;
  platform?: BuildPlatformHeadersInput;
  accessToken?: string | null;
};

type Feedback = {
  respuesta: string;
  clasificacion?: string;
  detalle?: string;
  resultadoFuncional?: string;
};

function currentCaeaPeriodo(): { anio: number; mes: number; quincena: 1 | 2 } {
  const now = new Date();
  const anio = now.getFullYear();
  const mes = now.getMonth() + 1;
  const quincena: 1 | 2 = now.getDate() <= 15 ? 1 : 2;

  return { anio, mes, quincena };
}

export function ArcaHomologacionPage({
  t,
  canOperate = true,
  platform,
  accessToken,
}: ArcaHomologacionPageProps) {
  const translate = t ?? ((key: string) => translateArca('es', key));
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [caeaCodigo, setCaeaCodigo] = useState<string | null>(null);

  const requestOptions = useMemo(
    () => ({
      platform,
      headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : undefined,
    }),
    [accessToken, platform],
  );

  const applyEnvelopeFeedback = useCallback(
    (result: {
      kind: string;
      envelope?: { respuesta: string; resultado?: Record<string, unknown> };
      i18nKey?: string;
    }) => {
      if (result.kind === 'ok' && result.envelope) {
        const resultado = (result.envelope.resultado ?? {}) as Record<string, unknown>;
        setFeedback({
          respuesta: result.envelope.respuesta,
          clasificacion: typeof resultado.clasificacion === 'string' ? resultado.clasificacion : undefined,
          detalle: typeof resultado.detalle === 'string' ? resultado.detalle : undefined,
          resultadoFuncional:
            typeof resultado.resultadoFuncional === 'string'
              ? resultado.resultadoFuncional
              : typeof resultado.estado === 'string'
                ? resultado.estado
                : typeof resultado.codigo === 'string'
                  ? `caea:${resultado.codigo}`
                  : undefined,
        });
        if (typeof resultado.codigo === 'string' && resultado.codigo !== '') {
          setCaeaCodigo(resultado.codigo);
        }

        return;
      }
      if (result.kind === 'envelopeError' && result.envelope) {
        const resultado = (result.envelope.resultado ?? {}) as Record<string, unknown>;
        setFeedback({
          respuesta: result.envelope.respuesta,
          clasificacion: typeof resultado.clasificacion === 'string' ? resultado.clasificacion : undefined,
          detalle: typeof resultado.detalle === 'string' ? resultado.detalle : undefined,
          resultadoFuncional:
            typeof resultado.resultadoFuncional === 'string' ? resultado.resultadoFuncional : undefined,
        });

        return;
      }
      setFeedback({ respuesta: result.i18nKey ?? 'infra.transport' });
    },
    [],
  );

  const runConectividad = useCallback(
    async (servicio: ArcaServicio) => {
      if (!canOperate) {
        return;
      }
      setLoading(true);
      applyEnvelopeFeedback(await postArcaConectividad(servicio, requestOptions));
      setLoading(false);
    },
    [applyEnvelopeFeedback, canOperate, requestOptions],
  );

  const runFixture = useCallback(async () => {
    if (!canOperate) {
      return;
    }
    setLoading(true);
    applyEnvelopeFeedback(await postArcaComprobante(buildArcaFacturaAFixture(), requestOptions));
    setLoading(false);
  }, [applyEnvelopeFeedback, canOperate, requestOptions]);

  const runCaeaObtener = useCallback(async () => {
    if (!canOperate) {
      return;
    }
    setLoading(true);
    applyEnvelopeFeedback(await postArcaCaeaObtener(currentCaeaPeriodo(), requestOptions));
    setLoading(false);
  }, [applyEnvelopeFeedback, canOperate, requestOptions]);

  const runCaeaConsultar = useCallback(async () => {
    if (!canOperate) {
      return;
    }
    setLoading(true);
    applyEnvelopeFeedback(await getArcaCaea(currentCaeaPeriodo(), requestOptions));
    setLoading(false);
  }, [applyEnvelopeFeedback, canOperate, requestOptions]);

  const runCaeaSinMovimientos = useCallback(async () => {
    if (!canOperate) {
      return;
    }
    setLoading(true);
    applyEnvelopeFeedback(
      await postArcaCaeaInformarSinMovimientos(
        { ...currentCaeaPeriodo(), puntoVenta: 1 },
        requestOptions,
      ),
    );
    setLoading(false);
  }, [applyEnvelopeFeedback, canOperate, requestOptions]);

  const runCaeaInformarFixture = useCallback(async () => {
    if (!canOperate) {
      return;
    }
    setLoading(true);
    let codigo = caeaCodigo;
    if (!codigo) {
      const obtenido = await postArcaCaeaObtener(currentCaeaPeriodo(), requestOptions);
      if (obtenido.kind === 'ok' && typeof obtenido.envelope.resultado.codigo === 'string') {
        codigo = obtenido.envelope.resultado.codigo;
        setCaeaCodigo(codigo);
      } else {
        applyEnvelopeFeedback(obtenido);
        setLoading(false);

        return;
      }
    }
    const periodo = currentCaeaPeriodo();
    const result = await postArcaCaeaInformeFixture(
      {
        caeaCodigo: codigo,
        anio: periodo.anio,
        mes: periodo.mes,
        quincena: periodo.quincena,
        puntoVenta: 5,
      },
      requestOptions,
    );
    if (result.kind === 'ok') {
      const first = result.envelope.resultado.comprobantes?.[0] as
        | { resultadoFuncional?: string; arca?: { codigosOriginales?: string[] } }
        | undefined;
      setFeedback({
        respuesta: result.envelope.respuesta,
        resultadoFuncional: first?.resultadoFuncional,
        detalle: first?.arca?.codigosOriginales?.join(' | '),
      });
    } else {
      applyEnvelopeFeedback(result);
    }
    setLoading(false);
  }, [applyEnvelopeFeedback, caeaCodigo, canOperate, requestOptions]);

  if (!canOperate) {
    return (
      <section data-testid="arcaIntegration.homologacion.root">
        <p>{translate('arcaIntegration.homologacion.forbidden')}</p>
      </section>
    );
  }

  return (
    <section data-testid="arcaIntegration.homologacion.root">
      <LoadPanel visible={loading} showIndicator showPane />
      <h1>{translate('arcaIntegration.homologacion.root')}</h1>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
        <Button
          text={translate('arcaIntegration.homologacion.testWsaa')}
          onClick={() => void runConectividad('wsaa')}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.testWsaa' }}
        />
        <Button
          text={translate('arcaIntegration.homologacion.testWsfe')}
          onClick={() => void runConectividad('wsfe')}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.testWsfe' }}
        />
        <Button
          text={translate('arcaIntegration.homologacion.testWsfex')}
          onClick={() => void runConectividad('wsfex')}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.testWsfex' }}
        />
        <Button
          text={translate('arcaIntegration.homologacion.testPadron')}
          onClick={() => void runConectividad('padron')}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.testPadron' }}
        />
        <Button
          text={translate('arcaIntegration.homologacion.autorizarFixture')}
          type="default"
          onClick={() => void runFixture()}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.autorizarFixture' }}
        />
        <Button
          text={translate('arcaIntegration.homologacion.caeaObtener')}
          onClick={() => void runCaeaObtener()}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.caeaObtener' }}
        />
        <Button
          text={translate('arcaIntegration.homologacion.caeaConsultar')}
          onClick={() => void runCaeaConsultar()}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.caeaConsultar' }}
        />
        <Button
          text={translate('arcaIntegration.homologacion.caeaSinMovimientos')}
          onClick={() => void runCaeaSinMovimientos()}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.caeaSinMovimientos' }}
        />
        <Button
          text={translate('arcaIntegration.homologacion.caeaInformarFixture')}
          onClick={() => void runCaeaInformarFixture()}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.caeaInformarFixture' }}
        />
      </div>
      {caeaCodigo ? (
        <p data-testid="arcaIntegration.homologacion.caeaCodigo">
          {translate('arcaIntegration.homologacion.caeaCodigo')}: {caeaCodigo}
        </p>
      ) : null}
      {feedback ? (
        <div data-testid="arcaIntegration.homologacion.resultado">
          <p>{translate(feedback.respuesta)}</p>
          {feedback.clasificacion ? (
            <p>
              {translate('arcaIntegration.homologacion.clasificacion')}: {feedback.clasificacion}
            </p>
          ) : null}
          {feedback.detalle ? (
            <p data-testid="arcaIntegration.homologacion.detalle">{feedback.detalle}</p>
          ) : null}
          {feedback.resultadoFuncional ? <p>{feedback.resultadoFuncional}</p> : null}
        </div>
      ) : null}
    </section>
  );
}
