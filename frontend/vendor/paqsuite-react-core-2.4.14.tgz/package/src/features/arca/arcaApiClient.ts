import { apiRequest, type ApiRequestOptions } from '../../http/apiClient';
import type {
  ArcaAutorizacionResult,
  ArcaCertificadoBody,
  ArcaConectividadResult,
  ArcaConfigDto,
  ArcaServicio,
} from './arcaTypes';

export const arcaBasePath = '/api/v1/arca';

type RequestOverrides = Pick<ApiRequestOptions, 'platform' | 'signal' | 'headers'>;

export function getArcaConfig(options: RequestOverrides = {}) {
  return apiRequest<ArcaConfigDto>(`${arcaBasePath}/config`, {
    method: 'GET',
    ...options,
  });
}

export function putArcaConfig(
  body: Omit<ArcaConfigDto, 'hasCertificate'>,
  options: RequestOverrides = {},
) {
  return apiRequest<ArcaConfigDto>(`${arcaBasePath}/config`, {
    method: 'PUT',
    body: JSON.stringify(body),
    ...options,
  });
}

export function postArcaCertificate(body: ArcaCertificadoBody, options: RequestOverrides = {}) {
  return apiRequest<{ hasCertificate: true }>(`${arcaBasePath}/config/certificado`, {
    method: 'POST',
    body: JSON.stringify(body),
    ...options,
  });
}

export function postArcaConectividad(servicio: ArcaServicio, options: RequestOverrides = {}) {
  return apiRequest<ArcaConectividadResult>(`${arcaBasePath}/conectividad`, {
    method: 'POST',
    body: JSON.stringify({ servicio }),
    ...options,
  });
}

export function postArcaComprobante(
  body: Record<string, unknown>,
  options: RequestOverrides = {},
) {
  return apiRequest<ArcaAutorizacionResult>(`${arcaBasePath}/comprobantes`, {
    method: 'POST',
    body: JSON.stringify(body),
    ...options,
  });
}

export type ArcaCaeaPeriodo = { anio: number; mes: number; quincena: 1 | 2 };

export type ArcaCaeaDto = {
  codigo: string | null;
  estado: string;
  periodo: ArcaCaeaPeriodo;
  caea?: string;
  puntoVenta?: number;
};

export function postArcaCaeaObtener(body: ArcaCaeaPeriodo, options: RequestOverrides = {}) {
  return apiRequest<ArcaCaeaDto>(`${arcaBasePath}/caea/obtener`, {
    method: 'POST',
    body: JSON.stringify(body),
    ...options,
  });
}

export function getArcaCaea(periodo: ArcaCaeaPeriodo, options: RequestOverrides = {}) {
  const query = new URLSearchParams({
    anio: String(periodo.anio),
    mes: String(periodo.mes),
    quincena: String(periodo.quincena),
  });

  return apiRequest<ArcaCaeaDto>(`${arcaBasePath}/caea?${query.toString()}`, {
    method: 'GET',
    ...options,
  });
}

export function postArcaCaeaInformarSinMovimientos(
  body: ArcaCaeaPeriodo & { puntoVenta?: number },
  options: RequestOverrides = {},
) {
  return apiRequest<ArcaCaeaDto>(`${arcaBasePath}/caea/informar-sin-movimientos`, {
    method: 'POST',
    body: JSON.stringify(body),
    ...options,
  });
}

export function postArcaCaeaInformarComprobantes(
  body: { periodo: ArcaCaeaPeriodo; comprobantes: Record<string, unknown>[] },
  options: RequestOverrides = {},
) {
  return apiRequest<{ comprobantes: ArcaAutorizacionResult[] }>(
    `${arcaBasePath}/caea/informar-comprobantes`,
    {
      method: 'POST',
      body: JSON.stringify(body),
      ...options,
    },
  );
}
