export type ArcaAmbiente = 'homologacion' | 'produccion';

export type ArcaServicio = 'wsaa' | 'wsfe' | 'wsfex' | 'padron';

export type ArcaUrls = {
  wsaa: string;
  wsfe: string;
  wsfex: string;
  padron: string;
};

export type ArcaConfigDto = {
  ambiente: ArcaAmbiente;
  cuit: string;
  urls: ArcaUrls;
  timeoutSeconds: number;
  fceUmbralImporte: string;
  hasCertificate: boolean;
};

export type ArcaCertificadoUploadMode = 'pkcs12' | 'crtKey';

export type ArcaCertificadoPkcs12Body = {
  pkcs12Base64: string;
  passphrase: string;
};

export type ArcaCertificadoCrtKeyBody = {
  certificadoPem?: string;
  certificadoPemBase64?: string;
  clavePrivadaPem?: string;
  clavePrivadaPemBase64?: string;
  passphraseClave?: string;
  passphraseContenedor: string;
};

export type ArcaCertificadoBody = ArcaCertificadoPkcs12Body | ArcaCertificadoCrtKeyBody;

export type ArcaConectividadResult = {
  servicio: ArcaServicio;
  clasificacion: string;
  ambiente: string;
  detalle?: string;
};

export type ArcaAutorizacionResult = {
  solicitudId?: string;
  resultadoFuncional?: string;
  circuitoDeterminado?: string;
  cae?: string | null;
  [key: string]: unknown;
};

/** Mirror FE del catálogo `resources/arca/ambiente-defaults.json` (laravel-core). */
export const arcaHomologacionUrls: ArcaUrls = {
  wsaa: 'https://wsaahomo.afip.gov.ar/ws/services/LoginCms',
  wsfe: 'https://wswhomo.afip.gov.ar/wsfev1/service.asmx',
  wsfex: 'https://wswhomo.afip.gov.ar/wsfexv1/service.asmx',
  padron: 'https://awshomo.afip.gov.ar/sr-padron/webservices/personaServiceA5',
};

export const arcaProduccionUrls: ArcaUrls = {
  wsaa: 'https://wsaa.afip.gov.ar/ws/services/LoginCms',
  wsfe: 'https://servicios1.afip.gov.ar/wsfev1/service.asmx',
  wsfex: 'https://servicios1.afip.gov.ar/wsfexv1/service.asmx',
  padron: 'https://aws.afip.gov.ar/sr-padron/webservices/personaServiceA5',
};

export function arcaDefaultUrlsForAmbiente(ambiente: ArcaAmbiente): ArcaUrls {
  return ambiente === 'produccion' ? { ...arcaProduccionUrls } : { ...arcaHomologacionUrls };
}

export const arcaEmptyConfig = (): ArcaConfigDto => ({
  ambiente: 'homologacion',
  cuit: '',
  urls: arcaDefaultUrlsForAmbiente('homologacion'),
  timeoutSeconds: 60,
  fceUmbralImporte: '0',
  hasCertificate: false,
});
