/**
 * @vitest-environment jsdom
 */
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { ArcaConfigDto } from './arcaTypes';

const { putArcaConfig, postArcaCertificate } = vi.hoisted(() => {
  const putArcaConfig = vi.fn();
  const postArcaCertificate = vi.fn();
  return { putArcaConfig, postArcaCertificate };
});

vi.mock('./arcaApiClient', () => ({
  putArcaConfig,
  postArcaCertificate,
}));

vi.mock('devextreme-react/load-panel', () => ({
  default: () => null,
}));

vi.mock('devextreme-react/form', () => ({
  default: () => null,
  GroupItem: () => null,
  SimpleItem: () => null,
}));

vi.mock('devextreme-react/select-box', () => ({
  default: (props: {
    value?: string;
    dataSource?: Array<{ value: string; text: string }>;
    elementAttr?: Record<string, string>;
    onValueChanged?: (event: { value: string }) => void;
  }) => (
    <select
      data-testid={props.elementAttr?.['data-testid']}
      value={props.value ?? ''}
      onChange={(event) => props.onValueChanged?.({ value: event.target.value })}
    >
      {(props.dataSource ?? []).map((item) => (
        <option key={item.value} value={item.value}>
          {item.text}
        </option>
      ))}
    </select>
  ),
}));

vi.mock('devextreme-react/file-uploader', () => ({
  default: (props: { elementAttr?: Record<string, string> }) => (
    <div data-testid={props.elementAttr?.['data-testid']} />
  ),
}));

vi.mock('devextreme-react/text-box', () => ({
  default: (props: {
    value?: string;
    mode?: string;
    elementAttr?: Record<string, string>;
    placeholder?: string;
  }) => (
    <input
      type={props.mode === 'password' ? 'password' : 'text'}
      data-testid={props.elementAttr?.['data-testid']}
      value={props.value ?? ''}
      placeholder={props.placeholder}
      readOnly
    />
  ),
}));

vi.mock('devextreme-react/button', () => ({
  default: (props: {
    text?: string;
    onClick?: () => void;
    elementAttr?: Record<string, string>;
  }) => (
    <button type="button" data-testid={props.elementAttr?.['data-testid']} onClick={props.onClick}>
      {props.text}
    </button>
  ),
}));

vi.mock('devextreme-react/popup', () => ({
  default: (props: {
    visible?: boolean;
    wrapperAttr?: Record<string, string>;
    children?: React.ReactNode;
  }) =>
    props.visible ? (
      <div data-testid={props.wrapperAttr?.['data-testid']}>{props.children}</div>
    ) : null,
}));

import { ArcaConfigPage } from './ArcaConfigPage';

const savedConfig: ArcaConfigDto = {
  ambiente: 'homologacion',
  cuit: '20111111101',
  urls: {
    wsaa: 'https://wsaahomo.afip.gov.ar/ws/services/LoginCms',
    wsfe: 'https://wswhomo.afip.gov.ar/wsfev1/service.asmx',
    wsfex: 'https://wswhomo.afip.gov.ar/wsfexv1/service.asmx',
    padron: 'https://awshomo.afip.gov.ar/sr-padron/webservices/personaServiceA5',
  },
  timeoutSeconds: 60,
  fceUmbralImporte: '0',
  hasCertificate: true,
};

describe('ArcaConfigPage', () => {
  afterEach(() => {
    cleanup();
  });

  beforeEach(() => {
    putArcaConfig.mockReset();
    postArcaCertificate.mockReset();
    putArcaConfig.mockResolvedValue({
      kind: 'ok',
      httpStatus: 200,
      envelope: { error: 0, respuesta: 'ok', resultado: savedConfig },
    });
  });

  it('muestra root, save, certificado y passphrase; no llama API al entrar', () => {
    render(<ArcaConfigPage />);
    expect(screen.getByTestId('arcaIntegration.config.root')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.config.save')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.config.mode')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.config.certificate')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.config.passphrase')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.config.hasCertificate').textContent).toContain(
      'Sin certificado',
    );
    expect(screen.queryByTestId('arcaIntegration.config.feedback')).toBeNull();
    expect(screen.queryByTestId('arcaIntegration.config.certificateCrt')).toBeNull();
    expect(document.body.textContent).not.toContain('pkcs12');
    expect(document.body.textContent).not.toContain('MIIG');
    expect(document.body.textContent?.toLowerCase()).not.toContain('download');
    expect(putArcaConfig).not.toHaveBeenCalled();
  });

  it('modo CRT+KEY muestra uploaders y passphrase de contenedor', () => {
    render(<ArcaConfigPage />);
    fireEvent.change(screen.getByTestId('arcaIntegration.config.mode'), {
      target: { value: 'crtKey' },
    });
    expect(screen.getByTestId('arcaIntegration.config.certificateCrt')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.config.certificateKey')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.config.passphraseContenedor')).toBeTruthy();
    expect(screen.queryByTestId('arcaIntegration.config.certificate')).toBeNull();
  });

  it('al guardar llama PUT config y muestra popup de resultado', async () => {
    render(<ArcaConfigPage />);
    fireEvent.click(screen.getByTestId('arcaIntegration.config.save'));
    await waitFor(() => expect(putArcaConfig).toHaveBeenCalledTimes(1));
    const body = putArcaConfig.mock.calls[0][0] as { cuit: string; hasCertificate?: boolean };
    expect(body.cuit).toBe('');
    expect(body.hasCertificate).toBeUndefined();
    expect(postArcaCertificate).not.toHaveBeenCalled();
    await waitFor(() => {
      expect(screen.getByTestId('arcaIntegration.config.feedback')).toBeTruthy();
      expect(screen.getByTestId('arcaIntegration.config.feedbackMessage').textContent).toContain(
        'OK',
      );
    });
  });

  it('sin permiso configurar no muta secretos', () => {
    render(<ArcaConfigPage canConfigure={false} />);
    expect(screen.queryByTestId('arcaIntegration.config.save')).toBeNull();
    expect(screen.queryByTestId('arcaIntegration.config.passphrase')).toBeNull();
    expect(putArcaConfig).not.toHaveBeenCalled();
  });
});

describe('arcaDefaultUrlsForAmbiente', () => {
  it('devuelve defaults de producción distintos de homologación', async () => {
    const { arcaDefaultUrlsForAmbiente, arcaHomologacionUrls, arcaProduccionUrls } =
      await import('./arcaTypes');
    expect(arcaDefaultUrlsForAmbiente('homologacion')).toEqual(arcaHomologacionUrls);
    expect(arcaDefaultUrlsForAmbiente('produccion')).toEqual(arcaProduccionUrls);
    expect(arcaDefaultUrlsForAmbiente('produccion').wsaa).not.toBe(arcaHomologacionUrls.wsaa);
  });
});
