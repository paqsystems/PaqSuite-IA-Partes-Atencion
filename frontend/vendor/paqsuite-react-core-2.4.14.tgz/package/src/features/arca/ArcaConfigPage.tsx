import { useCallback, useMemo, useState } from 'react';
import Button from 'devextreme-react/button';
import FileUploader from 'devextreme-react/file-uploader';
import Form, { GroupItem, SimpleItem } from 'devextreme-react/form';
import LoadPanel from 'devextreme-react/load-panel';
import Popup from 'devextreme-react/popup';
import SelectBox from 'devextreme-react/select-box';
import TextBox from 'devextreme-react/text-box';
import type { BuildPlatformHeadersInput } from '../../http/headers';
import { postArcaCertificate, putArcaConfig } from './arcaApiClient';
import { translateArca } from './arcaI18n';
import {
  arcaDefaultUrlsForAmbiente,
  arcaEmptyConfig,
  type ArcaAmbiente,
  type ArcaCertificadoBody,
  type ArcaCertificadoUploadMode,
  type ArcaConfigDto,
} from './arcaTypes';

export type ArcaConfigPageProps = {
  t?: (key: string) => string;
  canConfigure?: boolean;
  platform?: BuildPlatformHeadersInput;
  accessToken?: string | null;
};

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result ?? '');
      const comma = result.indexOf(',');
      resolve(comma >= 0 ? result.slice(comma + 1) : result);
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function fileToText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ''));
    reader.onerror = () => reject(reader.error);
    reader.readAsText(file);
  });
}

export function ArcaConfigPage({
  t,
  canConfigure = true,
  platform,
  accessToken,
}: ArcaConfigPageProps) {
  const translate = t ?? ((key: string) => translateArca('es', key));
  const [form, setForm] = useState<ArcaConfigDto>(arcaEmptyConfig);
  const [certificateMode, setCertificateMode] = useState<ArcaCertificadoUploadMode>('pkcs12');
  const [passphrase, setPassphrase] = useState('');
  const [pkcs12Base64, setPkcs12Base64] = useState('');
  const [certificadoPem, setCertificadoPem] = useState('');
  const [clavePrivadaPem, setClavePrivadaPem] = useState('');
  const [passphraseClave, setPassphraseClave] = useState('');
  const [passphraseContenedor, setPassphraseContenedor] = useState('');
  const [loading, setLoading] = useState(false);
  const [feedbackKey, setFeedbackKey] = useState<string | null>(null);

  const requestOptions = useMemo(
    () => ({
      platform,
      headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : undefined,
    }),
    [accessToken, platform],
  );

  const modeItems = useMemo(
    () => [
      { value: 'pkcs12' as const, text: translate('arcaIntegration.config.modePkcs12') },
      { value: 'crtKey' as const, text: translate('arcaIntegration.config.modeCrtKey') },
    ],
    [translate],
  );

  const closeFeedback = useCallback(() => {
    setFeedbackKey(null);
  }, []);

  const clearCertificateInputs = useCallback(() => {
    setPassphrase('');
    setPkcs12Base64('');
    setCertificadoPem('');
    setClavePrivadaPem('');
    setPassphraseClave('');
    setPassphraseContenedor('');
  }, []);

  const patchForm = useCallback((field: string, value: unknown) => {
    setForm((current) => {
      if (field.startsWith('urls.')) {
        const urlKey = field.slice(5) as keyof ArcaConfigDto['urls'];
        return { ...current, urls: { ...current.urls, [urlKey]: String(value ?? '') } };
      }
      if (field === 'timeoutSeconds') {
        return { ...current, timeoutSeconds: Number(value) || 0 };
      }
      if (field === 'ambiente') {
        const nextAmbiente = value as ArcaAmbiente;
        if (nextAmbiente !== 'homologacion' && nextAmbiente !== 'produccion') {
          return current;
        }
        if (nextAmbiente === current.ambiente) {
          return current;
        }
        // Al cambiar ambiente, reponer URLs default del catálogo (el usuario puede editarlas).
        return {
          ...current,
          ambiente: nextAmbiente,
          urls: arcaDefaultUrlsForAmbiente(nextAmbiente),
        };
      }
      if (field === 'cuit' || field === 'fceUmbralImporte') {
        return { ...current, [field]: value as never };
      }
      return current;
    });
  }, []);

  const buildCertificateBody = useCallback((): ArcaCertificadoBody | null => {
    if (certificateMode === 'pkcs12') {
      if (pkcs12Base64 === '' || passphrase === '') {
        return null;
      }
      return { pkcs12Base64, passphrase };
    }
    if (certificadoPem === '' || clavePrivadaPem === '') {
      return null;
    }
    return {
      certificadoPem,
      clavePrivadaPem,
      passphraseContenedor,
      ...(passphraseClave !== '' ? { passphraseClave } : {}),
    };
  }, [
    certificateMode,
    certificadoPem,
    clavePrivadaPem,
    passphrase,
    passphraseClave,
    passphraseContenedor,
    pkcs12Base64,
  ]);

  const save = useCallback(async () => {
    if (!canConfigure) {
      return;
    }
    setLoading(true);
    const result = await putArcaConfig(
      {
        ambiente: form.ambiente,
        cuit: form.cuit,
        urls: form.urls,
        timeoutSeconds: form.timeoutSeconds,
        fceUmbralImporte: form.fceUmbralImporte,
      },
      requestOptions,
    );
    if (result.kind === 'ok') {
      setForm((current) => ({ ...current, ...result.envelope.resultado }));
      let nextFeedback = result.envelope.respuesta;
      const certificateBody = buildCertificateBody();
      if (certificateBody !== null) {
        const cert = await postArcaCertificate(certificateBody, requestOptions);
        if (cert.kind === 'ok') {
          setForm((current) => ({ ...current, hasCertificate: true }));
          clearCertificateInputs();
          nextFeedback = cert.envelope.respuesta;
        } else if (cert.kind === 'envelopeError') {
          nextFeedback = cert.envelope.respuesta;
        } else {
          nextFeedback = cert.i18nKey;
        }
      }
      setFeedbackKey(nextFeedback);
    } else if (result.kind === 'envelopeError') {
      setFeedbackKey(result.envelope.respuesta);
    } else {
      setFeedbackKey(result.i18nKey);
    }
    setLoading(false);
  }, [
    buildCertificateBody,
    canConfigure,
    clearCertificateInputs,
    form,
    requestOptions,
  ]);

  if (!canConfigure) {
    return (
      <section data-testid="arcaIntegration.config.root">
        <p>{translate('arcaIntegration.config.forbidden')}</p>
      </section>
    );
  }

  return (
    <section data-testid="arcaIntegration.config.root">
      <LoadPanel visible={loading} showIndicator showPane />
      <h1>{translate('arcaIntegration.config.root')}</h1>
      <Form
        formData={form}
        colCount={2}
        labelLocation="top"
        onFieldDataChanged={(event) => {
          if (event.dataField) {
            patchForm(event.dataField, event.value);
          }
        }}
      >
        <GroupItem colCount={2}>
          <SimpleItem
            dataField="ambiente"
            editorType="dxSelectBox"
            label={{ text: translate('arcaIntegration.config.ambiente') }}
            editorOptions={{
              items: ['homologacion', 'produccion'],
              elementAttr: { 'data-testid': 'arcaIntegration.config.ambiente' },
            }}
          />
          <SimpleItem
            dataField="cuit"
            editorType="dxTextBox"
            label={{ text: translate('arcaIntegration.config.cuit') }}
            editorOptions={{
              elementAttr: { 'data-testid': 'arcaIntegration.config.cuit' },
            }}
          />
          <SimpleItem
            dataField="timeoutSeconds"
            editorType="dxNumberBox"
            label={{ text: translate('arcaIntegration.config.timeout') }}
            editorOptions={{
              min: 10,
              max: 180,
              elementAttr: { 'data-testid': 'arcaIntegration.config.timeout' },
            }}
          />
          <SimpleItem
            dataField="fceUmbralImporte"
            editorType="dxTextBox"
            label={{ text: translate('arcaIntegration.config.fceUmbral') }}
            editorOptions={{
              elementAttr: { 'data-testid': 'arcaIntegration.config.fceUmbral' },
            }}
          />
          <SimpleItem
            dataField="urls.wsaa"
            editorType="dxTextBox"
            label={{ text: translate('arcaIntegration.config.urlWsaa') }}
            editorOptions={{
              elementAttr: { 'data-testid': 'arcaIntegration.config.urlWsaa' },
            }}
          />
          <SimpleItem
            dataField="urls.wsfe"
            editorType="dxTextBox"
            label={{ text: translate('arcaIntegration.config.urlWsfe') }}
            editorOptions={{
              elementAttr: { 'data-testid': 'arcaIntegration.config.urlWsfe' },
            }}
          />
          <SimpleItem
            dataField="urls.wsfex"
            editorType="dxTextBox"
            label={{ text: translate('arcaIntegration.config.urlWsfex') }}
            editorOptions={{
              elementAttr: { 'data-testid': 'arcaIntegration.config.urlWsfex' },
            }}
          />
          <SimpleItem
            dataField="urls.padron"
            editorType="dxTextBox"
            label={{ text: translate('arcaIntegration.config.urlPadron') }}
            editorOptions={{
              elementAttr: { 'data-testid': 'arcaIntegration.config.urlPadron' },
            }}
          />
        </GroupItem>
      </Form>
      <p data-testid="arcaIntegration.config.hasCertificate">
        {form.hasCertificate
          ? translate('arcaIntegration.config.hasCertificate')
          : translate('arcaIntegration.config.noCertificate')}
      </p>
      <SelectBox
        dataSource={modeItems}
        displayExpr="text"
        valueExpr="value"
        value={certificateMode}
        onValueChanged={(event) => {
          const next = event.value as ArcaCertificadoUploadMode;
          setCertificateMode(next);
          clearCertificateInputs();
        }}
        elementAttr={{ 'data-testid': 'arcaIntegration.config.mode' }}
      />
      {certificateMode === 'pkcs12' ? (
        <>
          <FileUploader
            accept=".p12,.pfx,application/x-pkcs12"
            uploadMode="useForm"
            showFileList
            labelText={translate('arcaIntegration.config.certificate')}
            elementAttr={{ 'data-testid': 'arcaIntegration.config.certificate' }}
            onValueChanged={(event) => {
              const files = (event.value as File[] | undefined) ?? [];
              const file = files[0];
              if (!file) {
                setPkcs12Base64('');
                return;
              }
              void fileToBase64(file).then(setPkcs12Base64);
            }}
          />
          <TextBox
            value={passphrase}
            mode="password"
            onValueChanged={(event) => setPassphrase(String(event.value ?? ''))}
            placeholder={translate('arcaIntegration.config.passphrase')}
            inputAttr={{ autoComplete: 'new-password', name: 'arcaCertificatePassphrase' }}
            elementAttr={{ 'data-testid': 'arcaIntegration.config.passphrase' }}
          />
        </>
      ) : (
        <>
          <FileUploader
            accept=".crt,.pem,.cer,application/x-x509-ca-cert,application/pkix-cert"
            uploadMode="useForm"
            showFileList
            labelText={translate('arcaIntegration.config.certificateCrt')}
            elementAttr={{ 'data-testid': 'arcaIntegration.config.certificateCrt' }}
            onValueChanged={(event) => {
              const files = (event.value as File[] | undefined) ?? [];
              const file = files[0];
              if (!file) {
                setCertificadoPem('');
                return;
              }
              void fileToText(file).then(setCertificadoPem);
            }}
          />
          <FileUploader
            accept=".key,.pem,application/pkcs8"
            uploadMode="useForm"
            showFileList
            labelText={translate('arcaIntegration.config.certificateKey')}
            elementAttr={{ 'data-testid': 'arcaIntegration.config.certificateKey' }}
            onValueChanged={(event) => {
              const files = (event.value as File[] | undefined) ?? [];
              const file = files[0];
              if (!file) {
                setClavePrivadaPem('');
                return;
              }
              void fileToText(file).then(setClavePrivadaPem);
            }}
          />
          <TextBox
            value={passphraseClave}
            mode="password"
            onValueChanged={(event) => setPassphraseClave(String(event.value ?? ''))}
            placeholder={translate('arcaIntegration.config.passphraseClave')}
            inputAttr={{ autoComplete: 'new-password', name: 'arcaCertificateKeyPassphrase' }}
            elementAttr={{ 'data-testid': 'arcaIntegration.config.passphraseClave' }}
          />
          <TextBox
            value={passphraseContenedor}
            mode="password"
            onValueChanged={(event) => setPassphraseContenedor(String(event.value ?? ''))}
            placeholder={translate('arcaIntegration.config.passphraseContenedor')}
            inputAttr={{ autoComplete: 'new-password', name: 'arcaCertificateContainerPassphrase' }}
            elementAttr={{ 'data-testid': 'arcaIntegration.config.passphraseContenedor' }}
          />
        </>
      )}
      <Button
        text={translate('arcaIntegration.config.save')}
        type="default"
        onClick={() => void save()}
        elementAttr={{ 'data-testid': 'arcaIntegration.config.save' }}
      />
      <Popup
        visible={feedbackKey !== null}
        onHiding={closeFeedback}
        showTitle
        showCloseButton
        dragEnabled={false}
        hideOnOutsideClick
        title={translate('arcaIntegration.config.feedbackTitle')}
        width={420}
        height="auto"
        wrapperAttr={{ 'data-testid': 'arcaIntegration.config.feedback' }}
      >
        <p data-testid="arcaIntegration.config.feedbackMessage">
          {feedbackKey ? translate(feedbackKey) : ''}
        </p>
        <Button
          text={translate('arcaIntegration.config.feedbackAccept')}
          type="default"
          onClick={closeFeedback}
          elementAttr={{ 'data-testid': 'arcaIntegration.config.feedbackAccept' }}
        />
      </Popup>
    </section>
  );
}
