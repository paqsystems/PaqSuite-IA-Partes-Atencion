import { useCallback, useState } from 'react';
import Button from 'devextreme-react/button';
import { useExcelImport } from './useExcelImport';
import { ExcelImportModal } from './ExcelImportModal';
import { downloadBlob } from './downloadBlob';
import type { ExcelImportCompletePayload } from './types';

export type ExcelImportToolbarProps = {
  processCode: string;
  onComplete: (payload: ExcelImportCompletePayload) => void;
  disabled?: boolean;
  showTemplateButton?: boolean;
  sheetName?: string;
  /** Gate de capacidad host (`ExcelImportEnabled`). Si false → no se ofrece. */
  capabilityEnabled?: boolean;
  t?: (key: string) => string;
};

/**
 * Toolbar embebido de importación Excel (GEN-14): Descargar plantilla | Importar.
 * Se oculta (`null`) si el host desactivó la capacidad (`ExcelImportEnabled=No`).
 * Excluido en mobile por policy del host (no se monta en native).
 *
 * MUST layout (host): montar este componente en una **fila propia** de la pantalla —
 * nunca en la misma fila/flex que filtros, título u otros controles. El root fuerza
 * `width: 100%` y `flex-basis: 100%` para ocupar toda la línea cuando el padre es flex con wrap.
 *
 * Tras Procesar con `done` / `partial` / `queued`, el modal se cierra solo (TR: queued
 * inmediato; UX sync: no dejar el resumen bloqueando). En `failed` permanece abierto.
 */
export function ExcelImportToolbar({
  processCode,
  onComplete,
  disabled,
  showTemplateButton = true,
  sheetName,
  capabilityEnabled = true,
  t,
}: ExcelImportToolbarProps) {
  const translate = t ?? ((key: string) => key);
  const [modalOpen, setModalOpen] = useState(false);

  const handleComplete = useCallback(
    (payload: ExcelImportCompletePayload) => {
      onComplete(payload);
      if (
        payload.status === 'done' ||
        payload.status === 'partial' ||
        payload.status === 'queued'
      ) {
        setModalOpen(false);
      }
    },
    [onComplete],
  );

  const importState = useExcelImport({
    processCode,
    onComplete: handleComplete,
    sheetName,
  });

  if (!capabilityEnabled) {
    return null;
  }

  const handleTemplate = () => {
    void importState
      .getTemplate()
      .then((blob) => {
        downloadBlob(blob, `${processCode}-plantilla.xlsx`);
      })
      .catch(() => {
        window.alert(translate('excelImport.templateError'));
      });
  };

  return (
    <div
      data-testid="excelImport.toolbar"
      className="excel-import-toolbar"
      style={{
        display: 'flex',
        flexWrap: 'wrap',
        gap: 8,
        width: '100%',
        flexBasis: '100%',
        flexGrow: 0,
        flexShrink: 0,
        alignSelf: 'stretch',
        boxSizing: 'border-box',
        marginTop: 8,
        marginBottom: 8,
      }}
    >
      {showTemplateButton ? (
        <Button
          text={translate('excelImport.template')}
          icon="download"
          disabled={disabled}
          onClick={handleTemplate}
          elementAttr={{ 'data-testid': 'excelImport.template' }}
        />
      ) : null}
      <Button
        text={translate('excelImport.import')}
        icon="upload"
        type="default"
        stylingMode="contained"
        disabled={disabled}
        onClick={() => {
          importState.reset();
          setModalOpen(true);
        }}
        elementAttr={{ 'data-testid': 'excelImport.import' }}
      />
      <ExcelImportModal
        visible={modalOpen}
        onClose={() => setModalOpen(false)}
        importState={importState}
        processCode={processCode}
        t={t}
      />
    </div>
  );
}
