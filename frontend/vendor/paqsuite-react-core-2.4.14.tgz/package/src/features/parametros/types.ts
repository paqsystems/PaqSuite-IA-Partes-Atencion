export type ParametroTipoValor = 'S' | 'T' | 'I' | 'N' | 'D' | 'B' | 'F';

export type ParametroListItem = {
  programa: string;
  clave: string;
  tipoValor: ParametroTipoValor;
  valor: string | number | boolean | null;
  caption: string;
  tooltip: string | null;
  precisionFecha?: 'date' | 'datetime';
  meta?: {
    enum?: string[];
    lookup?: {
      lookupId: string;
      valueField?: string;
      labelField?: string;
      search?: boolean;
      pageSize?: number;
    };
  };
};

export type ParametroPatchBody = {
  programa: string;
  valor: string | number | boolean | null;
};

export type ParametroValue = string | number | boolean | null;

export type ParametroLookupDefinition = {
  lookupId: string;
  valueField?: string;
  labelField?: string;
  search?: boolean;
  pageSize?: number;
};

export type LookupOption = {
  value: string | number;
  label: string;
};

export type ParametrosLookupApi = {
  list: (
    lookup: ParametroLookupDefinition,
    query?: string,
  ) => Promise<LookupOption[]>;
};

export type ParametrosApi = {
  list: (programa: string) => Promise<ParametroListItem[]>;
  update: (
    programa: string,
    clave: string,
    valor: ParametroValue
  ) => Promise<ParametroListItem>;
};
