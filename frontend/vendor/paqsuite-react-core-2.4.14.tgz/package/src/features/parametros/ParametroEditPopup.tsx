import { useEffect, useMemo, useState } from 'react';
import Popup from 'devextreme-react/popup';
import Button from 'devextreme-react/button';
import CheckBox from 'devextreme-react/check-box';
import NumberBox from 'devextreme-react/number-box';
import TextBox from 'devextreme-react/text-box';
import TextArea from 'devextreme-react/text-area';
import SelectBox from 'devextreme-react/select-box';
import DateBox from 'devextreme-react/date-box';
import { patchParametro, type RequestOverrides } from './parametrosApi';
import {
  mapEnvelopeErrorToI18nKey,
  resolveParametroCaption,
  resolveParametroTextValor,
  resolveParametroTooltip,
} from './parametroDisplay';
import type { ParametroListItem } from './types';

export type ParametroEditPopupProps = {
  visible: boolean;
  item: ParametroListItem;
  onCancel: () => void;
  onSaved: () => void;
  t: (key: string) => string;
  requestOptions?: RequestOverrides;
};

type EnumOption = { value: string; text: string };

export function ParametroEditPopup({
  visible,
  item,
  onCancel,
  onSaved,
  t,
  requestOptions = {},
}: ParametroEditPopupProps) {
  const [draft, setDraft] = useState<string | number | boolean | null>(item.valor);
  const [saving, setSaving] = useState(false);
  const [errorKey, setErrorKey] = useState<string | null>(null);

  const caption = useMemo(() => resolveParametroCaption(item, t), [item, t]);
  const tooltip = useMemo(() => resolveParametroTooltip(item, t), [item, t]);

  const enumOptions = useMemo((): EnumOption[] => {
    return (item.meta?.enum ?? []).map((value) => ({
      value,
      text: resolveParametroTextValor(item.programa, item.clave, value, t),
    }));
  }, [item.clave, item.meta?.enum, item.programa, t]);

  useEffect(() => {
    setDraft(item.valor);
    setErrorKey(null);
  }, [item]);

  const handleSave = async () => {
    setSaving(true);
    setErrorKey(null);
    const result = await patchParametro(
      item.clave,
      {
        programa: item.programa,
        valor: draft,
      },
      requestOptions,
    );
    setSaving(false);
    if (result.kind === 'ok') {
      onSaved();
      return;
    }
    if (result.kind === 'envelopeError') {
      setErrorKey(mapEnvelopeErrorToI18nKey(result.envelope.respuesta));
      return;
    }
    setErrorKey(result.i18nKey || 'parametros.modal.error.validationFailed');
  };

  const valueLabel = t('parametros.list.valor');

  return (
    <Popup
      visible={visible}
      showCloseButton
      onHiding={onCancel}
      width={480}
      height="auto"
      dragEnabled
      shading
      wrapperAttr={{ class: 'pqParametrosModal', 'data-testid': 'parametros.modal' }}
      titleRender={() => (
        <div className="pqParametrosModalHeader">
          <div className="pqParametrosModalTitle">{caption}</div>
          {tooltip ? <div className="pqParametrosModalTooltip">{tooltip}</div> : null}
        </div>
      )}
    >
      <div className="pqParametrosModalBody">
        {item.tipoValor === 'B' ? (
          <CheckBox
            text={caption}
            value={Boolean(draft)}
            onValueChanged={(e) => setDraft(Boolean(e.value))}
            elementAttr={{ 'data-testid': 'parametros.editor' }}
          />
        ) : null}
        {item.tipoValor === 'I' || item.tipoValor === 'D' ? (
          <NumberBox
            label={valueLabel}
            labelMode="floating"
            stylingMode="outlined"
            value={typeof draft === 'number' ? draft : Number(draft ?? 0)}
            onValueChanged={(e) => setDraft(e.value ?? null)}
            showSpinButtons
            elementAttr={{ 'data-testid': 'parametros.editor' }}
          />
        ) : null}
        {item.tipoValor === 'S' && enumOptions.length > 0 ? (
          <SelectBox
            label={valueLabel}
            labelMode="floating"
            stylingMode="outlined"
            items={enumOptions}
            valueExpr="value"
            displayExpr="text"
            value={typeof draft === 'string' ? draft : String(draft ?? '')}
            onValueChanged={(e) => setDraft(e.value ?? null)}
            searchEnabled={enumOptions.length > 8}
            elementAttr={{ 'data-testid': 'parametros.editor' }}
          />
        ) : null}
        {item.tipoValor === 'S' && enumOptions.length === 0 ? (
          <TextBox
            label={valueLabel}
            labelMode="floating"
            stylingMode="outlined"
            value={typeof draft === 'string' ? draft : String(draft ?? '')}
            onValueChanged={(e) => setDraft(e.value ?? '')}
            elementAttr={{ 'data-testid': 'parametros.editor' }}
          />
        ) : null}
        {item.tipoValor === 'T' ? (
          <TextArea
            label={valueLabel}
            labelMode="floating"
            stylingMode="outlined"
            value={typeof draft === 'string' ? draft : String(draft ?? '')}
            onValueChanged={(e) => setDraft(e.value ?? '')}
            height={120}
            elementAttr={{ 'data-testid': 'parametros.editor' }}
          />
        ) : null}
        {item.tipoValor === 'F' ? (
          <DateBox
            label={valueLabel}
            labelMode="floating"
            stylingMode="outlined"
            type={item.precisionFecha === 'datetime' ? 'datetime' : 'date'}
            displayFormat={item.precisionFecha === 'datetime' ? 'dd/MM/yyyy HH:mm' : 'dd/MM/yyyy'}
            useMaskBehavior
            value={typeof draft === 'string' ? draft : undefined}
            onValueChanged={(e) => {
              const v = e.value;
              if (v instanceof Date) {
                setDraft(
                  item.precisionFecha === 'datetime' ? v.toISOString() : v.toISOString().slice(0, 10),
                );
              } else {
                setDraft(v === null || v === undefined ? null : String(v));
              }
            }}
            elementAttr={{ 'data-testid': 'parametros.editor' }}
          />
        ) : null}

        {errorKey ? (
          <div role="alert" className="pqParametrosModalError" data-testid="parametros.modal.error">
            {t(errorKey)}
          </div>
        ) : null}

        <div className="pqParametrosModalActions">
          <Button
            text={t('parametros.modal.cancel')}
            stylingMode="outlined"
            onClick={onCancel}
            elementAttr={{ 'data-testid': 'parametros.cancel' }}
          />
          <Button
            text={t('parametros.modal.save')}
            type="default"
            stylingMode="contained"
            disabled={saving}
            onClick={() => void handleSave()}
            elementAttr={{ 'data-testid': 'parametros.save' }}
          />
        </div>
      </div>
    </Popup>
  );
}
