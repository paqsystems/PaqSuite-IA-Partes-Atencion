import { useEffect, useMemo, useState } from 'react';
import Popup from 'devextreme-react/popup';
import CheckBox from 'devextreme-react/check-box';
import NumberBox from 'devextreme-react/number-box';
import TextBox from 'devextreme-react/text-box';
import TextArea from 'devextreme-react/text-area';
import SelectBox from 'devextreme-react/select-box';
import { DialogActionButton } from '../../ui/process/DialogActionButton';
import { ProcessDateBox } from '../../ui/process/ProcessDateBox';
import { patchParametro, type RequestOverrides } from './parametrosApi';
import {
  mapEnvelopeErrorToI18nKey,
  resolveParametroCaption,
  resolveParametroTextValor,
  resolveParametroTooltip,
} from './parametroDisplay';
import type {
  LookupOption,
  ParametroListItem,
  ParametrosApi,
  ParametrosLookupApi,
} from './types';

export type ParametroEditPopupProps = {
  visible: boolean;
  item: ParametroListItem;
  onCancel: () => void;
  onSaved: () => void;
  t: (key: string) => string;
  requestOptions?: RequestOverrides;
  parametrosApi?: ParametrosApi;
  lookupApi?: ParametrosLookupApi;
};

type EnumOption = { value: string; text: string };

export function ParametroEditPopup({
  visible,
  item,
  onCancel,
  onSaved,
  t,
  requestOptions = {},
  parametrosApi,
  lookupApi,
}: ParametroEditPopupProps) {
  const [draft, setDraft] = useState<string | number | boolean | null>(item.valor);
  const [saving, setSaving] = useState(false);
  const [errorKey, setErrorKey] = useState<string | null>(null);
  const [lookupOptions, setLookupOptions] = useState<LookupOption[]>([]);

  const caption = useMemo(() => resolveParametroCaption(item, t), [item, t]);
  const tooltip = useMemo(() => resolveParametroTooltip(item, t), [item, t]);

  const enumOptions = useMemo((): EnumOption[] => {
    return (item.meta?.enum ?? []).map((value) => ({
      value,
      text: resolveParametroTextValor(item.programa, item.clave, value, t),
    }));
  }, [item.clave, item.meta?.enum, item.programa, t]);

  useEffect(() => {
    setDraft(item.valor);
    setErrorKey(null);
    const lookup = item.meta?.lookup;
    if (!lookup || !lookupApi) {
      setLookupOptions([]);
      return;
    }
    void lookupApi.list(lookup).then(setLookupOptions).catch(() => {
      setLookupOptions([]);
      setErrorKey('parametros.modal.error.lookup');
    });
  }, [item, lookupApi]);

  const handleSave = async () => {
    setSaving(true);
    setErrorKey(null);
    if (parametrosApi) {
      try {
        await parametrosApi.update(item.programa, item.clave, draft);
        setSaving(false);
        onSaved();
      } catch (reason: unknown) {
        setSaving(false);
        setErrorKey(reason instanceof Error ? reason.message : 'parametros.modal.error.validationFailed');
      }
      return;
    }
    const result = await patchParametro(
      item.clave,
      { programa: item.programa, valor: draft },
      requestOptions,
    );
    setSaving(false);
    if (result.kind === 'ok') {
      onSaved();
      return;
    }
    if (result.kind === 'envelopeError') {
      setErrorKey(mapEnvelopeErrorToI18nKey(result.envelope.respuesta));
      return;
    }
    setErrorKey(result.i18nKey || 'parametros.modal.error.validationFailed');
  };

  const valueLabel = t('parametros.list.valor');

  return (
    <Popup
      visible={visible}
      showCloseButton
      onHiding={onCancel}
      width={480}
      height="auto"
      dragEnabled
      shading
      wrapperAttr={{ class: 'pqParametrosModal', 'data-testid': 'parametros.modal' }}
      titleRender={() => (
        <div className="pqParametrosModalHeader">
          <div className="pqParametrosModalTitle">{caption}</div>
          {tooltip ? <div className="pqParametrosModalTooltip">{tooltip}</div> : null}
        </div>
      )}
    >
      <div className="pqParametrosModalBody">
        {item.tipoValor === 'B' ? (
          <CheckBox
            text={caption}
            value={Boolean(draft)}
            onValueChanged={(e) => setDraft(Boolean(e.value))}
            elementAttr={{ 'data-testid': 'parametros.editor' }}
          />
        ) : null}
        {item.tipoValor === 'I' || item.tipoValor === 'N' ? (
          <NumberBox
            label={valueLabel}
            labelMode="floating"
            stylingMode="outlined"
            value={typeof draft === 'number' ? draft : Number(draft ?? 0)}
            onValueChanged={(e) => setDraft(e.value ?? null)}
            showSpinButtons
            elementAttr={{ 'data-testid': 'parametros.editor' }}
          />
        ) : null}
        {(lookupOptions.length > 0 || (item.tipoValor === 'S' && enumOptions.length > 0)) ? (
          <SelectBox
            label={valueLabel}
            labelMode="floating"
            stylingMode="outlined"
            items={
              lookupOptions.length > 0
                ? lookupOptions
                : enumOptions
            }
            valueExpr="value"
            displayExpr={lookupOptions.length > 0 ? 'label' : 'text'}
            value={draft}
            onValueChanged={(e) => setDraft(e.value ?? null)}
            searchEnabled={enumOptions.length > 8}
            elementAttr={{ 'data-testid': 'parametros.editor' }}
          />
        ) : null}
        {item.tipoValor === 'S' && enumOptions.length === 0 && lookupOptions.length === 0 ? (
          <TextBox
            label={valueLabel}
            labelMode="floating"
            stylingMode="outlined"
            value={typeof draft === 'string' ? draft : String(draft ?? '')}
            onValueChanged={(e) => setDraft(e.value ?? '')}
            elementAttr={{ 'data-testid': 'parametros.editor' }}
          />
        ) : null}
        {item.tipoValor === 'T' ? (
          <TextArea
            label={valueLabel}
            labelMode="floating"
            stylingMode="outlined"
            value={typeof draft === 'string' ? draft : String(draft ?? '')}
            onValueChanged={(e) => setDraft(e.value ?? '')}
            height={120}
            elementAttr={{ 'data-testid': 'parametros.editor' }}
          />
        ) : null}
        {item.tipoValor === 'D' || item.tipoValor === 'F' ? (
          <ProcessDateBox
            label={valueLabel}
            labelMode="floating"
            stylingMode="outlined"
            type={item.precisionFecha === 'datetime' ? 'datetime' : 'date'}
            value={typeof draft === 'string' ? draft : undefined}
            onValueChanged={(e) => {
              const v = e.value;
              if (v instanceof Date) {
                setDraft(
                  item.precisionFecha === 'datetime' ? v.toISOString() : v.toISOString().slice(0, 10),
                );
              } else {
                setDraft(v === null || v === undefined ? null : String(v));
              }
            }}
            elementAttr={{ 'data-testid': 'parametros.editor' }}
          />
        ) : null}

        {errorKey ? (
          <div role="alert" className="pqParametrosModalError" data-testid="parametros.modal.error">
            {t(errorKey)}
          </div>
        ) : null}

        <div className="pqParametrosModalActions">
          <DialogActionButton
            text={t('parametros.modal.cancel')}
            stylingMode="outlined"
            onClick={onCancel}
            elementAttr={{ 'data-testid': 'parametros.cancel' }}
          />
          <DialogActionButton
            text={t('parametros.modal.save')}
            type="default"
            stylingMode="contained"
            disabled={saving}
            onClick={() => void handleSave()}
            elementAttr={{ 'data-testid': 'parametros.save' }}
          />
        </div>
      </div>
    </Popup>
  );
}
