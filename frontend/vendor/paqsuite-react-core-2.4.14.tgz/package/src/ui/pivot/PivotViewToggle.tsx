import Button from 'devextreme-react/button';

export type PivotViewMode = 'grid' | 'pivot';

export type PivotViewToggleProps = {
  value: PivotViewMode;
  onChange: (view: PivotViewMode) => void;
  gridLabel?: string;
  pivotLabel?: string;
  disabled?: boolean;
};

/** Toggle único Grilla|Pivot — testid `pivot.toggle`. */
export function PivotViewToggle({
  value,
  onChange,
  gridLabel = 'Grilla',
  pivotLabel = 'Pivot',
  disabled,
}: PivotViewToggleProps) {
  const nextView: PivotViewMode = value === 'grid' ? 'pivot' : 'grid';
  const activeLabel = value === 'grid' ? gridLabel : pivotLabel;
  const nextLabel = value === 'grid' ? pivotLabel : gridLabel;

  return (
    <Button
      text={activeLabel}
      hint={`${nextLabel}`}
      type="default"
      stylingMode="contained"
      disabled={disabled}
      onClick={() => onChange(nextView)}
      elementAttr={{
        'data-testid': 'pivot.toggle',
        'data-active-view': value,
        'data-next-view': nextView,
      }}
    />
  );
}
