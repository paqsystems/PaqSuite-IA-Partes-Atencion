import { describe, expect, it } from 'vitest';
import type { PivotConsultaCatalogDto } from './pivotCatalogClient';
import {
  mapCatalogToPivotFields,
  resolveDefaultSummaryType,
} from './mapCatalogToPivotFields';

describe('mapCatalogToPivotFields', () => {
  it('defaults numeric summaryType to sum', () => {
    expect(resolveDefaultSummaryType('number')).toBe('sum');
    expect(resolveDefaultSummaryType('numeric')).toBe('sum');
  });

  it('maps catalog fields with sum for numeric', () => {
    const catalog: PivotConsultaCatalogDto = {
      consultaId: 'consultaSmokePivot',
      mostrarGrillaYPivot: true,
      soloPivot: false,
      campos: [
        {
          dataField: 'importe',
          dataType: 'number',
          nombreVisible: 'Importe',
        },
        {
          dataField: 'cliente',
          dataType: 'string',
          nombreVisible: 'Cliente',
        },
      ],
    };

    const fields = mapCatalogToPivotFields(catalog);
    const importe = fields.find((field) => field.dataField === 'importe');
    const cliente = fields.find((field) => field.dataField === 'cliente');

    expect(importe?.summaryType).toBe('sum');
    expect(importe?.area).toBe('data');
    expect(importe?.caption).toBe('Importe');
    expect(cliente?.summaryType).toBe('count');
  });

  it('applies shortDate format to date fields with locale', () => {
    const catalog: PivotConsultaCatalogDto = {
      consultaId: 'consultaFechas',
      mostrarGrillaYPivot: true,
      soloPivot: false,
      campos: [
        {
          dataField: 'fecha',
          dataType: 'date',
          nombreVisible: 'Fecha',
        },
      ],
    };

    const fields = mapCatalogToPivotFields(catalog, undefined, { locale: 'es' });
    const fecha = fields.find((field) => field.dataField === 'fecha');
    expect(fecha?.format).toBe('shortDate');
    expect(typeof fecha?.customizeText).toBe('function');
    expect(fecha?.customizeText?.({ value: new Date(2026, 6, 31) })).toMatch(/31/);
  });

  it('applies decimal format to numeric fields with thousands separator', () => {
    const catalog: PivotConsultaCatalogDto = {
      consultaId: 'consultaImportes',
      mostrarGrillaYPivot: true,
      soloPivot: false,
      campos: [
        {
          dataField: 'importe',
          dataType: 'number',
          nombreVisible: 'Importe',
        },
      ],
    };

    const fields = mapCatalogToPivotFields(catalog, undefined, { locale: 'es-AR' });
    const importe = fields.find((field) => field.dataField === 'importe');
    expect(importe?.format).toBe('decimal');
    expect(typeof importe?.customizeText).toBe('function');
    expect(importe?.customizeText?.({ value: 231467719.60999998 })).toBe('231.467.719,61');
  });
});
