import { useContext, type ComponentProps } from 'react';
import DateBox from 'devextreme-react/date-box';
import { I18nContext } from 'react-i18next';
import { resolveDateDisplayFormat, type DatePrecision } from './resolveDateDisplayFormat';

type DateBoxProps = ComponentProps<typeof DateBox>;

export type ProcessDateBoxProps = Omit<DateBoxProps, 'displayFormat' | 'useMaskBehavior'> & {
  locale?: string;
  precision?: DatePrecision;
};

function resolvePrecision(type: DateBoxProps['type'], precision?: DatePrecision): DatePrecision {
  if (precision) {
    return precision;
  }
  if (type === 'time') {
    return 'time';
  }
  if (type === 'datetime') {
    return 'datetime';
  }
  return 'date';
}

function resolveActiveLocale(explicit: string | undefined, contextLocale: string | undefined): string {
  const preferred = explicit?.trim();
  if (preferred) {
    return preferred;
  }
  const fromContext = contextLocale?.trim();
  if (fromContext) {
    return fromContext;
  }
  return 'es';
}

/** DateBox GEN: máscara con separadores del locale activo (SPEC-001-02). */
export function ProcessDateBox({ locale, precision, type, ...rest }: ProcessDateBoxProps) {
  const i18nContext = useContext(I18nContext);
  const activePrecision = resolvePrecision(type, precision);
  const activeLocale = resolveActiveLocale(locale, i18nContext?.i18n?.language);
  const boxType = activePrecision === 'date' ? (type ?? 'date') : activePrecision;

  return (
    <DateBox
      {...rest}
      type={boxType}
      displayFormat={resolveDateDisplayFormat(activeLocale, activePrecision)}
      useMaskBehavior
    />
  );
}
