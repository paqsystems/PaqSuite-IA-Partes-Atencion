import type { LocaleCode } from '../../i18n/localeCatalog';
import { normalizeLocale } from '../../i18n/normalizeLocale';

export type DatePrecision = 'date' | 'datetime' | 'time';

type DatePatternRow = {
  date: string;
  dateTime: string;
  time: string;
};

/** SPEC-001-02 §5: los cinco locales comparten orden día/mes/año y separador `/`. */
const datePatterns: Record<LocaleCode, DatePatternRow> = {
  es: { date: 'dd/MM/yyyy', dateTime: 'dd/MM/yyyy HH:mm', time: 'HH:mm' },
  en: { date: 'dd/MM/yyyy', dateTime: 'dd/MM/yyyy HH:mm', time: 'HH:mm' },
  pt: { date: 'dd/MM/yyyy', dateTime: 'dd/MM/yyyy HH:mm', time: 'HH:mm' },
  fr: { date: 'dd/MM/yyyy', dateTime: 'dd/MM/yyyy HH:mm', time: 'HH:mm' },
  it: { date: 'dd/MM/yyyy', dateTime: 'dd/MM/yyyy HH:mm', time: 'HH:mm' },
};

export function resolveDateDisplayFormat(
  locale: string | null | undefined,
  precision: DatePrecision = 'date',
): string {
  const code = normalizeLocale(locale) ?? 'es';
  const row = datePatterns[code];
  if (precision === 'time') {
    return row.time;
  }
  if (precision === 'datetime') {
    return row.dateTime;
  }
  return row.date;
}
