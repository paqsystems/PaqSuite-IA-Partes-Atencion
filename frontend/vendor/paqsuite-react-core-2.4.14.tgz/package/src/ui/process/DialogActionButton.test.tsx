/**
 * @vitest-environment jsdom
 */
import type { ReactNode } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it, vi } from 'vitest';

vi.mock('devextreme-react/button', () => ({
  default: (props: {
    text?: string;
    accessKey?: string;
    elementAttr?: Record<string, string>;
    render?: () => ReactNode;
  }) => (
    <button
      type="button"
      data-testid={props.elementAttr?.['data-testid'] ?? 'dialogAction'}
      data-access-key={props.accessKey ?? ''}
    >
      {props.render ? props.render() : props.text}
    </button>
  ),
}));

import { DialogActionButton } from './DialogActionButton';

describe('DialogActionButton', () => {
  it('expone accessKey y subraya la primera letra', () => {
    const html = renderToStaticMarkup(<DialogActionButton text="Guardar" />);
    expect(html).toContain('data-access-key="g"');
    expect(html).toContain('text-decoration:underline');
    expect(html).toContain('G');
    expect(html).toContain('uardar');
  });

  it('mantiene la letra del caption estable mientras el texto de carga cambia', () => {
    const html = renderToStaticMarkup(
      <DialogActionButton text="Guardando…" accessCaption="Cambiar contraseña" />,
    );
    expect(html).toContain('data-access-key="c"');
    expect(html).toContain('Guardando…');
    expect(html).not.toContain('text-decoration:underline');
  });

  it('no asigna accessKey si el caption no tiene letra', () => {
    const html = renderToStaticMarkup(<DialogActionButton text="…" />);
    expect(html).toContain('data-access-key=""');
  });
});
