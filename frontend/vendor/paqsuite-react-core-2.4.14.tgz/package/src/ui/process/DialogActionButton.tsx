import type { ReactNode } from 'react';
import Button from 'devextreme-react/button';
import { resolveAcceleratorIndex, resolveAccessKey } from './resolveAccessKey';

export type DialogActionButtonProps = {
  text: string;
  /** Caption estable del atajo cuando `text` cambia (por ejemplo «Guardando…»). */
  accessCaption?: string;
  onClick?: () => void;
  type?: 'back' | 'danger' | 'default' | 'normal' | 'success';
  stylingMode?: 'text' | 'outlined' | 'contained';
  disabled?: boolean;
  useSubmitBehavior?: boolean;
  hint?: string;
  icon?: string;
  elementAttr?: Record<string, string>;
};

function AcceleratorCaption({ caption, letterIndex }: { caption: string; letterIndex: number }): ReactNode {
  if (letterIndex < 0) {
    return <span>{caption}</span>;
  }
  return (
    <span>
      {caption.slice(0, letterIndex)}
      <span style={{ textDecoration: 'underline' }}>{caption.charAt(letterIndex)}</span>
      {caption.slice(letterIndex + 1)}
    </span>
  );
}

/** Botón de diálogo GEN con Alt+letra alineado al caption traducido. */
export function DialogActionButton({
  text,
  accessCaption,
  ...rest
}: DialogActionButtonProps) {
  const source = accessCaption ?? text;
  const accessKey = resolveAccessKey(source);
  const underlineVisible = text === source;
  const letterIndex = underlineVisible ? resolveAcceleratorIndex(text) : -1;

  return (
    <Button
      {...rest}
      text={text}
      accessKey={accessKey}
      render={
        accessKey && underlineVisible
          ? () => <AcceleratorCaption caption={text} letterIndex={letterIndex} />
          : undefined
      }
    />
  );
}
