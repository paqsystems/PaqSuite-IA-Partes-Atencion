import { describe, expect, it } from 'vitest';
import { supportedLocales } from '../../i18n/localeCatalog';
import { resolveDateDisplayFormat } from './resolveDateDisplayFormat';

describe('resolveDateDisplayFormat', () => {
  it('usa separador / en fecha y fecha-hora para los cinco locales', () => {
    for (const locale of supportedLocales) {
      const date = resolveDateDisplayFormat(locale, 'date');
      const dateTime = resolveDateDisplayFormat(locale, 'datetime');
      expect(date, locale).toBe('dd/MM/yyyy');
      expect(date, locale).toContain('/');
      expect(date, locale).not.toMatch(/^\d{8}$/);
      expect(dateTime, locale).toBe('dd/MM/yyyy HH:mm');
      expect(dateTime, locale).toContain('/');
      expect(dateTime, locale).toContain(':');
    }
  });

  it('usa HH:mm en hora', () => {
    expect(resolveDateDisplayFormat('es', 'time')).toBe('HH:mm');
    expect(resolveDateDisplayFormat('fr', 'time')).toContain(':');
  });

  it('cae en es si el locale no está en el catálogo', () => {
    expect(resolveDateDisplayFormat('de', 'date')).toBe('dd/MM/yyyy');
    expect(resolveDateDisplayFormat(null, 'date')).toBe('dd/MM/yyyy');
  });
});
