const accentFold: Record<string, string> = {
  á: 'a',
  à: 'a',
  â: 'a',
  ä: 'a',
  ã: 'a',
  å: 'a',
  é: 'e',
  è: 'e',
  ê: 'e',
  ë: 'e',
  í: 'i',
  ì: 'i',
  î: 'i',
  ï: 'i',
  ó: 'o',
  ò: 'o',
  ô: 'o',
  ö: 'o',
  õ: 'o',
  ú: 'u',
  ù: 'u',
  û: 'u',
  ü: 'u',
  ñ: 'n',
  ç: 'c',
};

const letterPattern = /\p{L}/u;

/** Índice de la primera letra del caption, o -1 si no hay letra. */
export function resolveAcceleratorIndex(caption: string): number {
  const match = letterPattern.exec(caption);
  if (!match || match.index === undefined) {
    return -1;
  }
  return match.index;
}

/**
 * Letra de atajo Alt a partir del caption ya traducido.
 * Pliega acentos a ASCII (`á` → `a`) para el atributo `accessKey`.
 */
export function resolveAccessKey(caption: string): string | undefined {
  const index = resolveAcceleratorIndex(caption);
  if (index < 0) {
    return undefined;
  }
  const raw = caption.charAt(index).toLowerCase();
  const folded = accentFold[raw] ?? raw;
  if (!/^[a-z]$/.test(folded)) {
    return undefined;
  }
  return folded;
}
