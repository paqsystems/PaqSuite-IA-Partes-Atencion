import { describe, expect, it } from 'vitest';
import { gridI18nCatalogs } from '../../i18n/gridI18n';
import type { LocaleCode } from '../../i18n/localeCatalog';
import { resolveAccessKey } from './resolveAccessKey';

describe('resolveAccessKey', () => {
  it('toma la primera letra del caption traducido', () => {
    expect(resolveAccessKey('Cancelar')).toBe('c');
    expect(resolveAccessKey('Aceptar')).toBe('a');
    expect(resolveAccessKey('Guardar')).toBe('g');
    expect(resolveAccessKey('Annuler')).toBe('a');
    expect(resolveAccessKey('Annulla')).toBe('a');
    expect(resolveAccessKey('Save')).toBe('s');
    expect(resolveAccessKey('Cancel')).toBe('c');
  });

  it('pliega el acento de la primera letra', () => {
    expect(resolveAccessKey('Árbol')).toBe('a');
    expect(resolveAccessKey('«Éxito»')).toBe('e');
  });

  it('omite captions sin letra latina', () => {
    expect(resolveAccessKey('')).toBeUndefined();
    expect(resolveAccessKey('…')).toBeUndefined();
    expect(resolveAccessKey('123')).toBeUndefined();
  });

  it('los pares Cancelar/Guardar de plantillas no comparten inicial', () => {
    const locales = Object.keys(gridI18nCatalogs) as LocaleCode[];
    for (const locale of locales) {
      const catalog = gridI18nCatalogs[locale];
      const cancel = resolveAccessKey(catalog['gridLayout.saveAsCancel']);
      const confirm = resolveAccessKey(catalog['gridLayout.saveAsConfirm']);
      expect(cancel, locale).toBeTruthy();
      expect(confirm, locale).toBeTruthy();
      expect(cancel, locale).not.toBe(confirm);
    }
  });
});
