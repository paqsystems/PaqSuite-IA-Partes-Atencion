/**
 * @vitest-environment jsdom
 */
import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it, vi } from 'vitest';

vi.mock('devextreme-react/date-box', () => ({
  default: (props: { displayFormat?: string; useMaskBehavior?: boolean; type?: string }) => (
    <input
      data-display-format={props.displayFormat ?? ''}
      data-mask={props.useMaskBehavior ? 'true' : 'false'}
      data-type={props.type ?? ''}
    />
  ),
}));

import { ProcessDateBox } from './ProcessDateBox';

describe('ProcessDateBox', () => {
  it('aplica máscara dd/MM/yyyy en fecha', () => {
    const html = renderToStaticMarkup(<ProcessDateBox locale="es" type="date" />);
    expect(html).toContain('data-display-format="dd/MM/yyyy"');
    expect(html).toContain('data-mask="true"');
    expect(html).toContain('data-type="date"');
  });

  it('aplica fecha-hora y hora según el type', () => {
    const dateTime = renderToStaticMarkup(<ProcessDateBox locale="fr" type="datetime" />);
    const time = renderToStaticMarkup(<ProcessDateBox locale="it" type="time" />);
    expect(dateTime).toContain('data-display-format="dd/MM/yyyy HH:mm"');
    expect(dateTime).toContain('data-type="datetime"');
    expect(time).toContain('data-display-format="HH:mm"');
    expect(time).toContain('data-mask="true"');
  });
});
