import { useCallback, useRef, useState, type ComponentProps, type ReactNode } from 'react';
import DataGrid, {
  ColumnChooser,
  FilterRow,
  GroupItem,
  GroupPanel,
  HeaderFilter,
  Pager,
  Paging,
  Summary,
  TotalItem,
  Toolbar,
  Item as ToolbarItem,
  type DataGridRef,
} from 'devextreme-react/data-grid';
import type { ContextMenuPreparingEvent } from 'devextreme/ui/data_grid';
import type dxDataGrid from 'devextreme/ui/data_grid';
import type { BuildPlatformHeadersInput } from '../../http/headers';
import { useGridI18n } from '../../i18n/useGridI18n';
import { useMenuProcessPermissions } from '../../menu/MenuAuthContext';
import {
  enrichGridTotalItems,
  inferGridColumnDataType,
  isGridTotalItemActive,
  resolveAllowedGridSummaryTypes,
  toggleGridTotalItem,
  type GridSummaryType,
  type ProcessGridTotalItem,
} from './gridSummaryTypes';
import {
  GridLayoutSaveAsDialog,
  GridLayoutsToolbarControls,
  type GridLayoutsToolbarLabels,
} from './GridLayoutsToolbarControls';
import { useGridLayouts } from './useGridLayouts';
import { LoadingOverlay } from '../states/LoadingOverlay';
import { GridExportButton } from './GridExportButton';
import { GridRefreshButton } from './GridRefreshButton';
import { resolveGridPageSizes, type GridPageSizeParams } from './pageSizes';
import {
  exportDataGridExcel,
  hasGridExportableData,
  type GridExportMode,
} from './exportDataGridExcel';

function getGridInstance(ref: DataGridRef | null): dxDataGrid | undefined {
  if (!ref) {
    return undefined;
  }
  const maybe = ref as DataGridRef & { instance?: () => dxDataGrid };
  if (typeof maybe.instance === 'function') {
    return maybe.instance();
  }
  return undefined;
}

export type ProcessDataGridProps = ComponentProps<typeof DataGrid> & {
  /** Abre el alta (modal). Si falta, no se muestra el «+». */
  onCreate?: () => void;
  /**
   * Override explícito. Si se omite, se usa `permissions.create` del proceso de menú
   * de la ruta actual (`MenuAuthProvider`).
   */
  allowCreate?: boolean;
  /** Ruta de menú a resolver si no es `location.pathname` (p. ej. tests). */
  menuRouteName?: string;
  /** Traducción GEN-02 (prioridad sobre catálogo SDK). */
  t?: (key: string) => string;
  /** Locale activo — remonta textos al cambiar idioma. */
  locale?: string;
  createHint?: string;
  createTestId?: string;
  /** Barra superior para arrastrar columnas y agrupar. Default true. */
  groupPanelVisible?: boolean;
  /** Fila de filtro bajo títulos. Default true. */
  filterRowVisible?: boolean;
  /** Filtro por encabezado (DX HeaderFilter). Default true. */
  headerFilterVisible?: boolean;
  /** Selector agregar/quitar columnas. Default true. */
  columnChooserEnabled?: boolean;
  /** Pie + menú contextual de totalizadores. Default true. */
  summaryEnabled?: boolean;
  /** Totalizadores iniciales (el usuario puede agregar más por menú contextual). */
  defaultTotalItems?: ProcessGridTotalItem[];
  /** Totalizadores en filas agrupadas. Default false para evitar duplicar el pie. */
  groupSummaryEnabled?: boolean;
  /**
   * Formateadores de valor de pie/grupo por columna (p. ej. minutos → HH:mm).
   * Se aplican si el TotalItem no trae customizeText propio.
   */
  columnSummaryFormatters?: Record<string, (value: unknown) => string>;
  emptyGroupPanelText?: string;
  summaryTypeLabels?: Partial<Record<GridSummaryType, string>>;
  columnChooserTitle?: string;
  /**
   * Clave de proceso para plantillas GEN-11. Con `gridId` habilita el toolbar de layouts
   * (salvo `layoutsEnabled={false}`).
   */
  proceso?: string;
  gridId?: string;
  /** Default: true si hay `proceso` + `gridId`. */
  layoutsEnabled?: boolean;
  accessToken?: string | null;
  platform?: BuildPlatformHeadersInput;
  layoutLabels?: Partial<GridLayoutsToolbarLabels>;
  /**
   * Fetch inicial / refresh bloqueante del proceso (regla BASE 30).
   * Muestra `LoadingOverlay` con «Cargando…».
   */
  loading?: boolean;
  loadingLabel?: string;
  /**
   * Contenido extra a la izquierda del toolbar integrado (`location="before"`).
   * Uso típico: toggle Pivot / volver a grilla.
   * Orden derecha: plantillas → Excel → column chooser — ver SPEC-001-11 §3.3.
   */
  toolbarLeading?: ReactNode;
  /**
   * Export Excel (Básico / Formateado). Default `true`.
   * Va entre plantillas y column chooser.
   */
  exportEnabled?: boolean;
  exportTitle?: string;
  exportBasicLabel?: string;
  exportFormattedLabel?: string;
  exportNoDataHint?: string;
  /** Refresca datos del proceso (toolbar, derecha). */
  onRefresh?: () => void;
  refreshLabel?: string;
  /** Tamaños de página desde parámetros GridPageSize1..3. */
  pageSizes?: GridPageSizeParams;
};

/**
 * DataGrid estándar PaqSuite (regla BASE 29 / SPEC-001-11 §2–§5):
 * group panel, filter row, column chooser, pie/totalizadores, plantillas y «+» si hay alta.
 */
export function ProcessDataGrid({
  onCreate,
  allowCreate,
  menuRouteName,
  t,
  locale,
  createHint: createHintOverride,
  createTestId = 'processDataGrid.create',
  groupPanelVisible = true,
  filterRowVisible = true,
  headerFilterVisible = true,
  columnChooserEnabled = true,
  summaryEnabled = true,
  defaultTotalItems,
  groupSummaryEnabled = false,
  columnSummaryFormatters,
  emptyGroupPanelText: emptyGroupPanelTextOverride,
  summaryTypeLabels,
  columnChooserTitle: columnChooserTitleOverride,
  proceso,
  gridId,
  layoutsEnabled,
  accessToken,
  platform,
  layoutLabels,
  loading = false,
  loadingLabel: loadingLabelOverride,
  toolbarLeading,
  exportEnabled = true,
  exportTitle: exportTitleOverride,
  exportBasicLabel: exportBasicLabelOverride,
  exportFormattedLabel: exportFormattedLabelOverride,
  exportNoDataHint: exportNoDataHintOverride,
  onRefresh,
  refreshLabel: refreshLabelOverride,
  pageSizes,
  children,
  onContextMenuPreparing,
  ...gridProps
}: ProcessDataGridProps) {
  const gridI18n = useGridI18n({ locale, t });
  const createHint = createHintOverride ?? gridI18n.createHint;
  const emptyGroupPanelText = emptyGroupPanelTextOverride ?? gridI18n.groupPanelEmptyText;
  const columnChooserTitle = columnChooserTitleOverride ?? gridI18n.columnChooserTitle;
  const loadingLabel = loadingLabelOverride ?? gridI18n.loadingLabel;
  const refreshLabel = refreshLabelOverride ?? gridI18n.refreshLabel;
  const exportTitle = exportTitleOverride ?? gridI18n.exportTitle;
  const exportBasicLabel = exportBasicLabelOverride ?? gridI18n.exportBasicLabel;
  const exportFormattedLabel = exportFormattedLabelOverride ?? gridI18n.exportFormattedLabel;
  const exportNoDataHint = exportNoDataHintOverride ?? gridI18n.exportNoDataHint;
  const mergedLayoutLabels = { ...gridI18n.layoutsToolbarLabels, ...layoutLabels };
  const gridRef = useRef<DataGridRef>(null);
  const menuPermissions = useMenuProcessPermissions(menuRouteName);
  const canCreate =
    allowCreate !== undefined ? allowCreate : Boolean(menuPermissions?.create);
  const showCreate = Boolean(onCreate) && canCreate;
  const [totalItems, setTotalItems] = useState<ProcessGridTotalItem[]>(
    () => defaultTotalItems ?? []
  );
  const [saveAsOpen, setSaveAsOpen] = useState(false);

  const showLayouts =
    layoutsEnabled !== false && Boolean(proceso && gridId && accessToken);

  const captureState = useCallback(() => {
    const instance = getGridInstance(gridRef.current);
    const dxState = (instance?.state?.() ?? {}) as Record<string, unknown>;
    return {
      ...dxState,
      pqTotalItems: totalItems,
    };
  }, [totalItems]);

  const applyState = useCallback((state: unknown | null) => {
    const instance = getGridInstance(gridRef.current);
    if (!instance?.state) {
      return;
    }
    if (state == null) {
      instance.state(null);
      setTotalItems(defaultTotalItems ?? []);
      return;
    }
    const record = state as Record<string, unknown>;
    const { pqTotalItems, ...dxState } = record;
    instance.state(dxState);
    if (Array.isArray(pqTotalItems)) {
      setTotalItems(
        enrichGridTotalItems(pqTotalItems as ProcessGridTotalItem[], defaultTotalItems)
      );
    }
  }, [defaultTotalItems]);

  const layouts = useGridLayouts({
    proceso: proceso ?? '',
    gridId: gridId ?? '',
    accessToken,
    platform,
    enabled: showLayouts,
    ownerSuffix: mergedLayoutLabels.ownerSuffix,
    originalLabel: mergedLayoutLabels.originalLabel,
    captureState,
    applyState,
  });

  const labels = { ...gridI18n.summaryTypeLabels, ...summaryTypeLabels };

  const canExport = hasGridExportableData(gridProps.dataSource, loading);
  const exportProceso = proceso || gridId || 'grid';
  const resolvedPageSizes = resolveGridPageSizes(pageSizes);

  const handleExport = useCallback(
    (mode: GridExportMode) => {
      const instance = getGridInstance(gridRef.current);
      if (!instance || !canExport) {
        return;
      }
      void exportDataGridExcel({
        proceso: exportProceso,
        component: instance,
        mode,
      });
    },
    [canExport, exportProceso]
  );

  const resolveSummaryCustomizeText = useCallback(
    (item: ProcessGridTotalItem) => {
      if (item.customizeText) {
        return item.customizeText;
      }
      const formatter = columnSummaryFormatters?.[item.column];
      if (!formatter) {
        return undefined;
      }
      return (info: { value?: string | number | Date; valueText?: string }) => {
        const formatted = formatter(info.value);
        const template = item.displayFormat ?? `${labels[item.summaryType]}: {0}`;
        return template.replace('{0}', formatted);
      };
    },
    [columnSummaryFormatters, labels]
  );

  const handleContextMenuPreparing = useCallback(
    (e: ContextMenuPreparingEvent) => {
      onContextMenuPreparing?.(e);
      if (!summaryEnabled || layouts.busy || e.target !== 'footer') {
        return;
      }
      const column = e.column;
      const dataField = column?.dataField;
      const columnType = column?.type;
      if (!dataField || columnType === 'buttons' || columnType === 'selection') {
        return;
      }

      let dataType = column.dataType as string | undefined;
      if (!dataType && e.component) {
        const rows = e.component.getVisibleRows?.() ?? [];
        const sample = rows.find((row) => row.rowType === 'data')?.data as
          | Record<string, unknown>
          | undefined;
        if (sample && dataField in sample) {
          dataType = inferGridColumnDataType(sample[dataField]);
        }
      }

      const allowed = resolveAllowedGridSummaryTypes(dataType);
      const items = e.items ?? [];
      items.push({ beginGroup: true, text: gridI18n.summaryMenuSection, disabled: true } as never);
      for (const summaryType of allowed) {
        const active = isGridTotalItemActive(totalItems, dataField, summaryType);
        items.push({
          text: `${active ? '✓ ' : ''}${labels[summaryType]}`,
          onItemClick: () => {
            setTotalItems((prev) =>
              enrichGridTotalItems(
                toggleGridTotalItem(prev, dataField, summaryType),
                defaultTotalItems
              )
            );
          },
        });
      }
      e.items = items;
    },
    [
      defaultTotalItems,
      gridI18n.summaryMenuSection,
      labels,
      layouts.busy,
      onContextMenuPreparing,
      summaryEnabled,
      totalItems,
    ]
  );

  return (
    <>
      <LoadingOverlay visible={loading} label={loadingLabel} />
      <DataGrid
        ref={gridRef}
        showBorders
        showRowLines
        showColumnLines
        hoverStateEnabled
        allowColumnReordering
        allowColumnResizing
        columnAutoWidth
        {...gridProps}
        onContextMenuPreparing={handleContextMenuPreparing}
        elementAttr={{
          'data-testid': 'processDataGrid',
          ...(gridProps.elementAttr ?? {}),
        }}
      >
        {groupPanelVisible ? (
          <GroupPanel visible emptyPanelText={emptyGroupPanelText} />
        ) : null}
        {filterRowVisible ? <FilterRow visible applyFilter="auto" /> : null}
        {headerFilterVisible ? <HeaderFilter visible /> : null}
        {columnChooserEnabled ? (
          <ColumnChooser enabled mode="select" title={columnChooserTitle} />
        ) : null}
        <Paging defaultPageSize={resolvedPageSizes[0]} />
        <Pager
          visible
          showPageSizeSelector
          allowedPageSizes={[...resolvedPageSizes]}
          showInfo
        />

        <Toolbar>
          {toolbarLeading ? (
            <ToolbarItem
              location="before"
              locateInMenu="auto"
              render={() => <>{toolbarLeading}</>}
            />
          ) : null}
          {onRefresh ? (
            <ToolbarItem
              location="after"
              locateInMenu="auto"
              render={() => (
                <GridRefreshButton
                  onRefresh={onRefresh}
                  disabled={loading}
                  label={refreshLabel}
                />
              )}
            />
          ) : null}
          {showLayouts ? (
            <ToolbarItem
              location="after"
              locateInMenu="auto"
              render={() => (
                <GridLayoutsToolbarControls
                  layouts={layouts}
                  labels={mergedLayoutLabels}
                  onOpenSaveAs={() => setSaveAsOpen(true)}
                />
              )}
            />
          ) : null}
          {exportEnabled ? (
            <ToolbarItem
              location="after"
              locateInMenu="auto"
              render={() => (
                <GridExportButton
                  onExport={handleExport}
                  disabled={!canExport}
                  title={exportTitle}
                  basicLabel={exportBasicLabel}
                  formattedLabel={exportFormattedLabel}
                  noDataHint={exportNoDataHint}
                />
              )}
            />
          ) : null}
          {columnChooserEnabled ? (
            <ToolbarItem name="columnChooserButton" locateInMenu="auto" location="after" />
          ) : null}
          {showCreate ? (
            <ToolbarItem
              location="after"
              widget="dxButton"
              options={{
                icon: 'plus',
                hint: createHint,
                onClick: onCreate,
                elementAttr: { 'data-testid': createTestId },
              }}
            />
          ) : null}
        </Toolbar>

        {summaryEnabled ? (
          <Summary>
            {totalItems.map((item) => (
              <TotalItem
                key={item.name ?? `${item.column}-${item.summaryType}`}
                name={item.name}
                column={item.column}
                summaryType={item.summaryType}
                displayFormat={item.displayFormat ?? `${labels[item.summaryType]}: {0}`}
                valueFormat={item.valueFormat}
                customizeText={resolveSummaryCustomizeText(item)}
                showInColumn={item.showInColumn}
              />
            ))}
            {groupSummaryEnabled
              ? totalItems.map((item) => (
                  <GroupItem
                    key={`group-${item.name ?? `${item.column}-${item.summaryType}`}`}
                    column={item.column}
                    summaryType={item.summaryType}
                    displayFormat={item.displayFormat ?? `${labels[item.summaryType]}: {0}`}
                    valueFormat={item.valueFormat}
                    customizeText={resolveSummaryCustomizeText(item)}
                    alignByColumn
                  />
                ))
              : null}
          </Summary>
        ) : null}

        {children}
      </DataGrid>

      {showLayouts ? (
        <GridLayoutSaveAsDialog
          visible={saveAsOpen}
          busy={layouts.busy}
          errorMessage={gridI18n.resolveLayoutErrorMessage(layouts.errorMessage)}
          labels={mergedLayoutLabels}
          onHiding={() => setSaveAsOpen(false)}
          onConfirm={async (layoutName) => layouts.saveAs(layoutName)}
        />
      ) : null}
    </>
  );
}

export type { ProcessGridTotalItem, GridSummaryType };
