import { describe, expect, it } from 'vitest';
import {
  enrichGridTotalItems,
  inferGridColumnDataType,
  isGridTotalItemActive,
  normalizeGridTotalItems,
  resolveAllowedGridSummaryTypes,
  toggleGridTotalItem,
  type ProcessGridTotalItem,
} from './gridSummaryTypes';

describe('grid summary items', () => {
  it('does not reuse a different summary type display format', () => {
    const defaults: ProcessGridTotalItem[] = [
      {
        column: 'duracionHoras',
        summaryType: 'sum',
        displayFormat: 'Sum: {0} h',
      },
    ];

    const count = enrichGridTotalItems(
      toggleGridTotalItem(defaults, 'duracionHoras', 'count'),
      defaults,
    ).find((item) => item.summaryType === 'count');

    expect(count).toMatchObject({
      column: 'duracionHoras',
      summaryType: 'count',
    });
    expect(count?.displayFormat).toBeUndefined();
  });

  it('removes an active summary instead of creating a duplicate', () => {
    const items: ProcessGridTotalItem[] = [
      { column: 'importe', summaryType: 'sum' },
    ];

    expect(toggleGridTotalItem(items, 'importe', 'sum')).toEqual([]);
  });

  it('normalizes duplicated summaries by column and type', () => {
    const items: ProcessGridTotalItem[] = [
      { column: 'duracionMinutos', summaryType: 'sum', name: 'first' },
      { column: 'duracionMinutos', summaryType: 'sum', name: 'duplicate' },
      { column: 'duracionMinutos', summaryType: 'count' },
    ];

    expect(normalizeGridTotalItems(items)).toEqual([
      { column: 'duracionMinutos', summaryType: 'sum', name: 'first' },
      { column: 'duracionMinutos', summaryType: 'count' },
    ]);
    expect(toggleGridTotalItem(items, 'duracionMinutos', 'sum')).toEqual([
      { column: 'duracionMinutos', summaryType: 'count' },
    ]);
  });
});

describe('resolveAllowedGridSummaryTypes', () => {
  it('numéricos: contar, sumar, min, max, promedio', () => {
    expect(resolveAllowedGridSummaryTypes('number')).toEqual([
      'count',
      'sum',
      'min',
      'max',
      'avg',
    ]);
    expect(resolveAllowedGridSummaryTypes('numeric')).toEqual([
      'count',
      'sum',
      'min',
      'max',
      'avg',
    ]);
  });

  it('textos: contar, min, max', () => {
    expect(resolveAllowedGridSummaryTypes('string')).toEqual(['count', 'min', 'max']);
    expect(resolveAllowedGridSummaryTypes(undefined)).toEqual(['count', 'min', 'max']);
  });

  it('fechas: contar, min, max', () => {
    expect(resolveAllowedGridSummaryTypes('date')).toEqual(['count', 'min', 'max']);
    expect(resolveAllowedGridSummaryTypes('datetime')).toEqual(['count', 'min', 'max']);
  });
});

describe('inferGridColumnDataType', () => {
  it('infiere number / date / string', () => {
    expect(inferGridColumnDataType(12.5)).toBe('number');
    expect(inferGridColumnDataType('2026-07-31')).toBe('date');
    expect(inferGridColumnDataType('hola')).toBe('string');
  });
});

describe('toggleGridTotalItem', () => {
  it('agrega y quita el mismo totalizador', () => {
    const once = toggleGridTotalItem([], 'duracionMinutos', 'sum');
    expect(once).toHaveLength(1);
    expect(isGridTotalItemActive(once, 'duracionMinutos', 'sum')).toBe(true);
    const twice = toggleGridTotalItem(once, 'duracionMinutos', 'sum');
    expect(twice).toHaveLength(0);
  });
});
