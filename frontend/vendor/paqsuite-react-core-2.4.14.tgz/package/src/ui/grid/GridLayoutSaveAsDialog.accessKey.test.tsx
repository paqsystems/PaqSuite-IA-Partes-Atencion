/**
 * @vitest-environment jsdom
 */
import type { ReactNode } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it, vi } from 'vitest';

vi.mock('devextreme-react/select-box', () => ({
  default: () => null,
}));

vi.mock('devextreme-react/popup', () => ({
  Popup: (props: { children?: ReactNode }) => <div>{props.children}</div>,
}));

vi.mock('devextreme-react/text-box', () => ({
  default: () => <input />,
}));

vi.mock('devextreme-react/button', () => ({
  default: (props: { text?: string; accessKey?: string; elementAttr?: Record<string, string> }) => (
    <button
      type="button"
      data-testid={props.elementAttr?.['data-testid']}
      data-access-key={props.accessKey ?? ''}
      data-text={props.text}
    >
      {props.text}
    </button>
  ),
}));

import { GridLayoutSaveAsDialog } from './GridLayoutsToolbarControls';

describe('GridLayoutSaveAsDialog atajos', () => {
  it('asigna accessKey distintos a Cancelar y Guardar en español', () => {
    const html = renderToStaticMarkup(
      <GridLayoutSaveAsDialog visible onHiding={() => undefined} onConfirm={() => true} />,
    );
    expect(html).toContain('data-text="Cancelar"');
    expect(html).toContain('data-access-key="c"');
    expect(html).toContain('data-text="Guardar"');
    expect(html).toContain('data-access-key="g"');
    expect(html).toContain('data-testid="gridLayouts.saveAsConfirm"');
  });
});
