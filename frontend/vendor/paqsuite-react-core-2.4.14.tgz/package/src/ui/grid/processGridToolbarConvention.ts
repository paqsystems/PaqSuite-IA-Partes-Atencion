/**
 * Convención de toolbar para grillas de proceso (SPEC-001-11 §3.3).
 * Implementación de referencia: `ProcessDataGrid` y `ConsultaGrillaPivotShell.renderGridView`.
 *
 * Hosts ERP (p. ej. TANGO) deben replicar el mismo orden en `DataGridDX` /
 * `NativeDataGridWithExport`, sin redefinir la disposición en cada pantalla.
 */
export const processGridToolbarConvention = {
  /** Pivot, acciones de proceso, contenido custom del host. */
  leadingToolbarLocation: 'before' as const,
  /** Plantillas, Excel, búsqueda, selector de columnas. */
  trailingToolbarLocation: 'after' as const,
  /** Panel de agrupamiento en segunda fila a ancho completo (ítem `groupPanel`). */
  groupPanelToolbarItemName: 'groupPanel' as const,
} as const;
