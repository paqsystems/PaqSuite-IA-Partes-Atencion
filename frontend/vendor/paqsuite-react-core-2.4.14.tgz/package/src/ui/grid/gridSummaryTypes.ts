export type GridSummaryType = 'count' | 'sum' | 'min' | 'max' | 'avg';

export type GridColumnDataKind = 'number' | 'string' | 'date' | 'boolean' | 'object';

const NUMBER_TYPES = new Set(['number', 'numeric', 'int', 'float', 'decimal']);
const DATE_TYPES = new Set(['date', 'datetime', 'datetimeutc']);
const BOOLEAN_TYPES = new Set(['boolean', 'bool']);

/**
 * Totalizaciones permitidas por tipo de dato (regla BASE 29 / SPEC-001-11).
 * - numéricos: count, sum, min, max, avg
 * - textos / boolean: count, min, max
 * - fechas: count, min, max
 */
export function resolveAllowedGridSummaryTypes(
  dataType?: string | null
): GridSummaryType[] {
  const normalized = String(dataType ?? 'string').trim().toLowerCase();
  if (NUMBER_TYPES.has(normalized)) {
    return ['count', 'sum', 'min', 'max', 'avg'];
  }
  if (DATE_TYPES.has(normalized)) {
    return ['count', 'min', 'max'];
  }
  if (BOOLEAN_TYPES.has(normalized)) {
    return ['count', 'min', 'max'];
  }
  return ['count', 'min', 'max'];
}

export function normalizeGridColumnDataKind(
  dataType?: string | null
): GridColumnDataKind {
  const normalized = String(dataType ?? 'string').trim().toLowerCase();
  if (NUMBER_TYPES.has(normalized)) {
    return 'number';
  }
  if (DATE_TYPES.has(normalized)) {
    return 'date';
  }
  if (BOOLEAN_TYPES.has(normalized)) {
    return 'boolean';
  }
  if (normalized === 'object') {
    return 'object';
  }
  return 'string';
}

/** Inferencia cuando la columna no declara `dataType`. */
export function inferGridColumnDataType(value: unknown): GridColumnDataKind {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return 'number';
  }
  if (typeof value === 'boolean') {
    return 'boolean';
  }
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return 'date';
  }
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(trimmed) && !Number.isNaN(Date.parse(trimmed))) {
      return 'date';
    }
  }
  return 'string';
}

export const DEFAULT_GRID_SUMMARY_TYPE_LABELS: Record<GridSummaryType, string> = {
  count: 'Contar',
  sum: 'Sumar',
  min: 'Mínimo',
  max: 'Máximo',
  avg: 'Promediar',
};

export type ProcessGridTotalItem = {
  column: string;
  summaryType: GridSummaryType;
  name?: string;
  displayFormat?: string;
  valueFormat?: string | object;
  /** Preferible a valueFormat.formatter para TIME / formatos custom (DX Summary). */
  customizeText?: (itemInfo: { value?: string | number | Date; valueText?: string }) => string;
  showInColumn?: string;
};

/** El estado de layouts antiguos puede contener el mismo totalizador más de una vez. */
export function normalizeGridTotalItems(
  items: ProcessGridTotalItem[],
): ProcessGridTotalItem[] {
  const seen = new Set<string>();
  return items.filter((item) => {
    const key = `${item.column}::${item.summaryType}`;
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
}

/**
 * Al restaurar plantillas o activar totalizadores desde menú, reinyecta
 * valueFormat/customizeText desde defaults de la misma columna.
 */
export function enrichGridTotalItems(
  items: ProcessGridTotalItem[],
  defaults: ProcessGridTotalItem[] | undefined
): ProcessGridTotalItem[] {
  if (!defaults?.length) {
    return normalizeGridTotalItems(items);
  }
  return normalizeGridTotalItems(items).map((item) => {
    const exact = defaults.find(
      (def) => def.column === item.column && def.summaryType === item.summaryType
    );
    const byColumn = defaults.find((def) => def.column === item.column);
    const source = exact ?? byColumn;
    if (!source) {
      return item;
    }
    return {
      ...item,
      valueFormat: item.valueFormat ?? source.valueFormat,
      customizeText: item.customizeText ?? source.customizeText,
      displayFormat:
        exact?.displayFormat ??
        (item.displayFormat && item.displayFormat !== '{0}'
          ? item.displayFormat
          : undefined),
    };
  });
}

export function toggleGridTotalItem(
  items: ProcessGridTotalItem[],
  column: string,
  summaryType: GridSummaryType
): ProcessGridTotalItem[] {
  const normalizedItems = normalizeGridTotalItems(items);
  const index = normalizedItems.findIndex(
    (item) => item.column === column && item.summaryType === summaryType
  );
  if (index >= 0) {
    return normalizedItems.filter((_, i) => i !== index);
  }
  return [
    ...normalizedItems,
    {
      column,
      summaryType,
      name: `pq-${column}-${summaryType}`,
    },
  ];
}

export function isGridTotalItemActive(
  items: ProcessGridTotalItem[],
  column: string,
  summaryType: GridSummaryType
): boolean {
  return items.some((item) => item.column === column && item.summaryType === summaryType);
}
