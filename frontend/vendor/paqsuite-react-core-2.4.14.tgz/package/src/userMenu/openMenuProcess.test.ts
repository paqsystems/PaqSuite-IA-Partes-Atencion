import { afterEach, describe, expect, it, vi } from 'vitest';
import { openMenuProcess } from './openMenuProcess';

describe('openMenuProcess', () => {
  const navigate = vi.fn();

  afterEach(() => {
    navigate.mockReset();
    vi.unstubAllGlobals();
  });

  it('abre nueva pestaña en web cuando openInNewTab es true', () => {
    const openSpy = vi.fn();
    vi.stubGlobal('window', { open: openSpy });

    openMenuProcess({
      url: '/proceso-demo',
      openInNewTab: true,
      isNativeApp: false,
      navigate,
    });

    expect(openSpy).toHaveBeenCalledWith('/proceso-demo', '_blank', 'noopener,noreferrer');
    expect(navigate).not.toHaveBeenCalled();
  });

  it('usa navigate en la misma ventana cuando openInNewTab es false', () => {
    const openSpy = vi.fn();
    vi.stubGlobal('window', { open: openSpy });

    openMenuProcess({
      url: '/inicio',
      openInNewTab: false,
      isNativeApp: false,
      navigate,
    });

    expect(navigate).toHaveBeenCalledWith('/inicio');
    expect(openSpy).not.toHaveBeenCalled();
  });

  it('en native ignora openInNewTab y navega in-app', () => {
    const openSpy = vi.fn();
    vi.stubGlobal('window', { open: openSpy });

    openMenuProcess({
      url: '/stock',
      openInNewTab: true,
      isNativeApp: true,
      navigate,
    });

    expect(navigate).toHaveBeenCalledWith('/stock');
    expect(openSpy).not.toHaveBeenCalled();
  });
});
