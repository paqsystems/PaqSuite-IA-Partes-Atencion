import { describe, expect, it } from 'vitest';
import { loginI18nCatalogs, translateLogin } from './loginI18n';
import { supportedLocales } from './localeCatalog';

describe('translateLogin', () => {
  it('expone las mismas claves en los 5 locales', () => {
    const esKeys = Object.keys(loginI18nCatalogs.es).sort();
    for (const locale of supportedLocales) {
      expect(Object.keys(loginI18nCatalogs[locale]).sort()).toEqual(esKeys);
    }
  });

  it('traduce login.hint fuera del español', () => {
    expect(translateLogin('es', 'login.hint')).toBe(
      'Ingrese sus credenciales para continuar.'
    );
    expect(translateLogin('it', 'login.hint')).toBe(
      'Inserisci le tue credenziali per continuare.'
    );
    expect(translateLogin('en', 'login.hint')).not.toContain('credenciales');
  });

  it('usa fallback si la clave no existe', () => {
    expect(translateLogin('it', 'login.missing', 'Texto de respaldo')).toBe(
      'Texto de respaldo'
    );
  });
});
