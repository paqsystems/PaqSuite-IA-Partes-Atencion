/**
 * @vitest-environment jsdom
 */
import { describe, expect, it } from 'vitest';
import { renderHook } from '@testing-library/react';
import { I18nextProvider } from 'react-i18next';
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { registerGridI18nResources } from './registerGridI18nResources';
import { useGridI18n } from './useGridI18n';

async function createTestI18n() {
  const instance = i18n.createInstance();
  await instance.use(initReactI18next).init({
    lng: 'en',
    fallbackLng: 'es',
    interpolation: { escapeValue: false },
  });
  registerGridI18nResources(instance);
  return instance;
}

describe('useGridI18n', () => {
  it('resuelve textos desde react-i18next', async () => {
    const testI18n = await createTestI18n();
    await testI18n.changeLanguage('en');

    const { result } = renderHook(() => useGridI18n(), {
      wrapper: ({ children }) => (
        <I18nextProvider i18n={testI18n}>{children}</I18nextProvider>
      ),
    });

    expect(result.current.exportTitle).toBe('Excel');
    expect(result.current.summaryTypeLabels.sum).toBe('Sum');
    expect(result.current.groupPanelEmptyText).toContain('Drag');
  });

  it('prioriza t del host', async () => {
    const testI18n = await createTestI18n();
    const { result } = renderHook(
      () =>
        useGridI18n({
          t: (key) => (key === 'grid.action.create' ? 'Host add' : key),
        }),
      {
        wrapper: ({ children }) => (
          <I18nextProvider i18n={testI18n}>{children}</I18nextProvider>
        ),
      }
    );

    expect(result.current.createHint).toBe('Host add');
  });
});
