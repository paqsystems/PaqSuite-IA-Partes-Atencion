/** Formatea fecha vía `Intl.DateTimeFormat` (GEN-02); acepta Date, ISO string o timestamp. */
export function formatDate(value: Date | string | number, locale: string): string {
  const date = value instanceof Date ? value : new Date(value);
  return new Intl.DateTimeFormat(locale).format(date);
}

/** Formatea número vía `Intl.NumberFormat` (GEN-02). */
export function formatNumber(value: number, locale: string): string {
  return new Intl.NumberFormat(locale).format(value);
}

/** Importes y cantidades decimales: separador de miles y dos decimales (GEN-12 / regla BASE 32). */
export function formatDecimalNumber(value: number, locale: string): string {
  return new Intl.NumberFormat(locale, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}
