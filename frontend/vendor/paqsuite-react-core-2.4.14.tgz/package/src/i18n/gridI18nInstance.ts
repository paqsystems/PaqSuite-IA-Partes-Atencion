import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { gridI18nCatalogs } from './gridI18n';
import { supportedLocales } from './localeCatalog';

let initStarted = false;

/**
 * Instancia i18next mínima para consumo standalone del SDK (smoke, tests, hosts sin init previo).
 * Si el host ya inicializó i18n, solo debe llamar `registerGridI18nResources`.
 */
export function ensureGridI18nInstance(): void {
  if (i18n.isInitialized || initStarted) {
    return;
  }
  initStarted = true;
  const resources: Record<string, { translation: Record<string, string> }> = {};
  for (const locale of supportedLocales) {
    resources[locale] = { translation: gridI18nCatalogs[locale] };
  }
  void i18n.use(initReactI18next).init({
    resources,
    lng: 'es',
    fallbackLng: 'es',
    interpolation: { escapeValue: false },
  });
}
