import { type LocaleCode } from './localeCatalog';
import type { GridLayoutsToolbarLabels } from '../ui/grid/GridLayoutsToolbarControls';
import type { GridSummaryType } from '../ui/grid/gridSummaryTypes';

/** Claves GEN-02 / SPEC-001-11 expuestas por el SDK (grilla). */
export const frameworkGridI18nKeys = [
  'grid.dx.groupPanelEmpty',
  'grid.dx.columnChooserTitle',
  'grid.summary.menuSection',
  'grid.summary.count',
  'grid.summary.sum',
  'grid.summary.min',
  'grid.summary.max',
  'grid.summary.avg',
  'grid.action.create',
  'grid.action.refresh',
  'grid.loading',
  'grid.empty',
  'grid.error.generic',
  'gridExport.title',
  'gridExport.basic',
  'gridExport.formatted',
  'gridExport.noData',
  'gridLayout.originalLabel',
  'gridLayout.save',
  'gridLayout.saveAs',
  'gridLayout.delete',
  'gridLayout.saveAsTitle',
  'gridLayout.saveAsNameLabel',
  'gridLayout.saveAsConfirm',
  'gridLayout.saveAsCancel',
  'gridLayout.ownerMarker',
  'gridLayout.saveAsError',
  'gridLayout.saveAsFailed',
  'gridLayout.saveFailed',
  'gridLayout.deleteFailed',
  'gridLayout.error',
  'gridLayout.duplicateName',
] as const;

export type FrameworkGridI18nKey = (typeof frameworkGridI18nKeys)[number];

export const gridSummaryTypeI18nKeys: Record<GridSummaryType, FrameworkGridI18nKey> = {
  count: 'grid.summary.count',
  sum: 'grid.summary.sum',
  min: 'grid.summary.min',
  max: 'grid.summary.max',
  avg: 'grid.summary.avg',
};

const es: Record<string, string> = {
  'grid.dx.groupPanelEmpty': 'Arrastre un encabezado de columna aquí para agrupar',
  'grid.dx.columnChooserTitle': 'Columnas',
  'grid.summary.menuSection': 'Totalizadores',
  'grid.summary.count': 'Contar',
  'grid.summary.sum': 'Sumar',
  'grid.summary.min': 'Mínimo',
  'grid.summary.max': 'Máximo',
  'grid.summary.avg': 'Promediar',
  'grid.action.create': 'Agregar',
  'grid.action.refresh': 'Actualizar',
  'grid.loading': 'Cargando…',
  'grid.empty': 'No hay datos para mostrar.',
  'grid.error.generic': 'No se pudo cargar la grilla.',
  'gridExport.title': 'Excel',
  'gridExport.basic': 'Básico',
  'gridExport.formatted': 'Formateado',
  'gridExport.noData': 'Sin datos para exportar',
  'gridLayout.originalLabel': '<Original>',
  'gridLayout.save': 'Guardar',
  'gridLayout.saveAs': 'Guardar como…',
  'gridLayout.delete': 'Eliminar',
  'gridLayout.saveAsTitle': 'Guardar plantilla como…',
  'gridLayout.saveAsNameLabel': 'Nombre',
  'gridLayout.saveAsConfirm': 'Guardar',
  'gridLayout.saveAsCancel': 'Cancelar',
  'gridLayout.ownerMarker': ' (*)',
  'gridLayout.saveAsError': 'No se pudo guardar la plantilla. Revise el nombre o reintente.',
  'gridLayout.saveAsFailed': 'No se pudo guardar la plantilla.',
  'gridLayout.saveFailed': 'No se pudo guardar la plantilla activa.',
  'gridLayout.deleteFailed': 'No se pudo eliminar la plantilla.',
  'gridLayout.error': 'Ocurrió un error con las plantillas de grilla.',
  'gridLayout.duplicateName': 'Ya existe una plantilla con ese nombre.',
};

const en: Record<string, string> = {
  'grid.dx.groupPanelEmpty': 'Drag a column header here to group',
  'grid.dx.columnChooserTitle': 'Columns',
  'grid.summary.menuSection': 'Summaries',
  'grid.summary.count': 'Count',
  'grid.summary.sum': 'Sum',
  'grid.summary.min': 'Min',
  'grid.summary.max': 'Max',
  'grid.summary.avg': 'Average',
  'grid.action.create': 'Add',
  'grid.action.refresh': 'Refresh',
  'grid.loading': 'Loading…',
  'grid.empty': 'No data to display.',
  'grid.error.generic': 'Could not load the grid.',
  'gridExport.title': 'Excel',
  'gridExport.basic': 'Basic',
  'gridExport.formatted': 'Formatted',
  'gridExport.noData': 'No data to export',
  'gridLayout.originalLabel': '<Original>',
  'gridLayout.save': 'Save',
  'gridLayout.saveAs': 'Save as…',
  'gridLayout.delete': 'Delete',
  'gridLayout.saveAsTitle': 'Save layout as…',
  'gridLayout.saveAsNameLabel': 'Name',
  'gridLayout.saveAsConfirm': 'Save',
  'gridLayout.saveAsCancel': 'Cancel',
  'gridLayout.ownerMarker': ' (*)',
  'gridLayout.saveAsError': 'Could not save the layout. Check the name or try again.',
  'gridLayout.saveAsFailed': 'Could not save the layout.',
  'gridLayout.saveFailed': 'Could not save the active layout.',
  'gridLayout.deleteFailed': 'Could not delete the layout.',
  'gridLayout.error': 'A grid layout error occurred.',
  'gridLayout.duplicateName': 'A layout with that name already exists.',
};

const pt: Record<string, string> = {
  'grid.dx.groupPanelEmpty': 'Arraste um cabeçalho de coluna aqui para agrupar',
  'grid.dx.columnChooserTitle': 'Colunas',
  'grid.summary.menuSection': 'Totalizadores',
  'grid.summary.count': 'Contar',
  'grid.summary.sum': 'Somar',
  'grid.summary.min': 'Mínimo',
  'grid.summary.max': 'Máximo',
  'grid.summary.avg': 'Média',
  'grid.action.create': 'Adicionar',
  'grid.action.refresh': 'Atualizar',
  'grid.loading': 'Carregando…',
  'grid.empty': 'Não há dados para exibir.',
  'grid.error.generic': 'Não foi possível carregar a grade.',
  'gridExport.title': 'Excel',
  'gridExport.basic': 'Básico',
  'gridExport.formatted': 'Formatado',
  'gridExport.noData': 'Sem dados para exportar',
  'gridLayout.originalLabel': '<Original>',
  'gridLayout.save': 'Salvar',
  'gridLayout.saveAs': 'Salvar como…',
  'gridLayout.delete': 'Excluir',
  'gridLayout.saveAsTitle': 'Salvar layout como…',
  'gridLayout.saveAsNameLabel': 'Nome',
  'gridLayout.saveAsConfirm': 'Salvar',
  'gridLayout.saveAsCancel': 'Cancelar',
  'gridLayout.ownerMarker': ' (*)',
  'gridLayout.saveAsError': 'Não foi possível salvar o layout. Verifique o nome ou tente novamente.',
  'gridLayout.saveAsFailed': 'Não foi possível salvar o layout.',
  'gridLayout.saveFailed': 'Não foi possível salvar o layout ativo.',
  'gridLayout.deleteFailed': 'Não foi possível excluir o layout.',
  'gridLayout.error': 'Ocorreu um erro com os layouts da grade.',
  'gridLayout.duplicateName': 'Já existe um layout com esse nome.',
};

const fr: Record<string, string> = {
  'grid.dx.groupPanelEmpty': 'Faites glisser un en-tête de colonne ici pour grouper',
  'grid.dx.columnChooserTitle': 'Colonnes',
  'grid.summary.menuSection': 'Totaux',
  'grid.summary.count': 'Compter',
  'grid.summary.sum': 'Somme',
  'grid.summary.min': 'Min',
  'grid.summary.max': 'Max',
  'grid.summary.avg': 'Moyenne',
  'grid.action.create': 'Ajouter',
  'grid.action.refresh': 'Actualiser',
  'grid.loading': 'Chargement…',
  'grid.empty': 'Aucune donnée à afficher.',
  'grid.error.generic': 'Impossible de charger la grille.',
  'gridExport.title': 'Excel',
  'gridExport.basic': 'Basique',
  'gridExport.formatted': 'Formaté',
  'gridExport.noData': 'Aucune donnée à exporter',
  'gridLayout.originalLabel': '<Original>',
  'gridLayout.save': 'Enregistrer',
  'gridLayout.saveAs': 'Enregistrer sous…',
  'gridLayout.delete': 'Supprimer',
  'gridLayout.saveAsTitle': 'Enregistrer la disposition sous…',
  'gridLayout.saveAsNameLabel': 'Nom',
  'gridLayout.saveAsConfirm': 'Enregistrer',
  'gridLayout.saveAsCancel': 'Annuler',
  'gridLayout.ownerMarker': ' (*)',
  'gridLayout.saveAsError': "Impossible d'enregistrer la disposition. Vérifiez le nom ou réessayez.",
  'gridLayout.saveAsFailed': "Impossible d'enregistrer la disposition.",
  'gridLayout.saveFailed': "Impossible d'enregistrer la disposition active.",
  'gridLayout.deleteFailed': 'Impossible de supprimer la disposition.',
  'gridLayout.error': 'Erreur liée aux dispositions de grille.',
  'gridLayout.duplicateName': 'Une disposition porte déjà ce nom.',
};

const it: Record<string, string> = {
  'grid.dx.groupPanelEmpty': "Trascina qui l'intestazione di una colonna per raggruppare",
  'grid.dx.columnChooserTitle': 'Colonne',
  'grid.summary.menuSection': 'Totali',
  'grid.summary.count': 'Conteggio',
  'grid.summary.sum': 'Somma',
  'grid.summary.min': 'Min',
  'grid.summary.max': 'Max',
  'grid.summary.avg': 'Media',
  'grid.action.create': 'Aggiungi',
  'grid.action.refresh': 'Aggiorna',
  'grid.loading': 'Caricamento…',
  'grid.empty': 'Nessun dato da visualizzare.',
  'grid.error.generic': 'Impossibile caricare la griglia.',
  'gridExport.title': 'Excel',
  'gridExport.basic': 'Base',
  'gridExport.formatted': 'Formattato',
  'gridExport.noData': 'Nessun dato da esportare',
  'gridLayout.originalLabel': '<Original>',
  'gridLayout.save': 'Salva',
  'gridLayout.saveAs': 'Salva con nome…',
  'gridLayout.delete': 'Elimina',
  'gridLayout.saveAsTitle': 'Salva layout con nome…',
  'gridLayout.saveAsNameLabel': 'Nome',
  'gridLayout.saveAsConfirm': 'Salva',
  'gridLayout.saveAsCancel': 'Annulla',
  'gridLayout.ownerMarker': ' (*)',
  'gridLayout.saveAsError': 'Impossibile salvare il layout. Controlla il nome o riprova.',
  'gridLayout.saveAsFailed': 'Impossibile salvare il layout.',
  'gridLayout.saveFailed': 'Impossibile salvare il layout attivo.',
  'gridLayout.deleteFailed': 'Impossibile eliminare il layout.',
  'gridLayout.error': 'Errore relativo ai layout della griglia.',
  'gridLayout.duplicateName': 'Esiste già un layout con questo nome.',
};

export const gridI18nCatalogs: Record<LocaleCode, Record<string, string>> = {
  es,
  en,
  pt,
  fr,
  it,
};

/** Mensajes DevExtreme DataGrid (override `loadMessages`) derivados del catálogo GEN. */
export function gridDevExtremeMessagesForLocale(locale: LocaleCode): Record<string, string> {
  return {
    'dxDataGrid-groupPanelEmptyText': translateGrid(locale, 'grid.dx.groupPanelEmpty'),
    'dxDataGrid-columnChooserTitle': translateGrid(locale, 'grid.dx.columnChooserTitle'),
  };
}

export function translateGrid(locale: LocaleCode, key: string, fallback?: string): string {
  const catalog = gridI18nCatalogs[locale] ?? gridI18nCatalogs.es;
  return catalog[key] ?? gridI18nCatalogs.es[key] ?? fallback ?? key;
}

export type GridTranslateFn = (key: string, fallback?: string) => string;

export function buildGridLayoutsToolbarLabels(resolve: GridTranslateFn): GridLayoutsToolbarLabels {
  return {
    originalLabel: resolve('gridLayout.originalLabel', '<Original>'),
    save: resolve('gridLayout.save'),
    saveAs: resolve('gridLayout.saveAs'),
    delete: resolve('gridLayout.delete'),
    saveAsTitle: resolve('gridLayout.saveAsTitle'),
    saveAsNameLabel: resolve('gridLayout.saveAsNameLabel'),
    saveAsConfirm: resolve('gridLayout.saveAsConfirm'),
    saveAsCancel: resolve('gridLayout.saveAsCancel'),
    ownerSuffix: resolve('gridLayout.ownerMarker', ' (*)'),
    saveAsError: resolve('gridLayout.saveAsError'),
  };
}

export function buildGridSummaryTypeLabels(
  resolve: GridTranslateFn
): Record<GridSummaryType, string> {
  return {
    count: resolve('grid.summary.count'),
    sum: resolve('grid.summary.sum'),
    min: resolve('grid.summary.min'),
    max: resolve('grid.summary.max'),
    avg: resolve('grid.summary.avg'),
  };
}

const layoutErrorKeyMap: Record<string, FrameworkGridI18nKey> = {
  'layouts.saveAsFailed': 'gridLayout.saveAsFailed',
  'layouts.saveFailed': 'gridLayout.saveFailed',
  'layouts.deleteFailed': 'gridLayout.deleteFailed',
  'layouts.error': 'gridLayout.error',
};

/** Traduce claves técnicas de layouts (`layouts.*` / envelope) a texto UI. */
export function resolveGridLayoutErrorMessage(
  resolve: GridTranslateFn,
  messageKey: string | null | undefined
): string | null {
  if (!messageKey) {
    return null;
  }
  const mapped = layoutErrorKeyMap[messageKey];
  if (mapped) {
    return resolve(mapped);
  }
  if (messageKey.startsWith('gridLayout.')) {
    return resolve(messageKey);
  }
  return messageKey;
}
