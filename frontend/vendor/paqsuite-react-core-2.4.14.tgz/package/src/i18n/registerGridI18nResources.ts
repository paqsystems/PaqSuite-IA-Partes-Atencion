import type { i18n as I18nInstance } from 'i18next';
import { gridI18nCatalogs } from './gridI18n';
import { supportedLocales } from './localeCatalog';

/**
 * Fusiona el catálogo GEN-02 de grilla en la instancia i18next del host.
 * Llamar una vez tras `i18n.init` (junto a login/envelope/shell del producto).
 */
export function registerGridI18nResources(
  i18n: I18nInstance,
  namespace: string = 'translation'
): void {
  for (const locale of supportedLocales) {
    i18n.addResourceBundle(locale, namespace, gridI18nCatalogs[locale], true, true);
  }
}
