import { useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { normalizeLocale } from './normalizeLocale';
import {
  buildGridLayoutsToolbarLabels,
  buildGridSummaryTypeLabels,
  resolveGridLayoutErrorMessage,
  type GridTranslateFn,
  translateGrid,
} from './gridI18n';
import type { GridLayoutsToolbarLabels } from '../ui/grid/GridLayoutsToolbarControls';
import type { GridSummaryType } from '../ui/grid/gridSummaryTypes';
import { ensureGridI18nInstance } from './gridI18nInstance';

export type UseGridI18nOptions = {
  /** Locale activo (p. ej. prefs usuario). Si falta, usa `i18n.language`. */
  locale?: string;
  /** Traductor del host; prioridad sobre react-i18next y catálogo SDK. */
  t?: (key: string) => string;
};

export type UseGridI18nResult = {
  locale: ReturnType<typeof normalizeLocale> extends infer T ? NonNullable<T> | 'es' : 'es';
  resolve: GridTranslateFn;
  summaryTypeLabels: Record<GridSummaryType, string>;
  layoutsToolbarLabels: GridLayoutsToolbarLabels;
  groupPanelEmptyText: string;
  columnChooserTitle: string;
  createHint: string;
  loadingLabel: string;
  refreshLabel: string;
  exportTitle: string;
  exportBasicLabel: string;
  exportFormattedLabel: string;
  exportNoDataHint: string;
  summaryMenuSection: string;
  resolveLayoutErrorMessage: (messageKey: string | null | undefined) => string | null;
};

ensureGridI18nInstance();

/**
 * Hook GEN-02 / GEN-11: textos de sistema de grilla vía react-i18next + catálogo SDK.
 */
export function useGridI18n(options?: UseGridI18nOptions): UseGridI18nResult {
  const { t: i18nT, i18n } = useTranslation(undefined, { useSuspense: false });
  const locale = normalizeLocale(options?.locale ?? i18n.language) ?? 'es';

  const resolve = useCallback<GridTranslateFn>(
    (key, fallback) => {
      if (options?.t) {
        const hostValue = options.t(key);
        if (hostValue && hostValue !== key) {
          return hostValue;
        }
      }
      if (i18n.isInitialized) {
        const translated = i18nT(key, { defaultValue: '' });
        if (translated) {
          return translated;
        }
      }
      return translateGrid(locale, key, fallback);
    },
    [i18n.isInitialized, i18nT, locale, options?.t]
  );

  const summaryTypeLabels = useMemo(() => buildGridSummaryTypeLabels(resolve), [resolve]);
  const layoutsToolbarLabels = useMemo(() => buildGridLayoutsToolbarLabels(resolve), [resolve]);

  const resolveLayoutErrorMessage = useCallback(
    (messageKey: string | null | undefined) => resolveGridLayoutErrorMessage(resolve, messageKey),
    [resolve]
  );

  return useMemo(
    () => ({
      locale,
      resolve,
      summaryTypeLabels,
      layoutsToolbarLabels,
      groupPanelEmptyText: resolve('grid.dx.groupPanelEmpty'),
      columnChooserTitle: resolve('grid.dx.columnChooserTitle'),
      createHint: resolve('grid.action.create'),
      loadingLabel: resolve('grid.loading'),
      refreshLabel: resolve('grid.action.refresh'),
      exportTitle: resolve('gridExport.title'),
      exportBasicLabel: resolve('gridExport.basic'),
      exportFormattedLabel: resolve('gridExport.formatted'),
      exportNoDataHint: resolve('gridExport.noData'),
      summaryMenuSection: resolve('grid.summary.menuSection'),
      resolveLayoutErrorMessage,
    }),
    [
      locale,
      resolve,
      summaryTypeLabels,
      layoutsToolbarLabels,
      resolveLayoutErrorMessage,
    ]
  );
}
