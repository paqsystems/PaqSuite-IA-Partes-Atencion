import { describe, expect, it } from 'vitest';
import {
  buildGridSummaryTypeLabels,
  frameworkGridI18nKeys,
  gridI18nCatalogs,
  resolveGridLayoutErrorMessage,
  translateGrid,
} from './gridI18n';

describe('gridI18n', () => {
  it('expone las mismas claves en los 5 locales', () => {
    for (const locale of ['es', 'en', 'pt', 'fr', 'it'] as const) {
      for (const key of frameworkGridI18nKeys) {
        expect(gridI18nCatalogs[locale][key]).toBeTruthy();
      }
    }
  });

  it('traduce totalizadores en inglés', () => {
    expect(translateGrid('en', 'grid.summary.sum')).toBe('Sum');
    expect(translateGrid('es', 'grid.summary.sum')).toBe('Sumar');
  });

  it('buildGridSummaryTypeLabels usa resolve', () => {
    const labels = buildGridSummaryTypeLabels((key) => translateGrid('en', key));
    expect(labels.avg).toBe('Average');
  });

  it('mapea claves layouts.* legacy', () => {
    const resolve = (key: string) => translateGrid('es', key);
    expect(resolveGridLayoutErrorMessage(resolve, 'layouts.saveAsFailed')).toContain('plantilla');
  });
});
