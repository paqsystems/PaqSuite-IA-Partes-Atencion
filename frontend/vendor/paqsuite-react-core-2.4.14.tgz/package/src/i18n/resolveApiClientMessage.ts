import { transportI18nKey, type ApiClientResult } from '../http/parseEnvelope';
import { type LocaleCode } from './localeCatalog';
import { translateEnvelopeRespuesta } from './envelopeI18n';

export type ResolveApiClientMessageOptions = {
  /** Traductor del host (`t`) antes del catálogo SDK. */
  hostTranslate?: (key: string) => string | undefined;
  fallback?: string;
};

function resolveKey(
  locale: LocaleCode,
  key: string,
  options?: ResolveApiClientMessageOptions
): string {
  const hostMessage = options?.hostTranslate?.(key);
  if (hostMessage) {
    return hostMessage;
  }
  return translateEnvelopeRespuesta(locale, key, options?.fallback);
}

/**
 * Mensaje visible para cualquier `ApiClientResult` (GEN-20 + GEN-33).
 * Usar en handlers globales de error cuando la UI no tiene `t()` directo.
 */
export function resolveApiClientMessage(
  locale: LocaleCode,
  result: ApiClientResult<unknown>,
  options?: ResolveApiClientMessageOptions
): string {
  if (result.kind === 'transportError') {
    return resolveKey(locale, result.i18nKey ?? transportI18nKey, options);
  }
  if (result.kind === 'envelopeError') {
    return resolveKey(locale, result.envelope.respuesta, options);
  }
  return options?.fallback ?? '';
}
