import type { LocaleCode } from './localeCatalog';
import {
  resolveAuthHeroConfig,
  type AuthHeroConfig,
  type ResolveAuthHeroConfigInput,
} from '../ui/auth/authHeroConfig';

/** Clave canónica del título de producto en catálogos del host (`productI18n`). */
export const productTitleI18nKey = 'product.title';

/** Clave canónica del tagline del hero auth en catálogos del host. */
export const productTaglineI18nKey = 'product.tagline';

export type ProductBrandingCatalogs = Record<LocaleCode, Record<string, string>>;

export function resolveProductBrandingString(
  locale: LocaleCode,
  catalogs: ProductBrandingCatalogs,
  key: string,
  fallback = ''
): string {
  const catalog = catalogs[locale] ?? {};
  const esCatalog = catalogs.es ?? {};
  const value = catalog[key] ?? esCatalog[key];
  if (value == null) {
    return fallback;
  }
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : fallback;
}

export type ResolveAuthHeroFromProductI18nInput = {
  locale: LocaleCode;
  productCatalogs: ProductBrandingCatalogs;
  productTitleKey?: string;
  productTaglineKey?: string;
  /** Logo opcional (p. ej. `VITE_AUTH_COMPANY_LOGO_URL`). */
  companyLogoUrl?: string | null;
  /** Si true (default), ignora `productTitle`/`productTagline` de build-time. */
  preferI18nProductCopy?: boolean;
  productTitle?: string | null;
  productTagline?: string | null;
  fallbackTitle?: string;
  fallbackTagline?: string;
};

/**
 * Hero auth con título/tagline desde catálogo de producto del host (SPEC-001-02-update / TR-GEN-01-shell-ui-update).
 */
export function resolveAuthHeroFromProductI18n(
  input: ResolveAuthHeroFromProductI18nInput
): AuthHeroConfig {
  const preferI18n = input.preferI18nProductCopy !== false;
  const titleKey = input.productTitleKey ?? productTitleI18nKey;
  const taglineKey = input.productTaglineKey ?? productTaglineI18nKey;

  const i18nTitle = resolveProductBrandingString(
    input.locale,
    input.productCatalogs,
    titleKey,
    input.fallbackTitle ?? ''
  );
  const i18nTagline = resolveProductBrandingString(
    input.locale,
    input.productCatalogs,
    taglineKey,
    input.fallbackTagline ?? ''
  );

  const envFields: Pick<
    ResolveAuthHeroConfigInput,
    'productTitle' | 'productTagline' | 'companyLogoUrl'
  > = {
    companyLogoUrl: input.companyLogoUrl,
    productTitle: preferI18n ? null : input.productTitle,
    productTagline: preferI18n ? null : input.productTagline,
  };

  return resolveAuthHeroConfig({
    ...envFields,
    fallbackTitle: i18nTitle,
    fallbackTagline: i18nTagline,
  });
}
