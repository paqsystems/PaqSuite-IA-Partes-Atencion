import { describe, expect, it } from 'vitest';
import { agentOfflineI18nKey } from './envelopeI18n';
import { resolveApiClientMessage } from './resolveApiClientMessage';

describe('resolveApiClientMessage', () => {
  it('traduce envelopeError agent.offline en inglés', () => {
    const message = resolveApiClientMessage('en', {
      kind: 'envelopeError',
      httpStatus: 503,
      envelope: { error: 9002, respuesta: agentOfflineI18nKey, resultado: {} },
    });
    expect(message).toBe('The agent is not available.');
  });

  it('prioriza hostTranslate sobre catálogo SDK', () => {
    const message = resolveApiClientMessage(
      'en',
      {
        kind: 'envelopeError',
        httpStatus: 503,
        envelope: { error: 9002, respuesta: agentOfflineI18nKey, resultado: {} },
      },
      { hostTranslate: () => 'Host override' }
    );
    expect(message).toBe('Host override');
  });

  it('traduce transportError con infra.transport', () => {
    const message = resolveApiClientMessage('es', {
      kind: 'transportError',
      i18nKey: 'infra.transport',
    });
    expect(message).toBe('infra.transport');
  });
});
