import { describe, expect, it } from 'vitest';
import {
  productTaglineI18nKey,
  productTitleI18nKey,
  resolveAuthHeroFromProductI18n,
  resolveProductBrandingString,
} from './productBrandingI18n';

const catalogs = {
  es: {
    [productTitleI18nKey]: 'Mi Producto',
    [productTaglineI18nKey]: 'Descripción en español.',
  },
  en: {
    [productTitleI18nKey]: 'My Product',
    [productTaglineI18nKey]: 'Description in English.',
  },
  pt: {},
  fr: {},
  it: {},
};

describe('resolveProductBrandingString', () => {
  it('resuelve por locale con fallback a es', () => {
    expect(
      resolveProductBrandingString('en', catalogs, productTitleI18nKey, 'fallback')
    ).toBe('My Product');
    expect(
      resolveProductBrandingString('pt', catalogs, productTitleI18nKey, 'fallback')
    ).toBe('Mi Producto');
  });
});

describe('resolveAuthHeroFromProductI18n', () => {
  it('arma hero desde catálogo según locale', () => {
    const heroEs = resolveAuthHeroFromProductI18n({
      locale: 'es',
      productCatalogs: catalogs,
    });
    const heroEn = resolveAuthHeroFromProductI18n({
      locale: 'en',
      productCatalogs: catalogs,
    });

    expect(heroEs.productTitle).toBe('Mi Producto');
    expect(heroEs.productTagline).toBe('Descripción en español.');
    expect(heroEn.productTitle).toBe('My Product');
    expect(heroEn.productTagline).toBe('Description in English.');
  });

  it('ignora env de título cuando preferI18nProductCopy es true', () => {
    const hero = resolveAuthHeroFromProductI18n({
      locale: 'en',
      productCatalogs: catalogs,
      productTitle: 'Título monolingüe env',
      productTagline: 'Tagline env',
    });

    expect(hero.productTitle).toBe('My Product');
    expect(hero.productTagline).toBe('Description in English.');
  });
});
