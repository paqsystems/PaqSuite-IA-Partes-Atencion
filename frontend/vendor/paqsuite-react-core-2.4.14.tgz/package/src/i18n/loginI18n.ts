import { type LocaleCode } from './localeCatalog';

const es: Record<string, string> = {
  'login.title': 'Iniciar sesión',
  'login.hint': 'Ingrese sus credenciales para continuar.',
  'login.usuario': 'Usuario',
  'login.password': 'Contraseña',
  'login.forgot': 'Olvidé mi contraseña',
  'login.submit': 'Ingresar',
  'login.submitting': 'Ingresando…',
  'login.tenant': 'Tenant / instalación',
};

const en: Record<string, string> = {
  'login.title': 'Sign in',
  'login.hint': 'Enter your credentials to continue.',
  'login.usuario': 'User',
  'login.password': 'Password',
  'login.forgot': 'Forgot password?',
  'login.submit': 'Sign in',
  'login.submitting': 'Signing in…',
  'login.tenant': 'Tenant / installation',
};

const pt: Record<string, string> = {
  'login.title': 'Entrar',
  'login.hint': 'Insira suas credenciais para continuar.',
  'login.usuario': 'Usuário',
  'login.password': 'Senha',
  'login.forgot': 'Esqueci minha senha',
  'login.submit': 'Entrar',
  'login.submitting': 'Entrando…',
  'login.tenant': 'Tenant / instalação',
};

const fr: Record<string, string> = {
  'login.title': 'Connexion',
  'login.hint': 'Saisissez vos identifiants pour continuer.',
  'login.usuario': 'Utilisateur',
  'login.password': 'Mot de passe',
  'login.forgot': 'Mot de passe oublié ?',
  'login.submit': 'Se connecter',
  'login.submitting': 'Connexion…',
  'login.tenant': 'Tenant / installation',
};

const it: Record<string, string> = {
  'login.title': 'Accedi',
  'login.hint': 'Inserisci le tue credenziali per continuare.',
  'login.usuario': 'Utente',
  'login.password': 'Password',
  'login.forgot': 'Password dimenticata?',
  'login.submit': 'Accedi',
  'login.submitting': 'Accesso…',
  'login.tenant': 'Tenant / installazione',
};

export const loginI18nCatalogs: Record<LocaleCode, Record<string, string>> = {
  es,
  en,
  pt,
  fr,
  it,
};

export function translateLogin(
  locale: LocaleCode,
  key: string,
  fallback?: string
): string {
  const catalog = loginI18nCatalogs[locale] ?? loginI18nCatalogs.es;
  return catalog[key] ?? loginI18nCatalogs.es[key] ?? fallback ?? key;
}
