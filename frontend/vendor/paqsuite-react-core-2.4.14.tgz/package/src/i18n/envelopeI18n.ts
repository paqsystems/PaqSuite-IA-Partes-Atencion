import { type LocaleCode } from './localeCatalog';

export const agentOfflineI18nKey = 'agent.offline';
export const agentGatewayMisconfiguredI18nKey = 'agent.gatewayMisconfigured';

const es: Record<string, string> = {
  [agentOfflineI18nKey]: 'El agente no está disponible.',
  [agentGatewayMisconfiguredI18nKey]:
    'El canal Gateway no está configurado correctamente.',
};

const en: Record<string, string> = {
  [agentOfflineI18nKey]: 'The agent is not available.',
  [agentGatewayMisconfiguredI18nKey]: 'The Gateway channel is misconfigured.',
};

const pt: Record<string, string> = {
  [agentOfflineI18nKey]: 'O agente não está disponível.',
  [agentGatewayMisconfiguredI18nKey]: 'O canal Gateway não está configurado corretamente.',
};

const fr: Record<string, string> = {
  [agentOfflineI18nKey]: "L'agent n'est pas disponible.",
  [agentGatewayMisconfiguredI18nKey]: 'Le canal Gateway est mal configuré.',
};

const it: Record<string, string> = {
  [agentOfflineI18nKey]: "L'agente non è disponibile.",
  [agentGatewayMisconfiguredI18nKey]: 'Il canale Gateway non è configurato correttamente.',
};

export const envelopeI18nCatalogs: Record<LocaleCode, Record<string, string>> = {
  es,
  en,
  pt,
  fr,
  it,
};

/** Claves envelope traducidas por el SDK (GEN-33 canal Gateway + infra transversal). */
export const frameworkEnvelopeI18nKeys = [
  agentOfflineI18nKey,
  agentGatewayMisconfiguredI18nKey,
] as const;

/**
 * Traduce `envelope.respuesta` cuando la clave es canónica del Framework.
 * Hosts: usar como `defaultValue` de `t(respuesta)` o antes de mostrar errores de API.
 */
export function translateEnvelopeRespuesta(
  locale: LocaleCode,
  respuesta: string,
  fallback?: string
): string {
  const catalog = envelopeI18nCatalogs[locale] ?? envelopeI18nCatalogs.es;
  return catalog[respuesta] ?? envelopeI18nCatalogs.es[respuesta] ?? fallback ?? respuesta;
}
