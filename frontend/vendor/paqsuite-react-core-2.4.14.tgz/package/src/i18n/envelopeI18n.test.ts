import { describe, expect, it } from 'vitest';
import { supportedLocales } from './localeCatalog';
import {
  agentGatewayMisconfiguredI18nKey,
  agentOfflineI18nKey,
  envelopeI18nCatalogs,
  frameworkEnvelopeI18nKeys,
  translateEnvelopeRespuesta,
} from './envelopeI18n';

describe('envelopeI18n', () => {
  it('incluye agent.offline y agent.gatewayMisconfigured en los 5 idiomas', () => {
    const esKeys = frameworkEnvelopeI18nKeys.slice().sort();
    for (const locale of supportedLocales) {
      expect(Object.keys(envelopeI18nCatalogs[locale]).sort()).toEqual(esKeys);
    }
  });

  it('traduce agent.offline según locale', () => {
    expect(translateEnvelopeRespuesta('es', agentOfflineI18nKey)).toContain('agente');
    expect(translateEnvelopeRespuesta('en', agentOfflineI18nKey)).toBe(
      'The agent is not available.'
    );
    expect(translateEnvelopeRespuesta('en', agentOfflineI18nKey)).not.toContain('agent.offline');
  });

  it('traduce agent.gatewayMisconfigured según locale', () => {
    expect(translateEnvelopeRespuesta('es', agentGatewayMisconfiguredI18nKey)).toContain(
      'Gateway'
    );
    expect(translateEnvelopeRespuesta('en', agentGatewayMisconfiguredI18nKey)).toContain(
      'misconfigured'
    );
  });

  it('devuelve fallback o la clave cruda si no está en catálogo', () => {
    expect(translateEnvelopeRespuesta('en', 'custom.host.key', 'Host message')).toBe(
      'Host message'
    );
    expect(translateEnvelopeRespuesta('en', 'custom.host.key')).toBe('custom.host.key');
  });
});
