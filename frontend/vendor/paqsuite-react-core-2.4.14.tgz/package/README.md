# @paqsuite/react-core

Headers de plataforma (`X-Paq-Cliente`, `X-Company-Id`) y cliente HTTP con envelope PaqSuite.

Norma: [`docs/05-open-spec/001-Generalidades/SPEC-001-20-contrato-api-envelope.md`](../../../docs/05-open-spec/001-Generalidades/SPEC-001-20-contrato-api-envelope.md)

## Instalación (producto)

```json
{
  "dependencies": {
    "@paqsuite/react-core": "github:paqsystems/react-core#v2.4.7"
  }
}
```

Distribución: repo [`paqsystems/react-core`](https://github.com/paqsystems/react-core) (source TS para Vite).  
Runbook: [`docs/06-operacion/adopcion-sdk-registry.md`](../../../docs/06-operacion/adopcion-sdk-registry.md).

## Desarrollo en el monorepo

```bash
npm install
npm test
npm run build
```

## Breaking change (v2)

`apiRequest` ya **no** retorna `Promise<PaqSuiteEnvelope<T>>`.  
Retorna `Promise<ApiClientResult<T>>`:

| `kind` | Uso |
|--------|-----|
| `ok` | `error === 0` y HTTP &lt; 400; usar `envelope.resultado` |
| `envelopeError` | Envelope válido con error de API; UI: `t(envelope.respuesta)` |
| `transportError` | Red, no-JSON o shape inválido; UI: `t('infra.transport')` |

```ts
import { apiRequest } from '@paqsuite/react-core';

const result = await apiRequest<{ items: unknown[] }>('/api/v1/items', {
  platform: { cliente: 'demo', companyId: 1 },
  headers: { Authorization: `Bearer ${token}` },
});

if (result.kind === 'ok') {
  console.log(result.envelope.resultado);
} else if (result.kind === 'envelopeError') {
  showError(t(result.envelope.respuesta));
} else {
  showError(t(result.i18nKey)); // infra.transport
}
```

Claves envelope del Framework (p. ej. `agent.offline`, `agent.gatewayMisconfigured` — GEN-33):

```ts
import { resolveApiClientMessage, translateEnvelopeRespuesta } from '@paqsuite/react-core';

// Con locale activo y catálogo SDK (5 idiomas):
showError(resolveApiClientMessage(locale, result));

// O como defaultValue del host:
showError(t(result.envelope.respuesta, {
  defaultValue: translateEnvelopeRespuesta(locale, result.envelope.respuesta),
}));
```

Migración: reemplazar `const data = await apiRequest(...)` por el switch de `kind`.

## Tenancy FE (v2.1 — SPEC-001-19)

```ts
import {
  resolveClienteCode,
  isDevOrNonCanonicalHostname,
  persistClienteCode,
  buildPlatformHeaders,
  resolveEmpresaGate,
  blockedNoCompanyI18nKey,
  registerOnCompanyChange,
  applyEmpresaAppearance,
} from '@paqsuite/react-core';

const cliente = resolveClienteCode({
  isDevOrNonCanonicalUrl: isDevOrNonCanonicalHostname(location.hostname, import.meta.env.DEV),
  queryCliente: new URLSearchParams(location.search).get('cliente'),
  cookieCliente: readCookie('paqCliente'),
  sessionCliente: sessionStorage.getItem('paqCliente'),
});
persistClienteCode(cliente, browserPersistence); // cookie + sessionStorage (no localStorage)

// MUST host: ejecutar esto en main.tsx ANTES de BrowserRouter (bootstrapClienteFromWindow).
// Navigate / → /login sin search + persistir en useEffect = DEMO en producción.

const headers = buildPlatformHeaders({ cliente, companyId });

const gate = resolveEmpresaGate({ tenancy: 'multi', empresasConPermiso });
if (gate === 'blockedNoCompany') showError(t(blockedNoCompanyI18nKey));
```

### Checklist host (shell)

- 4 zonas: `data-testid` `shellHeader` | `shellSidebar` | `shellMain` | `shellFooter` | `shellFooterCliente` | `shellFooterEmpresa`
- Footer con `{cliente}` (instalación) y empresa también en `single`
- Login público ≠ tema A1; `applyEmpresaAppearance` al cambiar empresa + change-password
- Registrar `registerOnCompanyChange` para invalidar menú/caché

Norma: [`SPEC-001-19`](../../../docs/05-open-spec/001-Generalidades/SPEC-001-19-shell-branding-y-tenancy.md).

### Branding por cliente (logo instalación)

```ts
import {
  resolveClienteLogoUrl,
  resolveClienteDefaultLogoUrl,
  ClienteLogo,
  ShellBrand,
} from '@paqsuite/react-core';

const logoUrl = resolveClienteLogoUrl('ankasdelsur'); // → /images/ANKASDELSUR.jpg

// Componente con fallback CLIENTE.jpg → default.jpg → ocultar
<ClienteLogo cliente={cliente} className="pqAuthLoginLogo" testId="authCompanyLogo" />

// Header shell: logo + título producto
<ShellBrand cliente={cliente} productTitle="PedidosWeb" />
```

Assets en el **host**: `frontend/public/images/{CLIENTE}.jpg` + `default.jpg` + `DEMO.jpg`. Ver `MANUAL-DEL-PROGRAMADOR.md` §3.2.

## Experiencia mobile (GEN-22)

Exports principales:

- `isNativeApp`, `resolveApiBaseUrl`, `bootstrapApiBaseUrl`, `applyWebApiBaseUrlFromEnv`, `MobileConfigPanel`
- Preferences: `preferenceKeys`, `setPreferencesAdapter`, `hydrateApiBaseUrlCache`, `writeNativeAuthSnapshot`
- **Web multidominio (Vercel + Forge):** en `main.tsx` llamar `await bootstrapApiBaseUrl({ envBaseUrl: import.meta.env.VITE_API_BASE_URL, projectSlug: '…' })` **antes** del primer `apiRequest`. Ver [`adopcion-api-base-url.md`](../../../docs/06-operacion/adopcion-api-base-url.md).
- Policy: `createMobilePolicy`, `genMobileExclusions`, `isPivotMenuItem`, `MobileMenuShell`, `MobileRouteGuard`
  - Familia `pivots`: rutas `/pivots|` `/pivot/*` + `procedimientoContains: ['pivot']`; informe mixto → exclusión **proceso entero** (C1-12-F05); i18n `mobile.exclusion.pivot`
- Kardex: `ConsultaKardexList`, `KardexItem`
- Push: `useMobilePushOptIn`, `setMobilePushBridge`, `registerMobilePushHandlers`

Claves Preferences: `paqMobile.apiBaseUrlOverride`, `paqAuth.accessToken`, `paqAuth.tenant`, `paqAuth.sessionJson`.

Peer opcional: `@capacitor/preferences` (inyectar vía `setPreferencesAdapter` en el host).

Evidencia: `apps/smoke-frontend` + [CHECKLIST-001-22](../../../docs/05-open-spec/001-Generalidades/CHECKLIST-001-22-adopcion-mobile.md).

Norma: [`SPEC-001-22`](../../../docs/05-open-spec/001-Generalidades/SPEC-001-22-experiencia-mobile.md).

## Importaciones Excel (GEN-14)

Exports: `ExcelImportToolbar`, `ExcelImportModal`, `ExcelImportErrorsGrid`, `useExcelImport`, `excelImportApiClient`, `excelImportPolicy`.

Host:
- Montar `ExcelImportToolbar` con `processCode` + `onComplete` en una **fila propia** (MUST; no compartir fila con otros controles).
- No rutas `/excel-import/*`. En native no montar (`isNativeApp` / policy).
- Grilla de errores: solo nº de fila + texto (tooltip con el texto completo).

Evidencia: `apps/smoke-frontend` ruta `/demo/clientes-import`. Norma: [`SPEC-001-14`](../../../docs/05-open-spec/001-Generalidades/SPEC-001-14-importaciones-excel.md).

## Pivots (GEN-12)

Exports: `ConsultaGrillaPivotShell`, `PivotGridBlock`, `PivotViewToggle`, `PivotExportButton`, `exportPivotGridExcel` / `buildPivotExportFileName`, `fetchPivotCatalog`, clients layouts/plantillas, `mapCatalogToPivotFields`, `applyPivotState` / `capturePivotState`, `isPivotMenuItem`.

Host: montar shell con `catalog` + `loadPivotDataset`; toolbar auto: Actualizar → layouts → plantilla → **export** (opt-out `exportEnabled={false}`). Native: shell/block/export retornan `null`; menú/deep-link filtrados por `genMobileExclusions` + `isPivotMenuItem`.

Evidencia smoke: `/pivots/consulta-smoke` + `PivotCatalogSmokeSeeder`. Flags env BE (`PIVOTS_ENABLED` / `PIVOT_LAYOUTS_ENABLED`). Norma: [`SPEC-001-12`](../../../docs/05-open-spec/001-Generalidades/SPEC-001-12-pivots-y-layouts.md).

## ARCA Integration (GEN-32)

Exports: `ArcaConfigPage`, `ArcaHomologacionPage`, `arcaApiClient`, `translateArca`, `buildArcaFacturaAFixture`.

Host: consume `/api/v1/arca` con el JSON `ComprobanteFiscal`; persiste CAE en **su** modelo. Consola smoke en `/admin/arca/config` y `/admin/arca/homologacion`. **No** copiar ids de menú `70000–70200`. Native: family `arca` en `genMobileExclusions`.

Adopción: [`adopcion-gen-32-arca.md`](../../../docs/06-operacion/adopcion-gen-32-arca.md). Norma: [`SPEC-001-32`](../../../docs/05-open-spec/001-Generalidades/SPEC-001-32-arca-integration.md).

## Grillas de proceso (`ProcessDataGrid`, GEN-11)

Export: `ProcessDataGrid`, tipos `ProcessDataGridProps` / `ProcessGridTotalItem`, helpers de summary y layouts.

Toolbar **integrada** (contrato SPEC-001-11 §3.3):

1. **Izquierda** — prop opcional **`toolbarLeading`** (p. ej. botón Pivot).
2. **Derecha** — plantillas (si `proceso` + `gridId` + token) → **column chooser** → **«+»** (si alta).

```tsx
import { ProcessDataGrid } from '@paqsuite/react-core';

<ProcessDataGrid
  proceso="demo.consulta"
  gridId="detalle"
  accessToken={token}
  platform={platform}
  toolbarLeading={<Button text="Pivot" onClick={…} />}
>
  {/* columnas */}
</ProcessDataGrid>
```

Norma: [`SPEC-001-11`](../../../docs/05-open-spec/001-Generalidades/SPEC-001-11-grillas-y-layouts.md) §3.3 · regla BASE `29`.

### i18n grilla (GEN-02 + GEN-11)

`ProcessDataGrid` y `DataGridDx` usan **react-i18next** (`useGridI18n` interno). Catálogo SDK en 5 locales: claves `grid.*`, `gridExport.*`, `gridLayout.*`.

**Host con i18next propio** — tras `i18n.init`:

```ts
import { registerGridI18nResources, syncDevExtremeLocale } from '@paqsuite/react-core';

registerGridI18nResources(i18n);
syncDevExtremeLocale(locale); // incluye overrides DX group panel / column chooser
```

Props opcionales en `ProcessDataGrid`: `locale`, `t` (misma prioridad que `MenuSidebar`). Overrides puntuales (`summaryTypeLabels`, `layoutLabels`, …) siguen vigentes.

Remount al cambiar idioma: `key={\`${gridId}-${locale}\`}` en la grilla (SPEC-001-02 §7).

Exports: `gridI18nCatalogs`, `frameworkGridI18nKeys`, `translateGrid`, `useGridI18n`, `registerGridI18nResources`.

## Auth UI (GEN-01) — adopción host

Familia visual login/forgot/reset (referencia PedidosWeb). **No copiar CSS** del producto; consumir el paquete.

```ts
import {
  AuthLoginLayout,
  AuthCardLayout,
  resolveAuthHeroConfig,
  readViteAuthHeroEnv,
  authClassNames,
  LanguageSelector,
  translateLogin,
} from '@paqsuite/react-core';
import '@paqsuite/react-core/auth.css';

const hero = resolveAuthHeroConfig({
  ...readViteAuthHeroEnv(),
  // o i18n: t('login.title') / t('login.subtitle')
  fallbackTitle: 'Mi Producto',
  fallbackTagline: 'Descripción del portal para el usuario.',
});

<AuthLoginLayout
  hero={hero}
  cardTitle={translateLogin(locale, 'login.title', 'Iniciar sesión')}
  cardHint={translateLogin(locale, 'login.hint', 'Ingrese sus credenciales para continuar.')}
  toolbar={<LanguageSelector testId="authLanguageSelect" locale={locale} onLocaleChange={…} />}
  footer={<Link to="/forgot-password">{translateLogin(locale, 'login.forgot', 'Olvidé mi contraseña')}</Link>}
>
  <form className={authClassNames.form}>…</form>
</AuthLoginLayout>
```

Los campos de contraseña del formulario host deben usar `TextBox` DevExtreme en modo
`password` inicialmente y ofrecer el toggle integrado `eyeopen`/`eyeclose` para mostrar u
ocultar el valor. La interacción es local, conserva el valor, no persiste ni registra la
contraseña y debe exponer `hint` i18n (`Mostrar contraseña` / `Ocultar contraseña`) y un
`data-testid` estable. La regla aplica también a reset y change-password; ver
[`TR-GEN-04-login-frontend`](../../../docs/04-tareas/001-Generalidades/TR-GEN-04-login-frontend.md).

| Variable | Uso |
|----------|-----|
| `VITE_AUTH_PRODUCT_TITLE` | Título del hero (ej. «Partes de Atención») |
| `VITE_AUTH_PRODUCT_TAGLINE` | Descripción del proyecto en el hero |
| `VITE_AUTH_COMPANY_LOGO_URL` | Logo opcional; vacío → no renderizar |

Forgot/reset: `AuthCardLayout` + mismos tokens. Change-password: sin gradiente auth (shell/A1).

**Shell:** `import '@paqsuite/react-core/shell.css'` — ver [`adopcion-shell-ui.md`](../../../docs/06-operacion/adopcion-shell-ui.md).

**Checklist Must (hosts nuevos / QC):** [`docs/06-operacion/adopcion-auth-ui.md`](../../../docs/06-operacion/adopcion-auth-ui.md) — alias Vite+TS, import CSS, env título/tagline, anti-patrones.

Norma: [`SPEC-001-01`](../../../docs/05-open-spec/001-Generalidades/SPEC-001-01-diseno-pantallas-estetica-ui.md) · [`TR-GEN-01`](../../../docs/04-tareas/001-Generalidades/TR-GEN-01-auth-ui.md).
