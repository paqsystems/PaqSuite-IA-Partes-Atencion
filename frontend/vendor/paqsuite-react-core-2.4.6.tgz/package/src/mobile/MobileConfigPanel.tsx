import { useId, useState } from 'react';
import Button from 'devextreme-react/button';
import Popup from 'devextreme-react/popup';
import TextBox from 'devextreme-react/text-box';
import { buildPlatformHeaders } from '../http/headers';
import { parseEnvelope } from '../http/parseEnvelope';
import { writeApiBaseUrlOverride } from './nativeSessionStorage';
import {
  normalizeApiBaseUrl,
  resolveApiBaseUrl,
  setCachedResolvedApiBaseUrl,
} from './resolveApiBaseUrl';
import {
  buildMobileHealthUrl,
  evaluateMobileConfigSaveGate,
} from './mobileConfigRules';

export type MobileConfigPanelProps = {
  getTenantForHealth: () => string | null;
  defaultApiBaseUrl?: string;
  projectSlug?: string;
  onSaved?: (apiBaseUrl: string) => void;
  t?: (key: string) => string;
  /** Override inicial (p. ej. valor hidratado). */
  initialOverride?: string;
};

type HealthState = 'idle' | 'ok' | 'fail';

/**
 * Engranaje mobile: trigger `mobileConfigOpen` + popup (C1-22-01).
 * Solo override URL API; health con `X-Paq-Cliente`; save solo si health OK.
 */
export function MobileConfigPanel({
  getTenantForHealth,
  defaultApiBaseUrl,
  projectSlug = 'smoke',
  onSaved,
  t,
  initialOverride = '',
}: MobileConfigPanelProps) {
  const translate = t ?? ((key: string) => key);
  const popupId = useId();
  const [open, setOpen] = useState(false);
  const [apiUrl, setApiUrl] = useState(initialOverride);
  const [healthState, setHealthState] = useState<HealthState>('idle');
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  function resolveCandidateBase(): string {
    return resolveApiBaseUrl({
      override: apiUrl.trim() || null,
      envBaseUrl: defaultApiBaseUrl,
      projectSlug,
    });
  }

  async function testConnection(): Promise<boolean> {
    const tenant = getTenantForHealth()?.trim() || null;
    const gate = evaluateMobileConfigSaveGate({ tenant, healthOk: true });
    if (!gate.canSave && gate.messageKey === 'mobile.config.tenantRequired') {
      setHealthState('fail');
      setMessage(translate('mobile.config.tenantRequired'));
      return false;
    }

    setBusy(true);
    setMessage(null);
    try {
      const base = resolveCandidateBase();
      const healthUrl = buildMobileHealthUrl(base);
      const headers = buildPlatformHeaders({ cliente: tenant! });
      const response = await fetch(healthUrl, {
        method: 'GET',
        headers,
      });
      const text = await response.text();
      let parsed: unknown = null;
      try {
        parsed = text === '' ? null : JSON.parse(text);
      } catch {
        setHealthState('fail');
        setMessage(translate('mobile.config.testFail'));
        return false;
      }

      const envelope = parseEnvelope(parsed);
      if (!envelope || envelope.error !== 0) {
        setHealthState('fail');
        setMessage(translate('mobile.config.testFail'));
        return false;
      }

      setHealthState('ok');
      setMessage(translate('mobile.config.testOk'));
      return true;
    } catch {
      setHealthState('fail');
      setMessage(translate('mobile.config.testFail'));
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function handleSave(): Promise<void> {
    const tenant = getTenantForHealth()?.trim() || null;
    const preGate = evaluateMobileConfigSaveGate({
      tenant,
      healthOk: healthState === 'ok',
    });
    if (preGate.messageKey === 'mobile.config.tenantRequired') {
      setHealthState('fail');
      setMessage(translate('mobile.config.tenantRequired'));
      return;
    }

    const ok = healthState === 'ok' ? true : await testConnection();
    if (!ok) {
      return;
    }

    const postGate = evaluateMobileConfigSaveGate({ tenant, healthOk: true });
    if (!postGate.canSave) {
      setMessage(translate(postGate.messageKey ?? 'mobile.config.testFail'));
      return;
    }

    const normalized = normalizeApiBaseUrl(
      apiUrl.trim() || resolveCandidateBase()
    );
    await writeApiBaseUrlOverride(normalized);
    setCachedResolvedApiBaseUrl(
      resolveApiBaseUrl({
        override: normalized,
        envBaseUrl: defaultApiBaseUrl,
        projectSlug,
      })
    );
    onSaved?.(normalized);
    setOpen(false);
  }

  return (
    <div data-testid="mobileConfigPanel">
      <Button
        icon="preferences"
        stylingMode="text"
        onClick={() => {
          setOpen(true);
          setHealthState('idle');
          setMessage(null);
        }}
        elementAttr={{ 'data-testid': 'mobileConfigOpen', 'aria-label': 'config' }}
      />
      <Popup
        visible={open}
        onHiding={() => setOpen(false)}
        title={translate('mobile.config.title')}
        showTitle
        width={360}
        height="auto"
        dragEnabled={false}
        elementAttr={{ 'data-testid': 'mobileConfigPopup', id: popupId }}
      >
        <div className="paqMobileConfigForm">
          <label>
            <span>{translate('mobile.config.apiUrl')}</span>
            <TextBox
              value={apiUrl}
              onValueChanged={(event) => {
                setApiUrl(String(event.value ?? ''));
                setHealthState('idle');
              }}
              elementAttr={{ 'data-testid': 'mobileConfigApiUrl' }}
            />
          </label>
          {message ? <p data-testid="mobileConfigMessage">{message}</p> : null}
          <div className="paqMobileConfigActions">
            <Button
              text={translate('mobile.config.testConnection')}
              disabled={busy}
              onClick={() => void testConnection()}
              elementAttr={{ 'data-testid': 'mobileConfigTestConnection' }}
            />
            <Button
              text={translate('mobile.config.save')}
              type="default"
              disabled={busy || healthState === 'fail'}
              onClick={() => void handleSave()}
              elementAttr={{ 'data-testid': 'mobileConfigSave' }}
            />
          </div>
        </div>
      </Popup>
    </div>
  );
}
