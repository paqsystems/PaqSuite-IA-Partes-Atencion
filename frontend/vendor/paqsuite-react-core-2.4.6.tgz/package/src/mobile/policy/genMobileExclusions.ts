/**
 * Catálogo GEN de exclusiones mobile (SPEC-001-22 / TR-GEN-22-navigation-policy).
 * Matching: exacto, prefijo `path/`, o sufijo `*` (C1-22-03). Exclusiones ganan.
 */

export type GenMobileExclusion = {
  family: string;
  patterns: string[];
  /** Si true, también matchea `procedimiento` que contenga el substring. */
  procedimientoContains?: string[];
};

export const genMobileExclusions: GenMobileExclusion[] = [
  {
    family: 'pivots',
    patterns: ['/pivots', '/pivot', '/pivots/*', '/pivot/*'],
    procedimientoContains: ['pivot'],
  },
  {
    family: 'excelImport',
    patterns: ['/excel-import', '/excelImport', '/excel-import/*', '/excelImport/*'],
  },
  {
    family: 'adminSecurity',
    patterns: [
      '/admin/roles',
      '/admin/permisos',
      '/admin/security',
      '/admin/usuarios',
      '/admin/roles/*',
      '/admin/permisos/*',
      '/admin/security/*',
      '/admin/usuarios/*',
    ],
  },
  {
    family: 'tasksAdmin',
    patterns: ['/tasks', '/tareas', '/scheduled-tasks', '/tasks/*', '/tareas/*', '/scheduled-tasks/*'],
  },
  {
    family: 'auditAdmin',
    patterns: ['/audit-events', '/auditoria', '/audit', '/audit-events/*', '/auditoria/*', '/audit/*'],
  },
  {
    family: 'parameters',
    patterns: [
      '/parametros',
      '/parameters',
      '/abm-parametros',
      '/parametros/*',
      '/parameters/*',
      '/abm-parametros/*',
    ],
  },
  {
    family: 'gruposEmpresarios',
    patterns: ['/admin/grupos-empresarios', '/admin/grupos-empresarios/*'],
  },
  {
    family: 'notificationService',
    patterns: [
      '/admin/notification-service',
      '/admin/notification-service/*',
      'admin.notificationService',
      'admin.notificationService.monitor',
    ],
  },
  {
    family: 'emissionDesign',
    patterns: [
      '/emissions/design',
      '/emissions/design/*',
      '/emission/design',
      '/emission/design/*',
    ],
    procedimientoContains: ['emission.design', 'EMISSION_DESIGN'],
  },
  {
    family: 'arca',
    patterns: [
      '/admin/arca',
      '/admin/arca/*',
      'admin.arca.config',
      'admin.arca.homologacion',
    ],
    procedimientoContains: ['ARCA_CONFIGURE', 'ARCA_OPERATE'],
  },
];

/** Matching allowlist C1-22-03: exacto | prefijo `allow/` | sufijo `*`. */
export function matchesAllowlistEntry(routeName: string, allowEntry: string): boolean {
  const route = routeName.trim();
  const allow = allowEntry.trim();
  if (!route || !allow) {
    return false;
  }

  if (route === allow) {
    return true;
  }

  if (allow.endsWith('*')) {
    const prefix = allow.slice(0, -1);
    return route.startsWith(prefix);
  }

  return route.startsWith(`${allow}/`);
}

export function isExcludedByGenCatalog(
  routeName: string,
  procedimiento?: string | null,
  exclusions: GenMobileExclusion[] = genMobileExclusions
): boolean {
  const route = routeName.trim();
  for (const exclusion of exclusions) {
    for (const pattern of exclusion.patterns) {
      if (matchesAllowlistEntry(route, pattern)) {
        return true;
      }
    }
    if (procedimiento && exclusion.procedimientoContains) {
      const lower = procedimiento.toLowerCase();
      if (exclusion.procedimientoContains.some((token) => lower.includes(token.toLowerCase()))) {
        return true;
      }
    }
  }
  return false;
}
