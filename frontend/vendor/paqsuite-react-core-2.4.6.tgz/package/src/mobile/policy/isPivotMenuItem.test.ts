import { describe, expect, it } from 'vitest';
import {
  isPivotMenuItem,
  resolveMobileExclusionI18nKey,
} from './isPivotMenuItem';

describe('isPivotMenuItem (GEN-12)', () => {
  it('detecta por ruta /pivots/*', () => {
    expect(isPivotMenuItem({ routeName: '/pivots/consulta-smoke' })).toBe(true);
    expect(isPivotMenuItem({ routeName: '/pivot/report' })).toBe(true);
    expect(isPivotMenuItem({ routeName: '/dashboard' })).toBe(false);
  });

  it('detecta por procedimiento Contains pivot (mixto F05)', () => {
    expect(
      isPivotMenuItem({
        routeName: '/consultas/ventas',
        procedimiento: 'INFORME_PIVOT_SMOKE',
      })
    ).toBe(true);
  });

  it('detecta por menuKey / tipoProceso / consultaId conocida', () => {
    expect(isPivotMenuItem({ menuKey: 'informe-pivot-smoke' })).toBe(true);
    expect(isPivotMenuItem({ tipoProceso: 'pivotConsulta' })).toBe(true);
    expect(
      isPivotMenuItem({
        consultaId: 'consultaSmokePivot',
        knownPivotConsultaIds: ['consultaSmokePivot'],
      })
    ).toBe(true);
    expect(
      isPivotMenuItem({
        consultaId: 'otra',
        knownPivotConsultaIds: ['consultaSmokePivot'],
      })
    ).toBe(false);
  });
});

describe('resolveMobileExclusionI18nKey', () => {
  it('usa mobile.exclusion.pivot para rutas pivot', () => {
    expect(resolveMobileExclusionI18nKey('/pivots/consulta-smoke')).toBe(
      'mobile.exclusion.pivot'
    );
    expect(resolveMobileExclusionI18nKey('/dashboard')).toBe('menu.forbidden');
  });
});
