import {
  genMobileExclusions,
  isExcludedByGenCatalog,
  matchesAllowlistEntry,
  type GenMobileExclusion,
} from './genMobileExclusions';

export type MobileMenuItemLike = {
  routeName?: string | null;
  procedimiento?: string | null;
  menuKey?: string;
  children?: MobileMenuItemLike[];
};

export type MobilePolicy = {
  isAllowed: (routeName: string, procedimiento?: string | null) => boolean;
  filterItems: <T extends MobileMenuItemLike>(items: T[]) => T[];
};

/**
 * ¿La ruta está en allowlist del host? (sin evaluar exclusiones).
 */
export function isInAllowlist(
  routeName: string,
  allowlistRouteNames: string[]
): boolean {
  return allowlistRouteNames.some((entry) => matchesAllowlistEntry(routeName, entry));
}

/**
 * Allowlist del host ∩ ¬exclusiones GEN. Exclusiones ganan (C1-22-03).
 */
export function isMobileRouteAllowed(
  routeName: string,
  allowlistRouteNames: string[],
  exclusions: GenMobileExclusion[] = genMobileExclusions,
  procedimiento?: string | null
): boolean {
  if (isExcludedByGenCatalog(routeName, procedimiento, exclusions)) {
    return false;
  }
  if (allowlistRouteNames.length === 0) {
    return false;
  }
  return isInAllowlist(routeName, allowlistRouteNames);
}

export function createMobilePolicy(input: {
  allowlistRouteNames: string[];
  exclusions?: GenMobileExclusion[];
}): MobilePolicy {
  const exclusions = input.exclusions ?? genMobileExclusions;
  const allowlist = input.allowlistRouteNames;

  function isAllowed(routeName: string, procedimiento?: string | null): boolean {
    return isMobileRouteAllowed(routeName, allowlist, exclusions, procedimiento);
  }

  function filterItems<T extends MobileMenuItemLike>(items: T[]): T[] {
    return filterMenuItemsForMobile(items, isAllowed);
  }

  return { isAllowed, filterItems };
}

/**
 * Filtra árbol: procesos sin ruta permitida se quitan; grupos vacíos se quitan.
 */
export function filterMenuItemsForMobile<T extends MobileMenuItemLike>(
  items: T[],
  isAllowed: (routeName: string, procedimiento?: string | null) => boolean
): T[] {
  const result: T[] = [];

  for (const item of items) {
    const children = item.children
      ? filterMenuItemsForMobile(item.children as T[], isAllowed)
      : [];
    const route = item.routeName?.trim() || '';

    if (route) {
      if (!isAllowed(route, item.procedimiento)) {
        if (children.length > 0) {
          result.push({ ...item, children });
        }
        continue;
      }
      result.push({ ...item, children });
      continue;
    }

    if (children.length > 0) {
      result.push({ ...item, children });
    }
  }

  return result;
}

export { matchesAllowlistEntry, genMobileExclusions, isExcludedByGenCatalog };
