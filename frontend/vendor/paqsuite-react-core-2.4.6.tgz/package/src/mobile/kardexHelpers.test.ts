import { describe, expect, it } from 'vitest';
import { filterKardexItems, sliceKardexPage } from './kardex/kardexHelpers';
import type { KardexItem } from './kardex/types';

const items: KardexItem[] = [
  {
    id: '1',
    title: 'Artículo A-100',
    subtitle: 'Depósito Central',
    fields: [{ label: 'Stock', value: '1' }],
  },
  {
    id: '2',
    title: 'Artículo B-200',
    subtitle: 'Norte',
    fields: [{ label: 'Stock', value: '2' }],
  },
];

describe('kardexHelpers', () => {
  it('filtra por título/subtítulo', () => {
    expect(filterKardexItems(items, 'norte')).toHaveLength(1);
    expect(filterKardexItems(items, 'A-100')[0]?.id).toBe('1');
    expect(filterKardexItems(items, '')).toHaveLength(2);
  });

  it('pagina y expone hasMore', () => {
    expect(sliceKardexPage(items, 1)).toEqual({
      visible: [items[0]],
      hasMore: true,
    });
    expect(sliceKardexPage(items, 10).hasMore).toBe(false);
  });
});
