import { preferenceKeys } from '../preferenceKeys';
import { preferencesGet, preferencesSet } from '../preferencesStorage';
import { isNativeApp } from '../isNativeApp';

export type PushPlatform = 'android' | 'ios';

export type MobilePushBridge = {
  requestPermissions: () => Promise<'granted' | 'denied'>;
  getToken: () => Promise<string | null>;
  getPlatform: () => PushPlatform;
  addListeners?: (handlers: {
    onNotificationReceived?: (payload: unknown) => void;
  }) => void | (() => void);
};

let pushBridge: MobilePushBridge | null = null;
let listenersCleanup: (() => void) | undefined;

/** Inyecta bridge Capacitor Push (o mock en tests/smoke). */
export function setMobilePushBridge(bridge: MobilePushBridge | null): void {
  pushBridge = bridge;
}

export function getMobilePushBridge(): MobilePushBridge | null {
  return pushBridge;
}

export function registerMobilePushHandlers(input?: {
  onNotificationReceived?: (payload: unknown) => void;
}): void {
  listenersCleanup?.();
  listenersCleanup = undefined;
  const bridge = pushBridge;
  if (!bridge?.addListeners) {
    return;
  }
  const cleanup = bridge.addListeners({
    onNotificationReceived: input?.onNotificationReceived,
  });
  if (typeof cleanup === 'function') {
    listenersCleanup = cleanup;
  }
}

export async function hasAskedPushPermission(): Promise<boolean> {
  const value = await preferencesGet(preferenceKeys.pushPermissionAsked);
  return value === '1';
}

export async function markPushPermissionAsked(): Promise<void> {
  await preferencesSet(preferenceKeys.pushPermissionAsked, '1');
}

export function resolveDefaultPushPlatform(): PushPlatform {
  if (typeof navigator !== 'undefined' && /android/i.test(navigator.userAgent)) {
    return 'android';
  }
  return 'ios';
}

export function shouldAttemptPushOptIn(enabled: boolean): boolean {
  return enabled && isNativeApp();
}

/**
 * ¿Pedir permiso ahora? Cold start o primera transición a unread>0 (C1-22-06).
 * No pide en login (unread 0) ni si ya se preguntó.
 */
export function shouldPromptPushOptIn(input: {
  enabled: boolean;
  alreadyAsked: boolean;
  previousUnread: number;
  unreadCount: number;
}): boolean {
  if (!input.enabled || input.alreadyAsked) {
    return false;
  }
  if (input.unreadCount <= 0) {
    return false;
  }
  // Cold start (previous 0, unread>0) o transición 0→N
  return input.previousUnread === 0;
}

/** Tras permiso: solo POST si granted y hay token. */
export function shouldPostDeviceToken(input: {
  permission: 'granted' | 'denied' | 'unknown';
  token: string | null;
}): boolean {
  return input.permission === 'granted' && Boolean(input.token);
}
