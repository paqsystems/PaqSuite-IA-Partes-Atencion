import { useEffect, useRef, useState } from 'react';
import {
  getMobilePushBridge,
  hasAskedPushPermission,
  markPushPermissionAsked,
  resolveDefaultPushPlatform,
  shouldAttemptPushOptIn,
  shouldPostDeviceToken,
  shouldPromptPushOptIn,
  type PushPlatform,
} from './pushBridge';

export type UseMobilePushOptInArgs = {
  enabled: boolean;
  unreadCount: number;
  postDeviceToken: (token: string, platform: PushPlatform) => Promise<void>;
};

export type UseMobilePushOptInResult = {
  permission: 'unknown' | 'granted' | 'denied';
};

/**
 * Opt-in push: primera transición unreadCount>0 o cold start con unread (C1-22-06).
 */
export function useMobilePushOptIn(
  args: UseMobilePushOptInArgs
): UseMobilePushOptInResult {
  const { enabled, unreadCount, postDeviceToken } = args;
  const [permission, setPermission] = useState<'unknown' | 'granted' | 'denied'>(
    'unknown'
  );
  const askedRef = useRef(false);
  const previousUnreadRef = useRef(0);

  useEffect(() => {
    if (!shouldAttemptPushOptIn(enabled)) {
      return;
    }

    let cancelled = false;

    async function maybePrompt(): Promise<void> {
      if (askedRef.current) {
        return;
      }
      const already = await hasAskedPushPermission();
      if (already) {
        askedRef.current = true;
        return;
      }

      const bridge = getMobilePushBridge();
      if (!bridge) {
        return;
      }

      askedRef.current = true;
      await markPushPermissionAsked();
      const result = await bridge.requestPermissions();
      if (cancelled) {
        return;
      }
      setPermission(result);
      const token = result === 'granted' ? await bridge.getToken() : null;
      if (cancelled) {
        return;
      }
      if (!shouldPostDeviceToken({ permission: result, token })) {
        return;
      }
      const platform = bridge.getPlatform?.() ?? resolveDefaultPushPlatform();
      await postDeviceToken(token!, platform);
    }

    void (async () => {
      const alreadyAsked = await hasAskedPushPermission();
      if (alreadyAsked) {
        askedRef.current = true;
      }

      const previous = previousUnreadRef.current;
      previousUnreadRef.current = unreadCount;

      if (
        shouldPromptPushOptIn({
          enabled: true,
          alreadyAsked: alreadyAsked || askedRef.current,
          previousUnread: previous,
          unreadCount,
        })
      ) {
        await maybePrompt();
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [enabled, postDeviceToken, unreadCount]);

  return { permission };
}
