export type KardexField = {
  label: string;
  value: string;
};

export type KardexStatus = {
  text: string;
  tone?: 'neutral' | 'success' | 'warning' | 'danger';
};

export type KardexItem = {
  id: string;
  title: string;
  subtitle?: string;
  fields: KardexField[];
  status?: KardexStatus;
};
