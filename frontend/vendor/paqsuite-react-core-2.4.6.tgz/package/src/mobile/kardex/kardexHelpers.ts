/**
 * Helpers kardex testeables (presentador GEN-22).
 */

import type { KardexItem } from './types';

export function filterKardexItems(
  items: KardexItem[],
  query: string
): KardexItem[] {
  const q = query.trim().toLowerCase();
  if (!q) {
    return items;
  }
  return items.filter(
    (item) =>
      item.title.toLowerCase().includes(q) ||
      (item.subtitle?.toLowerCase().includes(q) ?? false)
  );
}

export function sliceKardexPage(
  items: KardexItem[],
  pageSize: number
): { visible: KardexItem[]; hasMore: boolean } {
  const size = Math.max(0, pageSize);
  return {
    visible: items.slice(0, size),
    hasMore: size < items.length,
  };
}
