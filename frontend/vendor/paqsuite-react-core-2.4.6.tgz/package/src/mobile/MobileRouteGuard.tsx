import { useEffect, useState, type ReactNode } from 'react';
import { resolveMobileExclusionI18nKey } from './policy/isPivotMenuItem';

export type MobileRouteGuardProps = {
  /** Default `/` (C1-22-04). No confundir con postLoginHomePath. */
  homePath?: string;
  pathname: string;
  isAllowed: (pathname: string) => boolean;
  onRedirect: (homePath: string) => void;
  children: ReactNode;
  t?: (key: string) => string;
  bypassPaths?: string[];
  /** Procedimiento del ítem activo (opcional; afina i18n GEN-12). */
  procedimiento?: string | null;
};

/**
 * En native, redirige rutas no permitidas a `homePath`.
 * Pivot → `mobile.exclusion.pivot`; resto → `menu.forbidden`.
 */
export function MobileRouteGuard({
  homePath = '/',
  pathname,
  isAllowed,
  onRedirect,
  children,
  t,
  bypassPaths = [],
  procedimiento = null,
}: MobileRouteGuardProps) {
  const translate = t ?? ((key: string) => key);
  const [forbiddenMessage, setForbiddenMessage] = useState<string | null>(null);

  useEffect(() => {
    if (bypassPaths.some((entry) => pathname === entry || pathname.startsWith(`${entry}/`))) {
      setForbiddenMessage(null);
      return;
    }

    if (isAllowed(pathname)) {
      setForbiddenMessage(null);
      return;
    }

    const i18nKey = resolveMobileExclusionI18nKey(pathname, procedimiento);
    setForbiddenMessage(translate(i18nKey));
    if (pathname !== homePath) {
      onRedirect(homePath);
    }
  }, [bypassPaths, homePath, isAllowed, onRedirect, pathname, procedimiento, translate]);

  return (
    <>
      {forbiddenMessage ? (
        <p data-testid="mobileRouteForbidden" role="alert">
          {forbiddenMessage}
        </p>
      ) : null}
      {children}
    </>
  );
}
