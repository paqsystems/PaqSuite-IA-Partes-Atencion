import { describe, expect, it, beforeEach } from 'vitest';
import {
  shouldPostDeviceToken,
  shouldPromptPushOptIn,
  setMobilePushBridge,
  getMobilePushBridge,
} from './push/pushBridge';
import {
  resetPreferencesMemory,
  setPreferencesAdapter,
  type PreferencesAdapter,
} from './preferencesStorage';

describe('shouldPromptPushOptIn (C1-22-06)', () => {
  it('no pide con unread 0 (login)', () => {
    expect(
      shouldPromptPushOptIn({
        enabled: true,
        alreadyAsked: false,
        previousUnread: 0,
        unreadCount: 0,
      })
    ).toBe(false);
  });

  it('pide en cold start unread>0', () => {
    expect(
      shouldPromptPushOptIn({
        enabled: true,
        alreadyAsked: false,
        previousUnread: 0,
        unreadCount: 3,
      })
    ).toBe(true);
  });

  it('pide en transición 0→1', () => {
    expect(
      shouldPromptPushOptIn({
        enabled: true,
        alreadyAsked: false,
        previousUnread: 0,
        unreadCount: 1,
      })
    ).toBe(true);
  });

  it('no pide segunda vez ni si alreadyAsked', () => {
    expect(
      shouldPromptPushOptIn({
        enabled: true,
        alreadyAsked: true,
        previousUnread: 0,
        unreadCount: 5,
      })
    ).toBe(false);
    expect(
      shouldPromptPushOptIn({
        enabled: true,
        alreadyAsked: false,
        previousUnread: 2,
        unreadCount: 3,
      })
    ).toBe(false);
  });
});

describe('shouldPostDeviceToken', () => {
  it('denied no POST; granted con token sí', () => {
    expect(shouldPostDeviceToken({ permission: 'denied', token: 'x' })).toBe(false);
    expect(shouldPostDeviceToken({ permission: 'granted', token: null })).toBe(false);
    expect(shouldPostDeviceToken({ permission: 'granted', token: 'tok' })).toBe(true);
  });
});

describe('bridge denied flow', () => {
  beforeEach(() => {
    resetPreferencesMemory();
    const store = new Map<string, string>();
    const adapter: PreferencesAdapter = {
      get: async (key) => store.get(key) ?? null,
      set: async (key, value) => {
        store.set(key, value);
      },
      remove: async (key) => {
        store.delete(key);
      },
    };
    setPreferencesAdapter(adapter);
    setMobilePushBridge({
      requestPermissions: async () => 'denied',
      getToken: async () => 'should-not-use',
      getPlatform: () => 'ios',
    });
  });

  it('denied → no post según reglas', async () => {
    const bridge = getMobilePushBridge()!;
    const permission = await bridge.requestPermissions();
    const token = permission === 'granted' ? await bridge.getToken() : null;
    expect(shouldPostDeviceToken({ permission, token })).toBe(false);
  });
});
