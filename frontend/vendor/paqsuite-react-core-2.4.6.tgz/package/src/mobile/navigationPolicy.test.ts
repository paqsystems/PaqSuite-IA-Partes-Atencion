import { describe, expect, it } from 'vitest';
import {
  createMobilePolicy,
  isMobileRouteAllowed,
  matchesAllowlistEntry,
  filterMenuItemsForMobile,
} from './policy/mobileRoutePolicy';
import { isExcludedByGenCatalog } from './policy/genMobileExclusions';

describe('matchesAllowlistEntry (C1-22-03)', () => {
  it('exacto, prefijo y wildcard', () => {
    expect(matchesAllowlistEntry('/dashboard', '/dashboard')).toBe(true);
    expect(matchesAllowlistEntry('/consultas/stock', '/consultas')).toBe(true);
    expect(matchesAllowlistEntry('/admin/roles', '/admin/*')).toBe(true);
    expect(matchesAllowlistEntry('/other', '/admin/*')).toBe(false);
  });
});

describe('gen exclusions ganan', () => {
  it('bloquea cada familia del catálogo GEN', () => {
    const cases = [
      '/pivots',
      '/pivot/report',
      '/excel-import',
      '/excelImport/batches',
      '/admin/roles',
      '/admin/permisos',
      '/admin/security',
      '/admin/usuarios',
      '/tasks',
      '/tareas/list',
      '/scheduled-tasks',
      '/audit-events',
      '/auditoria',
      '/audit',
      '/parametros',
      '/parameters',
      '/abm-parametros',
      '/admin/grupos-empresarios',
      '/admin/grupos-empresarios/edit',
      '/admin/notification-service',
      '/admin/notification-service/monitor',
      'admin.notificationService',
      'admin.notificationService.monitor',
      '/emissions/design',
      '/emissions/design/RESUMEN',
      '/emissions/design/EMISSION_SMOKE',
      '/emission/design',
      '/admin/arca',
      '/admin/arca/config',
      '/admin/arca/homologacion',
      'admin.arca.config',
      'admin.arca.homologacion',
    ];
    for (const route of cases) {
      expect(isExcludedByGenCatalog(route), route).toBe(true);
      expect(isMobileRouteAllowed(route, [route, '/dashboard'])).toBe(false);
    }
  });

  it('GEN-15: diseñador emisiones excluido por procedimiento emission.design', () => {
    expect(isExcludedByGenCatalog('/custom/design', 'emission.design')).toBe(true);
    expect(isExcludedByGenCatalog('/custom/design', 'EMISSION_DESIGN')).toBe(true);
  });

  it('GEN-32: consola ARCA excluida por ruta y procedimiento', () => {
    expect(isExcludedByGenCatalog('/admin/arca/config')).toBe(true);
    expect(isMobileRouteAllowed('/admin/arca/config', ['/admin/arca/config', '/dashboard'])).toBe(
      false,
    );
    expect(isExcludedByGenCatalog('/custom/arca', 'ARCA_CONFIGURE')).toBe(true);
    expect(isExcludedByGenCatalog('/custom/arca', 'ARCA_OPERATE')).toBe(true);
  });

  it('bloquea pivots y excel aunque estén en allowlist', () => {
    expect(isExcludedByGenCatalog('/pivots')).toBe(true);
    expect(isExcludedByGenCatalog('/excel-import/batches')).toBe(true);
    expect(isMobileRouteAllowed('/pivots', ['/pivots', '/dashboard'])).toBe(false);
    expect(isMobileRouteAllowed('/dashboard', ['/dashboard'])).toBe(true);
  });

  it('bloquea por procedimiento pivot', () => {
    expect(isExcludedByGenCatalog('/custom', 'sp_pivot_ventas')).toBe(true);
  });

  it('GEN-12 F05: informe mixto excluido entero vía procedimiento', () => {
    expect(isExcludedByGenCatalog('/consultas/ventas', 'INFORME_PIVOT_SMOKE')).toBe(true);
    expect(
      isMobileRouteAllowed('/consultas/ventas', ['/consultas/*'], undefined, 'INFORME_PIVOT_SMOKE')
    ).toBe(false);
  });

  it('bloquea /parametros/:programa (GEN-10 C1-10-06)', () => {
    expect(isExcludedByGenCatalog('/parametros/Auth')).toBe(true);
    expect(isExcludedByGenCatalog('/parametros/ExcelImport')).toBe(true);
    expect(isMobileRouteAllowed('/parametros/Auth', ['/parametros/Auth', '/dashboard'])).toBe(false);
    expect(isMobileRouteAllowed('/dashboard', ['/dashboard'])).toBe(true);
  });
});

describe('createMobilePolicy.filterItems', () => {
  it('filtra árbol y conserva ancestros con hijos válidos', () => {
    const policy = createMobilePolicy({
      allowlistRouteNames: ['/dashboard', '/consultas/*'],
    });

    const filtered = policy.filterItems([
      {
        menuKey: 'root',
        text: 'Root',
        children: [
          { menuKey: 'dash', routeName: '/dashboard', children: [] },
          { menuKey: 'pivot', routeName: '/pivots', children: [] },
          { menuKey: 'stock', routeName: '/consultas/stock', children: [] },
          { menuKey: 'excel', routeName: '/excel-import', children: [] },
        ],
      },
    ]);

    expect(filtered).toHaveLength(1);
    const routes = (filtered[0]?.children ?? []).map((c) => c.routeName);
    expect(routes).toEqual(['/dashboard', '/consultas/stock']);
  });
});

describe('filterMenuItemsForMobile', () => {
  it('quita grupos vacíos', () => {
    const items = filterMenuItemsForMobile(
      [
        {
          menuKey: 'g',
          children: [{ menuKey: 'x', routeName: '/admin/roles', children: [] }],
        },
      ],
      (route) => route === '/dashboard'
    );
    expect(items).toHaveLength(0);
  });
});
