import { describe, expect, it, vi } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import type { PivotConsultaCatalogDto } from './pivotCatalogClient';
import { PivotGridBlock } from './PivotGridBlock';

vi.mock('../../mobile/isNativeApp', () => ({
  isNativeApp: () => false,
}));

vi.mock('devextreme-react/pivot-grid', () => {
  const PivotGrid = () => <div data-testid="pivot.grid.mock" />;
  (PivotGrid as { Export?: () => null }).Export = () => null;
  (PivotGrid as { FieldChooser?: () => null }).FieldChooser = () => null;
  (PivotGrid as { FieldPanel?: () => null }).FieldPanel = () => null;
  return { default: PivotGrid, Export: () => null, FieldChooser: () => null, FieldPanel: () => null };
});

vi.mock('devextreme-react/drop-down-button', () => ({
  default: (props: {
    disabled?: boolean;
    elementAttr?: Record<string, string>;
    items?: Array<{ id: string; text: string; testId: string }>;
  }) => (
    <div
      data-testid={props.elementAttr?.['data-testid']}
      data-disabled={props.disabled ? 'true' : 'false'}
    >
      {(props.items ?? []).map((item) => (
        <div key={item.id} data-testid={item.testId}>
          {item.text}
        </div>
      ))}
    </div>
  ),
}));

vi.mock('./PivotRefreshButton', () => ({
  PivotRefreshButton: () => <button type="button" data-testid="pivot.refresh" />,
}));

const catalog: PivotConsultaCatalogDto = {
  consultaId: 'consultaSmokePivot',
  mostrarGrillaYPivot: true,
  soloPivot: false,
  campos: [{ dataField: 'importe', dataType: 'number', nombreVisible: 'Importe' }],
};

describe('PivotGridBlock export', () => {
  it('auto-append export cuando exportEnabled y deshabilita sin filas', () => {
    const html = renderToStaticMarkup(
      <PivotGridBlock consultaId="consultaSmokePivot" catalog={catalog} rows={[]} />
    );

    expect(html).toContain('pivot.export');
    expect(html).toContain('pivot.exportModeFormatted');
    expect(html).toContain('pivot.exportModeBasic');
    expect(html).toContain('data-disabled="true"');
  });

  it('oculta export si exportEnabled=false (C1-12-F06)', () => {
    const html = renderToStaticMarkup(
      <PivotGridBlock
        consultaId="consultaSmokePivot"
        catalog={catalog}
        rows={[{ importe: 10 }]}
        exportEnabled={false}
      />
    );

    expect(html).not.toContain('pivot.export');
  });

  it('habilita export con filas', () => {
    const html = renderToStaticMarkup(
      <PivotGridBlock
        consultaId="consultaSmokePivot"
        catalog={catalog}
        rows={[{ importe: 10 }]}
      />
    );

    expect(html).toContain('data-disabled="false"');
  });
});
