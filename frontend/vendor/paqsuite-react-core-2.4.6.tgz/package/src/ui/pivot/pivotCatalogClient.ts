import { apiRequest, type ApiClientResult, type ApiRequestOptions } from '../../http/apiClient';

export type PivotSummaryType = 'sum' | 'avg' | 'min' | 'max' | 'count';

export type PivotCampoDataType = 'number' | 'string' | 'date' | 'datetime' | 'boolean';

export type PivotCampoCatalogDto = {
  dataField: string;
  dataType: PivotCampoDataType;
  nombreVisible: string;
  summaryType?: PivotSummaryType;
  allowedSummaryTypes?: PivotSummaryType[];
};

export type PivotConsultaCatalogDto = {
  consultaId: string;
  proceso?: string;
  procedimientoHost?: string;
  mostrarGrillaYPivot: boolean;
  soloPivot: boolean;
  campos: PivotCampoCatalogDto[];
};

export const pivotsCatalogBasePath = '/api/v1/pivots/consultas';

type RequestOverrides = Pick<ApiRequestOptions, 'platform' | 'signal' | 'headers'>;

export function fetchPivotCatalog(
  consultaId: string,
  options: RequestOverrides = {}
): Promise<ApiClientResult<PivotConsultaCatalogDto>> {
  const encoded = encodeURIComponent(consultaId);

  return apiRequest<PivotConsultaCatalogDto>(`${pivotsCatalogBasePath}/${encoded}`, {
    method: 'GET',
    ...options,
  });
}
