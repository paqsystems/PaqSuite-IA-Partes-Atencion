import dxPivotGrid from 'devextreme/ui/pivot_grid';
import { exportPivotGrid } from 'devextreme/common/export/excel';
import { Workbook } from 'exceljs';

export type PivotExportMode = 'basic' | 'formatted';

export const defaultPivotExportMode: PivotExportMode = 'formatted';

/** Nombre de archivo export Excel pivot — GEN-12. */
export function buildPivotExportFileName(consultaId: string, now: Date = new Date()): string {
  const yyyy = String(now.getFullYear());
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  const hh = String(now.getHours()).padStart(2, '0');
  const mi = String(now.getMinutes()).padStart(2, '0');
  const stamp = `${yyyy}${mm}${dd}_${hh}${mi}`;
  const safeConsultaId = consultaId.trim().replace(/[^A-Za-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '');
  return `${safeConsultaId || 'pivot'}_${stamp}.xlsx`;
}

export type ExportPivotGridExcelInput = {
  consultaId: string;
  component: dxPivotGrid;
  mode?: PivotExportMode;
  locale?: string;
};

function stripBasicCellStyles(excelCell: {
  font?: { bold?: boolean; [key: string]: unknown };
  fill?: unknown;
  numFmt?: string;
}): void {
  excelCell.font = { ...(excelCell.font ?? {}), bold: false };
  excelCell.fill = undefined;
  excelCell.numFmt = undefined;
}

/**
 * Export Excel cliente vía DevExtreme `exportPivotGrid` + exceljs (GEN-12).
 * Default mode: `formatted`. Pipeline distinto de grilla GEN-11.
 */
export async function exportPivotGridExcel(input: ExportPivotGridExcelInput): Promise<void> {
  if (typeof document === 'undefined') {
    return;
  }

  const mode = input.mode ?? defaultPivotExportMode;
  const workbook = new Workbook();
  const worksheet = workbook.addWorksheet('Pivot');

  await exportPivotGrid({
    component: input.component,
    worksheet,
    mergeRowFieldValues: mode === 'formatted',
    mergeColumnFieldValues: mode === 'formatted',
    customizeCell:
      mode === 'basic'
        ? ({ excelCell }) => {
            if (excelCell) {
              stripBasicCellStyles(excelCell);
            }
          }
        : undefined,
  });

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = buildPivotExportFileName(input.consultaId);
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}

export function hasPivotExportableData(rows: unknown[], loading?: boolean): boolean {
  return !loading && Array.isArray(rows) && rows.length > 0;
}
