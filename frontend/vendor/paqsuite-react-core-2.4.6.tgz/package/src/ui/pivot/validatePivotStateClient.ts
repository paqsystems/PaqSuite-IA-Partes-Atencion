export type PivotValidacionRule = {
  reglaCode: string;
  campo?: string;
  area?: string;
  parametros?: Record<string, unknown>;
};

export type PivotStateValidationError = {
  reglaCode: string;
  campo?: string;
  area?: string;
  field?: string;
};

type PivotStateField = {
  dataField?: string;
  area?: string | null;
};

/**
 * Mirror FE de PivotStateValidator (MVP). La verdad normativa es el BE.
 */
export function validatePivotStateClient(
  stateJson: string,
  rules: PivotValidacionRule[]
): PivotStateValidationError[] {
  let decoded: { fields?: PivotStateField[] };
  try {
    decoded = JSON.parse(stateJson) as { fields?: PivotStateField[] };
  } catch {
    return [{ reglaCode: 'stateJsonInvalid', field: 'stateJson' }];
  }

  const byArea: Record<string, string[]> = {
    filter: [],
    row: [],
    column: [],
    data: [],
  };

  for (const field of decoded.fields ?? []) {
    const dataField = field.dataField ?? '';
    const area = field.area ?? '';
    if (!dataField || !area || !(area in byArea)) {
      continue;
    }
    byArea[area].push(dataField);
  }

  const errors: PivotStateValidationError[] = [];

  for (const rule of rules) {
    if (rule.reglaCode === 'fieldForbiddenInArea' && rule.campo && rule.area) {
      if ((byArea[rule.area] ?? []).includes(rule.campo)) {
        errors.push({
          reglaCode: rule.reglaCode,
          campo: rule.campo,
          area: rule.area,
          field: rule.campo,
        });
      }
    }

    if (rule.reglaCode === 'fieldRequiredInArea' && rule.campo && rule.area) {
      if (!(byArea[rule.area] ?? []).includes(rule.campo)) {
        errors.push({
          reglaCode: rule.reglaCode,
          campo: rule.campo,
          area: rule.area,
          field: rule.campo,
        });
      }
    }

    if (rule.reglaCode === 'maxFieldsInArea' && rule.area) {
      const max = Number(rule.parametros?.max ?? 0);
      const count = (byArea[rule.area] ?? []).length;
      if (max > 0 && count > max) {
        errors.push({
          reglaCode: rule.reglaCode,
          area: rule.area,
          field: rule.area,
        });
      }
    }
  }

  return errors;
}
