import Button from 'devextreme-react/button';
import type { ReactNode } from 'react';
import { stateClassNames } from '../tokens';

export type ErrorStateProps = {
  title: ReactNode;
  description?: ReactNode;
  onRetry?: () => void;
  retryLabel?: ReactNode;
};

/** Estado de error con acción DevExtreme (`Button`) — GEN-01. */
export function ErrorState({ title, description, onRetry, retryLabel }: ErrorStateProps) {
  return (
    <div className={stateClassNames.error} data-testid="errorState" role="alert">
      <p>{title}</p>
      {description ? <p>{description}</p> : null}
      {onRetry ? (
        <Button
          text={typeof retryLabel === 'string' ? retryLabel : 'Reintentar'}
          onClick={onRetry}
          type="default"
        />
      ) : null}
    </div>
  );
}
