import LoadPanel from 'devextreme-react/load-panel';
import type { ReactNode } from 'react';

export type LoadingOverlayProps = {
  label?: ReactNode;
  visible?: boolean;
};

/** Overlay de carga DevExtreme (`LoadPanel`) — GEN-01. */
export function LoadingOverlay({ label, visible = true }: LoadingOverlayProps) {
  return (
    <div data-testid="loadingOverlay">
      <LoadPanel
        visible={visible}
        showIndicator
        showPane
        shading
        message={typeof label === 'string' ? label : 'Cargando…'}
        position={{ of: 'window' }}
      />
    </div>
  );
}
