import type { ReactNode } from 'react';
import { stateClassNames } from '../tokens';

export type EmptyStateProps = {
  title: ReactNode;
  description?: ReactNode;
  action?: ReactNode;
};

/** Estado vacío estructural; acciones interactivas del host vía slot `action` (DX). */
export function EmptyState({ title, description, action }: EmptyStateProps) {
  return (
    <div className={stateClassNames.empty} data-testid="emptyState" role="status">
      <p>{title}</p>
      {description ? <p>{description}</p> : null}
      {action}
    </div>
  );
}
