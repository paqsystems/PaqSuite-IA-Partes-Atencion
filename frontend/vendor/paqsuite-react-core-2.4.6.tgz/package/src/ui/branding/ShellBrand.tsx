import type { ReactNode } from 'react';
import { ClienteLogo, type ClienteLogoProps } from './ClienteLogo';

export type ShellBrandProps = Omit<ClienteLogoProps, 'testId'> & {
  productTitle: ReactNode;
  logoTestId?: string;
};

/**
 * Header shell: logo de instalación + nombre de producto (SPEC-001-19).
 */
export function ShellBrand({
  productTitle,
  logoTestId = 'shellClienteLogo',
  className,
  ...logoProps
}: ShellBrandProps) {
  return (
    <div className={['pqShellBrand', className].filter(Boolean).join(' ')}>
      <ClienteLogo {...logoProps} className="pqShellClienteLogo" testId={logoTestId} />
      <span className="pqShellBrandTitle">{productTitle}</span>
    </div>
  );
}
