import { useEffect, useState } from 'react';
import {
  resolveClienteDefaultLogoUrl,
  resolveClienteLogoUrl,
  type ResolveClienteLogoUrlInput,
} from '../../tenancy/clienteBranding';

export type ClienteLogoProps = ResolveClienteLogoUrlInput & {
  cliente: string;
  className?: string;
  testId?: string;
};

/**
 * Logo de instalación con fallback: `{CLIENTE}.jpg` → `default.jpg` → ocultar.
 */
export function ClienteLogo({
  cliente,
  basePath,
  defaultFileName,
  className,
  testId = 'clienteLogo',
}: ClienteLogoProps) {
  const brandingInput = { basePath, defaultFileName };
  const primarySrc = resolveClienteLogoUrl(cliente, brandingInput);
  const fallbackSrc = resolveClienteDefaultLogoUrl(brandingInput);

  const [src, setSrc] = useState(primarySrc);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    setSrc(primarySrc);
    setVisible(true);
  }, [primarySrc]);

  if (!visible) {
    return null;
  }

  return (
    <img
      className={className}
      src={src}
      alt=""
      data-testid={testId}
      onError={() => {
        if (src === fallbackSrc) {
          setVisible(false);
          return;
        }
        setSrc(fallbackSrc);
      }}
    />
  );
}
