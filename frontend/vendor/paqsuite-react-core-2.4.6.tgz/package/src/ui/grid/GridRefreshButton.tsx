import Button from 'devextreme-react/button';

export type GridRefreshButtonProps = {
  onRefresh: () => void;
  disabled?: boolean;
  label?: string;
};

/** Botón Actualizar DevExtreme — testid `gridRefresh`. */
export function GridRefreshButton({ onRefresh, disabled, label }: GridRefreshButtonProps) {
  return (
    <Button
      text={label ?? 'Actualizar'}
      disabled={disabled}
      onClick={onRefresh}
      elementAttr={{ 'data-testid': 'gridRefresh' }}
    />
  );
}
