import { describe, expect, it } from 'vitest';
import { resolveGridPageSizes } from './pageSizes';

describe('resolveGridPageSizes', () => {
  it('fallback [10, 25, 50] sin parámetros', () => {
    expect(resolveGridPageSizes()).toEqual([10, 25, 50]);
    expect(resolveGridPageSizes({})).toEqual([10, 25, 50]);
  });

  it('usa los parámetros de sistema cuando son válidos', () => {
    expect(resolveGridPageSizes({ GridPageSize1: 20, GridPageSize2: 40, GridPageSize3: 80 })).toEqual([
      20, 40, 80,
    ]);
  });

  it('cae a fallback posicional si el parámetro es inválido o falta', () => {
    expect(resolveGridPageSizes({ GridPageSize1: 0, GridPageSize2: 40 })).toEqual([10, 40, 50]);
    expect(resolveGridPageSizes({ GridPageSize2: -5 })).toEqual([10, 25, 50]);
  });
});
