import type { ReactNode } from 'react';

export type DashboardWidget = {
  id: string;
  title: string;
  render: () => ReactNode;
};

const widgets = new Map<string, DashboardWidget>();

/** Registra (o reemplaza) un widget por `id` (GEN-09). */
export function registerWidget(widget: DashboardWidget): void {
  widgets.set(widget.id, widget);
}

export function listWidgets(): DashboardWidget[] {
  return Array.from(widgets.values());
}

/** Solo tests / reset entre navegaciones de host. */
export function clearWidgets(): void {
  widgets.clear();
}
