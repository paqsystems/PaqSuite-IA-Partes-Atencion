import { apiRequest, type ApiClientResult } from '../../http/apiClient';

/** Canal de preferencias del usuario (TR-GEN-02); la selección activa vive aquí. */
export const userPreferencesPath = '/api/v1/user/preferences';

/** Fragmento leído/escrito por GEN-16 sobre el store único de preferencias. */
export type ActiveCredentialPreferenceDto = {
  activeLlmCredentialId: number | null;
};

/** `GET /api/v1/user/preferences` — lee `activeLlmCredentialId`. */
export function getActiveCredentialPreference(): Promise<
  ApiClientResult<ActiveCredentialPreferenceDto>
> {
  return apiRequest<ActiveCredentialPreferenceDto>(userPreferencesPath, {
    method: 'GET',
  });
}

/** `PATCH /api/v1/user/preferences` — persiste `activeLlmCredentialId` (BE normaliza id ajeno → null). */
export function setActiveCredentialPreference(
  activeLlmCredentialId: number | null
): Promise<ApiClientResult<ActiveCredentialPreferenceDto>> {
  return apiRequest<ActiveCredentialPreferenceDto>(userPreferencesPath, {
    method: 'PATCH',
    body: JSON.stringify({ activeLlmCredentialId }),
  });
}
