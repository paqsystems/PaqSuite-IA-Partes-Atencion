import { describe, expect, it } from 'vitest';
import { buildLlmCredentialPatchBody } from './llmCredentialsClient';
import { findProviderItem, providerLabel, resolveSupportsVision } from './formHelpers';
import type { LlmProviderCatalogItem } from './types';

const catalog: LlmProviderCatalogItem[] = [
  {
    id: 'openai',
    label: 'OpenAI',
    requiresBaseUrl: false,
    models: ['gpt-4o', 'gpt-3.5'],
    supportsVisionByModel: { 'gpt-4o': true, 'gpt-3.5': false },
    defaultSupportsVision: false,
  },
  { id: 'ollama', labelKey: 'providers.ollama', requiresBaseUrl: true },
];

describe('resolveSupportsVision', () => {
  it('usa el mapa por modelo cuando existe', () => {
    expect(resolveSupportsVision(catalog[0], 'gpt-4o')).toBe(true);
    expect(resolveSupportsVision(catalog[0], 'gpt-3.5')).toBe(false);
  });

  it('cae a defaultSupportsVision y luego false', () => {
    expect(resolveSupportsVision(catalog[0], 'modelo-desconocido')).toBe(false);
    expect(resolveSupportsVision(undefined, 'x')).toBe(false);
  });
});

describe('providerLabel', () => {
  it('usa labelKey con traductor', () => {
    expect(providerLabel(catalog[1]!, (key) => `T:${key}`)).toBe('T:providers.ollama');
  });

  it('fallback a label o id', () => {
    expect(providerLabel(catalog[0]!)).toBe('OpenAI');
  });
});

describe('findProviderItem', () => {
  it('encuentra por id', () => {
    expect(findProviderItem(catalog, 'ollama')?.requiresBaseUrl).toBe(true);
    expect(findProviderItem(catalog, 'nope')).toBeUndefined();
  });
});

describe('buildLlmCredentialPatchBody', () => {
  it('omite secreto vacío / null para conservarlo', () => {
    expect(buildLlmCredentialPatchBody({ secreto: '' })).not.toHaveProperty('secreto');
    expect(buildLlmCredentialPatchBody({ secreto: null })).not.toHaveProperty('secreto');
    expect(buildLlmCredentialPatchBody({})).not.toHaveProperty('secreto');
  });

  it('conserva secreto no vacío', () => {
    expect(buildLlmCredentialPatchBody({ secreto: 'sk-x' }).secreto).toBe('sk-x');
  });
});
