import { describe, expect, it } from 'vitest';
import {
  firstEnabledCredentialId,
  resolveActiveCredential,
} from './resolveActiveCredential';
import type { LlmCredentialDto } from './types';

function credential(overrides: Partial<LlmCredentialDto>): LlmCredentialDto {
  return {
    id: 1,
    nombre: 'A',
    proveedor: 'openai',
    modelo: 'gpt',
    baseUrl: null,
    supportsVision: false,
    enabled: true,
    hasSecret: true,
    ...overrides,
  };
}

describe('resolveActiveCredential', () => {
  it('solo expone credenciales habilitadas como opciones', () => {
    const list = [credential({ id: 1 }), credential({ id: 2, enabled: false })];
    const resolved = resolveActiveCredential(list, 1);
    expect(resolved.enabledCredentials).toHaveLength(1);
    expect(resolved.activeResolved?.id).toBe(1);
    expect(resolved.configurationRequired).toBe(false);
  });

  it('id activo fuera de habilitadas → stale (configurationRequired)', () => {
    const list = [credential({ id: 2, enabled: false })];
    const resolved = resolveActiveCredential(list, 2);
    expect(resolved.activeResolved).toBeNull();
    expect(resolved.configurationRequired).toBe(true);
    expect(resolved.canAttachImages).toBe(false);
  });

  it('canAttachImages solo si la activa soporta visión', () => {
    const list = [credential({ id: 3, supportsVision: true })];
    const resolved = resolveActiveCredential(list, 3);
    expect(resolved.canAttachImages).toBe(true);
  });

  it('activeCredentialId null → sin resolución', () => {
    const resolved = resolveActiveCredential([credential({})], null);
    expect(resolved.activeResolved).toBeNull();
    expect(resolved.configurationRequired).toBe(true);
  });
});

describe('firstEnabledCredentialId', () => {
  it('devuelve la primera habilitada por nombre ASC', () => {
    const list = [
      credential({ id: 1, nombre: 'Zeta' }),
      credential({ id: 2, nombre: 'Alfa' }),
      credential({ id: 3, nombre: 'Beta', enabled: false }),
    ];
    expect(firstEnabledCredentialId(list)).toBe(2);
  });

  it('null si no hay habilitadas', () => {
    expect(firstEnabledCredentialId([credential({ enabled: false })])).toBeNull();
  });
});
