import { useCallback, useEffect, useRef, useState } from 'react';
import {
  getActiveCredentialPreference,
  setActiveCredentialPreference,
} from './activeCredentialPreference';
import { listLlmCredentials } from './llmCredentialsClient';
import {
  firstEnabledCredentialId,
  resolveActiveCredential,
} from './resolveActiveCredential';
import type {
  LlmCredentialDto,
  LlmSelectionState,
  UseLlmCredentialSelectionOptions,
} from './types';

/** Revalidación por defecto del listado (M3, TR-GEN-16-seleccion). */
export const defaultLlmCredentialsStaleMs = 30_000;

/**
 * Hook de selección activa compartida (Chat / Smart Capture).
 * Resuelve stale al montar y expone `setActiveCredentialId` (PATCH prefs) y
 * `refresh`. Autoselect es opt-in (`autoSelectFirstEnabled`, default false).
 */
export function useLlmCredentialSelection(
  options: UseLlmCredentialSelectionOptions = {}
): LlmSelectionState {
  const {
    autoSelectFirstEnabled = false,
    llmCredentialsStaleMs = defaultLlmCredentialsStaleMs,
  } = options;

  const [credentials, setCredentials] = useState<LlmCredentialDto[]>([]);
  const [activeCredentialId, setActiveCredentialIdState] = useState<number | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const lastFetchAtRef = useRef<number>(0);

  const refresh = useCallback(async () => {
    setLoading(true);
    const [listResult, prefResult] = await Promise.all([
      listLlmCredentials(),
      getActiveCredentialPreference(),
    ]);

    let nextCredentials: LlmCredentialDto[] = [];
    if (listResult.kind === 'ok') {
      nextCredentials = listResult.envelope.resultado.items ?? [];
    }
    let nextActive: number | null = null;
    if (prefResult.kind === 'ok') {
      nextActive = prefResult.envelope.resultado.activeLlmCredentialId ?? null;
    }

    const resolved = resolveActiveCredential(nextCredentials, nextActive);
    if (resolved.configurationRequired && autoSelectFirstEnabled) {
      const candidate = firstEnabledCredentialId(nextCredentials);
      if (candidate !== null) {
        nextActive = candidate;
        await setActiveCredentialPreference(candidate);
      }
    }

    setCredentials(nextCredentials);
    setActiveCredentialIdState(nextActive);
    lastFetchAtRef.current = Date.now();
    setLoading(false);
  }, [autoSelectFirstEnabled]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const setActiveCredentialId = useCallback(
    async (id: number | null) => {
      setActiveCredentialIdState(id);
      const result = await setActiveCredentialPreference(id);
      if (result.kind === 'ok') {
        setActiveCredentialIdState(result.envelope.resultado.activeLlmCredentialId ?? null);
      }
    },
    []
  );

  const maybeRevalidate = useCallback(async () => {
    if (Date.now() - lastFetchAtRef.current >= llmCredentialsStaleMs) {
      await refresh();
    }
  }, [llmCredentialsStaleMs, refresh]);

  useEffect(() => {
    void maybeRevalidate;
  }, [maybeRevalidate]);

  const resolved = resolveActiveCredential(credentials, activeCredentialId);

  return {
    credentials: resolved.enabledCredentials,
    activeCredentialId,
    activeResolved: resolved.activeResolved,
    configurationRequired: resolved.configurationRequired,
    canAttachImages: resolved.canAttachImages,
    loading,
    setActiveCredentialId,
    refresh,
  };
}
