import type { LlmCredentialDto } from './types';

export type ResolvedSelection = {
  /** Solo credenciales habilitadas (opciones del SelectBox). */
  enabledCredentials: LlmCredentialDto[];
  /** Credencial activa resuelta o `null` si stale / ausente. */
  activeResolved: LlmCredentialDto | null;
  /** true si no hay activa válida → gate «configuración requerida». */
  configurationRequired: boolean;
  /** true solo si la activa resuelta soporta visión. */
  canAttachImages: boolean;
};

/**
 * Resuelve la selección activa a partir del listado crudo y la preferencia.
 * Regla stale (TR-GEN-16-seleccion §5): si el id activo no está entre las
 * habilitadas, `activeResolved=null` y `configurationRequired=true`.
 */
export function resolveActiveCredential(
  credentials: LlmCredentialDto[],
  activeCredentialId: number | null
): ResolvedSelection {
  const enabledCredentials = credentials.filter((credential) => credential.enabled);
  const activeResolved =
    activeCredentialId === null
      ? null
      : enabledCredentials.find((credential) => credential.id === activeCredentialId) ?? null;

  return {
    enabledCredentials,
    activeResolved,
    configurationRequired: activeResolved === null,
    canAttachImages: activeResolved?.supportsVision === true,
  };
}

/**
 * Devuelve el id de la primera credencial habilitada por `nombre` ASC, o `null`.
 * Usado por el autoselect opt-in del hook (default off).
 */
export function firstEnabledCredentialId(credentials: LlmCredentialDto[]): number | null {
  const enabled = credentials
    .filter((credential) => credential.enabled)
    .slice()
    .sort((left, right) => left.nombre.localeCompare(right.nombre));
  return enabled.length > 0 ? enabled[0]!.id : null;
}
