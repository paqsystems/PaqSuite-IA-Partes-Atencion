/**
 * Tipos GEN-16 — credenciales LLM (BYOK), catálogo de proveedores host y
 * estado de selección activa compartida entre Chat y Smart Capture.
 *
 * Contratos: TR-GEN-16-api-credenciales §5, TR-GEN-16-preferencias-ui §5,
 * TR-GEN-16-seleccion-activa-consumidores §5.
 */

/** DTO de credencial devuelto por el API (nunca incluye el secreto). */
export type LlmCredentialDto = {
  id: number;
  nombre: string;
  proveedor: string;
  modelo: string;
  baseUrl: string | null;
  supportsVision: boolean;
  enabled: boolean;
  hasSecret: boolean;
};

/** Body de alta (`POST /api/v1/llm-credentials`). `secreto` obligatorio. */
export type LlmCredentialCreateBody = {
  nombre: string;
  proveedor: string;
  modelo: string;
  secreto: string;
  baseUrl?: string | null;
  supportsVision?: boolean;
  enabled?: boolean;
  requiresBaseUrl?: boolean;
};

/**
 * Body de edición (`PATCH /api/v1/llm-credentials/{id}`).
 * `secreto` omitido / null / "" → conservar el actual.
 */
export type LlmCredentialPatchBody = {
  nombre?: string;
  proveedor?: string;
  modelo?: string;
  secreto?: string | null;
  baseUrl?: string | null;
  supportsVision?: boolean;
  enabled?: boolean;
  requiresBaseUrl?: boolean;
};

/** Ítem del catálogo de proveedores que aporta el host (Framework no hardcodea). */
export type LlmProviderCatalogItem = {
  id: string;
  labelKey?: string;
  label?: string;
  helpUrl?: string | null;
  requiresBaseUrl: boolean;
  models?: string[];
  supportsVisionByModel?: Record<string, boolean>;
  defaultSupportsVision?: boolean;
};

/** Estado expuesto por `useLlmCredentialSelection` (TR selección §5). */
export type LlmSelectionState = {
  credentials: LlmCredentialDto[];
  activeCredentialId: number | null;
  activeResolved: LlmCredentialDto | null;
  configurationRequired: boolean;
  canAttachImages: boolean;
  loading: boolean;
  setActiveCredentialId: (id: number | null) => Promise<void>;
  refresh: () => Promise<void>;
};

export type UseLlmCredentialSelectionOptions = {
  autoSelectFirstEnabled?: boolean;
  onOpenPreferences?: () => void;
  llmCredentialsStaleMs?: number;
};
