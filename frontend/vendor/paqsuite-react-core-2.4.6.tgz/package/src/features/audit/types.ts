/**
 * Tipos GEN-17 — bitácora de auditoría (TR-GEN-17-bitacora-api-writers §5,
 * TR-GEN-17-retencion-purga §5, consulta UI).
 */

export type AuditEventDto = {
  eventId: string;
  occurredAt: string;
  actorUserId: number | null;
  companyId: number | null;
  source: string;
  action: string;
  entityType: string | null;
  entityId: string | null;
  result: string;
  payload: Record<string, unknown>;
};

export type AuditEventCreateBody = {
  occurredAt?: string;
  companyId?: number | null;
  source: string;
  action: string;
  entityType?: string | null;
  entityId?: string | null;
  result: string;
  payload?: Record<string, unknown>;
};

export type AuditEventListQuery = {
  source?: string;
  mineOnly?: boolean;
  from?: string;
  to?: string;
  page?: number;
  pageSize?: number;
};

export type AuditEventsPurgeResult = {
  deletedCount: number;
  olderThanDays: number;
};

/** Temas seed GEN de bitácora (TR consulta-ui §Cierres). */
export const auditSeedSources = [
  'security',
  'assistant',
  'chat',
  'tasks',
  'emission',
  'excelImport',
] as const;

export type AuditSource = (typeof auditSeedSources)[number] | string;
