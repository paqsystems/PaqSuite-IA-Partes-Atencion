import { useCallback, useEffect, useState } from 'react';
import { listAuditEvents } from './auditEventsClient';
import type { AuditEventDto } from './types';

export type UseAuditEventsQueryState = {
  events: AuditEventDto[];
  loading: boolean;
  errorKey: string | null;
  mineOnly: boolean;
  setMineOnly: (value: boolean) => void;
  refresh: () => Promise<void>;
};

/**
 * Hook de consulta de bitácora por `source` con filtro `mineOnly`
 * (TR-GEN-17-bitacora-consulta-ui). El `source` viene siempre del path.
 */
export function useAuditEventsQuery(source: string): UseAuditEventsQueryState {
  const [events, setEvents] = useState<AuditEventDto[]>([]);
  const [loading, setLoading] = useState(false);
  const [errorKey, setErrorKey] = useState<string | null>(null);
  const [mineOnly, setMineOnly] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    setErrorKey(null);
    const result = await listAuditEvents({ source, mineOnly });
    setLoading(false);
    if (result.kind === 'ok') {
      setEvents(result.envelope.resultado.items ?? []);
      return;
    }
    setEvents([]);
    setErrorKey(
      result.kind === 'envelopeError' ? result.envelope.respuesta : 'infra.transport'
    );
  }, [source, mineOnly]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  return { events, loading, errorKey, mineOnly, setMineOnly, refresh };
}
