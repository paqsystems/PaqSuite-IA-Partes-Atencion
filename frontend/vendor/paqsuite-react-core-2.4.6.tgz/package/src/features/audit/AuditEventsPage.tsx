import { useCallback, useState } from 'react';
import DataGrid, {
  Column,
  FilterRow,
  HeaderFilter,
  Paging,
  Pager,
} from 'devextreme-react/data-grid';
import Button from 'devextreme-react/button';
import CheckBox from 'devextreme-react/check-box';
import Popup from 'devextreme-react/popup';
import { confirm } from 'devextreme/ui/dialog';
import { purgeAuditEvents } from './auditEventsClient';
import { useAuditEventsQuery } from './useAuditEventsQuery';
import type { AuditEventDto } from './types';

export type AuditEventsPageProps = {
  /** `source` del path `/audit-events/:source` (C1-17-08). */
  source: string;
  /** Muestra botón Purgar solo con permiso `audit-events-purge` (C1-17-03). */
  canPurge?: boolean;
  t?: (key: string) => string;
};

/**
 * Consulta de bitácora por tema (GEN-17). Grilla DX con filtros, filtro
 * «Solo los propios», refresh, detalle en Popup y botón Purgar (permiso).
 */
export function AuditEventsPage({ source, canPurge, t }: AuditEventsPageProps) {
  const translate = t ?? ((key: string) => key);
  const { events, loading, errorKey, mineOnly, setMineOnly, refresh } =
    useAuditEventsQuery(source);
  const [detail, setDetail] = useState<AuditEventDto | null>(null);

  const handlePurge = useCallback(async () => {
    const confirmed = await confirm(
      translate('auditEvents.purge.confirm'),
      translate('auditEvents.purge.title')
    );
    if (!confirmed) {
      return;
    }
    const result = await purgeAuditEvents();
    if (result.kind === 'ok') {
      void refresh();
    }
  }, [refresh, translate]);

  return (
    <div data-testid="auditEvents.page">
      <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 12 }}>
        <h2>{translate('auditEvents.menu.root')}</h2>
        <CheckBox
          value={mineOnly}
          text={translate('auditEvents.filter.mineOnly')}
          onValueChanged={(event) => setMineOnly((event.value as boolean) ?? false)}
          elementAttr={{ 'data-testid': 'auditEvents.filter.mineOnly' }}
        />
        <Button
          icon="refresh"
          onClick={() => void refresh()}
          elementAttr={{ 'data-testid': 'auditEvents.refresh' }}
        />
        {canPurge ? (
          <Button
            text={translate('auditEvents.purge.cta')}
            onClick={() => void handlePurge()}
            elementAttr={{ 'data-testid': 'auditEvents.purge' }}
          />
        ) : null}
      </div>

      {errorKey ? (
        <p data-i18n-key={errorKey}>{translate(errorKey)}</p>
      ) : events.length === 0 && !loading ? (
        <p data-testid="auditEvents.empty">{translate('auditEvents.empty')}</p>
      ) : (
        <DataGrid
          dataSource={events}
          keyExpr="eventId"
          showBorders
          columnAutoWidth
          elementAttr={{ 'data-testid': 'auditEvents.grid' }}
          onRowClick={(event) => {
            const row = event.data as AuditEventDto | undefined;
            if (row) {
              setDetail(row);
            }
          }}
        >
          <FilterRow visible />
          <HeaderFilter visible />
          <Paging defaultPageSize={25} />
          <Pager visible showInfo showPageSizeSelector allowedPageSizes={[25, 50, 100]} />
          <Column dataField="occurredAt" caption={translate('auditEvents.grid.occurredAt')} dataType="datetime" />
          <Column dataField="actorUserId" caption={translate('auditEvents.grid.actor')} />
          <Column dataField="action" caption={translate('auditEvents.grid.action')} />
          <Column dataField="entityType" caption={translate('auditEvents.grid.entityType')} />
          <Column dataField="entityId" caption={translate('auditEvents.grid.entityId')} />
          <Column dataField="result" caption={translate('auditEvents.grid.result')} />
        </DataGrid>
      )}

      <Popup
        visible={detail !== null}
        onHiding={() => setDetail(null)}
        showTitle
        title={translate('auditEvents.grid.detail')}
        width={560}
        height="auto"
        wrapperAttr={{ 'data-testid': 'auditEvents.detail' }}
      >
        {detail ? (
          <pre style={{ whiteSpace: 'pre-wrap' }}>
            {JSON.stringify(detail.payload, null, 2)}
          </pre>
        ) : null}
      </Popup>
    </div>
  );
}
