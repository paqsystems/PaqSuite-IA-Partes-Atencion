import { apiRequest, type ApiClientResult } from '../../http/apiClient';
import type {
  AuditEventCreateBody,
  AuditEventDto,
  AuditEventListQuery,
  AuditEventsPurgeResult,
} from './types';

export const auditEventsPath = '/api/v1/audit-events';

export type AuditEventListResult = {
  items: AuditEventDto[];
  page: number;
  pageSize: number;
  total?: number;
};

/** Construye la query del listado de bitácora (`source` siempre desde la UI). */
export function buildAuditEventsQuery(query: AuditEventListQuery): string {
  const params = new URLSearchParams();
  if (query.source) {
    params.set('source', query.source);
  }
  if (query.mineOnly) {
    params.set('mineOnly', 'true');
  }
  if (query.from) {
    params.set('from', query.from);
  }
  if (query.to) {
    params.set('to', query.to);
  }
  if (query.page !== undefined) {
    params.set('page', String(query.page));
  }
  if (query.pageSize !== undefined) {
    params.set('pageSize', String(query.pageSize));
  }
  const value = params.toString();
  return value ? `?${value}` : '';
}

/** `GET /api/v1/audit-events` — la UI siempre envía `source` del path (C1-17-08). */
export function listAuditEvents(
  query: AuditEventListQuery
): Promise<ApiClientResult<AuditEventListResult>> {
  return apiRequest<AuditEventListResult>(`${auditEventsPath}${buildAuditEventsQuery(query)}`, {
    method: 'GET',
  });
}

/** `GET /api/v1/audit-events/{eventId}`. */
export function getAuditEvent(eventId: string): Promise<ApiClientResult<AuditEventDto>> {
  return apiRequest<AuditEventDto>(`${auditEventsPath}/${eventId}`, { method: 'GET' });
}

/** `POST /api/v1/audit-events` — el actor HTTP es siempre el usuario autenticado. */
export function createAuditEvent(
  body: AuditEventCreateBody
): Promise<ApiClientResult<AuditEventDto>> {
  return apiRequest<AuditEventDto>(auditEventsPath, {
    method: 'POST',
    body: JSON.stringify(body),
  });
}

/** `POST /api/v1/audit-events/purge` — hard-delete por retención (permiso purge). */
export function purgeAuditEvents(
  olderThanDays?: number
): Promise<ApiClientResult<AuditEventsPurgeResult>> {
  return apiRequest<AuditEventsPurgeResult>(`${auditEventsPath}/purge`, {
    method: 'POST',
    body: JSON.stringify(olderThanDays === undefined ? {} : { olderThanDays }),
  });
}
