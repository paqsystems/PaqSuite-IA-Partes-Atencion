export const maxSmartCaptureImages = 4;
export const maxSmartCaptureImageBytes = 2 * 1024 * 1024;

export type ImageValidationError = 'imagesLimit' | 'imageTooLarge' | null;

/**
 * Validación UI previa de adjuntos (TR-GEN-03-panel-ui §5). Devuelve la clave
 * corta de error o `null`. Convive a propósito con las validaciones del
 * envelope backend.
 */
export function validateImageAddition(
  currentCount: number,
  incomingSizeBytes: number
): ImageValidationError {
  if (currentCount + 1 > maxSmartCaptureImages) {
    return 'imagesLimit';
  }
  if (incomingSizeBytes > maxSmartCaptureImageBytes) {
    return 'imageTooLarge';
  }
  return null;
}
