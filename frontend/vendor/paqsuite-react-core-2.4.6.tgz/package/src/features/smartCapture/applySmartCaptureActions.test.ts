import { describe, expect, it, vi } from 'vitest';
import { applySmartCaptureActions } from './applySmartCaptureActions';
import { SMART_CAPTURE_MAX_OPTIONS } from './useSmartCapturePendingChoice';
import type { SmartCaptureTurnAction } from './types';

describe('applySmartCaptureActions', () => {
  it('applies actions in order', async () => {
    const applied: string[] = [];
    const actions: SmartCaptureTurnAction[] = [
      { action: 'setField', payload: { field: 'a' }, resultado: 'ok' },
      { action: 'addLine', payload: { sku: '1' }, resultado: 'ok' },
    ];

    await applySmartCaptureActions(actions, {
      applyAction: (action) => {
        applied.push(action.action);
      },
    });

    expect(applied).toEqual(['setField', 'addLine']);
  });

  it('skips when canApply returns false', async () => {
    const applyAction = vi.fn();
    await applySmartCaptureActions(
      [{ action: 'save', payload: {}, resultado: 'ok' }],
      {
        canApply: () => false,
        applyAction,
      }
    );
    expect(applyAction).not.toHaveBeenCalled();
  });
});

describe('SMART_CAPTURE_MAX_OPTIONS', () => {
  it('is 10', () => {
    expect(SMART_CAPTURE_MAX_OPTIONS).toBe(10);
  });
});
