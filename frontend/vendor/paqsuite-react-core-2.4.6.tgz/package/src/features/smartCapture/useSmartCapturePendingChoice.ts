import { useCallback, useEffect, useState } from 'react';
import type { PendingChoice } from './types';

/** Máximo Should de opciones en `pendingChoice` (TR-GEN-03-comportamiento-hilo). */
export const SMART_CAPTURE_MAX_OPTIONS = 10;

export type SmartCaptureDeferredCause =
  | 'rootUnresolved'
  | 'ambiguity'
  | 'missingInfo'
  | 'validationPending'
  | 'permissionDenied'
  | 'confirmationRequired'
  | 'serviceUnavailable';

export type SmartCaptureDeferredItem = {
  cause: SmartCaptureDeferredCause;
  payload: Record<string, unknown>;
};

/**
 * Estado de `pendingChoice` del hilo: se reenvía en el próximo request y se
 * limpia al desmontar el proceso (Q13 — hilo no persistido).
 */
export function useSmartCapturePendingChoice() {
  const [pendingChoice, setPendingChoice] = useState<PendingChoice | null>(null);

  useEffect(() => {
    return () => {
      setPendingChoice(null);
    };
  }, []);

  const clearPendingChoice = useCallback(() => {
    setPendingChoice(null);
  }, []);

  const acceptPendingChoice = useCallback((next: PendingChoice | null) => {
    if (next === null) {
      setPendingChoice(null);
      return;
    }
    const options = next.options.slice(0, SMART_CAPTURE_MAX_OPTIONS);
    setPendingChoice({ ...next, options });
  }, []);

  return {
    pendingChoice,
    setPendingChoice: acceptPendingChoice,
    clearPendingChoice,
  };
}
