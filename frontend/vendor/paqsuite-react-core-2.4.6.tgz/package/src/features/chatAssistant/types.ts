/**
 * Tipos del contrato de turno del Chat Asistente documental v1
 * (TR-GEN-21-contrato-turno §5). Sin `actions` (el chat solo explica).
 */

export type ChatAssistantImage = {
  fileName: string;
  mimeType: string;
  contentBase64: string;
};

export type ChatAssistantTurnRequestV1 = {
  contractVersion: 1;
  credentialId: number;
  message: string;
  images?: ChatAssistantImage[];
};

export type ChatAssistantCitation = {
  title: string;
  locator?: string;
};

export type ChatAssistantTurnResultV1 = {
  reply: string;
  citations?: ChatAssistantCitation[];
  configurationRequired: boolean;
};

export type ChatAssistantThreadMessage = {
  role: 'user' | 'assistant';
  text: string;
  citations?: ChatAssistantCitation[];
  pending?: boolean;
};
