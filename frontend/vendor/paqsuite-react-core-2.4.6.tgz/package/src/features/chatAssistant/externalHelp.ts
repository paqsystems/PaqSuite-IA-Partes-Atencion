/**
 * Helpers de ayuda externa por URL (TR-GEN-21-ayuda-externa §5).
 * La ayuda externa NO es el chat documental: abre una URL del host en nueva
 * solapa (web) o browser del SO (Capacitor).
 */

export type OpenExternalHelpAdapters = {
  /** Adaptador Capacitor (Browser / Custom Tabs). Si falta en web → window.open. */
  openExternalUrl?: (url: string) => Promise<void> | void;
};

export type OpenExternalHelpResult = {
  opened: boolean;
  reason?: 'missing' | 'invalid';
};

/** true solo para URLs `http:` / `https:` parseables. */
export function isValidExternalHelpUrl(url: string | null | undefined): boolean {
  if (!url) {
    return false;
  }
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

/**
 * Resuelve la URL de ayuda desde la prop del host o un resolver del host.
 * NUNCA desde la query string del navegador (C1-21-07-URL: sin redirector abierto).
 */
export function resolveExternalHelpUrl(
  propUrl: string | null | undefined,
  resolver?: () => string | null | undefined
): string | null {
  if (propUrl) {
    return propUrl;
  }
  const resolved = resolver?.();
  return resolved ?? null;
}

/**
 * Abre la ayuda externa validando la URL. `opened=false` → el caller muestra
 * `userMenu.helpUnavailable`.
 */
export function openExternalHelp(
  url: string | null | undefined,
  adapters: OpenExternalHelpAdapters = {}
): OpenExternalHelpResult {
  if (!url) {
    return { opened: false, reason: 'missing' };
  }
  if (!isValidExternalHelpUrl(url)) {
    return { opened: false, reason: 'invalid' };
  }
  if (adapters.openExternalUrl) {
    void adapters.openExternalUrl(url);
    return { opened: true };
  }
  if (typeof window !== 'undefined') {
    window.open(url, '_blank', 'noopener,noreferrer');
  }
  return { opened: true };
}
