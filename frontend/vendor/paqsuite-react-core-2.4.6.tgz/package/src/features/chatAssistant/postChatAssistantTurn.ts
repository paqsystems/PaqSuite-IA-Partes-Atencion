import { apiRequest, type ApiClientResult } from '../../http/apiClient';
import type { ChatAssistantTurnRequestV1, ChatAssistantTurnResultV1 } from './types';

/** Endpoint canónico GEN del turno documental (TR-GEN-21-contrato-turno §5). */
export const chatAssistantTurnUrl = '/api/v1/chat-assistant/turns';

/**
 * Envía un turno al Chat Asistente documental. Único camino de envío
 * (C1-21-05). Devuelve el `ApiClientResult` de `apiRequest`.
 */
export function postChatAssistantTurn(
  body: ChatAssistantTurnRequestV1,
  options?: { signal?: AbortSignal; url?: string }
): Promise<ApiClientResult<ChatAssistantTurnResultV1>> {
  return apiRequest<ChatAssistantTurnResultV1>(options?.url ?? chatAssistantTurnUrl, {
    method: 'POST',
    body: JSON.stringify(body),
    signal: options?.signal,
  });
}
