import type { ChatAssistantImage, ChatAssistantTurnRequestV1 } from './types';

export type BuildChatAssistantTurnInput = {
  credentialId: number;
  message: string;
  images?: ChatAssistantImage[];
  supportsVision: boolean;
};

/**
 * Arma el request v1 del turno documental. Si `supportsVision=false` omite las
 * imágenes (defensa en profundidad; TR-GEN-21-contrato-turno §5).
 */
export function buildChatAssistantTurnRequest(
  input: BuildChatAssistantTurnInput
): ChatAssistantTurnRequestV1 {
  const request: ChatAssistantTurnRequestV1 = {
    contractVersion: 1,
    credentialId: input.credentialId,
    message: input.message,
  };
  if (input.supportsVision && input.images && input.images.length > 0) {
    request.images = input.images;
  }
  return request;
}
