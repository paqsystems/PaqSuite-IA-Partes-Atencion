import { describe, expect, it } from 'vitest';
import {
  buildCompletePayload,
  excelImportErrorEffect,
  excelImportErrorKey,
  resolveProcessEnablement,
} from './excelImportPolicy';
import type { ExcelImportBatchDto } from './types';

function batch(overrides: Partial<ExcelImportBatchDto>): ExcelImportBatchDto {
  return {
    batchId: 'b1',
    processCode: 'demo',
    status: 'validated',
    mode: null,
    allowPartial: false,
    sheetName: 'Hoja1',
    fileName: 'x.xlsx',
    fileSizeBytes: 10,
    totalRows: 10,
    validRows: 10,
    errorRows: 0,
    processedRows: null,
    failedRows: null,
    messageKey: null,
    ...overrides,
  };
}

describe('resolveProcessEnablement', () => {
  it('habilita con filas válidas y sin errores', () => {
    expect(resolveProcessEnablement(batch({})).enabled).toBe(true);
  });

  it('deshabilita si validRows = 0', () => {
    const result = resolveProcessEnablement(batch({ validRows: 0 }));
    expect(result.enabled).toBe(false);
    expect(result.reasonKey).toBe('excelImport.process.noValidRows');
  });

  it('deshabilita si hay errores y allowPartial=false', () => {
    const result = resolveProcessEnablement(batch({ errorRows: 3, allowPartial: false }));
    expect(result.enabled).toBe(false);
    expect(result.reasonKey).toBe('excelImport.process.partialNotAllowed');
  });

  it('habilita mixto con allowPartial=true', () => {
    expect(resolveProcessEnablement(batch({ errorRows: 3, allowPartial: true })).enabled).toBe(true);
  });

  it('deshabilita si el estado no es validated', () => {
    expect(resolveProcessEnablement(batch({ status: 'invalid' })).enabled).toBe(false);
  });
});

describe('excelImportErrorKey / effect', () => {
  it('resuelve la clave i18n del código', () => {
    expect(excelImportErrorKey(4606)).toBe('excelImport.error.4606');
  });

  it('4604 oculta, 4603 deshabilita, otro = mensaje', () => {
    expect(excelImportErrorEffect(4604)).toBe('hide');
    expect(excelImportErrorEffect(4603)).toBe('disable');
    expect(excelImportErrorEffect(4606)).toBe('message');
  });
});

describe('buildCompletePayload', () => {
  it('queued → contadores 0 y data null (C1-14-16)', () => {
    const payload = buildCompletePayload(batch({ status: 'queued', processedRows: 5 }));
    expect(payload).toMatchObject({ status: 'queued', mode: 'async', processedRows: 0, data: null });
  });

  it('done → contadores reales', () => {
    const payload = buildCompletePayload(
      batch({ status: 'done', mode: 'sync', processedRows: 8, failedRows: 2, data: { ok: true } })
    );
    expect(payload).toMatchObject({ status: 'done', mode: 'sync', processedRows: 8, failedRows: 2 });
    expect(payload.data).toEqual({ ok: true });
  });
});
