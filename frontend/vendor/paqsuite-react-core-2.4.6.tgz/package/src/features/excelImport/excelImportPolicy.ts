import type { ExcelImportBatchDto, ExcelImportCompletePayload } from './types';

/**
 * Regla de habilitación de Procesar (C1-14-05): deshabilitado si `validRows=0`
 * o (`allowPartial=false` y `errorRows>0`). Devuelve además la causa para el
 * tooltip i18n.
 */
export type ProcessEnablement = {
  enabled: boolean;
  reasonKey: string | null;
};

export function resolveProcessEnablement(
  batch: Pick<ExcelImportBatchDto, 'validRows' | 'errorRows' | 'allowPartial' | 'status'>
): ProcessEnablement {
  if (batch.status !== 'validated') {
    return { enabled: false, reasonKey: 'excelImport.process.notValidated' };
  }
  if (batch.validRows === 0) {
    return { enabled: false, reasonKey: 'excelImport.process.noValidRows' };
  }
  if (!batch.allowPartial && batch.errorRows > 0) {
    return { enabled: false, reasonKey: 'excelImport.process.partialNotAllowed' };
  }
  return { enabled: true, reasonKey: null };
}

/** Resuelve el código de error del envelope a clave i18n `excelImport.error.{codigo}`. */
export function excelImportErrorKey(codigo: number | string): string {
  return `excelImport.error.${codigo}`;
}

/** 4604 oculta el componente; 4603 deshabilita las acciones (TR ui-embebida §5). */
export function excelImportErrorEffect(
  codigo: number | string
): 'hide' | 'disable' | 'message' {
  const value = String(codigo);
  if (value === '4604') {
    return 'hide';
  }
  if (value === '4603') {
    return 'disable';
  }
  return 'message';
}

/**
 * Construye el payload `onComplete`. En `queued` los contadores son 0 y `data`
 * se omite (C1-14-16).
 */
export function buildCompletePayload(batch: ExcelImportBatchDto): ExcelImportCompletePayload {
  const status = batch.status as ExcelImportCompletePayload['status'];
  if (status === 'queued') {
    return {
      batchId: batch.batchId,
      processCode: batch.processCode,
      status: 'queued',
      mode: 'async',
      totalRows: batch.totalRows,
      processedRows: 0,
      failedRows: 0,
      data: null,
    };
  }
  return {
    batchId: batch.batchId,
    processCode: batch.processCode,
    status,
    mode: batch.mode === 'async' ? 'async' : 'sync',
    totalRows: batch.totalRows,
    processedRows: batch.processedRows ?? 0,
    failedRows: batch.failedRows ?? 0,
    data: batch.data ?? null,
  };
}
