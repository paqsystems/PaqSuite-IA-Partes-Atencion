import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const source = readFileSync(join(dirname(fileURLToPath(import.meta.url)), 'EmissionDialog.tsx'), 'utf8');

describe('EmissionDialog — fuente DX 26.1', () => {
  it('no usa fieldRender', () => {
    expect(source).not.toMatch(/fieldRender/);
  });

  it('no usa itemRender en el SelectBox de modo', () => {
    expect(source).not.toMatch(/itemRender/);
  });
});
