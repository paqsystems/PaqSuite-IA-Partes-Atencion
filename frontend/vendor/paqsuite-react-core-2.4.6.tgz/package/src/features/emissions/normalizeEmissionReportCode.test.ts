import { describe, expect, it } from 'vitest';
import {
  catalogCodeFromDxUrl,
  catalogEmissionReportCode,
  codesReferToSameEmissionReport,
  isUnknownEmissionReportCode,
  normalizeEmissionReportCode,
} from './normalizeEmissionReportCode';

describe('normalizeEmissionReportCode', () => {
  it('vacío queda vacío', () => {
    expect(normalizeEmissionReportCode('')).toBe('');
    expect(normalizeEmissionReportCode('   ')).toBe('');
    expect(normalizeEmissionReportCode(null)).toBe('');
  });

  it('toma el último segmento de path y reemplaza puntos (como sidecar SafeUrl)', () => {
    expect(normalizeEmissionReportCode('partes.informes.consultaDetallada.Alt')).toBe(
      'partes-informes-consultaDetallada-Alt'
    );
    expect(normalizeEmissionReportCode('folder/Mi reporte.repx')).toBe('Mi-reporte-repx');
  });

  it('conserva puntos del código de catálogo (no hyphenizar para el host DX)', () => {
    expect(catalogEmissionReportCode('partes.consultaDetallada.principal')).toBe(
      'partes.consultaDetallada.principal'
    );
  });

  it('coerce número a string sin throw', () => {
    expect(catalogEmissionReportCode(12)).toBe('12');
    expect(normalizeEmissionReportCode(12)).toBe('12');
  });
});

describe('catalogCodeFromDxUrl', () => {
  it('conserva puntos del Save As (no hypheniza el catálogo)', () => {
    expect(catalogCodeFromDxUrl('partes.consultaDetallada.nuevoDiseno')).toBe(
      'partes.consultaDetallada.nuevoDiseno'
    );
    expect(catalogCodeFromDxUrl('folder/Mi reporte.repx')).toBe('Mi reporte');
  });
});

describe('isUnknownEmissionReportCode', () => {
  it('no trata como nuevo un Url equivalente al código conocido', () => {
    expect(
      isUnknownEmissionReportCode('partes.consultaDetallada.principal', [
        'partes-consultaDetallada-principal',
      ])
    ).toBe(false);
  });

  it('detecta Save As con nombre nuevo', () => {
    expect(
      isUnknownEmissionReportCode('Version personalizada', ['partes_consultaDetallada_principal'])
    ).toBe(true);
  });
});

describe('codesReferToSameEmissionReport', () => {
  it('compara case-insensitive tras normalizar', () => {
    expect(codesReferToSameEmissionReport('Foo.Bar', 'foo-bar')).toBe(true);
    expect(codesReferToSameEmissionReport('A', 'B')).toBe(false);
  });
});
