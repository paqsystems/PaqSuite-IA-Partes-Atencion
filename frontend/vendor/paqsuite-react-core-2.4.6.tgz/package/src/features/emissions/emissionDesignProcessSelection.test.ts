import { describe, expect, it } from 'vitest';
import {
  canMountDesigner,
  canMountDesignerHost,
  canShowDesignerChrome,
  confirmSelectedProcess,
  nextConfirmedAfterProcessChange,
  resolveInitialSelectValue,
  shouldAutoConfirmProcessList,
} from './emissionDesignProcessSelection';

describe('shouldAutoConfirmProcessList', () => {
  it('nunca auto-confirma (N=0, N=1 y N=2)', () => {
    expect(shouldAutoConfirmProcessList(0)).toBe(false);
    expect(shouldAutoConfirmProcessList(1)).toBe(false);
    expect(shouldAutoConfirmProcessList(2)).toBe(false);
  });
});

describe('canMountDesignerHost', () => {
  it('no monta el widget hasta que el catálogo de reports está listo', () => {
    expect(canMountDesignerHost('EMISSION_SMOKE', false)).toBe(false);
    expect(canMountDesignerHost('EMISSION_SMOKE', true)).toBe(true);
    expect(canMountDesignerHost(null, true)).toBe(false);
  });
});

describe('canShowDesignerChrome', () => {
  it('muestra Cerrar en cuanto hay proceso confirmado', () => {
    expect(canShowDesignerChrome('EMISSION_SMOKE')).toBe(true);
    expect(canShowDesignerChrome(null)).toBe(false);
    expect(canShowDesignerChrome('')).toBe(false);
    expect(canMountDesigner('')).toBe(false);
  });
});

describe('resolveInitialSelectValue', () => {
  it('preselecciona initialProcessCode sin confirmar', () => {
    expect(resolveInitialSelectValue('A')).toBe('A');
    expect(canMountDesigner(null)).toBe(false);
    expect(confirmSelectedProcess(null)).toBe(null);
  });

  it('usa processCode como alias deprecado si no hay initialProcessCode', () => {
    expect(resolveInitialSelectValue(undefined, 'B')).toBe('B');
    expect(resolveInitialSelectValue('A', 'B')).toBe('A');
    expect(resolveInitialSelectValue('', '')).toBe(null);
  });
});

describe('nextConfirmedAfterProcessChange', () => {
  it('N=1: sin confirmado previo sigue null al elegir el único ítem', () => {
    expect(nextConfirmedAfterProcessChange(null, 'ONLY')).toBe(null);
  });

  it('N=2: cambiar A→B invalida confirmación', () => {
    expect(nextConfirmedAfterProcessChange('A', 'B')).toBe(null);
    expect(nextConfirmedAfterProcessChange('A', 'A')).toBe('A');
  });
});

describe('confirmSelectedProcess', () => {
  it('confirma el value elegido (N=1 o N=2)', () => {
    expect(confirmSelectedProcess('B')).toBe('B');
    expect(confirmSelectedProcess(null)).toBe(null);
  });
});
