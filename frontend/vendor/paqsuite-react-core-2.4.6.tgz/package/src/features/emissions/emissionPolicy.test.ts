import { describe, expect, it } from 'vitest';
import {
  buildEmissionCompletePayload,
  canEmit,
  communicationOutputs,
  documentaryOutputs,
  isPreviewStale,
  isTerminalJob,
  mergeRecipientsAddOnly,
  resolveAvailableChannels,
  shouldOfferPreview,
  shouldOpenEmissionDialog,
} from './emissionPolicy';
import type { EmissionJobDto, EmissionOutputPolicy, PreviewInputs } from './types';

const hybridPolicy: EmissionOutputPolicy = {
  mode: 'HYBRID',
  outputs: [
    { channel: 'pdf', kind: 'documentary', mandatory: false, automatic: false, blocking: true },
    { channel: 'excel', kind: 'documentary', mandatory: false, automatic: false, blocking: true },
    { channel: 'EMAIL', kind: 'communication', mandatory: false, automatic: false, blocking: false },
  ],
  recipientEditMode: 'FULL_EDIT',
};

describe('resolveAvailableChannels', () => {
  it('desktop usa salidas documentales de Output Policy', () => {
    const channels = resolveAvailableChannels(
      { channels: ['pdf', 'mail', 'print'], outputPolicy: hybridPolicy },
      false
    );
    expect(channels).toEqual(['pdf', 'excel']);
  });

  it('native filtra a rama corta (sin print/zip/mail)', () => {
    const channels = resolveAvailableChannels(
      {
        channels: ['pdf', 'print', 'excel', 'zip'],
        outputPolicy: {
          mode: 'INTERACTIVE',
          outputs: [
            { channel: 'pdf', kind: 'documentary', mandatory: false, automatic: false, blocking: true },
            { channel: 'print', kind: 'documentary', mandatory: false, automatic: false, blocking: true },
            { channel: 'excel', kind: 'documentary', mandatory: false, automatic: false, blocking: true },
            { channel: 'zip', kind: 'documentary', mandatory: false, automatic: false, blocking: true },
          ],
        },
      },
      true
    );
    expect(channels).toEqual(['pdf', 'excel']);
  });
});

describe('output policy helpers', () => {
  it('separa documentary vs communication', () => {
    expect(documentaryOutputs(hybridPolicy).map((item) => item.channel)).toEqual(['pdf', 'excel']);
    expect(communicationOutputs(hybridPolicy).map((item) => item.channel)).toEqual(['EMAIL']);
  });

  it('HYBRID / INTERACTIVE abren ventana', () => {
    expect(shouldOpenEmissionDialog(hybridPolicy)).toBe(true);
    expect(shouldOpenEmissionDialog({ ...hybridPolicy, mode: 'AUTOMATIC' })).toBe(false);
    expect(shouldOpenEmissionDialog({ ...hybridPolicy, mode: 'MANDATORY' })).toBe(false);
  });
});

describe('shouldOfferPreview', () => {
  it('desktop con requiresPreview=true → true', () => {
    expect(shouldOfferPreview({ requiresPreview: true }, false)).toBe(true);
  });
  it('native nunca ofrece preview', () => {
    expect(shouldOfferPreview({ requiresPreview: true }, true)).toBe(false);
  });
});

describe('isPreviewStale', () => {
  const base: PreviewInputs = { reportId: 1, mode: 'consolidated', groupId: null, channel: 'pdf' };
  it('sin preview previo → stale', () => {
    expect(isPreviewStale(null, base)).toBe(true);
  });
  it('mismas entradas → no stale', () => {
    expect(isPreviewStale(base, { ...base })).toBe(false);
  });
  it('cambio de reporte/modo/canal → stale', () => {
    expect(isPreviewStale(base, { ...base, reportId: 2 })).toBe(true);
    expect(isPreviewStale(base, { ...base, mode: 'segmented' })).toBe(true);
    expect(isPreviewStale(base, { ...base, channel: 'excel' })).toBe(true);
  });
});

describe('canEmit', () => {
  it('requiere al menos un canal', () => {
    expect(canEmit({ channels: [], mode: 'consolidated' })).toBe(false);
  });
  it('segmentado requiere grupo', () => {
    expect(canEmit({ channels: ['pdf'], mode: 'segmented', groupId: null })).toBe(false);
    expect(canEmit({ channels: ['pdf'], mode: 'segmented', groupId: 'g1' })).toBe(true);
  });
  it('requiresPreview desktop bloquea sin preview válido', () => {
    expect(
      canEmit({
        channels: ['pdf'],
        mode: 'consolidated',
        requiresPreview: true,
        hasValidPreview: false,
        isNative: false,
      })
    ).toBe(false);
    expect(
      canEmit({
        channels: ['pdf'],
        mode: 'consolidated',
        requiresPreview: true,
        hasValidPreview: false,
        isNative: true,
      })
    ).toBe(true);
  });
});

describe('isTerminalJob / buildEmissionCompletePayload', () => {
  it('incluye failedCommunication', () => {
    expect(isTerminalJob('done')).toBe(true);
    expect(isTerminalJob('failedCommunication')).toBe(true);
    expect(isTerminalJob('running')).toBe(false);
  });

  it('mapea outputCode y notificationIds', () => {
    const job: EmissionJobDto = {
      jobId: 'j1',
      processCode: 'demo',
      status: 'done',
      mode: 'consolidated',
      channel: 'pdf',
      fileName: 'r.pdf',
      messageKey: null,
      notificationId: 'n-1',
    };
    expect(buildEmissionCompletePayload(job)).toEqual({
      jobId: 'j1',
      processCode: 'demo',
      status: 'done',
      outputCode: 'pdf',
      mode: 'consolidated',
      fileName: 'r.pdf',
      notificationIds: ['n-1'],
    });
  });
});

describe('mergeRecipientsAddOnly', () => {
  it('conserva fijados y agrega extras', () => {
    expect(mergeRecipientsAddOnly(['a@test.com'], ['a@test.com', 'b@test.com'])).toEqual([
      'a@test.com',
      'b@test.com',
    ]);
  });
});
