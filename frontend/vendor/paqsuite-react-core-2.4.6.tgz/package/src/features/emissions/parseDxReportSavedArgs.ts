export type ParsedDxReportSaved = {
  url: string;
  layoutDefinition?: string;
};

const urlKeys = ['Url', 'url', 'NewUrl', 'newUrl', 'reportUrl'] as const;
const argsKeys = ['args', 'Args'] as const;
const maxDepth = 8;

function unwrapValue(value: unknown, depth = 0): unknown {
  if (depth > maxDepth || value == null) {
    return value;
  }
  if (typeof value === 'function') {
    try {
      return unwrapValue(value(), depth + 1);
    } catch {
      return undefined;
    }
  }
  if (typeof value === 'object') {
    const peek = (value as { peek?: unknown }).peek;
    if (typeof peek === 'function') {
      try {
        return unwrapValue(peek.call(value), depth + 1);
      } catch {
        return undefined;
      }
    }
  }
  return value;
}

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== 'object') {
    return null;
  }
  return value as Record<string, unknown>;
}

function readUrlFromObject(value: Record<string, unknown>): string {
  for (const key of urlKeys) {
    const candidate = unwrapValue(value[key]);
    if (typeof candidate === 'string' && candidate.trim() !== '') {
      return candidate.trim();
    }
  }
  return '';
}

function readLayoutFromObject(value: Record<string, unknown>): string | undefined {
  const report = unwrapValue(value.Report ?? value.report);
  if (!report || typeof report !== 'object') {
    return undefined;
  }
  const serialize = (report as { serialize?: () => string }).serialize;
  if (typeof serialize !== 'function') {
    return undefined;
  }
  try {
    const xml = serialize();
    return typeof xml === 'string' && xml.trim() !== '' ? xml : undefined;
  } catch {
    return undefined;
  }
}

function visit(
  node: unknown,
  seen: WeakSet<object>,
  acc: ParsedDxReportSaved,
  depth: number
): void {
  if (depth > maxDepth || node == null) {
    return;
  }
  const unwrapped = unwrapValue(node);
  if (Array.isArray(unwrapped)) {
    for (const item of unwrapped) {
      visit(item, seen, acc, depth + 1);
      if (acc.url && acc.layoutDefinition) {
        return;
      }
    }
    return;
  }
  const record = asRecord(unwrapped);
  if (!record) {
    return;
  }
  if (seen.has(record)) {
    return;
  }
  seen.add(record);

  if (!acc.url) {
    acc.url = readUrlFromObject(record);
  }
  if (!acc.layoutDefinition) {
    acc.layoutDefinition = readLayoutFromObject(record);
  }
  if (acc.url && acc.layoutDefinition) {
    return;
  }
  for (const key of argsKeys) {
    if (key in record) {
      visit(record[key], seen, acc, depth + 1);
    }
  }
}

/**
 * DevExpress ReportSaved: objeto plano, `(sender, args)`, o envelope React 26.1
 * `{ sender, args: { Url, Report }, component }`. Recorre `args`/`Args`,
 * unwrap de función y KO observable (`peek`).
 */
export function parseDxReportSavedArgs(args: unknown): ParsedDxReportSaved {
  const acc: ParsedDxReportSaved = { url: '' };
  visit(args, new WeakSet<object>(), acc, 0);
  return acc;
}
