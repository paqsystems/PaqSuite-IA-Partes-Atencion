import { apiRequest, type ApiClientResult } from '../../http/apiClient';
import { resolveRequestUrl } from '../../mobile/resolveApiBaseUrl';
import type {
  EmissionJobCreateRequest,
  EmissionJobDto,
  EmissionOutputPolicy,
  EmissionPreviewResult,
  EmissionProcessDto,
  EmissionProcessListItem,
} from './types';
import { isDocumentaryChannel } from './types';

export const emissionsBasePath = '/api/v1/emissions';

type ProcessApiPayload = {
  item?: {
    processCode: string;
    channels?: string[];
    allowsConsolidated?: boolean;
    allowsSegmented?: boolean;
    modes?: { consolidated: boolean; segmented: boolean };
    requiresPreview?: boolean;
    outputPolicy?: EmissionOutputPolicy;
    reports?: EmissionProcessDto['reports'];
    menuProcessCode?: string;
  };
} & Partial<EmissionProcessDto>;

type JobApiPayload = {
  item?: EmissionJobDto & Record<string, unknown>;
} & Partial<EmissionJobDto>;

function defaultOutputPolicy(channels: string[]): EmissionOutputPolicy {
  return {
    mode: 'INTERACTIVE',
    outputs: channels.filter(isDocumentaryChannel).map((channel) => ({
      channel,
      kind: 'documentary' as const,
      mandatory: false,
      automatic: false,
      blocking: true,
    })),
  };
}

function mapProcess(payload: ProcessApiPayload): EmissionProcessDto {
  const item = (payload.item ?? payload) as NonNullable<ProcessApiPayload['item']> &
    Partial<EmissionProcessDto>;
  const channels = (item.channels ?? []).filter((channel) => channel !== 'mail');
  return {
    processCode: String(item.processCode ?? ''),
    channels,
    modes: item.modes ?? {
      consolidated: Boolean(item.allowsConsolidated),
      segmented: Boolean(item.allowsSegmented),
    },
    requiresPreview: Boolean(item.requiresPreview),
    outputPolicy: item.outputPolicy ?? defaultOutputPolicy(channels),
    reports: item.reports ?? [],
    menuProcessCode: String(item.menuProcessCode ?? ''),
  };
}

function mapJob(payload: JobApiPayload): EmissionJobDto {
  const item = (payload.item ?? payload) as EmissionJobDto;
  return {
    jobId: String(item.jobId ?? ''),
    processCode: String(item.processCode ?? ''),
    status: item.status,
    mode: item.mode,
    channel: String(item.channel ?? ''),
    fileName: item.fileName ?? null,
    messageKey: item.messageKey ?? null,
    notificationId: item.notificationId ?? null,
    segmentKey: item.segmentKey ?? null,
  };
}

/** `GET .../processes/{processCode}` — metadata + Output Policy. */
export async function getEmissionProcess(
  processCode: string
): Promise<ApiClientResult<EmissionProcessDto>> {
  const result = await apiRequest<ProcessApiPayload>(
    `${emissionsBasePath}/processes/${encodeURIComponent(processCode)}`,
    { method: 'GET' }
  );
  if (result.kind !== 'ok') {
    return result;
  }
  return {
    ...result,
    envelope: {
      ...result.envelope,
      resultado: mapProcess(result.envelope.resultado),
    },
  };
}

/** `POST .../preview` — genera sesión de preview (solo desktop). */
export function createEmissionPreview(
  request: EmissionJobCreateRequest
): Promise<ApiClientResult<EmissionPreviewResult>> {
  return apiRequest<EmissionPreviewResult>(`${emissionsBasePath}/preview`, {
    method: 'POST',
    body: JSON.stringify(request),
  });
}

/** `POST .../jobs` — 1 canal documental por POST (C1-15-21). */
export async function createEmissionJob(
  request: EmissionJobCreateRequest
): Promise<ApiClientResult<EmissionJobDto>> {
  const result = await apiRequest<JobApiPayload>(`${emissionsBasePath}/jobs`, {
    method: 'POST',
    body: JSON.stringify(request),
  });
  if (result.kind !== 'ok') {
    return result;
  }
  return {
    ...result,
    envelope: {
      ...result.envelope,
      resultado: mapJob(result.envelope.resultado),
    },
  };
}

/** `GET .../jobs/{jobId}` — estado del job (polling async). */
export async function getEmissionJob(jobId: string): Promise<ApiClientResult<EmissionJobDto>> {
  const result = await apiRequest<JobApiPayload>(`${emissionsBasePath}/jobs/${jobId}`, {
    method: 'GET',
  });
  if (result.kind !== 'ok') {
    return result;
  }
  return {
    ...result,
    envelope: {
      ...result.envelope,
      resultado: mapJob(result.envelope.resultado),
    },
  };
}

export type EmissionJobDownloadResult =
  | { kind: 'ok'; blob: Blob }
  | { kind: 'error'; i18nKey: string };

function isJsonContentType(contentType: string): boolean {
  return contentType.toLowerCase().includes('application/json');
}

/** `GET .../jobs/{jobId}/download` — binario (fuera del envelope). */
export async function downloadEmissionJob(jobId: string): Promise<EmissionJobDownloadResult> {
  let response: Response;
  try {
    response = await fetch(resolveRequestUrl(`${emissionsBasePath}/jobs/${encodeURIComponent(jobId)}/download`), {
      method: 'GET',
      headers: { Accept: 'application/octet-stream' },
      credentials: 'same-origin',
    });
  } catch {
    return { kind: 'error', i18nKey: 'emission.error.download' };
  }

  if (!response.ok) {
    return { kind: 'error', i18nKey: 'emission.error.download' };
  }

  let blob: Blob;
  try {
    blob = await response.blob();
  } catch {
    return { kind: 'error', i18nKey: 'emission.error.download' };
  }

  const contentType = response.headers.get('content-type') ?? blob.type;
  if (blob.size === 0 || isJsonContentType(contentType) || isJsonContentType(blob.type)) {
    return { kind: 'error', i18nKey: 'emission.error.download' };
  }

  return { kind: 'ok', blob };
}

type ProcessListApiPayload = {
  items?: Array<{
    processCode?: string;
    name?: string;
    menuProcessCode?: string;
  }>;
};

/** `GET .../processes` — catálogo activo (diseñador + Emitir). No exige emission.design. */
export async function getEmissionProcesses(): Promise<
  ApiClientResult<{ items: EmissionProcessListItem[] }>
> {
  const result = await apiRequest<ProcessListApiPayload>(`${emissionsBasePath}/processes`, {
    method: 'GET',
  });
  if (result.kind !== 'ok') {
    return result;
  }
  const items = (result.envelope.resultado.items ?? [])
    .map((item) => ({
      processCode: String(item.processCode ?? ''),
      name: String(item.name ?? item.processCode ?? ''),
      menuProcessCode: item.menuProcessCode ? String(item.menuProcessCode) : undefined,
    }))
    .filter((item) => item.processCode !== '');
  return {
    ...result,
    envelope: {
      ...result.envelope,
      resultado: { items },
    },
  };
}
