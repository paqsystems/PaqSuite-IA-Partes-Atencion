import { afterEach, describe, expect, it, vi } from 'vitest';
import type { EmissionJobDto } from './types';

const { downloadBlobMock, printPdfBlobMock, downloadEmissionJobMock } = vi.hoisted(() => ({
  downloadBlobMock: vi.fn(),
  printPdfBlobMock: vi.fn(),
  downloadEmissionJobMock: vi.fn(),
}));

vi.mock('../excelImport/downloadBlob', () => ({
  downloadBlob: downloadBlobMock,
}));

vi.mock('./printPdfBlob', () => ({
  printPdfBlob: printPdfBlobMock,
}));

vi.mock('./emissionApiClient', () => ({
  downloadEmissionJob: downloadEmissionJobMock,
}));

import { deliverEmissionJobArtifact, emissionJobFileName } from './deliverEmissionJobArtifact';

function job(patch: Partial<EmissionJobDto> = {}): EmissionJobDto {
  return {
    jobId: 'job-1',
    processCode: 'p',
    status: 'done',
    mode: 'consolidated',
    channel: 'pdf',
    fileName: 'consulta.pdf',
    messageKey: null,
    ...patch,
  };
}

describe('deliverEmissionJobArtifact', () => {
  afterEach(() => {
    downloadBlobMock.mockReset();
    printPdfBlobMock.mockReset();
    downloadEmissionJobMock.mockReset();
  });

  it('pdf complete descarga con downloadBlob', async () => {
    const blob = new Blob(['x'], { type: 'application/pdf' });
    downloadEmissionJobMock.mockResolvedValue({ kind: 'ok', blob });
    const errorKey = await deliverEmissionJobArtifact({
      job: job(),
      trigger: 'complete',
      isNative: false,
    });
    expect(errorKey).toBeNull();
    expect(downloadBlobMock).toHaveBeenCalledWith(blob, 'consulta.pdf');
    expect(printPdfBlobMock).not.toHaveBeenCalled();
  });

  it('print complete en web abre diálogo de impresión y no descarga', async () => {
    const blob = new Blob(['x'], { type: 'application/pdf' });
    downloadEmissionJobMock.mockResolvedValue({ kind: 'ok', blob });
    await deliverEmissionJobArtifact({
      job: job({ channel: 'print', fileName: 'consulta.pdf' }),
      trigger: 'complete',
      isNative: false,
    });
    expect(printPdfBlobMock).toHaveBeenCalledWith(blob);
    expect(downloadBlobMock).not.toHaveBeenCalled();
  });

  it('print download guarda el PDF', async () => {
    const blob = new Blob(['x'], { type: 'application/pdf' });
    downloadEmissionJobMock.mockResolvedValue({ kind: 'ok', blob });
    await deliverEmissionJobArtifact({
      job: job({ channel: 'print', fileName: 'consulta.pdf' }),
      trigger: 'download',
      isNative: false,
    });
    expect(downloadBlobMock).toHaveBeenCalledWith(blob, 'consulta.pdf');
    expect(printPdfBlobMock).not.toHaveBeenCalled();
  });

  it('native print no llama print de escritorio; descarga el PDF', async () => {
    const blob = new Blob(['x'], { type: 'application/pdf' });
    downloadEmissionJobMock.mockResolvedValue({ kind: 'ok', blob });
    await deliverEmissionJobArtifact({
      job: job({ channel: 'print' }),
      trigger: 'complete',
      isNative: true,
    });
    expect(printPdfBlobMock).not.toHaveBeenCalled();
    expect(downloadBlobMock).toHaveBeenCalled();
  });

  it('mail no descarga', async () => {
    const errorKey = await deliverEmissionJobArtifact({
      job: job({ channel: 'mail' }),
      trigger: 'complete',
      isNative: false,
    });
    expect(errorKey).toBeNull();
    expect(downloadEmissionJobMock).not.toHaveBeenCalled();
    expect(downloadBlobMock).not.toHaveBeenCalled();
  });

  it('excel sin fileName usa extensión .xlsx', () => {
    expect(emissionJobFileName(job({ channel: 'excel', fileName: null }))).toBe('emission-job-1.xlsx');
    expect(emissionJobFileName(job({ channel: 'csv', fileName: null }))).toBe('emission-job-1.csv');
  });
});
