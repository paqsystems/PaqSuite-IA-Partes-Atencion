/** Abre el diálogo de impresión del navegador para un PDF (canal `print`, C1-15-11). */
export function printPdfBlob(blob: Blob): void {
  if (typeof document === 'undefined' || typeof URL === 'undefined') {
    return;
  }
  const objectUrl = URL.createObjectURL(blob);
  const iframe = document.createElement('iframe');
  iframe.setAttribute('data-testid', 'emission.printFrame');
  iframe.setAttribute('title', 'emission.print');
  iframe.style.position = 'fixed';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  iframe.src = objectUrl;
  iframe.addEventListener('load', () => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } finally {
      window.setTimeout(() => {
        iframe.remove();
        URL.revokeObjectURL(objectUrl);
      }, 1000);
    }
  });
  document.body.appendChild(iframe);
}
