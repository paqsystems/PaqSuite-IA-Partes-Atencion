import { useEffect, useMemo, useRef, useState } from 'react';
import Popup from 'devextreme-react/popup';
import Button from 'devextreme-react/button';
import SelectBox from 'devextreme-react/select-box';
import TagBox from 'devextreme-react/tag-box';
import CheckBox from 'devextreme-react/check-box';
import TextBox from 'devextreme-react/text-box';
import LoadPanel from 'devextreme-react/load-panel';
import { useEmission } from './useEmission';
import { shouldOfferPreview } from './emissionPolicy';
import { deliverEmissionJobArtifact } from './deliverEmissionJobArtifact';
import { EmissionGrupoEmpresarioSelect } from '../gruposEmpresarios/EmissionGrupoEmpresarioSelect';
import type {
  EmissionCompletePayload,
  EmissionDocumentaryChannel,
  EmissionMode,
  EmissionRecipientDraft,
} from './types';
import { isDocumentaryChannel } from './types';

export type EmissionDialogProps = {
  processCode: string;
  /** Contrato C1 (preferido). */
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  /** Alias legacy smoke 2026-07. */
  visible?: boolean;
  onClose?: () => void;
  isNative?: boolean;
  disabled?: boolean;
  /** GEN-23: host decide si monta selector de grupo. */
  permiteConsolidado?: boolean;
  onComplete?: (payload: EmissionCompletePayload) => void;
  t?: (key: string) => string;
};

/**
 * Ventana Emitir (GEN-15) 100 % DevExtreme.
 * N salidas documentales + canales comunicación (bridge servidor); native sin preview.
 */
export function EmissionDialog({
  processCode,
  open,
  onOpenChange,
  visible,
  onClose,
  isNative = false,
  disabled = false,
  permiteConsolidado = false,
  onComplete,
  t,
}: EmissionDialogProps) {
  const translate = t ?? ((key: string) => key);
  const isOpen = open ?? visible ?? false;
  const handleClose = () => {
    onOpenChange?.(false);
    onClose?.();
  };

  const emission = useEmission({ processCode, isNative, onComplete });
  const recipientEditMode = emission.process?.outputPolicy.recipientEditMode ?? null;
  const [deliveryErrorKey, setDeliveryErrorKey] = useState<string | null>(null);
  const deliveredJobIds = useRef(new Set<string>());

  const modeItems = useMemo(() => {
    const modes: EmissionMode[] = [];
    if (emission.process?.modes.consolidated) {
      modes.push('consolidated');
    }
    if (emission.process?.modes.segmented) {
      modes.push('segmented');
    }
    return modes.map((id) => ({
      id,
      label: translate(`emission.mode.${id}`),
    }));
  }, [emission.process, translate]);

  const offerPreview = emission.process
    ? shouldOfferPreview(emission.process, isNative)
    : false;

  useEffect(() => {
    const terminalJobs = emission.jobs.filter((job) => job.status === 'done');
    for (const job of terminalJobs) {
      if (deliveredJobIds.current.has(job.jobId)) {
        continue;
      }
      deliveredJobIds.current.add(job.jobId);
      void deliverEmissionJobArtifact({ job, trigger: 'complete', isNative }).then((errorKey) => {
        if (errorKey) {
          setDeliveryErrorKey(errorKey);
        }
      });
    }
  }, [emission.jobs, isNative]);

  const handleDownload = () => {
    if (
      !emission.job ||
      (emission.job.status !== 'done' && emission.job.status !== 'failedCommunication')
    ) {
      return;
    }
    void deliverEmissionJobArtifact({
      job: emission.job,
      trigger: 'download',
      isNative,
    }).then((errorKey) => {
      setDeliveryErrorKey(errorKey);
    });
  };

  const toggleDocumentary = (channel: string, checked: boolean) => {
    if (!isDocumentaryChannel(channel)) {
      return;
    }
    const next = checked
      ? Array.from(new Set([...emission.selection.channels, channel]))
      : emission.selection.channels.filter((item) => item !== channel);
    emission.setSelection({ channels: next as EmissionDocumentaryChannel[] });
  };

  const toggleCommunication = (channel: string, checked: boolean) => {
    const next = checked
      ? Array.from(new Set([...emission.selection.communicationChannels, channel]))
      : emission.selection.communicationChannels.filter((item) => item !== channel);
    emission.setSelection({ communicationChannels: next });
  };

  const addRecipientAddress = (address: string) => {
    if (recipientEditMode === 'NOT_EDITABLE' || !address.trim()) {
      return;
    }
    const next: EmissionRecipientDraft[] = [
      ...emission.selection.recipients,
      { address: address.trim(), role: 'TO' },
    ];
    emission.setSelection({ recipients: next });
  };

  return (
    <Popup
      visible={isOpen}
      onHiding={handleClose}
      showTitle
      title={translate('emission.dialog.title')}
      width={isNative ? '100%' : 820}
      height="auto"
      wrapperAttr={{ 'data-testid': 'emission.dialog' }}
    >
      <LoadPanel visible={emission.loading || emission.submitting} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div data-testid="emission.output">
          <p>{translate('emission.outputs.documentary')}</p>
          {emission.documentaryChannelItems.map((channel) => (
            <CheckBox
              key={channel}
              text={translate(`notificationService.channel.${channel}`)}
              value={emission.selection.channels.includes(channel as EmissionDocumentaryChannel)}
              disabled={disabled}
              onValueChanged={(event) => toggleDocumentary(channel, Boolean(event.value))}
              elementAttr={{ 'data-testid': `emission.channel.${channel}` }}
            />
          ))}
        </div>

        {emission.communicationChannelItems.length > 0 ? (
          <div data-testid="emission.communication">
            <p>{translate('emission.outputs.communication')}</p>
            {emission.communicationChannelItems.map((channel) => (
              <CheckBox
                key={channel}
                text={translate(`notificationService.channel.${channel}`)}
                value={emission.selection.communicationChannels.includes(channel)}
                disabled={disabled}
                onValueChanged={(event) => toggleCommunication(channel, Boolean(event.value))}
                elementAttr={{ 'data-testid': `emission.channel.${channel}` }}
              />
            ))}
          </div>
        ) : null}

        {modeItems.length > 1 ? (
          <SelectBox
            items={modeItems}
            valueExpr="id"
            displayExpr="label"
            value={emission.selection.mode}
            onValueChanged={(event) =>
              emission.setSelection({ mode: (event.value as EmissionMode) ?? 'consolidated' })
            }
            elementAttr={{ 'data-testid': 'emission.mode' }}
          />
        ) : null}

        <EmissionGrupoEmpresarioSelect
          enabled={permiteConsolidado}
          value={emission.selection.grupoEmpresarioId ?? null}
          onValueChange={(grupoEmpresarioId) => emission.setSelection({ grupoEmpresarioId })}
          t={translate}
        />

        {emission.process && emission.process.reports.length > 0 ? (
          <SelectBox
            items={emission.process.reports}
            valueExpr="id"
            displayExpr="name"
            value={emission.selection.reportId ?? null}
            placeholder={translate('emission.report')}
            onValueChanged={(event) =>
              emission.setSelection({ reportId: (event.value as number) ?? undefined })
            }
            elementAttr={{ 'data-testid': 'emission.report' }}
          />
        ) : null}

        {recipientEditMode && recipientEditMode !== 'NOT_EDITABLE' ? (
          <div data-testid="emission.recipients">
            <TagBox
              items={emission.selection.recipients.map((item) => item.address).filter(Boolean)}
              value={emission.selection.recipients.map((item) => item.address).filter(Boolean)}
              acceptCustomValue
              onCustomItemCreating={(event) => {
                const text = String(event.text ?? '');
                addRecipientAddress(text);
                event.customItem = text;
              }}
              onValueChanged={(event) => {
                const addresses = (event.value as string[]) ?? [];
                emission.setSelection({
                  recipients: addresses.map((address) => ({ address, role: 'TO' as const })),
                });
              }}
              disabled={disabled}
              elementAttr={{ 'data-testid': 'emission.recipients.tagbox' }}
            />
            {recipientEditMode === 'ADD_ONLY' ? (
              <p data-i18n-key="emission.recipients.addOnlyHint">
                {translate('emission.recipients.addOnlyHint')}
              </p>
            ) : null}
          </div>
        ) : null}

        {recipientEditMode === 'FULL_EDIT' && emission.selection.communicationChannels.length > 0 ? (
          <TextBox
            placeholder={translate('emission.recipients.add')}
            onEnterKey={(event) => {
              const value = String(event.component.option('value') ?? '');
              addRecipientAddress(value);
              event.component.option('value', '');
            }}
            elementAttr={{ 'data-testid': 'emission.recipients.input' }}
          />
        ) : null}

        {offerPreview ? (
          <div data-testid="emission.previewArea">
            <Button
              text={translate('emission.preview')}
              icon="find"
              disabled={emission.selection.channels.length === 0 || disabled}
              onClick={() => void emission.runPreview()}
              elementAttr={{ 'data-testid': 'emission.preview' }}
            />
            {emission.preview && !emission.previewStale ? (
              <iframe
                title={translate('emission.preview')}
                src={
                  emission.preview.contentUrl ??
                  (emission.preview.contentBase64
                    ? `data:${emission.preview.mimeType};base64,${emission.preview.contentBase64}`
                    : undefined)
                }
                style={{ width: '100%', height: 420, border: '1px solid #ddd', marginTop: 8 }}
                data-testid="emission.previewFrame"
              />
            ) : null}
            {emission.preview && emission.previewStale ? (
              <p data-i18n-key="emission.preview.stale">{translate('emission.preview.stale')}</p>
            ) : null}
          </div>
        ) : null}

        {emission.errorKey ? (
          <p data-i18n-key={emission.errorKey}>{translate(emission.errorKey)}</p>
        ) : null}
        {deliveryErrorKey ? (
          <p data-testid="emission.deliveryError" data-i18n-key={deliveryErrorKey}>
            {translate(deliveryErrorKey)}
          </p>
        ) : null}

        {emission.job &&
        (emission.job.status === 'done' || emission.job.status === 'failedCommunication') ? (
          <Button
            text={translate('emission.download')}
            icon="download"
            onClick={handleDownload}
            elementAttr={{ 'data-testid': 'emission.download' }}
          />
        ) : null}

        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <Button
            text={translate('emission.close')}
            onClick={handleClose}
            elementAttr={{ 'data-testid': 'emission.close' }}
          />
          <Button
            text={translate('emission.submit')}
            type="default"
            stylingMode="contained"
            disabled={disabled || !emission.canEmit || emission.submitting}
            onClick={() => void emission.emit()}
            elementAttr={{ 'data-testid': 'emission.submit' }}
          />
        </div>
      </div>
    </Popup>
  );
}
