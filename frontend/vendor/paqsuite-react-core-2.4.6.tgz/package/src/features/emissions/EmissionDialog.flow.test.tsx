/**
 * @vitest-environment jsdom
 *
 * Batería Emitir GEN-15 (`EmissionDialog` + `useEmission`).
 * El PDF real / sidecar y el botón de la consulta son del host (Partes).
 */
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { ComponentProps } from 'react';
import type { ApiClientResult } from '../../http/apiClient';
import type { EmissionCompletePayload, EmissionJobCreateRequest, EmissionProcessDto } from './types';

const { api, envelopeOk, envelopeError, PROCESS_CODE, PRINCIPAL_ID, ALT_ID, downloadBlobMock, printPdfBlobMock } =
  vi.hoisted(() => {
  const PROCESS_CODE = 'partes.informes.consultaDetallada';
  const PRINCIPAL_ID = 11;
  const ALT_ID = 12;

  function envelopeOk<T>(resultado: T): ApiClientResult<T> {
    return {
      kind: 'ok',
      httpStatus: 200,
      envelope: { error: 0, respuesta: 'ok', resultado },
    };
  }

  function envelopeError(error: number): ApiClientResult<never> {
    return {
      kind: 'envelopeError',
      httpStatus: 403,
      envelope: { error, respuesta: 'forbidden', resultado: {} },
    };
  }

  const api = {
    requiresPreview: false,
    failJob: false as false | number,
    lastJobRequest: null as EmissionJobCreateRequest | null,
    lastPreviewRequest: null as EmissionJobCreateRequest | null,
    downloadCalls: [] as string[],
    downloadResult: { kind: 'ok' as const, blob: new Blob(['pdf'], { type: 'application/pdf' }) } as
      | { kind: 'ok'; blob: Blob }
      | { kind: 'error'; i18nKey: string },
    modes: { consolidated: true, segmented: false },
    channels: ['pdf', 'excel'] as string[],
    reset(): void {
      api.requiresPreview = false;
      api.failJob = false;
      api.lastJobRequest = null;
      api.lastPreviewRequest = null;
      api.downloadCalls = [];
      api.downloadResult = { kind: 'ok', blob: new Blob(['pdf'], { type: 'application/pdf' }) };
      api.modes = { consolidated: true, segmented: false };
      api.channels = ['pdf', 'excel'];
    },
    processDto(): EmissionProcessDto {
      return {
        processCode: PROCESS_CODE,
        channels: api.channels,
        modes: api.modes,
        requiresPreview: api.requiresPreview,
        menuProcessCode: 'partes_consulta',
        reports: [
          {
            id: PRINCIPAL_ID,
            code: 'partes.consultaDetallada.principal',
            name: 'Principal',
            isPrincipal: true,
          },
          {
            id: ALT_ID,
            code: 'partes.consultaDetallada.alt',
            name: 'Alternativo',
            isPrincipal: false,
          },
        ],
        outputPolicy: {
          mode: 'INTERACTIVE',
          outputs: api.channels.map((channel) => ({
            channel,
            kind: 'documentary' as const,
            mandatory: false,
            automatic: false,
            blocking: true,
          })),
        },
      };
    },
  };

  const downloadBlobMock = vi.fn();
  const printPdfBlobMock = vi.fn();

  return {
    api,
    envelopeOk,
    envelopeError,
    PROCESS_CODE,
    PRINCIPAL_ID,
    ALT_ID,
    downloadBlobMock,
    printPdfBlobMock,
  };
});

vi.mock('../excelImport/downloadBlob', () => ({
  downloadBlob: downloadBlobMock,
}));

vi.mock('./printPdfBlob', () => ({
  printPdfBlob: printPdfBlobMock,
}));

vi.mock('./emissionApiClient', () => ({
  emissionsBasePath: '/api/v1/emissions',
  getEmissionProcess: async () => envelopeOk(api.processDto()),
  createEmissionPreview: async (request: EmissionJobCreateRequest) => {
    api.lastPreviewRequest = request;
    return envelopeOk({
      previewSessionId: 'preview-1',
      contentUrl: 'https://example.test/preview.pdf',
      mimeType: 'application/pdf',
      expiresAt: '2099-01-01T00:00:00Z',
    });
  },
  createEmissionJob: async (request: EmissionJobCreateRequest) => {
    api.lastJobRequest = request;
    if (api.failJob !== false) {
      return envelopeError(api.failJob);
    }
    return envelopeOk({
      jobId: 'job-1',
      processCode: request.processCode,
      status: 'done' as const,
      mode: request.mode,
      channel: request.channel,
      fileName: 'consulta.pdf',
      messageKey: null,
    });
  },
  getEmissionJob: async (jobId: string) =>
    envelopeOk({
      jobId,
      processCode: PROCESS_CODE,
      status: 'done' as const,
      mode: 'consolidated' as const,
      channel: 'pdf',
      fileName: 'consulta.pdf',
      messageKey: null,
    }),
  downloadEmissionJob: async (jobId: string) => {
    api.downloadCalls.push(jobId);
    return api.downloadResult;
  },
}));

vi.mock('../gruposEmpresarios/EmissionGrupoEmpresarioSelect', () => ({
  EmissionGrupoEmpresarioSelect: () => null,
}));

vi.mock('devextreme-react/load-panel', () => ({
  default: () => null,
}));

vi.mock('devextreme-react/popup', () => ({
  default: (props: {
    visible?: boolean;
    wrapperAttr?: Record<string, string>;
    children?: React.ReactNode;
  }) =>
    props.visible ? (
      <div data-testid={props.wrapperAttr?.['data-testid']}>{props.children}</div>
    ) : null,
}));

vi.mock('devextreme-react/button', () => ({
  default: (props: {
    text?: string;
    disabled?: boolean;
    onClick?: () => void;
    elementAttr?: Record<string, string>;
  }) => (
    <button
      type="button"
      data-testid={props.elementAttr?.['data-testid']}
      disabled={props.disabled === true}
      onClick={props.onClick}
    >
      {props.text}
    </button>
  ),
}));

vi.mock('devextreme-react/check-box', () => ({
  default: (props: {
    text?: string;
    value?: boolean;
    disabled?: boolean;
    onValueChanged?: (event: { value: boolean }) => void;
    elementAttr?: Record<string, string>;
  }) => (
    <label data-testid={props.elementAttr?.['data-testid']}>
      <input
        type="checkbox"
        checked={props.value === true}
        disabled={props.disabled === true}
        onChange={(event) => props.onValueChanged?.({ value: event.target.checked })}
      />
      {props.text}
    </label>
  ),
}));

type SelectItem = Record<string, unknown>;

vi.mock('devextreme-react/select-box', () => ({
  default: (props: {
    items?: SelectItem[] | string[];
    valueExpr?: string;
    displayExpr?: string;
    value?: string | number | null;
    onValueChanged?: (event: { value: string | number | null }) => void;
    elementAttr?: Record<string, string>;
  }) => {
    const testId = props.elementAttr?.['data-testid'] ?? 'select';
    const valueExpr = props.valueExpr;
    const items = props.items ?? [];
    const codes =
      testId === 'emission.report'
        ? (items as SelectItem[]).map((item) => String(item.id ?? '')).join('|')
        : undefined;

    return (
      <select
        data-testid={testId}
        data-report-ids={codes}
        value={props.value == null ? '' : String(props.value)}
        onChange={(event) => {
          const raw = event.target.value;
          if (raw === '') {
            props.onValueChanged?.({ value: null });
            return;
          }
          const firstItem = items[0];
          const numericIds =
            valueExpr === 'id' &&
            firstItem != null &&
            typeof firstItem !== 'string' &&
            typeof (firstItem as SelectItem).id === 'number';
          props.onValueChanged?.({
            value: numericIds ? Number(raw) : raw,
          });
        }}
      >
        <option value="" />
        {items.map((item) => {
          if (typeof item === 'string') {
            return (
              <option key={item} value={item}>
                {item}
              </option>
            );
          }
          const value = String(item[valueExpr ?? 'id'] ?? '');
          const label = String(item[props.displayExpr ?? 'name'] ?? value);
          return (
            <option key={value} value={value}>
              {label}
            </option>
          );
        })}
      </select>
    );
  },
}));

vi.mock('devextreme-react/tag-box', () => ({
  default: () => <div data-testid="emission.recipients.tagbox" />,
}));

vi.mock('devextreme-react/text-box', () => ({
  default: () => <input data-testid="emission.recipients.input" />,
}));

import { EmissionDialog } from './EmissionDialog';

function isSubmitEnabled(): boolean {
  return !(screen.getByTestId('emission.submit') as HTMLButtonElement).disabled;
}

function renderDialog(
  props?: Partial<ComponentProps<typeof EmissionDialog>> & {
    onComplete?: (payload: EmissionCompletePayload) => void;
  }
) {
  const onComplete = props?.onComplete ?? vi.fn();
  const onOpenChange = props?.onOpenChange ?? vi.fn();
  return {
    onComplete,
    onOpenChange,
    ...render(
      <EmissionDialog
        processCode={PROCESS_CODE}
        open
        onOpenChange={onOpenChange}
        onComplete={onComplete}
        {...props}
      />
    ),
  };
}

describe('EmissionDialog — flujo Emitir GEN-15', () => {
  beforeEach(() => {
    api.reset();
    downloadBlobMock.mockReset();
    printPdfBlobMock.mockReset();
  });

  afterEach(() => {
    cleanup();
  });

  it('carga el proceso de consulta, preselecciona PDF y el reporte principal', async () => {
    renderDialog();

    await waitFor(() => {
      expect(screen.getByTestId('emission.dialog')).toBeTruthy();
    });
    expect(screen.getByTestId('emission.channel.pdf')).toBeTruthy();
    await waitFor(() => {
      expect(screen.getByTestId('emission.report').getAttribute('data-report-ids')).toContain(
        String(PRINCIPAL_ID)
      );
    });
    expect((screen.getByTestId('emission.report') as HTMLSelectElement).value).toBe(String(PRINCIPAL_ID));
    await waitFor(() => {
      expect(isSubmitEnabled()).toBe(true);
    });
  });

  it('Emitir POST pdf con processCode, reportId principal y mode consolidated', async () => {
    const { onComplete } = renderDialog();

    await waitFor(() => {
      expect(isSubmitEnabled()).toBe(true);
    });
    fireEvent.click(screen.getByTestId('emission.submit'));

    await waitFor(() => {
      expect(api.lastJobRequest).not.toBeNull();
    });
    expect(api.lastJobRequest?.processCode).toBe(PROCESS_CODE);
    expect(api.lastJobRequest?.channel).toBe('pdf');
    expect(api.lastJobRequest?.mode).toBe('consolidated');
    expect(api.lastJobRequest?.reportId).toBe(PRINCIPAL_ID);
    expect(api.lastJobRequest?.mobile).toBe(false);

    await waitFor(() => {
      expect(onComplete).toHaveBeenCalled();
    });
    const payload = (onComplete as ReturnType<typeof vi.fn>).mock.calls[0][0] as EmissionCompletePayload;
    expect(payload.jobId).toBe('job-1');
    expect(payload.status).toBe('done');
    expect(payload.outputCode).toBe('pdf');
    expect(screen.getByTestId('emission.download')).toBeTruthy();
    await waitFor(() => {
      expect(downloadBlobMock).toHaveBeenCalled();
    });
    expect(downloadBlobMock.mock.calls[0][1]).toBe('consulta.pdf');
    expect(api.downloadCalls).toContain('job-1');
  });

  it('al elegir otro reporte el POST lleva ese reportId', async () => {
    renderDialog();

    await waitFor(() => {
      expect((screen.getByTestId('emission.report') as HTMLSelectElement).value).toBe(String(PRINCIPAL_ID));
    });
    fireEvent.change(screen.getByTestId('emission.report'), { target: { value: String(ALT_ID) } });
    fireEvent.click(screen.getByTestId('emission.submit'));

    await waitFor(() => {
      expect(api.lastJobRequest?.reportId).toBe(ALT_ID);
    });
    expect(api.lastJobRequest?.processCode).toBe(PROCESS_CODE);
  });

  it('con requiresPreview: no emite hasta preview; el job lleva previewSessionId', async () => {
    api.requiresPreview = true;
    renderDialog();

    await waitFor(() => {
      expect(screen.getByTestId('emission.preview')).toBeTruthy();
    });
    expect(isSubmitEnabled()).toBe(false);

    fireEvent.click(screen.getByTestId('emission.preview'));
    await waitFor(() => {
      expect(api.lastPreviewRequest?.processCode).toBe(PROCESS_CODE);
    });
    expect(api.lastPreviewRequest?.reportId).toBe(PRINCIPAL_ID);
    await waitFor(() => {
      expect(screen.getByTestId('emission.previewFrame')).toBeTruthy();
    });
    expect(isSubmitEnabled()).toBe(true);

    fireEvent.click(screen.getByTestId('emission.submit'));
    await waitFor(() => {
      expect(api.lastJobRequest?.previewSessionId).toBe('preview-1');
    });
  });

  it('native no ofrece preview y emite con mobile=true', async () => {
    renderDialog({ isNative: true });

    await waitFor(() => {
      expect(isSubmitEnabled()).toBe(true);
    });
    expect(screen.queryByTestId('emission.preview')).toBeNull();
    fireEvent.click(screen.getByTestId('emission.submit'));
    await waitFor(() => {
      expect(api.lastJobRequest?.mobile).toBe(true);
    });
    expect(api.lastJobRequest?.previewSessionId).toBeNull();
  });

  it('error de envelope se muestra y no llama onComplete', async () => {
    api.failJob = 4703;
    const { onComplete } = renderDialog();

    await waitFor(() => {
      expect(isSubmitEnabled()).toBe(true);
    });
    fireEvent.click(screen.getByTestId('emission.submit'));

    await waitFor(() => {
      expect(screen.getByText('emission.error.4703')).toBeTruthy();
    });
    expect(onComplete).not.toHaveBeenCalled();
  });

  it('Cerrar notifica onOpenChange(false)', async () => {
    const { onOpenChange } = renderDialog();

    await waitFor(() => {
      expect(screen.getByTestId('emission.close')).toBeTruthy();
    });
    fireEvent.click(screen.getByTestId('emission.close'));
    expect(onOpenChange).toHaveBeenCalledWith(false);
  });

  it('con un solo modo no monta emission.mode', async () => {
    renderDialog();

    await waitFor(() => {
      expect(isSubmitEnabled()).toBe(true);
    });
    expect(screen.queryByTestId('emission.mode')).toBeNull();
  });

  it('con consolidado y segmentado monta emission.mode y permite cambiarlo', async () => {
    api.modes = { consolidated: true, segmented: true };
    renderDialog();

    await waitFor(() => {
      expect(screen.getByTestId('emission.mode')).toBeTruthy();
    });
    const modeSelect = screen.getByTestId('emission.mode') as HTMLSelectElement;
    expect(Array.from(modeSelect.options).map((option) => option.value)).toEqual(
      expect.arrayContaining(['consolidated', 'segmented'])
    );
    fireEvent.change(modeSelect, { target: { value: 'segmented' } });
    expect((screen.getByTestId('emission.mode') as HTMLSelectElement).value).toBe('segmented');
  });

  it('Descargar reintenta la entrega del blob', async () => {
    renderDialog();

    await waitFor(() => {
      expect(isSubmitEnabled()).toBe(true);
    });
    fireEvent.click(screen.getByTestId('emission.submit'));
    await waitFor(() => {
      expect(screen.getByTestId('emission.download')).toBeTruthy();
    });
    await waitFor(() => {
      expect(downloadBlobMock).toHaveBeenCalledTimes(1);
    });
    fireEvent.click(screen.getByTestId('emission.download'));
    await waitFor(() => {
      expect(downloadBlobMock).toHaveBeenCalledTimes(2);
    });
  });

  it('job print done abre el diálogo de impresión y Descargar guarda el PDF', async () => {
    api.channels = ['print'];
    renderDialog();

    await waitFor(() => {
      expect(isSubmitEnabled()).toBe(true);
    });
    fireEvent.click(screen.getByTestId('emission.submit'));
    await waitFor(() => {
      expect(printPdfBlobMock).toHaveBeenCalledTimes(1);
    });
    expect(downloadBlobMock).not.toHaveBeenCalled();
    fireEvent.click(screen.getByTestId('emission.download'));
    await waitFor(() => {
      expect(downloadBlobMock).toHaveBeenCalledTimes(1);
    });
    expect(downloadBlobMock.mock.calls[0][1]).toBe('consulta.pdf');
  });

  it('si el download falla muestra emission.error.download y no guarda basura', async () => {
    api.downloadResult = { kind: 'error', i18nKey: 'emission.error.download' };
    renderDialog();

    await waitFor(() => {
      expect(isSubmitEnabled()).toBe(true);
    });
    fireEvent.click(screen.getByTestId('emission.submit'));
    await waitFor(() => {
      expect(screen.getByTestId('emission.download')).toBeTruthy();
    });
    fireEvent.click(screen.getByTestId('emission.download'));
    await waitFor(() => {
      expect(screen.getByTestId('emission.deliveryError')).toBeTruthy();
    });
    expect(screen.getByTestId('emission.deliveryError').textContent).toBe('emission.error.download');
    expect(downloadBlobMock).not.toHaveBeenCalled();
  });
});
