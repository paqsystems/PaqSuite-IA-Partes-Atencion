import { afterEach, describe, expect, it, vi } from 'vitest';
import { downloadEmissionJob } from './emissionApiClient';

describe('downloadEmissionJob', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('GET con Accept application/octet-stream y blob OK', async () => {
    const blob = new Blob(['%PDF'], { type: 'application/pdf' });
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      headers: { get: () => 'application/pdf' },
      blob: async () => blob,
    });
    vi.stubGlobal('fetch', fetchMock);

    const result = await downloadEmissionJob('job-9');
    expect(result).toEqual({ kind: 'ok', blob });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(url).toContain('/emissions/jobs/job-9/download');
    expect((init.headers as Record<string, string>).Accept).toBe('application/octet-stream');
  });

  it('HTTP error no entrega blob', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: false,
        status: 500,
        headers: { get: () => 'application/json' },
        blob: async () => new Blob(['{}'], { type: 'application/json' }),
      })
    );
    const result = await downloadEmissionJob('job-9');
    expect(result).toEqual({ kind: 'error', i18nKey: 'emission.error.download' });
  });

  it('blob JSON o vacío es error', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        headers: { get: () => 'application/json' },
        blob: async () => new Blob(['{"error":1}'], { type: 'application/json' }),
      })
    );
    const result = await downloadEmissionJob('job-9');
    expect(result).toEqual({ kind: 'error', i18nKey: 'emission.error.download' });
  });
});
