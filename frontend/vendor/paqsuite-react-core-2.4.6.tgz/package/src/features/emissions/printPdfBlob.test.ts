/**
 * @vitest-environment jsdom
 */
import { afterEach, describe, expect, it, vi } from 'vitest';
import { printPdfBlob } from './printPdfBlob';

describe('printPdfBlob', () => {
  afterEach(() => {
    document.body.innerHTML = '';
    vi.restoreAllMocks();
  });

  it('monta un iframe y llama contentWindow.print', () => {
    const print = vi.fn();
    if (typeof URL.createObjectURL !== 'function') {
      URL.createObjectURL = () => 'blob:print-test';
    }
    if (typeof URL.revokeObjectURL !== 'function') {
      URL.revokeObjectURL = () => undefined;
    }
    vi.spyOn(URL, 'createObjectURL').mockReturnValue('blob:print-test');
    vi.spyOn(URL, 'revokeObjectURL').mockImplementation(() => undefined);

    printPdfBlob(new Blob(['%PDF'], { type: 'application/pdf' }));

    const iframe = document.querySelector('[data-testid="emission.printFrame"]') as HTMLIFrameElement;
    expect(iframe).toBeTruthy();
    Object.defineProperty(iframe, 'contentWindow', {
      value: { focus: vi.fn(), print },
      configurable: true,
    });
    iframe.dispatchEvent(new Event('load'));
    expect(print).toHaveBeenCalled();
  });
});
