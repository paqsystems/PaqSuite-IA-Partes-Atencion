import { describe, expect, it } from 'vitest';
import { parseDxReportSavedArgs } from './parseDxReportSavedArgs';

describe('parseDxReportSavedArgs', () => {
  it('lee Url y serialize del objeto único', () => {
    const parsed = parseDxReportSavedArgs({
      Url: 'Nuevo diseño',
      Report: { serialize: () => '<XtraReportsLayoutSerializer/>' },
    });
    expect(parsed.url).toBe('Nuevo diseño');
    expect(parsed.layoutDefinition).toBe('<XtraReportsLayoutSerializer/>');
  });

  it('lee el segundo argumento estilo sender, args', () => {
    const parsed = parseDxReportSavedArgs([
      { sender: true },
      { url: 'Alt.v2', report: { serialize: () => '<xml/>' } },
    ]);
    expect(parsed.url).toBe('Alt.v2');
    expect(parsed.layoutDefinition).toBe('<xml/>');
  });

  it('lee el envelope React 26.1 { sender, args: { Url, Report }, component }', () => {
    const parsed = parseDxReportSavedArgs([
      {
        sender: { name: 'designer' },
        args: {
          Url: 'partes.consultaDetallada.alt',
          Report: { serialize: () => '<XtraReportsLayoutSerializer/>' },
        },
        component: {},
      },
    ]);
    expect(parsed.url).toBe('partes.consultaDetallada.alt');
    expect(parsed.layoutDefinition).toBe('<XtraReportsLayoutSerializer/>');
  });

  it('unwrap Url si es función', () => {
    const parsed = parseDxReportSavedArgs({
      Url: () => 'via-fn',
      Report: { serialize: () => '<xml/>' },
    });
    expect(parsed.url).toBe('via-fn');
  });

  it('unwrap Url si es KO observable (peek)', () => {
    const parsed = parseDxReportSavedArgs({
      Url: { peek: () => 'via-peek' },
      Report: { serialize: () => '<xml/>' },
    });
    expect(parsed.url).toBe('via-peek');
  });

  it('no entra en ciclo si args se apunta a sí mismo', () => {
    const circular: { Args: unknown; Url?: string } = { Args: null };
    circular.Args = circular;
    const parsed = parseDxReportSavedArgs(circular);
    expect(parsed.url).toBe('');
  });

  it('sin Url deja url vacía para que el host muestre emission.design.saveAsFailed', () => {
    const parsed = parseDxReportSavedArgs({ sender: {}, args: { Report: {} }, component: {} });
    expect(parsed.url).toBe('');
    expect(parsed.layoutDefinition).toBeUndefined();
  });
});
