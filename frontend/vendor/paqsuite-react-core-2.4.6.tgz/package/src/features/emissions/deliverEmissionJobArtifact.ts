import { downloadBlob } from '../excelImport/downloadBlob';
import { downloadEmissionJob } from './emissionApiClient';
import { printPdfBlob } from './printPdfBlob';
import type { EmissionJobDto } from './types';

const channelExtensions: Record<string, string> = {
  pdf: 'pdf',
  print: 'pdf',
  excel: 'xlsx',
  csv: 'csv',
  zip: 'zip',
};

export function emissionJobFileName(job: EmissionJobDto): string {
  const named = job.fileName?.trim();
  if (named) {
    return named;
  }
  const extension = channelExtensions[job.channel] ?? 'bin';
  return `emission-${job.jobId}.${extension}`;
}

export type DeliverEmissionTrigger = 'complete' | 'download';

/**
 * Entrega el artefacto del job: descarga en el navegador, o diálogo de impresión
 * si el canal es `print` y el trigger es complete (web). Mail no descarga.
 */
export async function deliverEmissionJobArtifact(options: {
  job: EmissionJobDto;
  trigger: DeliverEmissionTrigger;
  isNative: boolean;
}): Promise<string | null> {
  const { job, trigger, isNative } = options;
  if (job.channel === 'mail') {
    return null;
  }
  if (trigger === 'complete' && job.status !== 'done') {
    return null;
  }

  const result = await downloadEmissionJob(job.jobId);
  if (result.kind !== 'ok') {
    return result.i18nKey;
  }

  if (trigger === 'complete' && job.channel === 'print' && !isNative) {
    printPdfBlob(result.blob);
    return null;
  }

  downloadBlob(result.blob, emissionJobFileName(job));
  return null;
}
