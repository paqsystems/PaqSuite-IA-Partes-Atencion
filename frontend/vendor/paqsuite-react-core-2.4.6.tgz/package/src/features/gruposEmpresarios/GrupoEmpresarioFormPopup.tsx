import { useEffect, useState } from 'react';
import Popup from 'devextreme-react/popup';
import TextBox from 'devextreme-react/text-box';
import Switch from 'devextreme-react/switch';
import Button from 'devextreme-react/button';
import {
  createGrupoEmpresario,
  getGrupoEmpresario,
  updateGrupoEmpresario,
} from './gruposEmpresariosApi';
import { GruposEmpresariosMembersGrid, type MemberEmpresaRow } from './GruposEmpresariosMembersGrid';
import type { GrupoEmpresarioListItem } from './types';

export type GrupoEmpresarioFormPopupProps = {
  visible: boolean;
  mode: 'create' | 'edit';
  initial?: GrupoEmpresarioListItem | null;
  empresas: MemberEmpresaRow[];
  onCancel: () => void;
  onSaved: () => void;
  t?: (key: string) => string;
};

export function GrupoEmpresarioFormPopup({
  visible,
  mode,
  initial,
  empresas,
  onCancel,
  onSaved,
  t,
}: GrupoEmpresarioFormPopupProps) {
  const translate = t ?? ((key: string) => key);
  const [nombre, setNombre] = useState('');
  const [activo, setActivo] = useState(true);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [saving, setSaving] = useState(false);
  const [errorKey, setErrorKey] = useState<string | null>(null);

  useEffect(() => {
    if (!visible) {
      return;
    }
    setErrorKey(null);
    setNombre(initial?.nombre ?? '');
    setActivo(initial?.activo ?? true);
    setSelectedIds([]);

    if (mode === 'edit' && initial) {
      void getGrupoEmpresario(initial.id).then((result) => {
        if (result.kind === 'ok') {
          setNombre(result.envelope.resultado.item.nombre);
          setActivo(result.envelope.resultado.item.activo);
          setSelectedIds(result.envelope.resultado.item.miembros.map((m) => m.id));
        }
      });
    }
  }, [visible, mode, initial]);

  const handleSave = async () => {
    setErrorKey(null);
    if (nombre.trim() === '') {
      setErrorKey('gruposEmpresarios.validation.nameRequired');
      return;
    }
    if (selectedIds.length < 1) {
      setErrorKey('gruposEmpresarios.validation.minMembers');
      return;
    }

    setSaving(true);
    const body = { nombre: nombre.trim(), activo, miembroIds: selectedIds };
    const result =
      mode === 'create'
        ? await createGrupoEmpresario(body)
        : await updateGrupoEmpresario(initial!.id, body);
    setSaving(false);

    if (result.kind === 'ok') {
      onSaved();
      return;
    }
    setErrorKey(result.envelope.respuesta || 'gruposEmpresarios.loadError');
  };

  return (
    <Popup
      visible={visible}
      onHiding={onCancel}
      showTitle
      title={translate('gruposEmpresarios.title')}
      width={720}
      height="auto"
    >
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <TextBox
          value={nombre}
          onValueChanged={(e) => setNombre(String(e.value ?? ''))}
          label={translate('gruposEmpresarios.form.nombre')}
          elementAttr={{ 'data-testid': 'gruposEmpresariosNombre' }}
        />
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span>{translate('gruposEmpresarios.form.activo')}</span>
          <Switch
            value={activo}
            onValueChanged={(e) => setActivo(Boolean(e.value))}
            elementAttr={{ 'data-testid': 'gruposEmpresariosActivo' }}
          />
        </div>
        <GruposEmpresariosMembersGrid
          rows={empresas}
          selectedIds={selectedIds}
          onSelectionChange={setSelectedIds}
          t={translate}
        />
        {errorKey ? <div role="alert">{translate(errorKey)}</div> : null}
        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <Button
            text={translate('gruposEmpresarios.form.cancel')}
            onClick={onCancel}
            elementAttr={{ 'data-testid': 'gruposEmpresariosCancel' }}
          />
          <Button
            text={translate('gruposEmpresarios.form.save')}
            type="default"
            disabled={saving}
            onClick={() => void handleSave()}
            elementAttr={{ 'data-testid': 'gruposEmpresariosSave' }}
          />
        </div>
      </div>
    </Popup>
  );
}
