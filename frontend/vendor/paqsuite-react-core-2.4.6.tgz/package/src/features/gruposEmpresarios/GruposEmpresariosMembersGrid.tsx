import DataGrid, {
  Column,
  FilterRow,
  Paging,
  Selection,
  Sorting,
} from 'devextreme-react/data-grid';

export type MemberEmpresaRow = {
  id: number;
  nombreEmpresa: string;
};

export type GruposEmpresariosMembersGridProps = {
  rows: MemberEmpresaRow[];
  selectedIds: number[];
  onSelectionChange: (ids: number[]) => void;
  t?: (key: string) => string;
};

/**
 * Grilla DX de miembros (tilde + nombre). Sin layouts/export/group/chooser/pie.
 */
export function GruposEmpresariosMembersGrid({
  rows,
  selectedIds,
  onSelectionChange,
  t,
}: GruposEmpresariosMembersGridProps) {
  const translate = t ?? ((key: string) => key);

  return (
    <div data-testid="gruposEmpresariosMembersGrid">
      <DataGrid
        dataSource={rows}
        keyExpr="id"
        showBorders
        hoverStateEnabled
        selectedRowKeys={selectedIds}
        onSelectionChanged={(event) => {
          const keys = (event.selectedRowKeys ?? []) as number[];
          onSelectionChange(keys.map((id) => Number(id)));
        }}
      >
        <Selection mode="multiple" showCheckBoxesMode="always" />
        <FilterRow visible />
        <Sorting mode="multiple" />
        <Paging defaultPageSize={20} />
        <Column
          dataField="nombreEmpresa"
          caption={translate('gruposEmpresarios.form.miembros')}
          allowSorting
          allowFiltering
        />
      </DataGrid>
    </div>
  );
}
