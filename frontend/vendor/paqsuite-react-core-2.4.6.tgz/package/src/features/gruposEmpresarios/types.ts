export type GrupoEmpresarioListItem = {
  id: number;
  nombre: string;
  cantidadMiembros: number;
  activo: boolean;
};

export type GrupoEmpresarioMiembro = {
  id: number;
  nombreEmpresa: string;
};

export type GrupoEmpresarioDetalle = GrupoEmpresarioListItem & {
  miembros: GrupoEmpresarioMiembro[];
};

export type GrupoEmpresarioUpsertBody = {
  nombre: string;
  activo?: boolean;
  miembroIds: number[];
};

export type GrupoEmpresarioOpcion = {
  id: number;
  nombre: string;
};

export type GrupoEmpresarioListResult = {
  items: GrupoEmpresarioListItem[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
};
