import { useEffect, useMemo, useState } from 'react';
import SelectBox from 'devextreme-react/select-box';
import { listGrupoEmpresarioOpciones } from './gruposEmpresariosApi';
import type { GrupoEmpresarioOpcion } from './types';

export type EmissionGrupoEmpresarioSelectProps = {
  value: number | null;
  onValueChange: (grupoEmpresarioId: number | null) => void;
  disabled?: boolean;
  /** Si false, no renderiza (C1-23-06 — prop host). */
  enabled?: boolean;
  t?: (key: string) => string;
};

const EMPRESA_ACTIVA_SENTINEL = 0;

/**
 * Selector de alcance por grupo en Emitir. No muta empresa activa del shell.
 * Con 0 opciones: visible y deshabilitado (C1-23-05).
 */
export function EmissionGrupoEmpresarioSelect({
  value,
  onValueChange,
  disabled = false,
  enabled = true,
  t,
}: EmissionGrupoEmpresarioSelectProps) {
  const translate = t ?? ((key: string) => key);
  const [opciones, setOpciones] = useState<GrupoEmpresarioOpcion[]>([]);
  const [loading, setLoading] = useState(false);
  const [errorKey, setErrorKey] = useState<string | null>(null);

  useEffect(() => {
    if (!enabled) {
      return;
    }
    let active = true;
    setLoading(true);
    void listGrupoEmpresarioOpciones().then((result) => {
      if (!active) {
        return;
      }
      setLoading(false);
      if (result.kind === 'ok') {
        setOpciones(result.envelope.resultado.items ?? []);
        setErrorKey(null);
      } else {
        setErrorKey(result.envelope.respuesta || 'gruposEmpresarios.emission.loadError');
      }
    });
    return () => {
      active = false;
    };
  }, [enabled]);

  const items = useMemo(
    () => [
      { id: EMPRESA_ACTIVA_SENTINEL, nombre: translate('gruposEmpresarios.emission.empresaActiva') },
      ...opciones,
    ],
    [opciones, translate]
  );

  if (!enabled) {
    return null;
  }

  const noOpciones = opciones.length === 0;
  const selectDisabled = disabled || loading || noOpciones;
  const selectValue = value ?? EMPRESA_ACTIVA_SENTINEL;

  return (
    <div>
      <SelectBox
        items={items}
        value={selectValue}
        valueExpr="id"
        displayExpr="nombre"
        searchEnabled={opciones.length > 8}
        disabled={selectDisabled}
        label={translate('gruposEmpresarios.emission.scopeLabel')}
        onValueChanged={(event) => {
          const next = Number(event.value);
          onValueChange(next === EMPRESA_ACTIVA_SENTINEL || Number.isNaN(next) ? null : next);
        }}
        elementAttr={{ 'data-testid': 'gruposEmpresariosEmissionSelect' }}
      />
      <span data-testid="gruposEmpresariosEmissionEmpresaActiva" style={{ display: 'none' }}>
        {selectValue === EMPRESA_ACTIVA_SENTINEL ? '1' : '0'}
      </span>
      {errorKey ? <div role="alert">{translate(errorKey)}</div> : null}
    </div>
  );
}
