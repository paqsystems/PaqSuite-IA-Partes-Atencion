import { describe, expect, it, vi } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import { ParametrosGeneralesPage } from './ParametrosGeneralesPage';

vi.mock('./parametrosApi', () => ({
  listParametros: vi.fn(async () => ({
    kind: 'ok',
    envelope: {
      error: 0,
      respuesta: 'ok',
      resultado: {
        items: [
          {
            programa: 'Auth',
            clave: 'MinutosWeb',
            tipoValor: 'I',
            valor: 60,
            caption: 'Inactividad web',
            tooltip: null,
          },
        ],
      },
    },
  })),
  patchParametro: vi.fn(),
}));

describe('ParametrosGeneralesPage', () => {
  it('expone testids y no monta export/layouts/chooser GEN-11', () => {
    const html = renderToStaticMarkup(<ParametrosGeneralesPage programa="Auth" />);

    expect(html).toContain('parametros.root');
    expect(html).toContain('parametros.grid');
    expect(html).toContain('parametros.refresh');
    expect(html).toContain('data-grid-id="parametros.Auth"');
    expect(html.toLowerCase()).not.toContain('export');
    expect(html.toLowerCase()).not.toContain('columnchooser');
    expect(html.toLowerCase()).not.toContain('grouppanel');
  });
});
