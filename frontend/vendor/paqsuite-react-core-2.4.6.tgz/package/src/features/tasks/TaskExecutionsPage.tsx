import { useCallback, useEffect, useState } from 'react';
import DataGrid, { Column, Paging, Pager } from 'devextreme-react/data-grid';
import Button from 'devextreme-react/button';
import Popup from 'devextreme-react/popup';
import { confirm } from 'devextreme/ui/dialog';
import {
  getTaskExecution,
  listTaskExecutions,
  purgeTaskExecutions,
} from './tasksClient';
import { resolveSemaphoreColor } from './semaphoreMap';
import type { TaskExecutionDto, TaskExecutionFilters } from './types';

export type TaskExecutionsPageProps = {
  filters?: TaskExecutionFilters;
  /** Muestra el botón Purgar (permiso admin del host). */
  canPurge?: boolean;
  t?: (key: string) => string;
};

/**
 * Monitor de ejecuciones (GEN-13): grilla DX + semáforo derivado en FE +
 * refresh + detalle en Popup + purga admin.
 */
export function TaskExecutionsPage({ filters, canPurge, t }: TaskExecutionsPageProps) {
  const translate = t ?? ((key: string) => key);
  const [rows, setRows] = useState<TaskExecutionDto[]>([]);
  const [detail, setDetail] = useState<TaskExecutionDto | null>(null);

  const load = useCallback(async () => {
    const result = await listTaskExecutions(filters);
    if (result.kind === 'ok') {
      setRows(result.envelope.resultado.items ?? []);
    }
  }, [filters]);

  useEffect(() => {
    void load();
  }, [load]);

  const openDetail = useCallback(async (id: number) => {
    const result = await getTaskExecution(id);
    if (result.kind === 'ok') {
      const payload = result.envelope.resultado as { item?: TaskExecutionDto } | TaskExecutionDto;
      const item =
        payload && typeof payload === 'object' && 'item' in payload
          ? payload.item ?? null
          : (payload as TaskExecutionDto);
      setDetail(item);
    }
  }, []);

  const handlePurge = useCallback(async () => {
    const confirmed = await confirm(
      translate('tareasProgramadas.ejecuciones.purgeConfirm'),
      translate('tareasProgramadas.ejecuciones.purgeTitle')
    );
    if (!confirmed) {
      return;
    }
    const result = await purgeTaskExecutions();
    if (result.kind === 'ok') {
      void load();
    }
  }, [load, translate]);

  return (
    <div data-testid="tareasProgramadas.ejecuciones.root">
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 12 }}>
        <h2>{translate('tareasProgramadas.ejecuciones.title')}</h2>
        <Button
          text={translate('tareasProgramadas.ejecuciones.refresh')}
          icon="refresh"
          onClick={() => void load()}
          elementAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.refresh' }}
        />
        {canPurge ? (
          <Button
            text={translate('tareasProgramadas.ejecuciones.purge')}
            onClick={() => void handlePurge()}
            elementAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.purge' }}
          />
        ) : null}
      </div>

      <DataGrid
        dataSource={rows}
        keyExpr="id"
        showBorders
        columnAutoWidth
        elementAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.grid' }}
        onRowClick={(event) => {
          const row = event.data as TaskExecutionDto | undefined;
          if (row) {
            void openDetail(row.id);
          }
        }}
      >
        <Paging defaultPageSize={25} />
        <Pager visible showInfo />
        <Column
          caption={translate('tareasProgramadas.ejecuciones.semaphore')}
          width={90}
          cellRender={(cell) => {
            const row = cell.data as TaskExecutionDto;
            const color = resolveSemaphoreColor(row.statusCode);
            return (
              <span
                data-semaphore={color}
                style={{
                  display: 'inline-block',
                  width: 12,
                  height: 12,
                  borderRadius: '50%',
                  background: color,
                }}
              />
            );
          }}
        />
        <Column dataField="definitionId" caption={translate('tareasProgramadas.ejecuciones.definition')} />
        <Column dataField="statusCode" caption={translate('tareasProgramadas.ejecuciones.status')} />
        <Column dataField="mode" caption={translate('tareasProgramadas.ejecuciones.mode')} />
        <Column dataField="isSimulation" caption={translate('tareasProgramadas.ejecuciones.simulation')} dataType="boolean" />
        <Column dataField="startedAt" caption={translate('tareasProgramadas.ejecuciones.startedAt')} dataType="datetime" />
        <Column dataField="finishedAt" caption={translate('tareasProgramadas.ejecuciones.finishedAt')} dataType="datetime" />
      </DataGrid>

      <Popup
        visible={detail !== null}
        onHiding={() => setDetail(null)}
        showTitle
        title={translate('tareasProgramadas.ejecuciones.detail')}
        width={520}
        height="auto"
        wrapperAttr={{ 'data-testid': 'tareasProgramadas.ejecuciones.detail' }}
      >
        {detail ? (
          <div>
            <p>{`#${detail.id} — ${detail.statusCode}`}</p>
            <p>{`${detail.startedAt ?? '—'} → ${detail.finishedAt ?? '—'}`}</p>
          </div>
        ) : null}
      </Popup>
    </div>
  );
}
