import { describe, expect, it } from 'vitest';
import { resolveSemaphoreColor } from './semaphoreMap';
import { buildTaskExecutionQuery } from './tasksClient';

describe('resolveSemaphoreColor', () => {
  it('mapea statusCode → color (C1-13-15)', () => {
    expect(resolveSemaphoreColor('EXITOSA')).toBe('green');
    expect(resolveSemaphoreColor('EXITOSA_CON_OBSERVACIONES')).toBe('yellow');
    expect(resolveSemaphoreColor('FALLIDA')).toBe('red');
    expect(resolveSemaphoreColor('OMITIDA')).toBe('red');
    expect(resolveSemaphoreColor('EN_EJECUCION')).toBe('blue');
  });

  it('sin historial / desconocido → gray', () => {
    expect(resolveSemaphoreColor(null)).toBe('gray');
    expect(resolveSemaphoreColor(undefined)).toBe('gray');
    expect(resolveSemaphoreColor('OTRO')).toBe('gray');
  });
});

describe('buildTaskExecutionQuery', () => {
  it('vacío sin filtros', () => {
    expect(buildTaskExecutionQuery()).toBe('');
    expect(buildTaskExecutionQuery({})).toBe('');
  });

  it('serializa filtros presentes', () => {
    const query = buildTaskExecutionQuery({ definitionId: 5, status: 'FALLIDA' });
    expect(query).toContain('definitionId=5');
    expect(query).toContain('status=FALLIDA');
    expect(query.startsWith('?')).toBe(true);
  });
});
