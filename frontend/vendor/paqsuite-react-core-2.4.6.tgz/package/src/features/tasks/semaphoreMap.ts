import type { TaskExecutionStatusCode } from './types';

export type SemaphoreColor = 'green' | 'yellow' | 'red' | 'blue' | 'gray';

/**
 * Semáforo derivado en FE a partir de `statusCode` (C1-13-15). Nunca se
 * persiste ni viene del API. Sin historial → `gray`.
 */
export function resolveSemaphoreColor(
  statusCode: TaskExecutionStatusCode | string | null | undefined
): SemaphoreColor {
  switch (statusCode) {
    case 'EXITOSA':
      return 'green';
    case 'EXITOSA_CON_OBSERVACIONES':
      return 'yellow';
    case 'FALLIDA':
    case 'OMITIDA':
      return 'red';
    case 'EN_EJECUCION':
      return 'blue';
    default:
      return 'gray';
  }
}
