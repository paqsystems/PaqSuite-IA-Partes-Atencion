import { useCallback, useEffect, useState } from 'react';
import DataGrid, { Column, Paging, Pager } from 'devextreme-react/data-grid';
import Button from 'devextreme-react/button';
import {
  listTaskDefinitions,
  runTaskDefinition,
  simulateTaskDefinition,
} from './tasksClient';
import type { TaskDefinitionDto } from './types';

export type TaskDefinitionsPageProps = {
  /** Navegación a alta / edición (rutas host `.../nueva`, `.../:id/editar`). */
  onNew?: () => void;
  onEdit?: (id: number) => void;
  /** Mapa processId → supportsSimulation (host lo obtiene del catálogo). */
  supportsSimulationByProcessId?: Record<number, boolean>;
  t?: (key: string) => string;
};

/**
 * Listado de definiciones de tareas (GEN-13). Grilla DX; el alta/edición se
 * hace en páginas full-page del host (`onNew` / `onEdit`).
 */
export function TaskDefinitionsPage({
  onNew,
  onEdit,
  supportsSimulationByProcessId,
  t,
}: TaskDefinitionsPageProps) {
  const translate = t ?? ((key: string) => key);
  const [rows, setRows] = useState<TaskDefinitionDto[]>([]);

  const load = useCallback(async () => {
    const result = await listTaskDefinitions();
    if (result.kind === 'ok') {
      const payload = result.envelope.resultado as { items?: TaskDefinitionDto[] };
      setRows(payload.items ?? []);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const handleRun = useCallback(
    async (id: number) => {
      await runTaskDefinition(id);
      void load();
    },
    [load]
  );

  const handleSimulate = useCallback(
    async (id: number) => {
      await simulateTaskDefinition(id);
      void load();
    },
    [load]
  );

  return (
    <div data-testid="tareasProgramadas.definiciones.root">
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 12 }}>
        <h2>{translate('tareasProgramadas.definiciones.title')}</h2>
        <Button
          text={translate('tareasProgramadas.definiciones.new')}
          type="default"
          stylingMode="contained"
          onClick={() => onNew?.()}
          elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.new' }}
        />
      </div>
      <DataGrid
        dataSource={rows}
        keyExpr="id"
        showBorders
        columnAutoWidth
        elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.grid' }}
        onRowDblClick={(event) => {
          const row = event.data as TaskDefinitionDto | undefined;
          if (row) {
            onEdit?.(row.id);
          }
        }}
      >
        <Paging defaultPageSize={25} />
        <Pager visible showInfo />
        <Column dataField="taskTitle" caption={translate('tareasProgramadas.definiciones.title')} />
        <Column dataField="frequencyType" caption={translate('tareasProgramadas.definiciones.frequency')} />
        <Column dataField="nextRunAt" caption={translate('tareasProgramadas.definiciones.nextRun')} dataType="datetime" />
        <Column dataField="lastStatusCode" caption={translate('tareasProgramadas.definiciones.lastStatus')} />
        <Column dataField="isActive" caption={translate('tareasProgramadas.definiciones.active')} dataType="boolean" />
        <Column
          caption={translate('tareasProgramadas.definiciones.actions')}
          width={220}
          cellRender={(cell) => {
            const row = cell.data as TaskDefinitionDto;
            const canSimulate = supportsSimulationByProcessId?.[row.processId] ?? true;
            return (
              <div style={{ display: 'flex', gap: 4 }}>
                <Button
                  text={translate('tareasProgramadas.definiciones.run')}
                  stylingMode="outlined"
                  onClick={() => void handleRun(row.id)}
                  elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.run' }}
                />
                {canSimulate ? (
                  <Button
                    text={translate('tareasProgramadas.definiciones.simulate')}
                    stylingMode="text"
                    onClick={() => void handleSimulate(row.id)}
                    elementAttr={{ 'data-testid': 'tareasProgramadas.definiciones.simulate' }}
                  />
                ) : null}
              </div>
            );
          }}
        />
      </DataGrid>
    </div>
  );
}
