import { apiRequest, type ApiClientResult } from '../../http/apiClient';
import type {
  TaskDefinitionCreateBody,
  TaskDefinitionDto,
  TaskExecutionDto,
  TaskExecutionFilters,
  TaskExecutionLogDto,
  TaskProcessDto,
} from './types';

export const taskProcessesPath = '/api/v1/task-processes';
export const taskDefinitionsPath = '/api/v1/task-definitions';
export const taskExecutionsPath = '/api/v1/task-executions';

type ListEnvelope<T> = { items: T[] };

/** Construye la query string del monitor de ejecuciones (omite vacíos). */
export function buildTaskExecutionQuery(filters: TaskExecutionFilters = {}): string {
  const params = new URLSearchParams();
  if (filters.definitionId !== undefined) {
    params.set('definitionId', String(filters.definitionId));
  }
  if (filters.companyId !== undefined) {
    params.set('companyId', String(filters.companyId));
  }
  if (filters.status) {
    params.set('status', filters.status);
  }
  if (filters.from) {
    params.set('from', filters.from);
  }
  if (filters.to) {
    params.set('to', filters.to);
  }
  const query = params.toString();
  return query ? `?${query}` : '';
}

/** GEN-13 catálogo: lista procesos (incluye inactivos). */
export function listTaskProcesses(): Promise<ApiClientResult<ListEnvelope<TaskProcessDto>>> {
  return apiRequest<ListEnvelope<TaskProcessDto>>(taskProcessesPath, { method: 'GET' });
}

/** GEN-13 catálogo: toggle `isActive`. */
export function setTaskProcessActive(
  id: number,
  isActive: boolean
): Promise<ApiClientResult<TaskProcessDto>> {
  return apiRequest<TaskProcessDto>(`${taskProcessesPath}/${id}`, {
    method: 'PATCH',
    body: JSON.stringify({ isActive }),
  });
}

/** GEN-13 definiciones: listado. */
export function listTaskDefinitions(): Promise<
  ApiClientResult<ListEnvelope<TaskDefinitionDto>>
> {
  return apiRequest<ListEnvelope<TaskDefinitionDto>>(taskDefinitionsPath, { method: 'GET' });
}

/** GEN-13 definiciones: detalle. */
export function getTaskDefinition(id: number): Promise<ApiClientResult<TaskDefinitionDto>> {
  return apiRequest<TaskDefinitionDto>(`${taskDefinitionsPath}/${id}`, { method: 'GET' });
}

/** GEN-13 definiciones: alta. */
export function createTaskDefinition(
  body: TaskDefinitionCreateBody
): Promise<ApiClientResult<TaskDefinitionDto>> {
  return apiRequest<TaskDefinitionDto>(taskDefinitionsPath, {
    method: 'POST',
    body: JSON.stringify(body),
  });
}

/** GEN-13 definiciones: edición. */
export function patchTaskDefinition(
  id: number,
  body: Partial<TaskDefinitionCreateBody>
): Promise<ApiClientResult<TaskDefinitionDto>> {
  return apiRequest<TaskDefinitionDto>(`${taskDefinitionsPath}/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(body),
  });
}

/** GEN-13 definiciones: baja lógica (soft, `isActive=false`). */
export function deleteTaskDefinition(id: number): Promise<ApiClientResult<{ isActive: boolean }>> {
  return apiRequest<{ isActive: boolean }>(`${taskDefinitionsPath}/${id}`, { method: 'DELETE' });
}

/** GEN-13 ejecución: run manual. */
export function runTaskDefinition(
  id: number,
  body: { mode?: string; parameters?: Record<string, unknown>; companyIds?: number[] } = {}
): Promise<ApiClientResult<{ batchId: number; executions: Array<{ id: number; statusCode: string }> }>> {
  return apiRequest(`${taskDefinitionsPath}/${id}/run`, {
    method: 'POST',
    body: JSON.stringify(body),
  });
}

/** GEN-13 ejecución: simulación (422/4406 si el proceso no soporta). */
export function simulateTaskDefinition(
  id: number,
  body: { parameters?: Record<string, unknown>; companyIds?: number[] } = {}
): Promise<ApiClientResult<{ batchId: number; executions: Array<{ id: number; statusCode: string }> }>> {
  return apiRequest(`${taskDefinitionsPath}/${id}/simulate`, {
    method: 'POST',
    body: JSON.stringify(body),
  });
}

/** GEN-13 monitor: listado de ejecuciones con filtros. */
export function listTaskExecutions(
  filters: TaskExecutionFilters = {}
): Promise<ApiClientResult<ListEnvelope<TaskExecutionDto>>> {
  return apiRequest<ListEnvelope<TaskExecutionDto>>(
    `${taskExecutionsPath}${buildTaskExecutionQuery(filters)}`,
    { method: 'GET' }
  );
}

/** GEN-13 monitor: detalle de ejecución. */
export function getTaskExecution(id: number): Promise<ApiClientResult<TaskExecutionDto>> {
  return apiRequest<TaskExecutionDto>(`${taskExecutionsPath}/${id}`, { method: 'GET' });
}

/** GEN-13 monitor: logs de una ejecución. */
export function getTaskExecutionLogs(
  id: number
): Promise<ApiClientResult<ListEnvelope<TaskExecutionLogDto>>> {
  return apiRequest<ListEnvelope<TaskExecutionLogDto>>(`${taskExecutionsPath}/${id}/logs`, {
    method: 'GET',
  });
}

/** GEN-13 monitor: purga admin (default = parámetro de retención). */
export function purgeTaskExecutions(
  olderThanDays?: number
): Promise<ApiClientResult<{ deletedCount: number; olderThanDays: number }>> {
  return apiRequest<{ deletedCount: number; olderThanDays: number }>(
    `${taskExecutionsPath}/purge`,
    {
      method: 'POST',
      body: JSON.stringify(olderThanDays === undefined ? {} : { olderThanDays }),
    }
  );
}
