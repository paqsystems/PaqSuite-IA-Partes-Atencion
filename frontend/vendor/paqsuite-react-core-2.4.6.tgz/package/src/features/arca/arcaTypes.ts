export type ArcaAmbiente = 'homologacion' | 'produccion';

export type ArcaServicio = 'wsaa' | 'wsfe' | 'wsfex' | 'padron';

export type ArcaUrls = {
  wsaa: string;
  wsfe: string;
  wsfex: string;
  padron: string;
};

export type ArcaConfigDto = {
  ambiente: ArcaAmbiente;
  cuit: string;
  urls: ArcaUrls;
  timeoutSeconds: number;
  fceUmbralImporte: string;
  hasCertificate: boolean;
};

export type ArcaConectividadResult = {
  servicio: ArcaServicio;
  clasificacion: string;
  ambiente: string;
};

export type ArcaAutorizacionResult = {
  solicitudId?: string;
  resultadoFuncional?: string;
  circuitoDeterminado?: string;
  cae?: string | null;
  [key: string]: unknown;
};

export const arcaHomologacionUrls: ArcaUrls = {
  wsaa: 'https://wsaahomo.afip.gov.ar/ws/services/LoginCms',
  wsfe: 'https://wswhomo.afip.gov.ar/wsfev1/service.asmx',
  wsfex: 'https://wswhomo.afip.gov.ar/wsfexv1/service.asmx',
  padron: 'https://awshomo.afip.gov.ar/sr-padron/webservices/personaServiceA5',
};

export const arcaEmptyConfig = (): ArcaConfigDto => ({
  ambiente: 'homologacion',
  cuit: '',
  urls: { ...arcaHomologacionUrls },
  timeoutSeconds: 60,
  fceUmbralImporte: '0',
  hasCertificate: false,
});
