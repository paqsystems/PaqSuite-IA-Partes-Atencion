/**
 * @vitest-environment jsdom
 */
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { ArcaConfigDto } from './arcaTypes';

const { getArcaConfig, putArcaConfig, postArcaCertificate } = vi.hoisted(() => {
  const getArcaConfig = vi.fn();
  const putArcaConfig = vi.fn();
  const postArcaCertificate = vi.fn();
  return { getArcaConfig, putArcaConfig, postArcaCertificate };
});

vi.mock('./arcaApiClient', () => ({
  getArcaConfig,
  putArcaConfig,
  postArcaCertificate,
}));

vi.mock('devextreme-react/load-panel', () => ({
  default: () => null,
}));

vi.mock('devextreme-react/form', () => ({
  default: () => null,
  GroupItem: () => null,
  SimpleItem: () => null,
}));

vi.mock('devextreme-react/file-uploader', () => ({
  default: (props: { elementAttr?: Record<string, string> }) => (
    <div data-testid={props.elementAttr?.['data-testid']} />
  ),
}));

vi.mock('devextreme-react/text-box', () => ({
  default: (props: {
    value?: string;
    mode?: string;
    elementAttr?: Record<string, string>;
    placeholder?: string;
  }) => (
    <input
      type={props.mode === 'password' ? 'password' : 'text'}
      data-testid={props.elementAttr?.['data-testid']}
      value={props.value ?? ''}
      placeholder={props.placeholder}
      readOnly
    />
  ),
}));

vi.mock('devextreme-react/button', () => ({
  default: (props: {
    text?: string;
    onClick?: () => void;
    elementAttr?: Record<string, string>;
  }) => (
    <button type="button" data-testid={props.elementAttr?.['data-testid']} onClick={props.onClick}>
      {props.text}
    </button>
  ),
}));

import { ArcaConfigPage } from './ArcaConfigPage';

const savedConfig: ArcaConfigDto = {
  ambiente: 'homologacion',
  cuit: '20111111101',
  urls: {
    wsaa: 'https://wsaahomo.afip.gov.ar/ws/services/LoginCms',
    wsfe: 'https://wswhomo.afip.gov.ar/wsfev1/service.asmx',
    wsfex: 'https://wswhomo.afip.gov.ar/wsfexv1/service.asmx',
    padron: 'https://awshomo.afip.gov.ar/sr-padron/webservices/personaServiceA5',
  },
  timeoutSeconds: 60,
  fceUmbralImporte: '0',
  hasCertificate: true,
};

describe('ArcaConfigPage', () => {
  afterEach(() => {
    cleanup();
  });

  beforeEach(() => {
    getArcaConfig.mockReset();
    putArcaConfig.mockReset();
    postArcaCertificate.mockReset();
    getArcaConfig.mockResolvedValue({
      kind: 'ok',
      httpStatus: 200,
      envelope: { error: 0, respuesta: 'ok', resultado: savedConfig },
    });
    putArcaConfig.mockResolvedValue({
      kind: 'ok',
      httpStatus: 200,
      envelope: { error: 0, respuesta: 'ok', resultado: savedConfig },
    });
  });

  it('muestra root, save, certificado y passphrase; no lista el PKCS#12', async () => {
    render(<ArcaConfigPage />);
    await waitFor(() => {
      expect(screen.getByTestId('arcaIntegration.config.root')).toBeTruthy();
    });
    expect(screen.getByTestId('arcaIntegration.config.save')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.config.certificate')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.config.passphrase')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.config.hasCertificate').textContent).toContain(
      'Hay certificado cargado',
    );
    expect(document.body.textContent).not.toContain('pkcs12');
    expect(document.body.textContent).not.toContain('MIIG');
  });

  it('al guardar llama PUT config', async () => {
    render(<ArcaConfigPage />);
    await waitFor(() => expect(getArcaConfig).toHaveBeenCalled());
    fireEvent.click(screen.getByTestId('arcaIntegration.config.save'));
    await waitFor(() => expect(putArcaConfig).toHaveBeenCalledTimes(1));
    const body = putArcaConfig.mock.calls[0][0] as { cuit: string; hasCertificate?: boolean };
    expect(body.cuit).toBe('20111111101');
    expect(body.hasCertificate).toBeUndefined();
    expect(postArcaCertificate).not.toHaveBeenCalled();
  });

  it('sin permiso configurar no muta secretos', () => {
    render(<ArcaConfigPage canConfigure={false} />);
    expect(screen.queryByTestId('arcaIntegration.config.save')).toBeNull();
    expect(screen.queryByTestId('arcaIntegration.config.passphrase')).toBeNull();
    expect(getArcaConfig).not.toHaveBeenCalled();
  });
});
