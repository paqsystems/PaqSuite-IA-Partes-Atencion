import { useCallback, useEffect, useState } from 'react';
import Button from 'devextreme-react/button';
import FileUploader from 'devextreme-react/file-uploader';
import Form, { GroupItem, SimpleItem } from 'devextreme-react/form';
import LoadPanel from 'devextreme-react/load-panel';
import TextBox from 'devextreme-react/text-box';
import { getArcaConfig, postArcaCertificate, putArcaConfig } from './arcaApiClient';
import { translateArca } from './arcaI18n';
import { arcaEmptyConfig, type ArcaConfigDto } from './arcaTypes';

export type ArcaConfigPageProps = {
  t?: (key: string) => string;
  canConfigure?: boolean;
};

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result ?? '');
      const comma = result.indexOf(',');
      resolve(comma >= 0 ? result.slice(comma + 1) : result);
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export function ArcaConfigPage({ t, canConfigure = true }: ArcaConfigPageProps) {
  const translate = t ?? ((key: string) => translateArca('es', key));
  const [form, setForm] = useState<ArcaConfigDto>(arcaEmptyConfig);
  const [passphrase, setPassphrase] = useState('');
  const [pkcs12Base64, setPkcs12Base64] = useState('');
  const [loading, setLoading] = useState(false);
  const [feedbackKey, setFeedbackKey] = useState<string | null>(null);

  const patchForm = useCallback((field: string, value: unknown) => {
    setForm((current) => {
      if (field.startsWith('urls.')) {
        const urlKey = field.slice(5) as keyof ArcaConfigDto['urls'];
        return { ...current, urls: { ...current.urls, [urlKey]: String(value ?? '') } };
      }
      if (field === 'timeoutSeconds') {
        return { ...current, timeoutSeconds: Number(value) || 0 };
      }
      if (field === 'ambiente' || field === 'cuit' || field === 'fceUmbralImporte') {
        return { ...current, [field]: value as never };
      }
      return current;
    });
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    const result = await getArcaConfig();
    setLoading(false);
    if (result.kind === 'ok') {
      setForm({
        ...result.envelope.resultado,
        urls: { ...arcaEmptyConfig().urls, ...result.envelope.resultado.urls },
      });
      setPassphrase('');
      setPkcs12Base64('');
      setFeedbackKey(result.envelope.respuesta);
      return;
    }
    if (result.kind === 'envelopeError') {
      setFeedbackKey(result.envelope.respuesta);
      return;
    }
    setFeedbackKey(result.i18nKey);
  }, []);

  useEffect(() => {
    if (canConfigure) {
      void load();
    }
  }, [canConfigure, load]);

  const save = useCallback(async () => {
    if (!canConfigure) {
      return;
    }
    setLoading(true);
    const result = await putArcaConfig({
      ambiente: form.ambiente,
      cuit: form.cuit,
      urls: form.urls,
      timeoutSeconds: form.timeoutSeconds,
      fceUmbralImporte: form.fceUmbralImporte,
    });
    if (result.kind === 'ok') {
      setForm((current) => ({ ...current, ...result.envelope.resultado }));
      setFeedbackKey(result.envelope.respuesta);
      if (pkcs12Base64 !== '' && passphrase !== '') {
        const cert = await postArcaCertificate({ pkcs12Base64, passphrase });
        if (cert.kind === 'ok') {
          setForm((current) => ({ ...current, hasCertificate: true }));
          setPassphrase('');
          setPkcs12Base64('');
          setFeedbackKey(cert.envelope.respuesta);
        } else if (cert.kind === 'envelopeError') {
          setFeedbackKey(cert.envelope.respuesta);
        } else {
          setFeedbackKey(cert.i18nKey);
        }
      }
    } else if (result.kind === 'envelopeError') {
      setFeedbackKey(result.envelope.respuesta);
    } else {
      setFeedbackKey(result.i18nKey);
    }
    setLoading(false);
  }, [canConfigure, form, passphrase, pkcs12Base64]);

  if (!canConfigure) {
    return (
      <section data-testid="arcaIntegration.config.root">
        <p>{translate('arcaIntegration.config.forbidden')}</p>
      </section>
    );
  }

  return (
    <section data-testid="arcaIntegration.config.root">
      <LoadPanel visible={loading} showIndicator showPane />
      <h1>{translate('arcaIntegration.config.root')}</h1>
      <Form
        formData={form}
        colCount={2}
        labelLocation="top"
        onFieldDataChanged={(event) => {
          if (event.dataField) {
            patchForm(event.dataField, event.value);
          }
        }}
      >
        <GroupItem colCount={2}>
          <SimpleItem
            dataField="ambiente"
            editorType="dxSelectBox"
            label={{ text: translate('arcaIntegration.config.ambiente') }}
            editorOptions={{
              items: ['homologacion', 'produccion'],
              elementAttr: { 'data-testid': 'arcaIntegration.config.ambiente' },
            }}
          />
          <SimpleItem
            dataField="cuit"
            editorType="dxTextBox"
            label={{ text: translate('arcaIntegration.config.cuit') }}
            editorOptions={{
              elementAttr: { 'data-testid': 'arcaIntegration.config.cuit' },
            }}
          />
          <SimpleItem
            dataField="timeoutSeconds"
            editorType="dxNumberBox"
            label={{ text: translate('arcaIntegration.config.timeout') }}
            editorOptions={{
              min: 10,
              max: 180,
              elementAttr: { 'data-testid': 'arcaIntegration.config.timeout' },
            }}
          />
          <SimpleItem
            dataField="fceUmbralImporte"
            editorType="dxTextBox"
            label={{ text: translate('arcaIntegration.config.fceUmbral') }}
            editorOptions={{
              elementAttr: { 'data-testid': 'arcaIntegration.config.fceUmbral' },
            }}
          />
          <SimpleItem
            dataField="urls.wsaa"
            editorType="dxTextBox"
            label={{ text: translate('arcaIntegration.config.urlWsaa') }}
            editorOptions={{
              elementAttr: { 'data-testid': 'arcaIntegration.config.urlWsaa' },
            }}
          />
          <SimpleItem
            dataField="urls.wsfe"
            editorType="dxTextBox"
            label={{ text: translate('arcaIntegration.config.urlWsfe') }}
            editorOptions={{
              elementAttr: { 'data-testid': 'arcaIntegration.config.urlWsfe' },
            }}
          />
          <SimpleItem
            dataField="urls.wsfex"
            editorType="dxTextBox"
            label={{ text: translate('arcaIntegration.config.urlWsfex') }}
            editorOptions={{
              elementAttr: { 'data-testid': 'arcaIntegration.config.urlWsfex' },
            }}
          />
          <SimpleItem
            dataField="urls.padron"
            editorType="dxTextBox"
            label={{ text: translate('arcaIntegration.config.urlPadron') }}
            editorOptions={{
              elementAttr: { 'data-testid': 'arcaIntegration.config.urlPadron' },
            }}
          />
        </GroupItem>
      </Form>
      <p data-testid="arcaIntegration.config.hasCertificate">
        {form.hasCertificate
          ? translate('arcaIntegration.config.hasCertificate')
          : translate('arcaIntegration.config.noCertificate')}
      </p>
      <FileUploader
        accept=".p12,.pfx,application/x-pkcs12"
        uploadMode="useForm"
        showFileList
        labelText={translate('arcaIntegration.config.certificate')}
        elementAttr={{ 'data-testid': 'arcaIntegration.config.certificate' }}
        onValueChanged={(event) => {
          const files = (event.value as File[] | undefined) ?? [];
          const file = files[0];
          if (!file) {
            setPkcs12Base64('');
            return;
          }
          void fileToBase64(file).then(setPkcs12Base64);
        }}
      />
      <TextBox
        value={passphrase}
        mode="password"
        onValueChanged={(event) => setPassphrase(String(event.value ?? ''))}
        placeholder={translate('arcaIntegration.config.passphrase')}
        inputAttr={{ autoComplete: 'new-password', name: 'arcaCertificatePassphrase' }}
        elementAttr={{ 'data-testid': 'arcaIntegration.config.passphrase' }}
      />
      <Button
        text={translate('arcaIntegration.config.save')}
        type="default"
        onClick={() => void save()}
        elementAttr={{ 'data-testid': 'arcaIntegration.config.save' }}
      />
      {feedbackKey ? (
        <p data-testid="arcaIntegration.config.feedback">{translate(feedbackKey)}</p>
      ) : null}
    </section>
  );
}
