import { useCallback, useState } from 'react';
import Button from 'devextreme-react/button';
import LoadPanel from 'devextreme-react/load-panel';
import { postArcaComprobante, postArcaConectividad } from './arcaApiClient';
import { buildArcaFacturaAFixture } from './arcaFixtureFacturaA';
import { translateArca } from './arcaI18n';
import type { ArcaServicio } from './arcaTypes';

export type ArcaHomologacionPageProps = {
  t?: (key: string) => string;
  canOperate?: boolean;
};

type Feedback = {
  respuesta: string;
  clasificacion?: string;
  resultadoFuncional?: string;
};

export function ArcaHomologacionPage({ t, canOperate = true }: ArcaHomologacionPageProps) {
  const translate = t ?? ((key: string) => translateArca('es', key));
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<Feedback | null>(null);

  const runConectividad = useCallback(async (servicio: ArcaServicio) => {
    if (!canOperate) {
      return;
    }
    setLoading(true);
    const result = await postArcaConectividad(servicio);
    if (result.kind === 'ok') {
      setFeedback({
        respuesta: result.envelope.respuesta,
        clasificacion: result.envelope.resultado.clasificacion,
      });
    } else if (result.kind === 'envelopeError') {
      const resultado = result.envelope.resultado as { clasificacion?: string; resultadoFuncional?: string };
      setFeedback({
        respuesta: result.envelope.respuesta,
        clasificacion: resultado.clasificacion,
        resultadoFuncional: resultado.resultadoFuncional,
      });
    } else {
      setFeedback({ respuesta: result.i18nKey });
    }
    setLoading(false);
  }, [canOperate]);

  const runFixture = useCallback(async () => {
    if (!canOperate) {
      return;
    }
    setLoading(true);
    const result = await postArcaComprobante(buildArcaFacturaAFixture());
    if (result.kind === 'ok') {
      setFeedback({
        respuesta: result.envelope.respuesta,
        resultadoFuncional: result.envelope.resultado.resultadoFuncional,
      });
    } else if (result.kind === 'envelopeError') {
      const resultado = result.envelope.resultado as { resultadoFuncional?: string };
      setFeedback({
        respuesta: result.envelope.respuesta,
        resultadoFuncional: resultado.resultadoFuncional,
      });
    } else {
      setFeedback({ respuesta: result.i18nKey });
    }
    setLoading(false);
  }, [canOperate]);

  if (!canOperate) {
    return (
      <section data-testid="arcaIntegration.homologacion.root">
        <p>{translate('arcaIntegration.homologacion.forbidden')}</p>
      </section>
    );
  }

  return (
    <section data-testid="arcaIntegration.homologacion.root">
      <LoadPanel visible={loading} showIndicator showPane />
      <h1>{translate('arcaIntegration.homologacion.root')}</h1>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
        <Button
          text={translate('arcaIntegration.homologacion.testWsaa')}
          onClick={() => void runConectividad('wsaa')}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.testWsaa' }}
        />
        <Button
          text={translate('arcaIntegration.homologacion.testWsfe')}
          onClick={() => void runConectividad('wsfe')}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.testWsfe' }}
        />
        <Button
          text={translate('arcaIntegration.homologacion.testWsfex')}
          onClick={() => void runConectividad('wsfex')}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.testWsfex' }}
        />
        <Button
          text={translate('arcaIntegration.homologacion.testPadron')}
          onClick={() => void runConectividad('padron')}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.testPadron' }}
        />
        <Button
          text={translate('arcaIntegration.homologacion.autorizarFixture')}
          type="default"
          onClick={() => void runFixture()}
          elementAttr={{ 'data-testid': 'arcaIntegration.homologacion.autorizarFixture' }}
        />
      </div>
      {feedback ? (
        <div data-testid="arcaIntegration.homologacion.resultado">
          <p>{translate(feedback.respuesta)}</p>
          {feedback.clasificacion ? (
            <p>
              {translate('arcaIntegration.homologacion.clasificacion')}: {feedback.clasificacion}
            </p>
          ) : null}
          {feedback.resultadoFuncional ? <p>{feedback.resultadoFuncional}</p> : null}
        </div>
      ) : null}
    </section>
  );
}
