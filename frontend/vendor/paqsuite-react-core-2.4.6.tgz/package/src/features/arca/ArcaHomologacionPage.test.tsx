/**
 * @vitest-environment jsdom
 */
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const { postArcaConectividad, postArcaComprobante } = vi.hoisted(() => ({
  postArcaConectividad: vi.fn(),
  postArcaComprobante: vi.fn(),
}));

vi.mock('./arcaApiClient', () => ({
  postArcaConectividad,
  postArcaComprobante,
}));

vi.mock('devextreme-react/load-panel', () => ({
  default: () => null,
}));

vi.mock('devextreme-react/button', () => ({
  default: (props: {
    text?: string;
    onClick?: () => void;
    elementAttr?: Record<string, string>;
  }) => (
    <button type="button" data-testid={props.elementAttr?.['data-testid']} onClick={props.onClick}>
      {props.text}
    </button>
  ),
}));

import { ArcaHomologacionPage } from './ArcaHomologacionPage';

describe('ArcaHomologacionPage', () => {
  afterEach(() => {
    cleanup();
  });

  beforeEach(() => {
    postArcaConectividad.mockReset();
    postArcaComprobante.mockReset();
    postArcaConectividad.mockResolvedValue({
      kind: 'ok',
      httpStatus: 200,
      envelope: {
        error: 0,
        respuesta: 'ok',
        resultado: { servicio: 'wsaa', clasificacion: 'ok', ambiente: 'homologacion' },
      },
    });
    postArcaComprobante.mockResolvedValue({
      kind: 'ok',
      httpStatus: 200,
      envelope: {
        error: 0,
        respuesta: 'ok',
        resultado: { resultadoFuncional: 'AUTORIZADO', circuitoDeterminado: 'comun' },
      },
    });
  });

  it('expone los cuatro tests y el fixture', () => {
    render(<ArcaHomologacionPage />);
    expect(screen.getByTestId('arcaIntegration.homologacion.root')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.homologacion.testWsaa')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.homologacion.testWsfe')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.homologacion.testWsfex')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.homologacion.testPadron')).toBeTruthy();
    expect(screen.getByTestId('arcaIntegration.homologacion.autorizarFixture')).toBeTruthy();
  });

  it('al probar WSAA muestra clasificacion del envelope', async () => {
    render(<ArcaHomologacionPage />);
    fireEvent.click(screen.getByTestId('arcaIntegration.homologacion.testWsaa'));
    await waitFor(() => expect(postArcaConectividad).toHaveBeenCalledWith('wsaa'));
    await waitFor(() => {
      expect(screen.getByTestId('arcaIntegration.homologacion.resultado').textContent).toContain('ok');
    });
  });

  it('autorizar fixture llama POST comprobantes y muestra resultadoFuncional', async () => {
    render(<ArcaHomologacionPage />);
    fireEvent.click(screen.getByTestId('arcaIntegration.homologacion.autorizarFixture'));
    await waitFor(() => expect(postArcaComprobante).toHaveBeenCalledTimes(1));
    const body = postArcaComprobante.mock.calls[0][0] as { identificacion: { letra: string } };
    expect(body.identificacion.letra).toBe('A');
    await waitFor(() => {
      expect(screen.getByTestId('arcaIntegration.homologacion.resultado').textContent).toContain(
        'AUTORIZADO',
      );
    });
  });

  it('sin permiso operar no dispara pruebas', () => {
    render(<ArcaHomologacionPage canOperate={false} />);
    expect(screen.queryByTestId('arcaIntegration.homologacion.testWsaa')).toBeNull();
  });
});
