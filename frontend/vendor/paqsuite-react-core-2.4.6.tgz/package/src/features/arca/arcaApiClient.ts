import { apiRequest, type ApiRequestOptions } from '../../http/apiClient';
import type {
  ArcaAutorizacionResult,
  ArcaConectividadResult,
  ArcaConfigDto,
  ArcaServicio,
} from './arcaTypes';

export const arcaBasePath = '/api/v1/arca';

type RequestOverrides = Pick<ApiRequestOptions, 'platform' | 'signal' | 'headers'>;

export function getArcaConfig(options: RequestOverrides = {}) {
  return apiRequest<ArcaConfigDto>(`${arcaBasePath}/config`, {
    method: 'GET',
    ...options,
  });
}

export function putArcaConfig(
  body: Omit<ArcaConfigDto, 'hasCertificate'>,
  options: RequestOverrides = {},
) {
  return apiRequest<ArcaConfigDto>(`${arcaBasePath}/config`, {
    method: 'PUT',
    body: JSON.stringify(body),
    ...options,
  });
}

export function postArcaCertificate(
  body: { pkcs12Base64: string; passphrase: string },
  options: RequestOverrides = {},
) {
  return apiRequest<{ hasCertificate: true }>(`${arcaBasePath}/config/certificado`, {
    method: 'POST',
    body: JSON.stringify(body),
    ...options,
  });
}

export function postArcaConectividad(servicio: ArcaServicio, options: RequestOverrides = {}) {
  return apiRequest<ArcaConectividadResult>(`${arcaBasePath}/conectividad`, {
    method: 'POST',
    body: JSON.stringify({ servicio }),
    ...options,
  });
}

export function postArcaComprobante(
  body: Record<string, unknown>,
  options: RequestOverrides = {},
) {
  return apiRequest<ArcaAutorizacionResult>(`${arcaBasePath}/comprobantes`, {
    method: 'POST',
    body: JSON.stringify(body),
    ...options,
  });
}
