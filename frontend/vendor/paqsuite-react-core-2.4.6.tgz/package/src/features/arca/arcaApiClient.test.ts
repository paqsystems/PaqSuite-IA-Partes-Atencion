import { describe, expect, it, vi } from 'vitest';
import { apiRequest } from '../../http/apiClient';
import { getArcaConfig, postArcaConectividad, putArcaConfig } from './arcaApiClient';

vi.mock('../../http/apiClient', () => ({
  apiRequest: vi.fn(async () => ({
    kind: 'ok',
    httpStatus: 200,
    envelope: { error: 0, respuesta: 'ok', resultado: {} },
  })),
}));

describe('arcaApiClient', () => {
  it('apunta a /api/v1/arca', async () => {
    await getArcaConfig();
    expect(apiRequest).toHaveBeenCalledWith('/api/v1/arca/config', expect.objectContaining({ method: 'GET' }));
    await putArcaConfig({
      ambiente: 'homologacion',
      cuit: '20111111101',
      urls: { wsaa: 'a', wsfe: 'b', wsfex: 'c', padron: 'd' },
      timeoutSeconds: 60,
      fceUmbralImporte: '0',
    });
    expect(apiRequest).toHaveBeenCalledWith(
      '/api/v1/arca/config',
      expect.objectContaining({ method: 'PUT' }),
    );
    await postArcaConectividad('wsaa');
    expect(apiRequest).toHaveBeenCalledWith(
      '/api/v1/arca/conectividad',
      expect.objectContaining({ method: 'POST' }),
    );
  });
});
