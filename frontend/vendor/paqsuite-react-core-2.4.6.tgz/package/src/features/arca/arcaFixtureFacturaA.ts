/** Fixture JSON SoT §10.1 (FC A común). `solicitudId` se genera en cada invocación. */
export function buildArcaFacturaAFixture(): Record<string, unknown> {
  const solicitudId =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID()
      : '550e8400-e29b-41d4-a716-446655440000';

  return {
    solicitud: {
      solicitudId,
      comprobanteHostId: 'fc-a-0001-00000042',
      hostCodigo: 'tango',
    },
    identificacion: {
      clase: 'factura',
      letra: 'A',
      regimenSolicitado: 'comun',
      puntoVenta: 1,
      numero: 42,
      fechaComprobante: '2026-08-31',
    },
    emisor: { cuit: '30123456789' },
    receptor: {
      tipoDocumento: 'cuit',
      numeroDocumento: '30765432109',
      cuit: '30765432109',
      razonSocial: 'Cliente SA',
      condicionIva: 'ivaResponsableInscripto',
    },
    operacion: { concepto: 'bienes' },
    fechas: { fechaComprobante: '2026-08-31' },
    moneda: { codigo: 'ARS', esMonedaLocal: true },
    importes: {
      netoGravado: '10000.00',
      iva: '2100.00',
      total: '12100.00',
    },
    iva: [{ alicuota: '21.00', baseImponible: '10000.00', importe: '2100.00' }],
    tributos: [],
    otrosImportes: [],
    comprobantesAsociados: [],
    opcionales: [],
    metadatosHost: { talonarioHost: 'TAL-A-01' },
  };
}
