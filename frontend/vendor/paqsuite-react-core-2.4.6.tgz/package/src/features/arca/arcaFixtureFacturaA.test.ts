import { describe, expect, it } from 'vitest';
import { buildArcaFacturaAFixture } from './arcaFixtureFacturaA';

describe('buildArcaFacturaAFixture', () => {
  it('genera FC A común con solicitudId UUID distinto en cada llamada', () => {
    const first = buildArcaFacturaAFixture() as {
      solicitud: { solicitudId: string };
      identificacion: { letra: string; regimenSolicitado: string };
    };
    const second = buildArcaFacturaAFixture() as {
      solicitud: { solicitudId: string };
    };
    expect(first.identificacion.letra).toBe('A');
    expect(first.identificacion.regimenSolicitado).toBe('comun');
    expect(first.solicitud.solicitudId).toMatch(
      /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i,
    );
    expect(second.solicitud.solicitudId).not.toBe(first.solicitud.solicitudId);
  });
});
