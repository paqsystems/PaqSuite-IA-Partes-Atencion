import { afterEach, describe, expect, it, vi } from 'vitest';
import { apiRequest, setApiUnauthorizedHandler } from './apiClient';
import { clienteHeaderName, companyHeaderName } from './headers';
import { transportI18nKey } from './parseEnvelope';

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

function stubFetch(body: string, status = 200, statusText = 'OK'): void {
  vi.stubGlobal(
    'fetch',
    vi.fn(async () =>
      new Response(body, {
        status,
        statusText,
        headers: { 'Content-Type': 'application/json' },
      })
    )
  );
}

describe('apiRequest', () => {
  it('clasifica éxito', async () => {
    stubFetch(
      JSON.stringify({
        error: 0,
        respuesta: 'ok',
        resultado: { id: 1 },
      })
    );

    const result = await apiRequest<{ id: number }>('/api/v1/x');

    expect(result.kind).toBe('ok');
    if (result.kind === 'ok') {
      expect(result.envelope.resultado.id).toBe(1);
      expect(result.httpStatus).toBe(200);
    }
  });

  it('clasifica envelopeError con clave i18n', async () => {
    stubFetch(
      JSON.stringify({
        error: 3002,
        respuesta: 'auth.invalidCredentials',
        resultado: {},
      }),
      401
    );

    const result = await apiRequest('/api/v1/login');

    expect(result.kind).toBe('envelopeError');
    if (result.kind === 'envelopeError') {
      expect(result.envelope.respuesta).toBe('auth.invalidCredentials');
      expect(result.httpStatus).toBe(401);
    }
  });

  it('HTTP 200 con error≠0 es envelopeError (legacy)', async () => {
    stubFetch(
      JSON.stringify({
        error: 1001,
        respuesta: 'tenant.invalid',
        resultado: {},
      }),
      200
    );

    const result = await apiRequest('/api/v1/x');
    expect(result.kind).toBe('envelopeError');
  });

  it('HTML → transportError', async () => {
    stubFetch('<html>bad gateway</html>', 502, 'Bad Gateway');

    const result = await apiRequest('/api/v1/x');

    expect(result.kind).toBe('transportError');
    if (result.kind === 'transportError') {
      expect(result.i18nKey).toBe(transportI18nKey);
      expect(result.httpStatus).toBe(502);
    }
  });

  it('shape inválido → transportError', async () => {
    stubFetch(
      JSON.stringify({ error: true, respuesta: 'ok', resultado: null })
    );

    const result = await apiRequest('/api/v1/x');
    expect(result.kind).toBe('transportError');
  });

  it('adjunta headers de plataforma', async () => {
    const fetchMock = vi.fn(async () =>
      new Response(
        JSON.stringify({ error: 0, respuesta: 'ok', resultado: {} }),
        { status: 200 }
      )
    );
    vi.stubGlobal('fetch', fetchMock);

    await apiRequest('/api/v1/x', {
      platform: { cliente: 'demo', companyId: 3 },
      headers: { Authorization: 'Bearer tok' },
    });

    const init = fetchMock.mock.calls[0][1] as RequestInit;
    const headers = new Headers(init.headers);
    expect(headers.get(clienteHeaderName)).toBe('demo');
    expect(headers.get(companyHeaderName)).toBe('3');
    expect(headers.get('Authorization')).toBe('Bearer tok');
  });

  it('fallo de red → transportError', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => {
        throw new TypeError('Failed to fetch');
      })
    );

    const result = await apiRequest('/api/v1/x');
    expect(result.kind).toBe('transportError');
  });

  it('invoca handler 401 salvo skipUnauthorizedHandler', async () => {
    const handler = vi.fn();
    setApiUnauthorizedHandler(handler);

    stubFetch(
      JSON.stringify({
        error: 3002,
        respuesta: 'auth.invalidCredentials',
        resultado: {},
      }),
      401
    );

    await apiRequest('/api/v1/me');
    expect(handler).toHaveBeenCalledTimes(1);

    handler.mockClear();
    await apiRequest('/api/v1/auth/login', { skipUnauthorizedHandler: true });
    expect(handler).not.toHaveBeenCalled();

    setApiUnauthorizedHandler(undefined);
  });
});
