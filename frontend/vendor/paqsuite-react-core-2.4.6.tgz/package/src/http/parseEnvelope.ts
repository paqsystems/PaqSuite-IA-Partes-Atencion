export type PaqSuiteEnvelope<T> = {
  error: number;
  respuesta: string;
  resultado: T;
};

export const transportI18nKey = 'infra.transport' as const;

export type ApiClientResult<T> =
  | { kind: 'ok'; httpStatus: number; envelope: PaqSuiteEnvelope<T> }
  | {
      kind: 'envelopeError';
      httpStatus: number;
      envelope: PaqSuiteEnvelope<unknown>;
    }
  | {
      kind: 'transportError';
      httpStatus?: number;
      i18nKey: typeof transportI18nKey;
      cause?: unknown;
    };

export function isEnvelope(value: unknown): value is PaqSuiteEnvelope<unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    return false;
  }

  const record = value as Record<string, unknown>;

  if (typeof record.error !== 'number' || !Number.isFinite(record.error)) {
    return false;
  }

  if (typeof record.respuesta !== 'string') {
    return false;
  }

  if (
    record.resultado === null ||
    typeof record.resultado !== 'object' ||
    Array.isArray(record.resultado)
  ) {
    return false;
  }

  return true;
}

export function parseEnvelope(value: unknown): PaqSuiteEnvelope<unknown> | null {
  return isEnvelope(value) ? value : null;
}
