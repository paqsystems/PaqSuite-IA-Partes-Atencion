export const clienteHeaderName = 'X-Paq-Cliente';
export const companyHeaderName = 'X-Company-Id';

export type PaqSuiteTenancy = 'single' | 'multi';
export type PaqSuiteDb = 'unified' | 'split';

export type BuildPlatformHeadersInput = {
  cliente: string;
  companyId?: string | number | null;
  tenancy?: PaqSuiteTenancy;
};

/**
 * Construye headers de instalación y empresa.
 * En tenancy=single, companyId es opcional (el backend puede auto-inyectar).
 */
export function buildPlatformHeaders(
  input: BuildPlatformHeadersInput
): Record<string, string> {
  const headers: Record<string, string> = {
    [clienteHeaderName]: input.cliente,
  };

  if (input.companyId !== undefined && input.companyId !== null && input.companyId !== '') {
    headers[companyHeaderName] = String(input.companyId);
  }

  return headers;
}
