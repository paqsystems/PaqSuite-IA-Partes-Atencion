import { beforeEach, describe, expect, it } from 'vitest';
import { clearActiveEmpresaId, getActiveEmpresaId, setActiveEmpresaId } from './empresaStorage';

describe('empresaStorage', () => {
  beforeEach(() => {
    clearActiveEmpresaId();
  });

  it('get inicial es null', () => {
    expect(getActiveEmpresaId()).toBeNull();
  });

  it('set/get persiste el id como string', () => {
    setActiveEmpresaId(7);
    expect(getActiveEmpresaId()).toBe('7');
  });

  it('clear elimina el valor persistido', () => {
    setActiveEmpresaId('demo');
    clearActiveEmpresaId();
    expect(getActiveEmpresaId()).toBeNull();
  });
});
