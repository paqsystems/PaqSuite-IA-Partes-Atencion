import { describe, expect, it } from 'vitest';
import {
  blockedNoCompanyI18nKey,
  resolveEmpresaGate,
} from './resolveEmpresaGate';

describe('resolveEmpresaGate', () => {
  it('N=0 bloquea', () => {
    expect(
      resolveEmpresaGate({ tenancy: 'multi', empresasConPermiso: [] })
    ).toBe('blockedNoCompany');
    expect(
      resolveEmpresaGate({ tenancy: 'single', empresasConPermiso: [] })
    ).toBe('blockedNoCompany');
  });

  it('single nunca selector', () => {
    expect(
      resolveEmpresaGate({
        tenancy: 'single',
        empresasConPermiso: [{ id: 1 }, { id: 2 }],
      })
    ).toBe('shell');
  });

  it('multi N=1 shell', () => {
    expect(
      resolveEmpresaGate({
        tenancy: 'multi',
        empresasConPermiso: [{ id: 1 }],
      })
    ).toBe('shell');
  });

  it('multi N>1 selector', () => {
    expect(
      resolveEmpresaGate({
        tenancy: 'multi',
        empresasConPermiso: [{ id: 1 }, { id: 2 }],
      })
    ).toBe('selector');
  });

  it('expone clave i18n N=0', () => {
    expect(blockedNoCompanyI18nKey).toBe('shell.blockedNoCompany');
  });
});
