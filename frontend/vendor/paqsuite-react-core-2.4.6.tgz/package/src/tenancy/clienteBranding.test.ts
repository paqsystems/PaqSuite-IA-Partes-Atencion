import { describe, expect, it } from 'vitest';
import {
  resolveClienteDefaultLogoUrl,
  resolveClienteLogoUrl,
} from './clienteBranding';

describe('resolveClienteLogoUrl', () => {
  it('normaliza cliente y arma path canónico', () => {
    expect(resolveClienteLogoUrl('  ankasdelsur ')).toBe('/images/ANKASDELSUR.jpg');
  });

  it('usa DEMO si el código queda vacío', () => {
    expect(resolveClienteLogoUrl('')).toBe('/images/DEMO.jpg');
  });

  it('respeta basePath custom', () => {
    expect(resolveClienteLogoUrl('quento', { basePath: '/assets/branding' })).toBe(
      '/assets/branding/QUENTO.jpg'
    );
  });
});

describe('resolveClienteDefaultLogoUrl', () => {
  it('arma path de default.jpg', () => {
    expect(resolveClienteDefaultLogoUrl()).toBe('/images/default.jpg');
  });

  it('respeta defaultFileName custom', () => {
    expect(
      resolveClienteDefaultLogoUrl({
        basePath: '/cdn',
        defaultFileName: 'fallback.jpg',
      })
    ).toBe('/cdn/fallback.jpg');
  });
});
