import { describe, expect, it } from 'vitest';
import {
  bootstrapClienteFromWindow,
  isDevOrNonCanonicalHostname,
  normalizeClienteCode,
  persistClienteCode,
  queryClienteFromSearch,
  resolveClienteCode,
} from './clienteBridge';

describe('normalizeClienteCode', () => {
  it('trim y uppercase', () => {
    expect(normalizeClienteCode('  demo ')).toBe('DEMO');
  });

  it('vacío / whitespace → ausente', () => {
    expect(normalizeClienteCode('')).toBe('');
    expect(normalizeClienteCode('   ')).toBe('');
    expect(normalizeClienteCode(null)).toBe('');
  });
});

describe('resolveClienteCode', () => {
  it('dev fuerza DEMO aunque haya query', () => {
    expect(
      resolveClienteCode({
        isDevOrNonCanonicalUrl: true,
        queryCliente: 'ACME',
      })
    ).toBe('DEMO');
  });

  it('query gana sobre cookie y session', () => {
    expect(
      resolveClienteCode({
        isDevOrNonCanonicalUrl: false,
        queryCliente: 'beta',
        cookieCliente: 'ACME',
        sessionCliente: 'ACME',
      })
    ).toBe('BETA');
  });

  it('sin query usa cookie', () => {
    expect(
      resolveClienteCode({
        isDevOrNonCanonicalUrl: false,
        cookieCliente: 'acme',
        sessionCliente: 'OTHER',
      })
    ).toBe('ACME');
  });

  it('sin orígenes → DEMO', () => {
    expect(
      resolveClienteCode({
        isDevOrNonCanonicalUrl: false,
      })
    ).toBe('DEMO');
  });

  it('query vacío se trata como ausente', () => {
    expect(
      resolveClienteCode({
        isDevOrNonCanonicalUrl: false,
        queryCliente: '  ',
        cookieCliente: 'acme',
      })
    ).toBe('ACME');
  });
});

describe('isDevOrNonCanonicalHostname', () => {
  it('detecta localhost e IP privada', () => {
    expect(isDevOrNonCanonicalHostname('localhost')).toBe(true);
    expect(isDevOrNonCanonicalHostname('10.0.2.2')).toBe(true);
    expect(isDevOrNonCanonicalHostname('192.168.1.10')).toBe(true);
    expect(isDevOrNonCanonicalHostname('frontend.paqsystems.ar')).toBe(false);
  });

  it('respeta flag DEV', () => {
    expect(isDevOrNonCanonicalHostname('frontend.paqsystems.ar', true)).toBe(
      true
    );
  });
});

describe('persistClienteCode', () => {
  it('escribe cookie y sessionStorage, no localStorage', () => {
    const store: Record<string, string> = {};
    const cookies: Record<string, string> = {};
    const written = persistClienteCode('acme', {
      getCookie: (n) => cookies[n] ?? null,
      setCookie: (n, v) => {
        cookies[n] = v;
      },
      getSession: (k) => store[k] ?? null,
      setSession: (k, v) => {
        store[k] = v;
      },
    });
    expect(written).toBe('ACME');
    expect(cookies.paqCliente).toBe('ACME');
    expect(store.paqCliente).toBe('ACME');
  });
});

describe('queryClienteFromSearch', () => {
  it('lee ?cliente= y normaliza', () => {
    expect(queryClienteFromSearch('?cliente=paq')).toBe('PAQ');
    expect(queryClienteFromSearch('locale=es')).toBe('');
    expect(queryClienteFromSearch('')).toBe('');
  });
});

describe('bootstrapClienteFromWindow', () => {
  it('query gana sobre cookie DEMO y persiste', () => {
    const store: Record<string, string> = {};
    const cookies: Record<string, string> = { paqCliente: 'DEMO' };
    const persistence = {
      getCookie: (n: string) => cookies[n] ?? null,
      setCookie: (n: string, v: string) => {
        cookies[n] = v;
      },
      getSession: (k: string) => store[k] ?? null,
      setSession: (k: string, v: string) => {
        store[k] = v;
      },
    };

    const written = bootstrapClienteFromWindow({
      persistence,
      isDevBuild: false,
      hostname: 'partesatencionpaqsystems.vercel.app',
      search: '?cliente=PAQ',
    });

    expect(written).toBe('PAQ');
    expect(cookies.paqCliente).toBe('PAQ');
    expect(store.paqCliente).toBe('PAQ');
  });
});
