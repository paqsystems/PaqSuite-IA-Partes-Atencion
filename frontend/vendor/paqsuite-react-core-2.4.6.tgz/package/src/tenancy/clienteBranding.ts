import { normalizeClienteCode } from './clienteBridge';

export const defaultClienteLogoFileName = 'default.jpg';

export type ResolveClienteLogoUrlInput = {
  /** Prefijo público; default `/images`. */
  basePath?: string;
  /** Nombre de archivo fallback; default `default.jpg`. */
  defaultFileName?: string;
};

function trimBasePath(basePath: string): string {
  const trimmed = basePath.trim();
  if (!trimmed || trimmed === '/') {
    return '';
  }
  return trimmed.replace(/\/+$/, '');
}

/**
 * URL canónica del logo de instalación: `/images/{CLIENTE}.jpg` (SPEC-001-19).
 */
export function resolveClienteLogoUrl(
  cliente: string,
  input: ResolveClienteLogoUrlInput = {}
): string {
  const basePath = trimBasePath(input.basePath ?? '/images');
  const code = normalizeClienteCode(cliente) || 'DEMO';
  const prefix = basePath ? `${basePath}/` : '/';
  return `${prefix}${code}.jpg`;
}

/**
 * URL del logo fallback del producto host.
 */
export function resolveClienteDefaultLogoUrl(
  input: ResolveClienteLogoUrlInput = {}
): string {
  const basePath = trimBasePath(input.basePath ?? '/images');
  const fileName = input.defaultFileName?.trim() || defaultClienteLogoFileName;
  const prefix = basePath ? `${basePath}/` : '/';
  return `${prefix}${fileName}`;
}
