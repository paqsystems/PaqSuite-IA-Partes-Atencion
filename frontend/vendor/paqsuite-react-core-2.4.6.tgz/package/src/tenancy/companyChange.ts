export type CompanyChangeHandler = (companyId: string | number) => void;

const handlers = new Set<CompanyChangeHandler>();

/**
 * Registry para que hosts invaliden menú/caché al cambiar empresa (C1 D1-S3).
 */
export function registerOnCompanyChange(handler: CompanyChangeHandler): () => void {
  handlers.add(handler);
  return () => {
    handlers.delete(handler);
  };
}

export function notifyCompanyChange(companyId: string | number): void {
  for (const handler of handlers) {
    handler(companyId);
  }
}

/** Solo tests. */
export function clearCompanyChangeHandlers(): void {
  handlers.clear();
}
