import { beforeEach, describe, expect, it, vi } from 'vitest';
import { changeActiveEmpresa } from './changeActiveEmpresa';
import { clearCompanyChangeHandlers, registerOnCompanyChange } from './companyChange';
import { clearActiveEmpresaId, getActiveEmpresaId } from './empresaStorage';
import { postLoginHomePath } from './resolveEmpresaGate';

describe('changeActiveEmpresa', () => {
  beforeEach(() => {
    clearActiveEmpresaId();
    clearCompanyChangeHandlers();
  });

  it('persiste el id activo', () => {
    changeActiveEmpresa({ companyId: 3 });
    expect(getActiveEmpresaId()).toBe('3');
  });

  it('notifica a los handlers registrados', () => {
    const handler = vi.fn();
    registerOnCompanyChange(handler);
    changeActiveEmpresa({ companyId: 5 });
    expect(handler).toHaveBeenCalledWith(5);
  });

  it('navega al home post-login por default', () => {
    const onNavigate = vi.fn();
    changeActiveEmpresa({ companyId: 1, onNavigate });
    expect(onNavigate).toHaveBeenCalledWith(postLoginHomePath);
  });

  it('navega a ruta custom si se especifica', () => {
    const onNavigate = vi.fn();
    changeActiveEmpresa({ companyId: 1, onNavigate, navigateTo: '/otra' });
    expect(onNavigate).toHaveBeenCalledWith('/otra');
  });

  it('no falla si no se pasa onNavigate', () => {
    expect(() => changeActiveEmpresa({ companyId: 1 })).not.toThrow();
  });
});
