import { isSupportedLocale, type LocaleCode } from './localeCatalog';

/**
 * Extrae el primary language subtag BCP47 (2 letras, ej. "es-AR" → "es")
 * y lo valida contra la lista blanca GEN-02. Retorna null si está vacío,
 * mal formado o no soportado.
 */
export function normalizeLocale(value?: string | null): LocaleCode | null {
  if (!value) {
    return null;
  }

  const primary = value.trim().split(/[-_]/)[0]?.toLowerCase() ?? '';
  if (!/^[a-z]{2}$/.test(primary)) {
    return null;
  }

  return isSupportedLocale(primary) ? primary : null;
}
