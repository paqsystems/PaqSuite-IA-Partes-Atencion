export const guestLocaleStorageKey = 'paqGuestLocale';

type SimpleStorage = {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
};

function createMemoryStorage(): SimpleStorage {
  const memory = new Map<string, string>();
  return {
    getItem: (key) => (memory.has(key) ? (memory.get(key) as string) : null),
    setItem: (key, value) => {
      memory.set(key, value);
    },
    removeItem: (key) => {
      memory.delete(key);
    },
  };
}

/** Fallback en memoria para SSR/tests sin `localStorage`; en browser usa el real. */
const fallbackStorage = createMemoryStorage();

function resolveStorage(): SimpleStorage {
  if (typeof localStorage !== 'undefined') {
    return localStorage;
  }
  return fallbackStorage;
}

/** Idioma elegido por un usuario invitado (pre-login), persistido client-side (GEN-02). */
export function getGuestLocale(): string | null {
  return resolveStorage().getItem(guestLocaleStorageKey);
}

export function setGuestLocale(locale: string): void {
  resolveStorage().setItem(guestLocaleStorageKey, locale);
}

export function clearGuestLocale(): void {
  resolveStorage().removeItem(guestLocaleStorageKey);
}
