import { describe, expect, it } from 'vitest';
import { normalizeLocale } from './normalizeLocale';

describe('normalizeLocale', () => {
  it('extrae el primary subtag de "es-AR"', () => {
    expect(normalizeLocale('es-AR')).toBe('es');
  });

  it('acepta separador underscore', () => {
    expect(normalizeLocale('en_US')).toBe('en');
  });

  it('normaliza a minúsculas', () => {
    expect(normalizeLocale('PT-BR')).toBe('pt');
  });

  it('retorna null si es vacío, null o undefined', () => {
    expect(normalizeLocale(null)).toBeNull();
    expect(normalizeLocale(undefined)).toBeNull();
    expect(normalizeLocale('')).toBeNull();
  });

  it('retorna null si el primary subtag no es alfabético de 2 letras', () => {
    expect(normalizeLocale('spa')).toBeNull();
    expect(normalizeLocale('123')).toBeNull();
    expect(normalizeLocale('e')).toBeNull();
  });

  it('retorna null si el locale no está en la lista blanca', () => {
    expect(normalizeLocale('de')).toBeNull();
    expect(normalizeLocale('zh-CN')).toBeNull();
  });
});
