export const supportedLocales = ['es', 'en', 'pt', 'fr', 'it'] as const;

export type LocaleCode = (typeof supportedLocales)[number];

/** Type guard contra el catálogo soportado (GEN-02). */
export function isSupportedLocale(value: string): value is LocaleCode {
  return (supportedLocales as readonly string[]).includes(value);
}
