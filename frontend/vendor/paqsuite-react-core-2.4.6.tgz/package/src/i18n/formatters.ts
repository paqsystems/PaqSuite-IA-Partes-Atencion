/** Formatea fecha vía `Intl.DateTimeFormat` (GEN-02); acepta Date, ISO string o timestamp. */
export function formatDate(value: Date | string | number, locale: string): string {
  const date = value instanceof Date ? value : new Date(value);
  return new Intl.DateTimeFormat(locale).format(date);
}

/** Formatea número vía `Intl.NumberFormat` (GEN-02). */
export function formatNumber(value: number, locale: string): string {
  return new Intl.NumberFormat(locale).format(value);
}
