import { describe, expect, it } from 'vitest';
import { formatDate, formatNumber } from './formatters';

describe('formatDate', () => {
  it('formatea una fecha para locale es', () => {
    const result = formatDate(new Date(2026, 0, 15), 'es');
    expect(typeof result).toBe('string');
    expect(result.length).toBeGreaterThan(0);
  });

  it('acepta ISO string y timestamp', () => {
    expect(formatDate('2026-01-15T00:00:00Z', 'en').length).toBeGreaterThan(0);
    expect(formatDate(Date.now(), 'en').length).toBeGreaterThan(0);
  });
});

describe('formatNumber', () => {
  it('usa coma decimal en locale es', () => {
    expect(formatNumber(1234.5, 'es')).toContain(',');
  });

  it('usa punto decimal en locale en', () => {
    expect(formatNumber(1234.5, 'en')).toContain('.');
  });
});
