import { describe, expect, it, vi } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import { ShellLayout } from './ShellLayout';

vi.mock('devextreme-react/button', () => ({
  default: (props: { elementAttr?: Record<string, string> }) => (
    <button type="button" data-testid={props.elementAttr?.['data-testid']} />
  ),
}));

describe('ShellLayout footer', () => {
  it('publica {cliente} cuando el host lo pasa', () => {
    const html = renderToStaticMarkup(
      <ShellLayout
        brand="Partes"
        menuSlot={<nav>menu</nav>}
        footer={{
          cliente: 'PAQ',
          empresa: 'PaqSystems',
          user: 'Sesión: PQ',
          version: 'v1.1.0',
        }}
      >
        <p>main</p>
      </ShellLayout>
    );

    expect(html).toContain('data-testid="shellFooterCliente"');
    expect(html).toContain('PAQ');
    expect(html).toContain('data-testid="shellFooterEmpresa"');
    expect(html).toContain('PaqSystems');
  });
});
