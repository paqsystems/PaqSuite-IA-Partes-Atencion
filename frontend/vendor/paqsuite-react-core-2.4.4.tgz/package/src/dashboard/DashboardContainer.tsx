import Button from 'devextreme-react/button';
import type { ReactNode } from 'react';
import { EmptyState } from '../ui/states/EmptyState';
import { ErrorState } from '../ui/states/ErrorState';
import { LoadingOverlay } from '../ui/states/LoadingOverlay';
import type { DashboardWidget } from './dashboardRegistry';

export type DashboardContainerProps = {
  loading?: boolean;
  error?: string | null;
  widgets?: DashboardWidget[];
  onRefresh?: () => void;
  emptyTitle: ReactNode;
  emptyDescription?: ReactNode;
};

/**
 * Contenedor dashboard GEN-09. Controles interactivos DevExtreme (`Button`).
 * Precedencia: loading → error → empty → grid widgets.
 */
export function DashboardContainer({
  loading = false,
  error = null,
  widgets = [],
  onRefresh,
  emptyTitle,
  emptyDescription,
}: DashboardContainerProps) {
  return (
    <div data-testid="dashboardContainer">
      {onRefresh ? (
        <Button
          text="Actualizar"
          onClick={onRefresh}
          elementAttr={{ 'data-testid': 'dashboardRefresh' }}
        />
      ) : null}
      {loading ? (
        <LoadingOverlay />
      ) : error ? (
        <ErrorState title={error} onRetry={onRefresh} />
      ) : widgets.length === 0 ? (
        <EmptyState title={emptyTitle} description={emptyDescription} />
      ) : (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: '1rem',
          }}
        >
          {widgets.map((widget) => (
            <div key={widget.id}>
              <h3>{widget.title}</h3>
              {widget.render()}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
