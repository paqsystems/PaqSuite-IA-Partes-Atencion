import { beforeEach, describe, expect, it } from 'vitest';
import { clearWidgets, listWidgets, registerWidget } from './dashboardRegistry';

describe('dashboardRegistry', () => {
  beforeEach(() => {
    clearWidgets();
  });

  it('lista vacía sin widgets registrados', () => {
    expect(listWidgets()).toEqual([]);
  });

  it('registra y lista widgets', () => {
    registerWidget({ id: 'w1', title: 'Widget 1', render: () => null });
    registerWidget({ id: 'w2', title: 'Widget 2', render: () => null });
    expect(listWidgets().map((w) => w.id)).toEqual(['w1', 'w2']);
  });

  it('reemplaza un widget con el mismo id', () => {
    registerWidget({ id: 'w1', title: 'Original', render: () => null });
    registerWidget({ id: 'w1', title: 'Actualizado', render: () => null });
    expect(listWidgets()).toHaveLength(1);
    expect(listWidgets()[0].title).toBe('Actualizado');
  });

  it('clearWidgets vacía el registro', () => {
    registerWidget({ id: 'w1', title: 'Widget 1', render: () => null });
    clearWidgets();
    expect(listWidgets()).toEqual([]);
  });
});
