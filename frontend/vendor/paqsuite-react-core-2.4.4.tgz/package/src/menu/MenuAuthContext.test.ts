import { describe, expect, it } from 'vitest';
import { findMenuProcessByRoute } from './MenuAuthContext';
import type { MenuNode } from './menuTypes';

describe('findMenuProcessByRoute', () => {
  const tree: MenuNode[] = [
    {
      id: 1,
      menuKey: 'seguridad',
      labelKey: null,
      text: 'Seguridad',
      routeName: null,
      procedimiento: null,
      order: 1,
      nodeType: 'group',
      iconName: null,
      processType: null,
      permissions: null,
      children: [
        {
          id: 2,
          menuKey: 'admin_roles',
          labelKey: null,
          text: 'Roles',
          routeName: '/admin/roles',
          procedimiento: null,
          order: 1,
          nodeType: 'process',
          iconName: null,
          processType: 'A',
          permissions: { create: true, delete: false, update: true, report: false },
          children: [],
        },
      ],
    },
  ];

  it('encuentra el process por routeName', () => {
    const node = findMenuProcessByRoute(tree, '/admin/roles');
    expect(node?.menuKey).toBe('admin_roles');
    expect(node?.permissions?.create).toBe(true);
  });

  it('normaliza trailing slash', () => {
    expect(findMenuProcessByRoute(tree, '/admin/roles/')?.menuKey).toBe('admin_roles');
  });

  it('null si no hay match', () => {
    expect(findMenuProcessByRoute(tree, '/admin/usuarios')).toBeNull();
  });
});
