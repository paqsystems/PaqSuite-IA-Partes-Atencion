import { describe, expect, it } from 'vitest';
import { filterMenuBySearch } from './filterMenuBySearch';
import { flattenOperationalMenu } from './flattenOperationalMenu';
import { foldMenuSearchText, menuSearchMatches } from './menuSearchAccentFold';
import type { MenuNode } from './menuTypes';

function node(
  partial: Partial<MenuNode> & Pick<MenuNode, 'id' | 'menuKey' | 'text' | 'nodeType'>,
): MenuNode {
  return {
    labelKey: null,
    routeName: null,
    procedimiento: null,
    order: partial.id,
    iconName: null,
    processType: null,
    permissions: null,
    children: [],
    ...partial,
  };
}

describe('menuSearchAccentFold', () => {
  it('pliega acentos y mayúsculas', () => {
    expect(foldMenuSearchText('Informes')).toBe('informes');
    expect(foldMenuSearchText('Atención')).toBe('atencion');
    expect(menuSearchMatches('Consulta detallada', 'detall')).toBe(true);
  });
});

describe('filterMenuBySearch', () => {
  const tree: MenuNode[] = [
    node({
      id: 1,
      menuKey: 'archivos',
      text: 'Archivos',
      nodeType: 'group',
      children: [
        node({
          id: 2,
          menuKey: 'clientes',
          text: 'Clientes',
          nodeType: 'process',
          routeName: '/archivos/clientes',
        }),
        node({
          id: 3,
          menuKey: 'asistentes',
          text: 'Asistentes',
          nodeType: 'process',
          routeName: '/archivos/asistentes',
        }),
      ],
    }),
  ];

  it('conserva ancestros de coincidencias', () => {
    const filtered = filterMenuBySearch(tree, 'client');
    expect(filtered).toHaveLength(1);
    expect(filtered[0].menuKey).toBe('archivos');
    expect(filtered[0].children.map((child) => child.menuKey)).toEqual(['clientes']);
  });

  it('sin query devuelve el árbol intacto', () => {
    expect(filterMenuBySearch(tree, '  ')).toEqual(tree);
  });
});

describe('flattenOperationalMenu', () => {
  it('deja solo process con ruta', () => {
    const flat = flattenOperationalMenu([
      node({
        id: 10,
        menuKey: 'partes',
        text: 'Partes',
        nodeType: 'group',
        children: [
          node({
            id: 11,
            menuKey: 'carga',
            text: 'Carga diaria',
            nodeType: 'process',
            routeName: '/partes/carga-diaria',
            order: 2,
          }),
          node({
            id: 12,
            menuKey: 'grupo_vacio',
            text: 'Sin ruta',
            nodeType: 'process',
            order: 1,
          }),
        ],
      }),
    ]);
    expect(flat.map((item) => item.menuKey)).toEqual(['carga']);
  });
});
