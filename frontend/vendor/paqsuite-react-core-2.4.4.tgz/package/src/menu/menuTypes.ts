export type MenuPermissions = {
  create: boolean;
  delete: boolean;
  update: boolean;
  report: boolean;
};

export type MenuNode = {
  id: number;
  menuKey: string;
  labelKey: string | null;
  text: string;
  routeName: string | null;
  procedimiento: string | null;
  order: number;
  nodeType: 'process' | 'group';
  iconName: string | null;
  processType: string | null;
  permissions: MenuPermissions | null;
  children: MenuNode[];
};

export type MenuResultado = {
  items: MenuNode[];
};
