import { describe, expect, it } from 'vitest';
import { filterMenuForMobile, isMenuKeyAllowedOnMobile } from './mobileMenuPolicy';

describe('mobileMenuPolicy', () => {
  it('excluye admin y pivot en mobile', () => {
    expect(isMenuKeyAllowedOnMobile('dashboard')).toBe(true);
    expect(isMenuKeyAllowedOnMobile('admin-usuarios')).toBe(false);
    expect(isMenuKeyAllowedOnMobile('pivot')).toBe(false);
  });

  it('filtra árbol recursivamente', () => {
    const filtered = filterMenuForMobile([
      {
        menuKey: 'seguridad',
        children: [
          { menuKey: 'admin-usuarios', children: [] },
          { menuKey: 'dashboard', children: [] },
        ],
      },
    ]);

    expect(filtered).toHaveLength(1);
    expect(filtered[0]?.children).toHaveLength(1);
    expect(filtered[0]?.children[0]?.menuKey).toBe('dashboard');
  });
});
