import {
  createContext,
  useContext,
  useMemo,
  type ReactNode,
} from 'react';
import type { MenuNode, MenuPermissions } from './menuTypes';

export type MenuAuthContextValue = {
  items: MenuNode[];
  setItems: (items: MenuNode[]) => void;
};

const MenuAuthContext = createContext<MenuAuthContextValue | null>(null);

export function MenuAuthProvider({
  children,
  value,
}: {
  children: ReactNode;
  value: MenuAuthContextValue;
}) {
  return <MenuAuthContext.Provider value={value}>{children}</MenuAuthContext.Provider>;
}

export function useMenuAuth(): MenuAuthContextValue | null {
  return useContext(MenuAuthContext);
}

export function findMenuProcessByRoute(
  nodes: MenuNode[],
  routeName: string
): MenuNode | null {
  const normalized = routeName.replace(/\/+$/, '') || '/';
  for (const node of nodes) {
    if (node.nodeType === 'process' && node.routeName) {
      const nodeRoute = node.routeName.replace(/\/+$/, '') || '/';
      if (nodeRoute === normalized) {
        return node;
      }
    }
    const child = findMenuProcessByRoute(node.children ?? [], routeName);
    if (child) {
      return child;
    }
  }
  return null;
}

/**
 * Permisos del proceso de menú que coincide con la ruta actual (o `routeName` explícita).
 * `null` si aún no hay menú / no hay nodo process para esa ruta.
 */
export function useMenuProcessPermissions(routeName?: string): MenuPermissions | null {
  const auth = useMenuAuth();
  return useMemo(() => {
    if (!auth || auth.items.length === 0) {
      return null;
    }
    const route =
      routeName ??
      (typeof window !== 'undefined' ? window.location.pathname : '');
    if (!route) {
      return null;
    }
    const process = findMenuProcessByRoute(auth.items, route);
    return process?.permissions ?? null;
  }, [auth, routeName]);
}
