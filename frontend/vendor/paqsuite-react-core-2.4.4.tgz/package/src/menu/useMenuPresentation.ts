import { useCallback, useEffect, useState } from 'react';
import {
  defaultMenuPresentationState,
  readMenuPresentationState,
  writeMenuPresentationState,
  type MenuDisplayMode,
  type MenuPresentationState,
} from './menuPresentationStorage';

function resolveInitialState(
  appId: string,
  userId: number | null,
): MenuPresentationState {
  if (userId === null) {
    return { ...defaultMenuPresentationState };
  }
  return readMenuPresentationState(appId, userId);
}

/**
 * Preferencias de presentación del menú (localStorage por usuario).
 * Sync servidor GET/PATCH `/user/preferences` queda como follow-up de TR-GEN-07.
 */
export function useMenuPresentation(userId: number | null, appId = 'paqsuite') {
  const [state, setState] = useState<MenuPresentationState>(() =>
    resolveInitialState(appId, userId),
  );

  useEffect(() => {
    setState(resolveInitialState(appId, userId));
  }, [appId, userId]);

  const persistState = useCallback(
    (updater: MenuPresentationState | ((current: MenuPresentationState) => MenuPresentationState)) => {
      setState((current) => {
        const nextState = typeof updater === 'function' ? updater(current) : updater;
        if (userId !== null) {
          writeMenuPresentationState(appId, userId, nextState);
        }
        return nextState;
      });
    },
    [appId, userId],
  );

  const toggleSidebarVisible = useCallback(() => {
    persistState((current) => ({
      ...current,
      sidebarVisible: !current.sidebarVisible,
    }));
  }, [persistState]);

  const toggleMenuTreeExpanded = useCallback(() => {
    persistState((current) => ({
      ...current,
      menuTreeExpanded: !current.menuTreeExpanded,
    }));
  }, [persistState]);

  const toggleMenuDisplayMode = useCallback(() => {
    persistState((current) => {
      const nextMode: MenuDisplayMode =
        current.menuDisplayMode === 'allBranches' ? 'operationalOnly' : 'allBranches';
      return {
        ...current,
        menuDisplayMode: nextMode,
      };
    });
  }, [persistState]);

  return {
    sidebarVisible: state.sidebarVisible,
    menuTreeExpanded: state.menuTreeExpanded,
    menuDisplayMode: state.menuDisplayMode,
    toggleSidebarVisible,
    toggleMenuTreeExpanded,
    toggleMenuDisplayMode,
  };
}
