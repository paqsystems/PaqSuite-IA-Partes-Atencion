import Button from 'devextreme-react/button';
import type { MenuDisplayMode } from './menuPresentationStorage';

export type MenuToolbarControlsLabels = {
  controls: string;
  toggleVisible: string;
  toggleExpand: string;
  expandAll: string;
  collapseAll: string;
  toggleDisplayMode: string;
  viewOperational: string;
  viewAllBranches: string;
};

export const defaultMenuToolbarLabels: MenuToolbarControlsLabels = {
  controls: 'Controles de menú',
  toggleVisible: 'Mostrar u ocultar menú',
  toggleExpand: 'Expandir o contraer ramas',
  expandAll: 'Expandir todas las ramas',
  collapseAll: 'Contraer todas las ramas',
  toggleDisplayMode: 'Con o sin ramificación',
  viewOperational: 'Ver solo opciones operativas',
  viewAllBranches: 'Ver todas las ramas',
};

export type MenuToolbarControlsProps = {
  menuTreeExpanded: boolean;
  menuDisplayMode: MenuDisplayMode;
  onToggleSidebar: () => void;
  onToggleExpandAll: () => void;
  onToggleDisplayMode: () => void;
  labels?: Partial<MenuToolbarControlsLabels>;
  /** Oculta expand/ramificación (p. ej. native compacto). */
  compact?: boolean;
};

/**
 * Tres botones icon-only del sidebar (GEN-07 / SPEC-001-07).
 */
export function MenuToolbarControls({
  menuTreeExpanded,
  menuDisplayMode,
  onToggleSidebar,
  onToggleExpandAll,
  onToggleDisplayMode,
  labels: labelsPartial,
  compact = false,
}: MenuToolbarControlsProps) {
  const labels = { ...defaultMenuToolbarLabels, ...labelsPartial };

  return (
    <div className="paqMenuToolbar" aria-label={labels.controls} data-testid="menuToolbar">
      <Button
        icon="menu"
        stylingMode="contained"
        className="paqMenuToolbarButton"
        hint={labels.toggleVisible}
        elementAttr={{
          'data-testid': 'menuToggleVisible',
          'aria-label': labels.toggleVisible,
        }}
        onClick={onToggleSidebar}
      />
      {!compact ? (
        <>
          <Button
            icon={menuTreeExpanded ? 'collapse' : 'expand'}
            stylingMode="contained"
            className="paqMenuToolbarButton"
            hint={menuTreeExpanded ? labels.collapseAll : labels.expandAll}
            elementAttr={{
              'data-testid': 'menuToggleExpand',
              'aria-label': labels.toggleExpand,
              'aria-pressed': String(menuTreeExpanded),
            }}
            onClick={onToggleExpandAll}
          />
          <Button
            icon={menuDisplayMode === 'operationalOnly' ? 'bulletlist' : 'hierarchy'}
            stylingMode="contained"
            className="paqMenuToolbarButton"
            hint={
              menuDisplayMode === 'operationalOnly'
                ? labels.viewAllBranches
                : labels.viewOperational
            }
            elementAttr={{
              'data-testid': 'menuToggleDisplayMode',
              'aria-label': labels.toggleDisplayMode,
              'aria-pressed': String(menuDisplayMode === 'operationalOnly'),
            }}
            onClick={onToggleDisplayMode}
          />
        </>
      ) : null}
    </div>
  );
}
