/**
 * Normaliza texto para búsqueda de menú: minúsculas + fold de acentos (CA-04).
 */
export function foldMenuSearchText(value: string): string {
  return value
    .normalize('NFD')
    .replace(/\p{M}/gu, '')
    .toLocaleLowerCase();
}

export function menuSearchMatches(haystack: string, queryFolded: string): boolean {
  if (queryFolded.length === 0) {
    return true;
  }
  return foldMenuSearchText(haystack).includes(queryFolded);
}
