import type { MenuNode } from './menuTypes';
import { foldMenuSearchText, menuSearchMatches } from './menuSearchAccentFold';

/**
 * Filtra el árbol por caption; conserva ancestros de coincidencias.
 * Si el propio nodo coincide, se conserva con todos sus hijos.
 */
export function filterMenuBySearch(menuItems: MenuNode[], rawQuery: string): MenuNode[] {
  const queryFolded = foldMenuSearchText(rawQuery.trim());
  if (queryFolded.length === 0) {
    return menuItems;
  }

  function walk(nodes: MenuNode[]): MenuNode[] {
    const result: MenuNode[] = [];

    for (const node of nodes) {
      const selfMatch = menuSearchMatches(node.text, queryFolded);
      const filteredChildren = walk(node.children ?? []);

      if (selfMatch) {
        result.push(node);
        continue;
      }

      if (filteredChildren.length > 0) {
        result.push({ ...node, children: filteredChildren });
      }
    }

    return result;
  }

  return walk(menuItems);
}
