import { useEffect, useMemo, useRef, useState } from 'react';
import Button from 'devextreme-react/button';
import LoadPanel from 'devextreme-react/load-panel';
import TextBox from 'devextreme-react/text-box';
import TreeView from 'devextreme-react/tree-view';
import type dxTreeView from 'devextreme/ui/tree_view';
import { apiRequest } from '../http/apiClient';
import type { BuildPlatformHeadersInput } from '../http/headers';
import { filterMenuBySearch } from './filterMenuBySearch';
import { flattenOperationalMenu } from './flattenOperationalMenu';
import type { MenuNode, MenuResultado } from './menuTypes';
import {
  defaultMenuToolbarLabels,
  MenuToolbarControls,
  type MenuToolbarControlsLabels,
} from './MenuToolbarControls';
import { useMenuPresentation } from './useMenuPresentation';

/** Debounce de filtrado de búsqueda (SPEC GEN-07, incremental). */
export const menuSearchDebounceMs = 300;

export type MenuSidebarLabels = MenuToolbarControlsLabels & {
  searchPlaceholder: string;
  empty: string;
  loadError: string;
  retry: string;
};

export const defaultMenuSidebarLabels: MenuSidebarLabels = {
  ...defaultMenuToolbarLabels,
  searchPlaceholder: 'Buscar en el menú…',
  empty: 'No hay opciones de menú disponibles.',
  loadError: 'No se pudo cargar el menú.',
  retry: 'Reintentar',
};

export type MenuSidebarProps = {
  platform: BuildPlatformHeadersInput;
  className?: string;
  /** Bearer Sanctum — Must para `/api/v1/user/menu` autenticado. */
  accessToken?: string | null;
  /** Persistencia local de presentación (por usuario). Ignorado si `presentation` viene controlado. */
  userId?: number | null;
  /** Prefijo localStorage (p. ej. `partes`, `pedidosweb`). */
  storageAppId?: string;
  /** Controles externos (p. ej. shell header); si falta, el sidebar gestiona estado interno. */
  presentation?: ReturnType<typeof useMenuPresentation>;
  onNavigate?: (routeName: string) => void;
  /** Filtro de producto tras la API (p. ej. AC cliente / mobile). */
  transformItems?: (items: MenuNode[]) => MenuNode[];
  /** Notifica el árbol (post-transform) al shell / MenuAuthProvider. */
  onItemsLoaded?: (items: MenuNode[]) => void;
  labels?: Partial<MenuSidebarLabels>;
  /** Notifica al shell para colapsar el panel (solo modo no controlado). */
  onSidebarVisibleChange?: (visible: boolean) => void;
};

type TreeItem = {
  id: string | number;
  text: string;
  menuKey: string;
  routeName?: string | null;
  nodeType: string;
  items?: TreeItem[];
};

function toTreeItems(nodes: MenuNode[]): TreeItem[] {
  return nodes.map((node) => ({
    id: node.id,
    text: node.text,
    menuKey: node.menuKey,
    routeName: node.routeName,
    nodeType: node.nodeType,
    items: node.children.length > 0 ? toTreeItems(node.children) : undefined,
  }));
}

function platformFetchKey(platform: BuildPlatformHeadersInput): string {
  return `${platform.cliente}|${platform.companyId ?? ''}|${platform.tenancy ?? ''}`;
}

/**
 * Sidebar menú DevExtreme — GEN-07: toolbar (3 botones) + búsqueda + TreeView.
 * La API se pide solo al montar / cambio de empresa-token / retry; los toggles operan en memoria.
 */
export function MenuSidebar({
  platform,
  className,
  accessToken,
  userId = null,
  storageAppId = 'paqsuite',
  presentation: presentationProp,
  onNavigate,
  transformItems,
  onItemsLoaded,
  labels: labelsPartial,
  onSidebarVisibleChange,
}: MenuSidebarProps) {
  const labels = { ...defaultMenuSidebarLabels, ...labelsPartial };
  const [rawItems, setRawItems] = useState<MenuNode[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchInput, setSearchInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [reloadToken, setReloadToken] = useState(0);
  const treeViewRef = useRef<dxTreeView | null>(null);
  const platformRef = useRef(platform);
  platformRef.current = platform;

  const fetchKey = platformFetchKey(platform);

  const internalPresentation = useMenuPresentation(
    presentationProp ? null : userId,
    storageAppId,
  );
  const presentation = presentationProp ?? internalPresentation;

  useEffect(() => {
    if (presentationProp) {
      return;
    }
    onSidebarVisibleChange?.(presentation.sidebarVisible);
  }, [onSidebarVisibleChange, presentation.sidebarVisible, presentationProp]);

  useEffect(() => {
    const handle = window.setTimeout(() => {
      setSearchQuery(searchInput);
    }, menuSearchDebounceMs);
    return () => window.clearTimeout(handle);
  }, [searchInput]);

  useEffect(() => {
    let cancelled = false;

    if (!accessToken) {
      setErrorMessage(labels.loadError);
      setLoading(false);
      return;
    }

    setLoading(true);
    apiRequest<MenuResultado>('/api/v1/user/menu', {
      platform: platformRef.current,
      headers: { Authorization: `Bearer ${accessToken}` },
    })
      .then((payload) => {
        if (cancelled) {
          return;
        }
        if (payload.kind === 'ok') {
          setRawItems(payload.envelope.resultado.items ?? []);
          setErrorMessage(null);
        } else if (payload.kind === 'envelopeError') {
          setErrorMessage(payload.envelope.respuesta || labels.loadError);
        } else {
          setErrorMessage(payload.i18nKey || labels.loadError);
        }
      })
      .catch((error: unknown) => {
        if (!cancelled) {
          setErrorMessage(error instanceof Error ? error.message : labels.loadError);
        }
      })
      .finally(() => {
        if (!cancelled) {
          setLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
    // Solo re-fetch por token / empresa-instalación / retry — no por toggles ni labels.
    // eslint-disable-next-line react-hooks/exhaustive-deps -- labels.loadError es texto i18n; no debe forzar GET
  }, [accessToken, fetchKey, reloadToken]);

  const items = useMemo(() => {
    if (!transformItems) {
      return rawItems;
    }
    return transformItems(rawItems);
  }, [rawItems, transformItems]);

  useEffect(() => {
    onItemsLoaded?.(items);
  }, [items, onItemsLoaded]);

  const visibleNodes = useMemo(() => {
    const searched = filterMenuBySearch(items, searchQuery);
    if (presentation.menuDisplayMode === 'operationalOnly') {
      return flattenOperationalMenu(searched);
    }
    return searched;
  }, [items, presentation.menuDisplayMode, searchQuery]);

  const treeItems = useMemo(() => toTreeItems(visibleNodes), [visibleNodes]);

  useEffect(() => {
    const instance = treeViewRef.current;
    if (!instance || presentation.menuDisplayMode === 'operationalOnly') {
      return;
    }

    if (presentation.menuTreeExpanded) {
      instance.expandAll();
      return;
    }

    instance.collapseAll();
  }, [presentation.menuDisplayMode, presentation.menuTreeExpanded, treeItems]);

  return (
    <nav className={className ?? 'paqMenuSidebar'} data-testid="menuSidebar">
      <MenuToolbarControls
        menuTreeExpanded={presentation.menuTreeExpanded}
        menuDisplayMode={presentation.menuDisplayMode}
        onToggleSidebar={presentation.toggleSidebarVisible}
        onToggleExpandAll={presentation.toggleMenuTreeExpanded}
        onToggleDisplayMode={presentation.toggleMenuDisplayMode}
        labels={labels}
      />
      <TextBox
        value={searchInput}
        valueChangeEvent="input"
        onValueChanged={(event) => setSearchInput(String(event.value ?? ''))}
        placeholder={labels.searchPlaceholder}
        mode="search"
        showClearButton
        stylingMode="outlined"
        elementAttr={{ 'data-testid': 'menuSearch' }}
        className="paqMenuSearch"
      />
      <LoadPanel
        visible={loading}
        showIndicator
        showPane
        shading={false}
        message="Cargando…"
        position={{ of: '.paqMenuSidebar' }}
      />
      {errorMessage ? (
        <div className="paqMenuState" data-testid="menuLoadError">
          <p className="error">{errorMessage}</p>
          <Button
            text={labels.retry}
            stylingMode="outlined"
            elementAttr={{ 'data-testid': 'menuRetry' }}
            onClick={() => setReloadToken((token) => token + 1)}
          />
        </div>
      ) : null}
      {!loading && !errorMessage && treeItems.length === 0 ? (
        <p className="paqMenuState" data-testid="menuEmpty">
          {labels.empty}
        </p>
      ) : null}
      {!loading && !errorMessage && treeItems.length > 0 ? (
        <TreeView
          ref={(component) => {
            treeViewRef.current = component?.instance() ?? null;
          }}
          items={treeItems}
          dataStructure="tree"
          keyExpr="menuKey"
          displayExpr="text"
          itemsExpr="items"
          focusStateEnabled
          selectByClick
          expandEvent="click"
          onItemClick={(event) => {
            const data = event.itemData as TreeItem | undefined;
            if (data?.nodeType === 'process' && data.routeName) {
              onNavigate?.(data.routeName);
            }
          }}
          itemRender={(item: TreeItem) => (
            <span data-testid={`menuNode-${item.menuKey}`}>{item.text}</span>
          )}
          elementAttr={{ 'data-testid': 'menuSidebarTree' }}
          className="paqMenuTree"
        />
      ) : null}
    </nav>
  );
}
