import type { MenuNode } from './menuTypes';

/** Solo hojas `process` con ruta (D1-07-10). */
export function flattenOperationalMenu(menuItems: MenuNode[]): MenuNode[] {
  const flattened: MenuNode[] = [];

  function walk(nodes: MenuNode[]) {
    for (const node of nodes) {
      if (node.nodeType === 'process' && node.routeName) {
        flattened.push({
          ...node,
          children: [],
        });
      }
      if (node.children.length > 0) {
        walk(node.children);
      }
    }
  }

  walk(menuItems);
  return flattened.sort((left, right) => left.order - right.order);
}

export function collectAllGroupMenuKeys(menuItems: MenuNode[]): string[] {
  const keys: string[] = [];

  function walk(nodes: MenuNode[]) {
    for (const node of nodes) {
      if (node.nodeType === 'group') {
        keys.push(node.menuKey);
      }
      if (node.children.length > 0) {
        walk(node.children);
      }
    }
  }

  walk(menuItems);
  return keys;
}
