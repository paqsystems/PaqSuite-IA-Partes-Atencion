/**
 * Exclusiones mobile por menuKey (compat GEN-07).
 * Preferir `createMobilePolicy` / `filterMenuItemsForMobile` (GEN-22, rutas).
 */
const mobileExcludedMenuKeys = new Set([
  'excel-import',
  'pivot',
  'admin-usuarios',
  'admin-roles',
  'admin-permisos',
  'admin-empresas',
]);

export function isMenuKeyAllowedOnMobile(menuKey: string): boolean {
  return !mobileExcludedMenuKeys.has(menuKey);
}

export function filterMenuForMobile<T extends { menuKey: string; children?: T[] }>(
  nodes: T[]
): T[] {
  return nodes
    .filter((node) => isMenuKeyAllowedOnMobile(node.menuKey))
    .map((node) => ({
      ...node,
      children: node.children ? filterMenuForMobile(node.children) : [],
    }))
    .filter(
      (node) =>
        (node.children?.length ?? 0) > 0 || isMenuKeyAllowedOnMobile(node.menuKey)
    );
}
