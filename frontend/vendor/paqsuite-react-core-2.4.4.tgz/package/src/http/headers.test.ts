import { describe, expect, it } from 'vitest';
import {
  buildPlatformHeaders,
  clienteHeaderName,
  companyHeaderName,
} from './headers';

describe('buildPlatformHeaders', () => {
  it('siempre incluye X-Paq-Cliente', () => {
    const headers = buildPlatformHeaders({ cliente: 'demo' });
    expect(headers[clienteHeaderName]).toBe('demo');
    expect(headers[companyHeaderName]).toBeUndefined();
  });

  it('incluye X-Company-Id cuando se informa', () => {
    const headers = buildPlatformHeaders({
      cliente: 'acme',
      companyId: 8,
      tenancy: 'multi',
    });
    expect(headers[clienteHeaderName]).toBe('acme');
    expect(headers[companyHeaderName]).toBe('8');
  });
});
