import { describe, expect, it } from 'vitest';
import { isEnvelope, parseEnvelope, transportI18nKey } from './parseEnvelope';

describe('parseEnvelope', () => {
  it('acepta envelope válido', () => {
    const value = {
      error: 0,
      respuesta: 'ok',
      resultado: { status: 'up' },
    };
    expect(isEnvelope(value)).toBe(true);
    expect(parseEnvelope(value)).toEqual(value);
  });

  it('rechaza resultado null', () => {
    expect(
      isEnvelope({ error: 0, respuesta: 'ok', resultado: null })
    ).toBe(false);
  });

  it('rechaza error booleano', () => {
    expect(
      isEnvelope({ error: false, respuesta: 'ok', resultado: {} })
    ).toBe(false);
  });

  it('rechaza resultado array', () => {
    expect(
      isEnvelope({ error: 0, respuesta: 'ok', resultado: [] })
    ).toBe(false);
  });

  it('exporta clave de transporte', () => {
    expect(transportI18nKey).toBe('infra.transport');
  });
});
