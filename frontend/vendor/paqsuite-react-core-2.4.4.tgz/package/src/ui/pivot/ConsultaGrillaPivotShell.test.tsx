import { describe, expect, it, vi } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import type { PivotConsultaCatalogDto } from './pivotCatalogClient';
import { ConsultaGrillaPivotShell } from './ConsultaGrillaPivotShell';

vi.mock('../../mobile/isNativeApp', () => ({
  isNativeApp: () => false,
}));

vi.mock('./PivotGridBlock', () => ({
  PivotGridBlock: () => <div data-testid="pivot.gridBlock.mock" />,
}));

vi.mock('./PivotViewToggle', () => ({
  PivotViewToggle: ({ value }: { value: string }) => (
    <div data-testid="pivot.toggle">toggle:{value}</div>
  ),
}));

const catalog: PivotConsultaCatalogDto = {
  consultaId: 'consultaSmokePivot',
  mostrarGrillaYPivot: true,
  soloPivot: false,
  campos: [
    { dataField: 'importe', dataType: 'number', nombreVisible: 'Importe' },
  ],
};

describe('ConsultaGrillaPivotShell', () => {
  it('starts in grid and does not mount pivot block', () => {
    const loadPivotDataset = vi.fn(async () => [{ importe: 1 }]);

    const html = renderToStaticMarkup(
      <ConsultaGrillaPivotShell
        consultaId="consultaSmokePivot"
        catalog={catalog}
        gridView={<div data-testid="host.grid">grilla</div>}
        loadPivotDataset={loadPivotDataset}
        initialView="grid"
      />
    );

    expect(html).toContain('pivot.shell');
    expect(html).toContain('pivot.shell.grid');
    expect(html).toContain('host.grid');
    expect(html).not.toContain('pivot.shell.pivot');
    expect(html).not.toContain('pivot.gridBlock.mock');
    expect(loadPivotDataset).not.toHaveBeenCalled();
  });

  it('soloPivot mounts pivot without grid', () => {
    const loadPivotDataset = vi.fn(async () => []);
    const html = renderToStaticMarkup(
      <ConsultaGrillaPivotShell
        consultaId="consultaSmokePivot"
        catalog={{ ...catalog, soloPivot: true, mostrarGrillaYPivot: false }}
        gridView={<div data-testid="host.grid">grilla</div>}
        loadPivotDataset={loadPivotDataset}
      />
    );

    expect(html).toContain('pivot.shell.pivot');
    expect(html).not.toContain('pivot.shell.grid');
    expect(html).not.toContain('pivot.toggle');
  });

  it('pivotsEnabled false renders only gridView', () => {
    const html = renderToStaticMarkup(
      <ConsultaGrillaPivotShell
        consultaId="consultaSmokePivot"
        catalog={catalog}
        gridView={<div data-testid="host.grid">grilla</div>}
        loadPivotDataset={async () => []}
        pivotsEnabled={false}
      />
    );

    expect(html).toContain('host.grid');
    expect(html).not.toContain('pivot.shell');
  });
});
