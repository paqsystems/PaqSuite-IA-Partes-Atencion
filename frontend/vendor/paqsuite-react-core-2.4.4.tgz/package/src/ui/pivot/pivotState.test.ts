import { describe, expect, it } from 'vitest';
import { applyPivotState, capturePivotState } from './pivotState';

describe('pivotState', () => {
  it('applyPivotState null resets', () => {
    expect(applyPivotState({ fields: [] }, null)).toBeNull();
  });

  it('applyPivotState parses json', () => {
    const next = applyPivotState(null, JSON.stringify({ fields: [{ dataField: 'a' }] }));
    expect(next).toEqual({ fields: [{ dataField: 'a' }] });
  });

  it('capturePivotState serializes', () => {
    expect(JSON.parse(capturePivotState({ fields: [] }))).toEqual({ fields: [] });
  });
});
