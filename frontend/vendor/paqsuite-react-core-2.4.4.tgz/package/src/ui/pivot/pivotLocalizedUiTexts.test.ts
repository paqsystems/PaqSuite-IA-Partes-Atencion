import { describe, expect, it } from 'vitest';
import { syncDevExtremeLocale } from '../../i18n/syncDevExtremeLocale';
import { getPivotLocalizedUiTexts } from './pivotLocalizedUiTexts';

describe('getPivotLocalizedUiTexts', () => {
  it('returns Spanish sector labels for es', () => {
    const texts = getPivotLocalizedUiTexts('es');
    expect(texts.fieldChooser.allFields.toLowerCase()).toContain('campo');
    expect(texts.fieldChooser.rowFields.toLowerCase()).toContain('fila');
    expect(texts.fieldChooserTitle.toLowerCase()).toContain('selector');
  });

  it('switches sector labels when locale changes', () => {
    const es = getPivotLocalizedUiTexts('es');
    const en = getPivotLocalizedUiTexts('en');
    expect(en.fieldChooser.allFields).toBe('All Fields');
    expect(en.fieldChooser.allFields).not.toBe(es.fieldChooser.allFields);
    syncDevExtremeLocale('es');
  });
});
