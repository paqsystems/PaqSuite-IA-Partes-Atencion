import { useState, type ReactNode } from 'react';
import Button from 'devextreme-react/button';
import SelectBox from 'devextreme-react/select-box';
import TextBox from 'devextreme-react/text-box';
import { Popup } from 'devextreme-react/popup';
import { PIVOT_LAYOUT_ORIGINAL_VALUE } from './pivotLayoutsClient';
import type { UsePivotLayoutsResult } from './usePivotLayouts';

export type PivotLayoutsToolbarLabels = {
  originalLabel: string;
  save: string;
  saveAs: string;
  delete: string;
  saveAsTitle: string;
  saveAsNameLabel: string;
  saveAsConfirm: string;
  saveAsCancel: string;
  ownerSuffix: string;
  saveAsError: string;
};

export const defaultPivotLayoutsToolbarLabels: PivotLayoutsToolbarLabels = {
  originalLabel: '<Original>',
  save: 'Guardar',
  saveAs: 'Guardar como…',
  delete: 'Eliminar',
  saveAsTitle: 'Guardar plantilla como…',
  saveAsNameLabel: 'Nombre',
  saveAsConfirm: 'Guardar',
  saveAsCancel: 'Cancelar',
  ownerSuffix: ' (*)',
  saveAsError: 'No se pudo guardar la plantilla. Revise el nombre o reintente.',
};

type PivotLayoutsToolbarControlsProps = {
  layouts: UsePivotLayoutsResult;
  labels?: Partial<PivotLayoutsToolbarLabels>;
  disabled?: boolean;
  onOpenSaveAs: () => void;
};

/**
 * Controles de plantillas GEN-12 para toolbar de PivotGrid
 * (Select + Guardar + Guardar como + Eliminar). Sin Popup interno.
 */
export function PivotLayoutsToolbarControls({
  layouts,
  labels: labelsPartial,
  disabled = false,
  onOpenSaveAs,
}: PivotLayoutsToolbarControlsProps) {
  const labels = { ...defaultPivotLayoutsToolbarLabels, ...labelsPartial };
  const busy = disabled || layouts.busy;

  async function handleSave() {
    if (layouts.selectedValue === PIVOT_LAYOUT_ORIGINAL_VALUE || !layouts.canDelete) {
      onOpenSaveAs();
      return;
    }
    const outcome = await layouts.save();
    if (outcome === 'saveAs') {
      onOpenSaveAs();
    }
  }

  return (
    <div
      data-testid="pivotLayoutToolbar"
      style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}
    >
      <SelectBox
        dataSource={layouts.items}
        value={layouts.selectedValue}
        valueExpr="value"
        displayExpr="displayName"
        width={220}
        disabled={busy}
        elementAttr={{ 'data-testid': 'pivot.layout.select' }}
        onValueChanged={(e) => {
          if (typeof e.value === 'string' && e.value !== layouts.selectedValue) {
            void layouts.selectLayout(e.value);
          }
        }}
      />
      <Button
        icon="save"
        hint={labels.save}
        stylingMode="text"
        disabled={busy || !layouts.canSave}
        onClick={() => void handleSave()}
        elementAttr={{ 'data-testid': 'pivot.layout.save' }}
      />
      <Button
        icon="copy"
        hint={labels.saveAs}
        stylingMode="text"
        disabled={busy}
        onClick={onOpenSaveAs}
        elementAttr={{ 'data-testid': 'pivot.layout.saveAs' }}
      />
      <Button
        icon="trash"
        hint={labels.delete}
        stylingMode="text"
        disabled={busy || !layouts.canDelete}
        onClick={() => void layouts.remove()}
        elementAttr={{ 'data-testid': 'pivot.layout.delete' }}
      />
    </div>
  );
}

type PivotLayoutSaveAsDialogProps = {
  visible: boolean;
  busy?: boolean;
  errorMessage?: string | null;
  labels?: Partial<PivotLayoutsToolbarLabels>;
  onHiding: () => void;
  onConfirm: (layoutName: string) => Promise<boolean> | boolean;
};

/**
 * Diálogo «Guardar como» — MUST montarse fuera del toolbar del PivotGrid.
 */
export function PivotLayoutSaveAsDialog({
  visible,
  busy = false,
  errorMessage = null,
  labels: labelsPartial,
  onHiding,
  onConfirm,
}: PivotLayoutSaveAsDialogProps): ReactNode {
  const labels = { ...defaultPivotLayoutsToolbarLabels, ...labelsPartial };
  const [saveAsName, setSaveAsName] = useState('');

  return (
    <Popup
      visible={visible}
      onHiding={onHiding}
      onShowing={() => setSaveAsName('')}
      title={labels.saveAsTitle}
      width={360}
      height="auto"
      showCloseButton
      dragEnabled
      hideOnOutsideClick
      wrapperAttr={{ class: 'pq-pivot-layout-save-as-popup' }}
      container={typeof document !== 'undefined' ? document.body : undefined}
    >
      <div style={{ display: 'grid', gap: 12, padding: 8 }} data-testid="pivot.layout.saveAsForm">
        <div style={{ display: 'grid', gap: 4 }}>
          <label>{labels.saveAsNameLabel}</label>
          <TextBox
            value={saveAsName}
            onValueChanged={(e) => setSaveAsName(String(e.value ?? ''))}
            elementAttr={{ 'data-testid': 'pivot.layout.saveAsName' }}
          />
        </div>
        {errorMessage ? (
          <div role="alert" data-testid="pivot.layout.saveAsError" style={{ color: '#b42318' }}>
            {errorMessage}
          </div>
        ) : null}
        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <Button text={labels.saveAsCancel} onClick={onHiding} />
          <Button
            text={labels.saveAsConfirm}
            type="default"
            disabled={!saveAsName.trim() || busy}
            onClick={() => {
              void Promise.resolve(onConfirm(saveAsName)).then((ok) => {
                if (ok) {
                  onHiding();
                }
              });
            }}
            elementAttr={{ 'data-testid': 'pivot.layout.saveAsConfirm' }}
          />
        </div>
      </div>
    </Popup>
  );
}
