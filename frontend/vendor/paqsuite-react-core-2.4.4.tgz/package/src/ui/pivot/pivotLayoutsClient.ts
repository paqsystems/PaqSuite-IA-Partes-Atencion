import { apiRequest, type ApiClientResult, type ApiRequestOptions } from '../../http/apiClient';

export type PivotLayoutListItem = {
  id: number;
  layoutName: string;
  isOwner: boolean;
  updatedAt: string;
};

export type PivotLayoutActiveDto = {
  layoutId: number | null;
  layoutName: string | null;
  stateJson: string | null;
};

type RequestOverrides = Pick<ApiRequestOptions, 'platform' | 'signal' | 'headers'>;

const basePath = '/api/v1/pivot-layouts';

/** Valor de SelectBox para la plantilla baseline / sistema. */
export const PIVOT_LAYOUT_ORIGINAL_VALUE = 'original';

export function formatPivotLayoutDisplayName(
  layoutName: string,
  isOwner: boolean,
  ownerSuffix = ' (*)'
): string {
  return isOwner ? `${layoutName}${ownerSuffix}` : layoutName;
}

export function listPivotLayouts(
  consultaId: string,
  options: RequestOverrides = {}
): Promise<ApiClientResult<{ items: PivotLayoutListItem[] }>> {
  const query = new URLSearchParams({ consultaId }).toString();

  return apiRequest<{ items: PivotLayoutListItem[] }>(`${basePath}?${query}`, {
    method: 'GET',
    ...options,
  });
}

export function getActivePivotLayout(
  consultaId: string,
  options: RequestOverrides = {}
): Promise<ApiClientResult<PivotLayoutActiveDto>> {
  const query = new URLSearchParams({ consultaId }).toString();

  return apiRequest<PivotLayoutActiveDto>(`${basePath}/active?${query}`, {
    method: 'GET',
    ...options,
  });
}

export function setActivePivotLayout(
  body: { consultaId: string; layoutId: number | null },
  options: RequestOverrides = {}
): Promise<ApiClientResult<Record<string, unknown>>> {
  return apiRequest<Record<string, unknown>>(`${basePath}/active`, {
    method: 'PUT',
    body: JSON.stringify(body),
    ...options,
  });
}

export function createPivotLayout(
  body: { consultaId: string; layoutName: string; stateJson: string | object },
  options: RequestOverrides = {}
): Promise<ApiClientResult<PivotLayoutActiveDto>> {
  return apiRequest<PivotLayoutActiveDto>(basePath, {
    method: 'POST',
    body: JSON.stringify(body),
    ...options,
  });
}

export function updatePivotLayout(
  id: number,
  body: { stateJson: string | object },
  options: RequestOverrides = {}
): Promise<ApiClientResult<PivotLayoutActiveDto>> {
  return apiRequest<PivotLayoutActiveDto>(`${basePath}/${id}`, {
    method: 'PUT',
    body: JSON.stringify(body),
    ...options,
  });
}

export function deletePivotLayout(
  id: number,
  options: RequestOverrides = {}
): Promise<ApiClientResult<Record<string, unknown>>> {
  return apiRequest<Record<string, unknown>>(`${basePath}/${id}`, {
    method: 'DELETE',
    ...options,
  });
}
