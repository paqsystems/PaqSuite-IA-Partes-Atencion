export type PivotStateJson = string;

export function applyPivotState(
  current: Record<string, unknown> | null | undefined,
  stateJson: string | null
): Record<string, unknown> | null {
  if (stateJson === null || stateJson === '') {
    return null;
  }

  try {
    const parsed = JSON.parse(stateJson) as unknown;
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return current ?? null;
    }
    return parsed as Record<string, unknown>;
  } catch {
    return current ?? null;
  }
}

export function capturePivotState(state: Record<string, unknown> | null | undefined): string {
  if (!state || typeof state !== 'object') {
    return JSON.stringify({ fields: [] });
  }

  return JSON.stringify(state);
}
