import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  buildPivotExportFileName,
  hasPivotExportableData,
} from './exportPivotGridExcel';

describe('buildPivotExportFileName', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-07-26T22:15:00'));
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('sanitiza consultaId y agrega stamp local', () => {
    expect(buildPivotExportFileName('consultaSmokePivot')).toBe(
      'consultaSmokePivot_20260726_2215.xlsx'
    );
  });

  it('reemplaza caracteres inválidos y usa fallback pivot', () => {
    expect(buildPivotExportFileName('a/b c!')).toBe('a_b_c_20260726_2215.xlsx');
    expect(buildPivotExportFileName('***')).toBe('pivot_20260726_2215.xlsx');
  });
});

describe('hasPivotExportableData', () => {
  it('requiere filas y no loading', () => {
    expect(hasPivotExportableData([{ a: 1 }], false)).toBe(true);
    expect(hasPivotExportableData([], false)).toBe(false);
    expect(hasPivotExportableData([{ a: 1 }], true)).toBe(false);
  });
});
