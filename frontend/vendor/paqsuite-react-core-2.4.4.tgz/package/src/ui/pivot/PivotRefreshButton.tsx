import Button from 'devextreme-react/button';

export type PivotRefreshButtonProps = {
  onRefresh: () => void;
  disabled?: boolean;
  label?: string;
};

/** Botón Actualizar modo Pivot — testid `pivot.refresh`. */
export function PivotRefreshButton({
  onRefresh,
  disabled,
  label = 'Actualizar',
}: PivotRefreshButtonProps) {
  return (
    <Button
      text={label}
      disabled={disabled}
      onClick={onRefresh}
      elementAttr={{ 'data-testid': 'pivot.refresh' }}
    />
  );
}
