import Button from 'devextreme-react/button';

export type PivotViewMode = 'grid' | 'pivot';

export type PivotViewToggleProps = {
  value: PivotViewMode;
  onChange: (view: PivotViewMode) => void;
  gridLabel?: string;
  pivotLabel?: string;
  disabled?: boolean;
};

/** Toggle Grilla|Pivot — testid `pivot.toggle`. */
export function PivotViewToggle({
  value,
  onChange,
  gridLabel = 'Grilla',
  pivotLabel = 'Pivot',
  disabled,
}: PivotViewToggleProps) {
  return (
    <div
      data-testid="pivot.toggle"
      role="group"
      style={{ display: 'inline-flex', gap: 4 }}
    >
      <Button
        text={gridLabel}
        type={value === 'grid' ? 'default' : 'normal'}
        stylingMode={value === 'grid' ? 'contained' : 'outlined'}
        disabled={disabled}
        onClick={() => onChange('grid')}
        elementAttr={{ 'data-testid': 'pivot.toggle.grid' }}
      />
      <Button
        text={pivotLabel}
        type={value === 'pivot' ? 'default' : 'normal'}
        stylingMode={value === 'pivot' ? 'contained' : 'outlined'}
        disabled={disabled}
        onClick={() => onChange('pivot')}
        elementAttr={{ 'data-testid': 'pivot.toggle.pivot' }}
      />
    </div>
  );
}
