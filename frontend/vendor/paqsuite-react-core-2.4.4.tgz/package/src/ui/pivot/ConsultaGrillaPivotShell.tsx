import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
  type Ref,
} from 'react';
import { isNativeApp } from '../../mobile/isNativeApp';
import type { PivotConsultaCatalogDto } from './pivotCatalogClient';
import {
  PivotGridBlock,
  type PivotGridBlockHandle,
} from './PivotGridBlock';
import { PivotViewToggle, type PivotViewMode } from './PivotViewToggle';

export type ConsultaGrillaPivotShellProps = {
  consultaId: string;
  catalog: PivotConsultaCatalogDto;
  gridView: ReactNode;
  loadPivotDataset: () => Promise<Record<string, unknown>[]>;
  initialView?: PivotViewMode;
  pivotsEnabled?: boolean;
  locale?: string;
  /** Default `true`. `false` oculta Export en toolbar pivot (C1-12-F06). */
  exportEnabled?: boolean;
  toolbarLayoutsSlot?: ReactNode;
  toolbarPlantillaSlot?: ReactNode;
  toolbarExportSlot?: ReactNode;
  toolbarExtras?: ReactNode;
  pivotRef?: Ref<PivotGridBlockHandle>;
  gridLabel?: string;
  pivotLabel?: string;
};

/**
 * Shell Grilla|Pivot GEN-12: exclusividad real (unmount), lazy load, slots toolbar.
 * Native Capacitor: null (C1-12-F05 / TR mobile-policy).
 */
export function ConsultaGrillaPivotShell({
  consultaId,
  catalog,
  gridView,
  loadPivotDataset,
  initialView = 'grid',
  pivotsEnabled = true,
  locale,
  exportEnabled = true,
  toolbarLayoutsSlot,
  toolbarPlantillaSlot,
  toolbarExportSlot,
  toolbarExtras,
  pivotRef,
  gridLabel,
  pivotLabel,
}: ConsultaGrillaPivotShellProps) {
  const forcePivot = pivotsEnabled && catalog.soloPivot;
  const showToggle = pivotsEnabled && catalog.mostrarGrillaYPivot && !catalog.soloPivot;

  const [view, setView] = useState<PivotViewMode>(() => {
    if (forcePivot) {
      return 'pivot';
    }
    return initialView;
  });

  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [pivotDatasetLoaded, setPivotDatasetLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const loadInFlight = useRef(false);

  const ensurePivotDataset = useCallback(async () => {
    if (pivotDatasetLoaded || loadInFlight.current) {
      return;
    }
    loadInFlight.current = true;
    setLoading(true);
    try {
      const data = await loadPivotDataset();
      setRows(data);
      setPivotDatasetLoaded(true);
    } finally {
      loadInFlight.current = false;
      setLoading(false);
    }
  }, [loadPivotDataset, pivotDatasetLoaded]);

  const refreshPivotDataset = useCallback(async () => {
    loadInFlight.current = true;
    setLoading(true);
    try {
      const data = await loadPivotDataset();
      setRows(data);
      setPivotDatasetLoaded(true);
    } finally {
      loadInFlight.current = false;
      setLoading(false);
    }
  }, [loadPivotDataset]);

  useEffect(() => {
    if (!pivotsEnabled) {
      return;
    }
    if (view === 'pivot' || forcePivot) {
      void ensurePivotDataset();
    }
  }, [ensurePivotDataset, forcePivot, pivotsEnabled, view]);

  if (isNativeApp()) {
    return null;
  }

  if (!pivotsEnabled) {
    return <>{gridView}</>;
  }

  const activeView: PivotViewMode = forcePivot ? 'pivot' : view;

  return (
    <div data-testid="pivot.shell">
      {showToggle ? (
        <div style={{ marginBottom: 8 }}>
          <PivotViewToggle
            value={activeView}
            onChange={setView}
            gridLabel={gridLabel}
            pivotLabel={pivotLabel}
          />
        </div>
      ) : null}

      {activeView === 'grid' ? (
        <div data-testid="pivot.shell.grid">{gridView}</div>
      ) : null}

      {activeView === 'pivot' ? (
        <div data-testid="pivot.shell.pivot">
          <PivotGridBlock
            ref={pivotRef}
            consultaId={consultaId}
            catalog={catalog}
            rows={rows}
            locale={locale}
            loading={loading}
            exportEnabled={exportEnabled}
            onRefresh={() => {
              void refreshPivotDataset();
            }}
            toolbarLayoutsSlot={toolbarLayoutsSlot}
            toolbarPlantillaSlot={toolbarPlantillaSlot}
            toolbarExportSlot={toolbarExportSlot}
            toolbarExtras={toolbarExtras}
          />
        </div>
      ) : null}
    </div>
  );
}
