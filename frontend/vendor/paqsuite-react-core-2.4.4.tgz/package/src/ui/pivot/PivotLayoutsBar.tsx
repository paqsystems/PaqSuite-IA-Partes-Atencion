import { useCallback, useRef, useState, type ReactNode } from 'react';
import Button from 'devextreme-react/button';
import type dxPivotGrid from 'devextreme/ui/pivot_grid';
import type { BuildPlatformHeadersInput } from '../../http/headers';
import {
  defaultPivotLayoutsToolbarLabels,
  PivotLayoutSaveAsDialog,
  PivotLayoutsToolbarControls,
  type PivotLayoutsToolbarLabels,
} from './PivotLayoutsToolbarControls';
import { applyPivotState, capturePivotState } from './pivotState';
import { usePivotLayouts } from './usePivotLayouts';
import { PivotExportButton } from './PivotExportButton';
import {
  exportPivotGridExcel,
  type PivotExportMode,
} from './exportPivotGridExcel';

export type PivotLayoutsBarProps = {
  consultaId: string;
  accessToken?: string | null;
  platform?: BuildPlatformHeadersInput;
  enabled?: boolean;
  layoutLabels?: Partial<PivotLayoutsToolbarLabels>;
  /** Controles a la izquierda (p. ej. botón «Grilla»). */
  leadingSlot?: ReactNode;
  /**
   * Obtiene el estado DX del PivotGrid (`dataSource.state()`).
   * Si falta, se serializa `{ fields: [] }`.
   */
  getPivotState: () => Record<string, unknown> | null | undefined;
  /**
   * Aplica estado al PivotGrid. `null` = volver a &lt;Original&gt;.
   */
  applyPivotStateJson: (state: Record<string, unknown> | null) => void;
  /**
   * Instancia DX para export Excel (y FieldChooser si `fieldChooserButtonEnabled`).
   */
  getPivotComponent?: () => dxPivotGrid | undefined;
  /** Default `true`. Excel va a la derecha de plantillas. */
  exportEnabled?: boolean;
  /** Sin filas / cargando → deshabilita Excel. Default `true` (habilitado). */
  canExport?: boolean;
  exportTitle?: string;
  exportBasicLabel?: string;
  exportFormattedLabel?: string;
  exportNoDataHint?: string;
  /**
   * Botón «Campos» en la barra (abre FieldChooser DX).
   * Default `false`: el FieldPanel del Pivot ya expone el ícono de campos.
   */
  fieldChooserButtonEnabled?: boolean;
  fieldChooserButtonLabel?: string;
  children: ReactNode;
};

/**
 * Barra GEN-12: leading | plantillas → Excel (derecha).
 */
export function PivotLayoutsBar({
  consultaId,
  accessToken,
  platform,
  enabled = true,
  layoutLabels,
  leadingSlot,
  getPivotState,
  applyPivotStateJson,
  getPivotComponent,
  exportEnabled = true,
  canExport = true,
  exportTitle,
  exportBasicLabel,
  exportFormattedLabel,
  exportNoDataHint,
  fieldChooserButtonEnabled = false,
  fieldChooserButtonLabel = 'Campos',
  children,
}: PivotLayoutsBarProps) {
  const [saveAsOpen, setSaveAsOpen] = useState(false);
  const getPivotStateRef = useRef(getPivotState);
  const applyPivotStateJsonRef = useRef(applyPivotStateJson);
  const getPivotComponentRef = useRef(getPivotComponent);
  getPivotStateRef.current = getPivotState;
  applyPivotStateJsonRef.current = applyPivotStateJson;
  getPivotComponentRef.current = getPivotComponent;

  const captureState = useCallback(
    () => capturePivotState(getPivotStateRef.current() ?? { fields: [] }),
    []
  );

  const applyState = useCallback((stateJson: string | null) => {
    const next = applyPivotState(null, stateJson);
    applyPivotStateJsonRef.current(next);
  }, []);

  const layouts = usePivotLayouts({
    consultaId,
    accessToken,
    platform,
    enabled: enabled && Boolean(accessToken) && Boolean(consultaId),
    ownerSuffix: layoutLabels?.ownerSuffix,
    originalLabel: layoutLabels?.originalLabel,
    captureState,
    applyState,
  });

  const showLayouts = enabled && Boolean(accessToken) && Boolean(consultaId);
  const showExport = exportEnabled !== false;
  const showFieldChooserButton = fieldChooserButtonEnabled === true;

  const handleExport = useCallback(
    (mode: PivotExportMode) => {
      const instance = getPivotComponentRef.current?.();
      if (!instance || !canExport) {
        return;
      }
      void exportPivotGridExcel({
        consultaId,
        component: instance,
        mode,
      });
    },
    [canExport, consultaId]
  );

  const handleOpenFieldChooser = useCallback(() => {
    const instance = getPivotComponentRef.current?.();
    const popup = instance?.getFieldChooserPopup?.();
    popup?.show?.();
  }, []);

  return (
    <div data-testid="pivotLayoutsBar">
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 8,
          marginBottom: 8,
          flexWrap: 'wrap',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>{leadingSlot}</div>
        {showLayouts || showExport || showFieldChooserButton ? (
          <div
            style={{
              marginLeft: 'auto',
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              flexWrap: 'wrap',
            }}
          >
            {showLayouts ? (
              <PivotLayoutsToolbarControls
                layouts={layouts}
                labels={layoutLabels}
                onOpenSaveAs={() => setSaveAsOpen(true)}
              />
            ) : null}
            {showExport ? (
              <PivotExportButton
                onExport={handleExport}
                disabled={!canExport}
                title={exportTitle}
                basicLabel={exportBasicLabel}
                formattedLabel={exportFormattedLabel}
                noDataHint={exportNoDataHint}
              />
            ) : null}
            {showFieldChooserButton ? (
              <Button
                text={fieldChooserButtonLabel}
                stylingMode="outlined"
                onClick={handleOpenFieldChooser}
                elementAttr={{ 'data-testid': 'pivot.fieldChooserButton' }}
              />
            ) : null}
          </div>
        ) : null}
      </div>
      {children}
      {showLayouts ? (
        <PivotLayoutSaveAsDialog
          visible={saveAsOpen}
          busy={layouts.busy}
          errorMessage={
            layouts.errorMessage
              ? layouts.errorMessage === 'layouts.saveAsFailed' ||
                layouts.errorMessage === 'layouts.saveFailed' ||
                layouts.errorMessage === 'layouts.error'
                ? layoutLabels?.saveAsError ?? defaultPivotLayoutsToolbarLabels.saveAsError
                : layouts.errorMessage
              : null
          }
          labels={layoutLabels}
          onHiding={() => setSaveAsOpen(false)}
          onConfirm={async (layoutName) => layouts.saveAs(layoutName)}
        />
      ) : null}
    </div>
  );
}
