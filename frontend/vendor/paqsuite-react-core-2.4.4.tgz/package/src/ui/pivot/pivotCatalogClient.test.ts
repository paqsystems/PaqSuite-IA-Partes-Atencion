import { afterEach, describe, expect, it, vi } from 'vitest';
import { fetchPivotCatalog } from './pivotCatalogClient';

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe('fetchPivotCatalog', () => {
  it('calls GET /api/v1/pivots/consultas/{consultaId}', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        new Response(
          JSON.stringify({
            error: 0,
            respuesta: 'ok',
            resultado: {
              consultaId: 'consultaSmokePivot',
              mostrarGrillaYPivot: true,
              soloPivot: false,
              campos: [],
            },
          }),
          {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
          }
        )
      )
    );

    const result = await fetchPivotCatalog('consultaSmokePivot');

    expect(result.kind).toBe('ok');
    expect(fetch).toHaveBeenCalledOnce();
    const [url, init] = (fetch as ReturnType<typeof vi.fn>).mock.calls[0] as [
      string,
      RequestInit,
    ];
    expect(url).toContain('/api/v1/pivots/consultas/consultaSmokePivot');
    expect(init.method).toBe('GET');
  });
});
