import DropDownButton from 'devextreme-react/drop-down-button';
import {
  defaultPivotExportMode,
  type PivotExportMode,
} from './exportPivotGridExcel';

export type PivotExportButtonProps = {
  onExport: (mode: PivotExportMode) => void;
  disabled?: boolean;
  title?: string;
  basicLabel?: string;
  formattedLabel?: string;
  noDataHint?: string;
};

type ExportMenuItem = {
  id: PivotExportMode;
  text: string;
  testId: string;
};

/**
 * DropDown Excel modo Pivot — testids `pivot.export*`.
 * `disabled` = sin datos. (Mobile excluye pivots a nivel de página.)
 */
export function PivotExportButton({
  onExport,
  disabled,
  title = 'Excel',
  basicLabel = 'Básico',
  formattedLabel = 'Tabla dinámica',
  noDataHint = 'Sin datos para exportar',
}: PivotExportButtonProps) {
  const items: ExportMenuItem[] = [
    {
      id: 'formatted',
      text: formattedLabel,
      testId: 'pivot.exportModeFormatted',
    },
    {
      id: 'basic',
      text: basicLabel,
      testId: 'pivot.exportModeBasic',
    },
  ];

  return (
    <DropDownButton
      text={title}
      items={items}
      keyExpr="id"
      displayExpr="text"
      disabled={disabled}
      hint={disabled ? noDataHint : title}
      dropDownOptions={{ width: 200 }}
      onItemClick={(e) => {
        const item = e.itemData as ExportMenuItem | undefined;
        const mode = item?.id ?? defaultPivotExportMode;
        onExport(mode);
      }}
      elementAttr={{ 'data-testid': 'pivot.export' }}
      itemRender={(item: ExportMenuItem) => (
        <div data-testid={item.testId}>{item.text}</div>
      )}
    />
  );
}
