import { describe, expect, it, vi } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import { PivotExportButton } from './PivotExportButton';

vi.mock('devextreme-react/drop-down-button', () => ({
  default: (props: {
    text?: string;
    disabled?: boolean;
    elementAttr?: Record<string, string>;
    items?: Array<{ id: string; text: string; testId: string }>;
    itemRender?: (item: { id: string; text: string; testId: string }) => unknown;
  }) => (
    <div
      data-testid={props.elementAttr?.['data-testid']}
      data-disabled={props.disabled ? 'true' : 'false'}
      data-text={props.text}
    >
      {(props.items ?? []).map((item) => (
        <div key={item.id} data-testid={item.testId}>
          {item.text}
        </div>
      ))}
    </div>
  ),
}));

describe('PivotExportButton', () => {
  it('expone Excel con modos Básico y Tabla dinámica', () => {
    const html = renderToStaticMarkup(
      <PivotExportButton onExport={() => undefined} disabled />
    );

    expect(html).toContain('pivot.export');
    expect(html).toContain('pivot.exportModeFormatted');
    expect(html).toContain('pivot.exportModeBasic');
    expect(html).toContain('data-text="Excel"');
    expect(html).toContain('data-disabled="true"');
    expect(html).toContain('Básico');
    expect(html).toContain('Tabla dinámica');
  });
});
