import { apiRequest, type ApiClientResult, type ApiRequestOptions } from '../../http/apiClient';

export type PivotPlantillaListItem = {
  plantillaId: number;
  plantillaName: string;
  descripcion?: string;
};

export type PivotValidacionRule = {
  reglaCode: string;
  campo?: string;
  area?: string;
  parametros?: Record<string, unknown>;
  mensajeClave?: string;
};

type RequestOverrides = Pick<ApiRequestOptions, 'platform' | 'signal' | 'headers'>;

function consultaBase(consultaId: string): string {
  return `/api/v1/pivots/consultas/${encodeURIComponent(consultaId)}`;
}

export function listPivotPlantillas(
  consultaId: string,
  options: RequestOverrides = {}
): Promise<ApiClientResult<{ items: PivotPlantillaListItem[] }>> {
  return apiRequest<{ items: PivotPlantillaListItem[] }>(`${consultaBase(consultaId)}/plantillas`, {
    method: 'GET',
    ...options,
  });
}

export function listPivotValidaciones(
  consultaId: string,
  options: RequestOverrides = {}
): Promise<ApiClientResult<{ items: PivotValidacionRule[] }>> {
  return apiRequest<{ items: PivotValidacionRule[] }>(`${consultaBase(consultaId)}/validaciones`, {
    method: 'GET',
    ...options,
  });
}

export function applyPivotPlantilla(
  consultaId: string,
  plantillaId: number,
  options: RequestOverrides = {}
): Promise<ApiClientResult<{ stateJson: string }>> {
  return apiRequest<{ stateJson: string }>(
    `${consultaBase(consultaId)}/plantillas/${plantillaId}/apply`,
    {
      method: 'POST',
      ...options,
    }
  );
}
