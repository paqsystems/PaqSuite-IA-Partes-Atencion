import { formatMessage } from 'devextreme/localization';
import { syncDevExtremeLocale } from '../../i18n/syncDevExtremeLocale';

export type PivotFieldChooserTexts = {
  allFields: string;
  columnFields: string;
  dataFields: string;
  filterFields: string;
  rowFields: string;
};

export type PivotFieldPanelTexts = {
  columnFieldArea: string;
  dataFieldArea: string;
  filterFieldArea: string;
  rowFieldArea: string;
};

export type PivotLocalizedUiTexts = {
  fieldChooserTitle: string;
  fieldChooser: PivotFieldChooserTexts;
  fieldPanel: PivotFieldPanelTexts;
};

/**
 * Textos de UI del Pivot (FieldChooser / FieldPanel) según locale DX activo.
 * Llamar tras `syncDevExtremeLocale` (o pasando `locale` para forzar sync).
 * MUST re-evaluar / remount al cambiar idioma (regla BASE 32).
 */
export function getPivotLocalizedUiTexts(locale?: string): PivotLocalizedUiTexts {
  if (locale) {
    syncDevExtremeLocale(locale);
  }

  return {
    fieldChooserTitle: formatMessage('dxPivotGrid-fieldChooserTitle'),
    fieldChooser: {
      allFields: formatMessage('dxPivotGrid-allFields'),
      columnFields: formatMessage('dxPivotGrid-columnFields'),
      dataFields: formatMessage('dxPivotGrid-dataFields'),
      filterFields: formatMessage('dxPivotGrid-filterFields'),
      rowFields: formatMessage('dxPivotGrid-rowFields'),
    },
    fieldPanel: {
      columnFieldArea: formatMessage('dxPivotGrid-columnFieldArea'),
      dataFieldArea: formatMessage('dxPivotGrid-dataFieldArea'),
      filterFieldArea: formatMessage('dxPivotGrid-filterFieldArea'),
      rowFieldArea: formatMessage('dxPivotGrid-rowFieldArea'),
    },
  };
}
