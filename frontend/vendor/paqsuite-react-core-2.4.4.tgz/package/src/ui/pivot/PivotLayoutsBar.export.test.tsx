import { describe, expect, it, vi } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import { PivotLayoutsBar } from './PivotLayoutsBar';

vi.mock('../../mobile/isNativeApp', () => ({
  isNativeApp: () => false,
}));

vi.mock('devextreme-react/drop-down-button', () => ({
  default: (props: {
    text?: string;
    disabled?: boolean;
    elementAttr?: Record<string, string>;
    items?: Array<{ id: string; text: string; testId: string }>;
  }) => (
    <div
      data-testid={props.elementAttr?.['data-testid']}
      data-disabled={props.disabled ? 'true' : 'false'}
      data-text={props.text}
    >
      {(props.items ?? []).map((item) => (
        <div key={item.id} data-testid={item.testId}>
          {item.text}
        </div>
      ))}
    </div>
  ),
}));

vi.mock('devextreme-react/button', () => ({
  default: (props: {
    text?: string;
    elementAttr?: Record<string, string>;
    onClick?: () => void;
  }) => (
    <button type="button" data-testid={props.elementAttr?.['data-testid']}>
      {props.text}
    </button>
  ),
}));

vi.mock('devextreme-react/select-box', () => ({
  default: () => <div data-testid="pivot.layout.select" />,
}));

vi.mock('./usePivotLayouts', () => ({
  usePivotLayouts: () => ({
    items: [],
    selectedValue: '__original__',
    busy: false,
    canSave: false,
    canDelete: false,
    errorMessage: null,
    selectLayout: async () => undefined,
    save: async () => 'ok' as const,
    saveAs: async () => true,
    remove: async () => undefined,
  }),
}));

describe('PivotLayoutsBar export', () => {
  it('muestra Excel aunque no haya getPivotComponent (visible por default)', () => {
    const html = renderToStaticMarkup(
      <PivotLayoutsBar
        consultaId="consulta.test"
        accessToken="tok"
        getPivotState={() => ({ fields: [] })}
        applyPivotStateJson={() => undefined}
      >
        <div>pivot</div>
      </PivotLayoutsBar>
    );

    expect(html).toContain('pivot.export');
    expect(html).toContain('data-text="Excel"');
    expect(html).toContain('Básico');
    expect(html).toContain('Tabla dinámica');
  });

  it('no muestra Campos por defecto (FieldPanel ya tiene el ícono)', () => {
    const html = renderToStaticMarkup(
      <PivotLayoutsBar
        consultaId="consulta.test"
        accessToken="tok"
        getPivotState={() => ({ fields: [] })}
        applyPivotStateJson={() => undefined}
        getPivotComponent={() => undefined}
      >
        <div>pivot</div>
      </PivotLayoutsBar>
    );

    expect(html).not.toContain('pivot.fieldChooserButton');
    expect(html).not.toContain('Campos');
  });

  it('muestra Campos solo si fieldChooserButtonEnabled', () => {
    const html = renderToStaticMarkup(
      <PivotLayoutsBar
        consultaId="consulta.test"
        accessToken="tok"
        getPivotState={() => ({ fields: [] })}
        applyPivotStateJson={() => undefined}
        getPivotComponent={() => undefined}
        fieldChooserButtonEnabled
      >
        <div>pivot</div>
      </PivotLayoutsBar>
    );

    expect(html).toContain('pivot.fieldChooserButton');
    expect(html).toContain('Campos');
  });
});
