import { describe, expect, it } from 'vitest';
import { validatePivotStateClient } from './validatePivotStateClient';

describe('validatePivotStateClient', () => {
  it('rejects fieldForbiddenInArea', () => {
    const errors = validatePivotStateClient(
      JSON.stringify({ fields: [{ dataField: 'cliente', area: 'data' }] }),
      [{ reglaCode: 'fieldForbiddenInArea', campo: 'cliente', area: 'data' }]
    );

    expect(errors).toHaveLength(1);
    expect(errors[0]?.reglaCode).toBe('fieldForbiddenInArea');
  });

  it('accepts valid state', () => {
    const errors = validatePivotStateClient(
      JSON.stringify({ fields: [{ dataField: 'cliente', area: 'row' }] }),
      [{ reglaCode: 'fieldForbiddenInArea', campo: 'cliente', area: 'data' }]
    );

    expect(errors).toEqual([]);
  });
});
