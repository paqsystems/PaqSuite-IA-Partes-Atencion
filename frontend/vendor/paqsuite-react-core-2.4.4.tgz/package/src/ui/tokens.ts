/**
 * classNames y rutas CSS del paquete. Layout auth canónico: `authLayout.css`
 * (+ tokens `--paq-auth-*`). Hosts sin loader CSS pueden inyectar texto.
 */
export const tokensCssPath = './tokens.css';
export const authLayoutCssPath = './auth/authLayout.css';
export const shellLayoutCssPath = './shell/shellLayout.css';

export const tokensCssText = `:root {
  --pq-auth-bg: #0f172a;
  --pq-auth-card-bg: #ffffff;
  --pq-auth-card-radius: 12px;
  --pq-auth-accent: #2563eb;
  --pq-auth-text: #1e293b;
  --pq-shell-header-height: 56px;
  --pq-shell-aside-width: 240px;
  --pq-shell-footer-height: 40px;
  --pq-shell-bg: #f8fafc;
  --pq-shell-border: #e2e8f0;
  --pq-shell-breakpoint-mobile: 767px;
}`;

export const authClassNames = {
  page: 'pqAuthLoginPage',
  hero: 'pqAuthLoginHero',
  card: 'pqAuthLoginCard',
  brand: 'pqAuthLoginBadge',
  title: 'pqAuthLoginTitle',
  footer: 'pqAuthLoginFooter',
  centeredPage: 'pqAuthCenteredPage',
  centeredCard: 'pqAuthCenteredCard',
  form: 'pqAuthForm',
  field: 'pqAuthField',
  fieldLabel: 'pqAuthFieldLabel',
  cta: 'pqAuthCta',
  messageError: 'pqAuthMessage pqAuthMessage--error',
  messageSuccess: 'pqAuthMessage pqAuthMessage--success',
} as const;

export const shellClassNames = {
  root: 'pqShell',
  menuOpen: 'pqShellMenuOpen',
  header: 'pqShellHeader',
  brand: 'pqShellBrand',
  aside: 'pqShellAside',
  main: 'pqShellMain',
  footer: 'pqShellFooter',
  menuToggle: 'pqShellMenuToggle',
} as const;

export const processClassNames = {
  page: 'pqProcessPage',
  header: 'pqProcessHeader',
  title: 'pqProcessTitle',
  toolbar: 'pqProcessToolbar',
  content: 'pqProcessContent',
} as const;

export const stateClassNames = {
  empty: 'pqEmptyState',
  error: 'pqErrorState',
  loading: 'pqLoadingOverlay',
} as const;
