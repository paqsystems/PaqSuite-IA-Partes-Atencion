export type FormSurface = 'popup' | 'page';

/** Heurística MVP GEN-01: ≤8 campos → popup; más → página completa. */
export function resolveFormSurface(fieldCount: number): FormSurface {
  return fieldCount <= 8 ? 'popup' : 'page';
}
