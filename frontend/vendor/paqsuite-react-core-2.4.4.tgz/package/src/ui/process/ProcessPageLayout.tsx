import type { ReactNode } from 'react';
import { processClassNames } from '../tokens';

export type ProcessPageLayoutProps = {
  title: ReactNode;
  toolbar?: ReactNode;
  children: ReactNode;
};

/**
 * Layout de proceso MVP (sin DevExtreme). Hosts productivos montan
 * `dxToolbar`/`dxDataGrid`/`dxForm` dentro de `toolbar`/`children` sin
 * cambiar zonas ni `data-testid`.
 */
export function ProcessPageLayout({ title, toolbar, children }: ProcessPageLayoutProps) {
  return (
    <section className={processClassNames.page} data-testid="processPageLayout">
      <h1 className={processClassNames.title}>{title}</h1>
      {toolbar ? <div className={processClassNames.toolbar}>{toolbar}</div> : null}
      <div className={processClassNames.content}>{children}</div>
    </section>
  );
}
