import { describe, expect, it } from 'vitest';
import { resolveFormSurface } from './resolveFormSurface';

describe('resolveFormSurface', () => {
  it('retorna popup con 8 campos o menos', () => {
    expect(resolveFormSurface(0)).toBe('popup');
    expect(resolveFormSurface(1)).toBe('popup');
    expect(resolveFormSurface(8)).toBe('popup');
  });

  it('retorna page con más de 8 campos', () => {
    expect(resolveFormSurface(9)).toBe('page');
    expect(resolveFormSurface(20)).toBe('page');
  });
});
