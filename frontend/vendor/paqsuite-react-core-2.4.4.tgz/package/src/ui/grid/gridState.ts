export type GridColumnState = {
  key: string;
  visible?: boolean;
  width?: number;
};

export type GridState = {
  pageSize?: number;
  columns?: GridColumnState[];
};

export type GridStateTarget = {
  pageSize: number;
  columns: GridColumnState[];
};

/** Restaura estado simple (columnas/pageSize) sobre un target mutable (MVP sin `dxDataGrid.state()`). */
export function applyState(target: GridStateTarget, state: GridState): void {
  if (typeof state.pageSize === 'number') {
    target.pageSize = state.pageSize;
  }
  if (state.columns) {
    target.columns = state.columns.map((column) => ({ ...column }));
  }
}

/** Captura el estado simple actual como objeto JSON plano (persistible en `localStorage`/backend). */
export function captureState(target: GridStateTarget): GridState {
  return {
    pageSize: target.pageSize,
    columns: target.columns.map((column) => ({ ...column })),
  };
}
