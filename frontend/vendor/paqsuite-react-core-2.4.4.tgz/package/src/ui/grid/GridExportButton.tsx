import DropDownButton from 'devextreme-react/drop-down-button';
import {
  defaultGridExportMode,
  type GridExportMode,
} from './exportDataGridExcel';

export type GridExportButtonProps = {
  onExport: (mode: GridExportMode) => void;
  disabled?: boolean;
  title?: string;
  basicLabel?: string;
  formattedLabel?: string;
  noDataHint?: string;
  /** @deprecated Usar `title`. */
  label?: string;
};

type ExportMenuItem = {
  id: GridExportMode;
  text: string;
  testId: string;
};

/**
 * DropDown Excel grilla — modalidades Básico / Formateado (GEN-11).
 * testids `gridExport` / `gridExportModeBasic` / `gridExportModeFormatted`.
 */
export function GridExportButton({
  onExport,
  disabled,
  title,
  basicLabel = 'Básico',
  formattedLabel = 'Formateado',
  noDataHint = 'Sin datos para exportar',
  label,
}: GridExportButtonProps) {
  const buttonTitle = title ?? label ?? 'Excel';

  const items: ExportMenuItem[] = [
    {
      id: 'formatted',
      text: formattedLabel,
      testId: 'gridExportModeFormatted',
    },
    {
      id: 'basic',
      text: basicLabel,
      testId: 'gridExportModeBasic',
    },
  ];

  return (
    <DropDownButton
      text={buttonTitle}
      items={items}
      keyExpr="id"
      displayExpr="text"
      disabled={disabled}
      hint={disabled ? noDataHint : buttonTitle}
      dropDownOptions={{ width: 180 }}
      onItemClick={(e) => {
        const item = e.itemData as ExportMenuItem | undefined;
        const mode = item?.id ?? defaultGridExportMode;
        onExport(mode);
      }}
      elementAttr={{ 'data-testid': 'gridExport' }}
      itemRender={(item: ExportMenuItem) => (
        <div data-testid={item.testId}>{item.text}</div>
      )}
    />
  );
}
