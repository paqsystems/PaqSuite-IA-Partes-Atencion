import { useState, type ReactNode } from 'react';
import Button from 'devextreme-react/button';
import SelectBox from 'devextreme-react/select-box';
import TextBox from 'devextreme-react/text-box';
import { Popup } from 'devextreme-react/popup';
import { GRID_LAYOUT_ORIGINAL_VALUE } from './gridLayoutsClient';
import type { UseGridLayoutsResult } from './useGridLayouts';

export type GridLayoutsToolbarLabels = {
  originalLabel: string;
  save: string;
  saveAs: string;
  delete: string;
  saveAsTitle: string;
  saveAsNameLabel: string;
  saveAsConfirm: string;
  saveAsCancel: string;
  ownerSuffix: string;
  saveAsError: string;
};

export const defaultGridLayoutsToolbarLabels: GridLayoutsToolbarLabels = {
  originalLabel: '<Original>',
  save: 'Guardar',
  saveAs: 'Guardar como…',
  delete: 'Eliminar',
  saveAsTitle: 'Guardar plantilla como…',
  saveAsNameLabel: 'Nombre',
  saveAsConfirm: 'Guardar',
  saveAsCancel: 'Cancelar',
  ownerSuffix: ' (*)',
  saveAsError: 'No se pudo guardar la plantilla. Revise el nombre o reintente.',
};

type GridLayoutsToolbarControlsProps = {
  layouts: UseGridLayoutsResult;
  labels?: Partial<GridLayoutsToolbarLabels>;
  disabled?: boolean;
  /** Abre el diálogo (estado vive fuera del toolbar DX). */
  onOpenSaveAs: () => void;
};

/**
 * Controles de plantillas GEN-11 para toolbar de DataGrid
 * (Select + Guardar + Guardar como + Eliminar). Sin Popup interno.
 */
export function GridLayoutsToolbarControls({
  layouts,
  labels: labelsPartial,
  disabled = false,
  onOpenSaveAs,
}: GridLayoutsToolbarControlsProps) {
  const labels = { ...defaultGridLayoutsToolbarLabels, ...labelsPartial };
  const busy = disabled || layouts.busy;

  async function handleSave() {
    // Primera plantilla / <Original> → Guardar como (SPEC-001-11).
    if (
      layouts.selectedValue === GRID_LAYOUT_ORIGINAL_VALUE ||
      !layouts.canDelete
    ) {
      onOpenSaveAs();
      return;
    }
    const outcome = await layouts.save();
    if (outcome === 'saveAs') {
      onOpenSaveAs();
    }
  }

  return (
    <div
      data-testid="gridLayoutsToolbar"
      style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}
    >
      <SelectBox
        dataSource={layouts.items}
        value={layouts.selectedValue}
        valueExpr="value"
        displayExpr="displayName"
        width={220}
        disabled={busy}
        elementAttr={{ 'data-testid': 'gridLayouts.select' }}
        onValueChanged={(e) => {
          if (typeof e.value === 'string' && e.value !== layouts.selectedValue) {
            void layouts.selectLayout(e.value);
          }
        }}
      />
      <Button
        icon="save"
        hint={labels.save}
        stylingMode="text"
        disabled={busy || !layouts.canSave}
        onClick={() => void handleSave()}
        elementAttr={{ 'data-testid': 'gridLayouts.save' }}
      />
      <Button
        icon="copy"
        hint={labels.saveAs}
        stylingMode="text"
        disabled={busy}
        onClick={onOpenSaveAs}
        elementAttr={{ 'data-testid': 'gridLayouts.saveAs' }}
      />
      <Button
        icon="trash"
        hint={labels.delete}
        stylingMode="text"
        disabled={busy || !layouts.canDelete}
        onClick={() => void layouts.remove()}
        elementAttr={{ 'data-testid': 'gridLayouts.delete' }}
      />
    </div>
  );
}

type GridLayoutSaveAsDialogProps = {
  visible: boolean;
  busy?: boolean;
  errorMessage?: string | null;
  labels?: Partial<GridLayoutsToolbarLabels>;
  onHiding: () => void;
  onConfirm: (layoutName: string) => Promise<boolean> | boolean;
};

/**
 * Diálogo «Guardar como» — MUST montarse fuera del toolbar del DataGrid
 * (mismo patrón PedidosWeb: `saveAsDialog` al lado de la página).
 */
export function GridLayoutSaveAsDialog({
  visible,
  busy = false,
  errorMessage = null,
  labels: labelsPartial,
  onHiding,
  onConfirm,
}: GridLayoutSaveAsDialogProps): ReactNode {
  const labels = { ...defaultGridLayoutsToolbarLabels, ...labelsPartial };
  const [saveAsName, setSaveAsName] = useState('');

  return (
    <Popup
      visible={visible}
      onHiding={onHiding}
      onShowing={() => setSaveAsName('')}
      title={labels.saveAsTitle}
      width={360}
      height="auto"
      showCloseButton
      dragEnabled
      hideOnOutsideClick
      wrapperAttr={{ class: 'pq-grid-layout-save-as-popup' }}
      container={typeof document !== 'undefined' ? document.body : undefined}
    >
      <div style={{ display: 'grid', gap: 12, padding: 8 }} data-testid="gridLayouts.saveAsForm">
        <div style={{ display: 'grid', gap: 4 }}>
          <label>{labels.saveAsNameLabel}</label>
          <TextBox
            value={saveAsName}
            onValueChanged={(e) => setSaveAsName(String(e.value ?? ''))}
            elementAttr={{ 'data-testid': 'gridLayouts.saveAsName' }}
          />
        </div>
        {errorMessage ? (
          <div role="alert" data-testid="gridLayouts.saveAsError" style={{ color: '#b42318' }}>
            {errorMessage}
          </div>
        ) : null}
        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <Button text={labels.saveAsCancel} onClick={onHiding} />
          <Button
            text={labels.saveAsConfirm}
            type="default"
            disabled={!saveAsName.trim() || busy}
            onClick={() => {
              void Promise.resolve(onConfirm(saveAsName)).then((ok) => {
                if (ok) {
                  onHiding();
                }
              });
            }}
            elementAttr={{ 'data-testid': 'gridLayouts.saveAsConfirm' }}
          />
        </div>
      </div>
    </Popup>
  );
}
