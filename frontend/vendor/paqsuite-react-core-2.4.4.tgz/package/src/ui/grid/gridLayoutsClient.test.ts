import { describe, expect, it } from 'vitest';
import { formatGridLayoutDisplayName, GRID_LAYOUT_ORIGINAL_VALUE } from './gridLayoutsClient';

describe('formatGridLayoutDisplayName', () => {
  it('agrega (*) solo a plantillas del usuario', () => {
    expect(formatGridLayoutDisplayName('Mi vista', true)).toBe('Mi vista (*)');
    expect(formatGridLayoutDisplayName('Compartida', false)).toBe('Compartida');
  });
});

describe('GRID_LAYOUT_ORIGINAL_VALUE', () => {
  it('es el sentinel de plantilla original', () => {
    expect(GRID_LAYOUT_ORIGINAL_VALUE).toBe('original');
  });
});
