import { apiRequest, type ApiClientResult, type ApiRequestOptions } from '../../http/apiClient';

export type GridLayoutListItem = {
  id: number;
  layoutName: string;
  isSystem: boolean;
  isOwner: boolean;
};

export type GridLayoutActiveDto = {
  layoutId: number | null;
  layoutName: string | null;
  isSystem?: boolean | null;
  isOwner?: boolean | null;
  stateJson: unknown | null;
};

type RequestOverrides = Pick<ApiRequestOptions, 'platform' | 'signal' | 'headers'>;

const basePath = '/api/v1/grid-layouts';

/** Valor de SelectBox para la plantilla de sistema / baseline. */
export const GRID_LAYOUT_ORIGINAL_VALUE = 'original';

export function formatGridLayoutDisplayName(
  layoutName: string,
  isOwner: boolean,
  ownerSuffix = ' (*)'
): string {
  return isOwner ? `${layoutName}${ownerSuffix}` : layoutName;
}

export function listGridLayouts(
  proceso: string,
  gridId: string,
  options: RequestOverrides = {}
): Promise<ApiClientResult<{ items: GridLayoutListItem[] }>> {
  const query = new URLSearchParams({ proceso, gridId }).toString();
  return apiRequest<{ items: GridLayoutListItem[] }>(`${basePath}?${query}`, {
    method: 'GET',
    ...options,
  });
}

export function getActiveGridLayout(
  proceso: string,
  gridId: string,
  options: RequestOverrides = {}
): Promise<ApiClientResult<GridLayoutActiveDto>> {
  const query = new URLSearchParams({ proceso, gridId }).toString();
  return apiRequest<GridLayoutActiveDto>(`${basePath}/active?${query}`, {
    method: 'GET',
    ...options,
  });
}

export function setActiveGridLayout(
  body: { proceso: string; gridId: string; layoutId: number | null },
  options: RequestOverrides = {}
): Promise<ApiClientResult<{ layoutId: number | null }>> {
  return apiRequest<{ layoutId: number | null }>(`${basePath}/active`, {
    method: 'PUT',
    body: JSON.stringify(body),
    ...options,
  });
}

export function createGridLayout(
  body: {
    proceso: string;
    gridId: string;
    layoutName: string;
    stateJson: unknown;
  },
  options: RequestOverrides = {}
): Promise<ApiClientResult<{ item: GridLayoutListItem }>> {
  return apiRequest<{ item: GridLayoutListItem }>(basePath, {
    method: 'POST',
    body: JSON.stringify(body),
    ...options,
  });
}

export function updateGridLayout(
  id: number,
  body: { stateJson: unknown },
  options: RequestOverrides = {}
): Promise<ApiClientResult<{ item: GridLayoutListItem }>> {
  return apiRequest<{ item: GridLayoutListItem }>(`${basePath}/${id}`, {
    method: 'PUT',
    body: JSON.stringify(body),
    ...options,
  });
}

export function deleteGridLayout(
  id: number,
  options: RequestOverrides = {}
): Promise<ApiClientResult<{ deleted: boolean }>> {
  return apiRequest<{ deleted: boolean }>(`${basePath}/${id}`, {
    method: 'DELETE',
    ...options,
  });
}
