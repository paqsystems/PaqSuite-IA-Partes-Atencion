export type GridPageSizeParamKey = 'GridPageSize1' | 'GridPageSize2' | 'GridPageSize3';
export type GridPageSizeParams = Partial<Record<GridPageSizeParamKey, number>>;

const defaultPageSizes: readonly [number, number, number] = [10, 25, 50];
const paramKeys: readonly GridPageSizeParamKey[] = ['GridPageSize1', 'GridPageSize2', 'GridPageSize3'];

/**
 * Resuelve los tamaños de página desde parámetros de sistema (GridPageSize1..3),
 * con fallback posicional a `[10, 25, 50]` (GEN-11).
 */
export function resolveGridPageSizes(params?: GridPageSizeParams): number[] {
  return paramKeys.map((key, index) => {
    const value = params?.[key];
    return typeof value === 'number' && value > 0 ? value : defaultPageSizes[index];
  });
}
