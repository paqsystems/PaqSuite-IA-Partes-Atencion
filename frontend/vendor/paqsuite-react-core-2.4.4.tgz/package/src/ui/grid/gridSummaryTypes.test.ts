import { describe, expect, it } from 'vitest';
import {
  inferGridColumnDataType,
  isGridTotalItemActive,
  resolveAllowedGridSummaryTypes,
  toggleGridTotalItem,
} from './gridSummaryTypes';

describe('resolveAllowedGridSummaryTypes', () => {
  it('numéricos: contar, sumar, min, max, promedio', () => {
    expect(resolveAllowedGridSummaryTypes('number')).toEqual([
      'count',
      'sum',
      'min',
      'max',
      'avg',
    ]);
    expect(resolveAllowedGridSummaryTypes('numeric')).toEqual([
      'count',
      'sum',
      'min',
      'max',
      'avg',
    ]);
  });

  it('textos: contar, min, max', () => {
    expect(resolveAllowedGridSummaryTypes('string')).toEqual(['count', 'min', 'max']);
    expect(resolveAllowedGridSummaryTypes(undefined)).toEqual(['count', 'min', 'max']);
  });

  it('fechas: contar, min, max', () => {
    expect(resolveAllowedGridSummaryTypes('date')).toEqual(['count', 'min', 'max']);
    expect(resolveAllowedGridSummaryTypes('datetime')).toEqual(['count', 'min', 'max']);
  });
});

describe('inferGridColumnDataType', () => {
  it('infiere number / date / string', () => {
    expect(inferGridColumnDataType(12.5)).toBe('number');
    expect(inferGridColumnDataType('2026-07-31')).toBe('date');
    expect(inferGridColumnDataType('hola')).toBe('string');
  });
});

describe('toggleGridTotalItem', () => {
  it('agrega y quita el mismo totalizador', () => {
    const once = toggleGridTotalItem([], 'duracionMinutos', 'sum');
    expect(once).toHaveLength(1);
    expect(isGridTotalItemActive(once, 'duracionMinutos', 'sum')).toBe(true);
    const twice = toggleGridTotalItem(once, 'duracionMinutos', 'sum');
    expect(twice).toHaveLength(0);
  });
});
