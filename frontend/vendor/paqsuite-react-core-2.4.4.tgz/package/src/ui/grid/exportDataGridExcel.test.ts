import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { buildGridExportFileName, hasGridExportableData } from './exportDataGridExcel';

describe('buildGridExportFileName', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-07-25T10:30:00'));
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('genera nombre .xlsx con el proceso normalizado', () => {
    expect(buildGridExportFileName('Clientes ABM')).toBe('clientes-abm_20260725_1030.xlsx');
  });

  it('usa fallback "grid" si el proceso queda vacío tras normalizar', () => {
    expect(buildGridExportFileName('***')).toBe('grid_20260725_1030.xlsx');
  });
});

describe('hasGridExportableData', () => {
  it('exige filas y no loading', () => {
    expect(hasGridExportableData([{ a: 1 }], false)).toBe(true);
    expect(hasGridExportableData([], false)).toBe(false);
    expect(hasGridExportableData([{ a: 1 }], true)).toBe(false);
  });
});
