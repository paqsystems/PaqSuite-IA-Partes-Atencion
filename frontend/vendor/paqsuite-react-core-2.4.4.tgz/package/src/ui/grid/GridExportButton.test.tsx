import { describe, expect, it, vi } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import { GridExportButton } from './GridExportButton';

vi.mock('devextreme-react/drop-down-button', () => ({
  default: (props: {
    text?: string;
    disabled?: boolean;
    elementAttr?: Record<string, string>;
    items?: Array<{ id: string; text: string; testId: string }>;
  }) => (
    <div
      data-testid={props.elementAttr?.['data-testid']}
      data-disabled={props.disabled ? 'true' : 'false'}
      data-text={props.text}
    >
      {(props.items ?? []).map((item) => (
        <div key={item.id} data-testid={item.testId}>
          {item.text}
        </div>
      ))}
    </div>
  ),
}));

describe('GridExportButton', () => {
  it('expone Excel con modos Básico y Formateado', () => {
    const html = renderToStaticMarkup(
      <GridExportButton onExport={() => undefined} disabled />
    );

    expect(html).toContain('gridExport');
    expect(html).toContain('gridExportModeBasic');
    expect(html).toContain('gridExportModeFormatted');
    expect(html).toContain('data-text="Excel"');
    expect(html).toContain('Básico');
    expect(html).toContain('Formateado');
    expect(html).toContain('data-disabled="true"');
  });
});
