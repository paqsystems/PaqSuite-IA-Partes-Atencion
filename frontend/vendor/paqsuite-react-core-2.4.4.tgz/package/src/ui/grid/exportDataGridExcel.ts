import dxDataGrid from 'devextreme/ui/data_grid';
import { exportDataGrid } from 'devextreme/common/export/excel';
import { Workbook } from 'exceljs';

export type GridExportMode = 'basic' | 'formatted';

export const defaultGridExportMode: GridExportMode = 'formatted';

/** Nombre de archivo de export Excel — GEN-11. */
export function buildGridExportFileName(proceso: string): string {
  const now = new Date();
  const yyyy = String(now.getFullYear());
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  const hh = String(now.getHours()).padStart(2, '0');
  const mi = String(now.getMinutes()).padStart(2, '0');
  const stamp = `${yyyy}${mm}${dd}_${hh}${mi}`;
  const safeProceso = proceso
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return `${safeProceso || 'grid'}_${stamp}.xlsx`;
}

export type ExportDataGridExcelInput = {
  proceso: string;
  component: dxDataGrid;
  /** `formatted` aplica estilos DX; `basic` limpia negrita/numFmt/fill. */
  mode?: GridExportMode;
};

function stripBasicCellStyles(excelCell: {
  font?: { bold?: boolean; [key: string]: unknown };
  fill?: unknown;
  numFmt?: string;
}): void {
  excelCell.font = { ...(excelCell.font ?? {}), bold: false };
  excelCell.fill = undefined;
  excelCell.numFmt = undefined;
}

/**
 * Export Excel cliente vía DevExtreme `exportDataGrid` + exceljs (GEN-11).
 * Default mode: `formatted`.
 */
export async function exportDataGridExcel(input: ExportDataGridExcelInput): Promise<void> {
  if (typeof document === 'undefined') {
    return;
  }

  const mode = input.mode ?? defaultGridExportMode;
  const workbook = new Workbook();
  const worksheet = workbook.addWorksheet('Data');

  await exportDataGrid({
    component: input.component,
    worksheet,
    autoFilterEnabled: mode !== 'basic',
    customizeCell:
      mode === 'basic'
        ? ({ excelCell }) => {
            if (excelCell) {
              stripBasicCellStyles(excelCell);
            }
          }
        : undefined,
  });

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = buildGridExportFileName(input.proceso);
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}

/** True si hay filas de datos visibles exportables. */
export function hasGridExportableData(
  dataSource: unknown,
  loading?: boolean
): boolean {
  if (loading) {
    return false;
  }
  if (Array.isArray(dataSource)) {
    return dataSource.length > 0;
  }
  return true;
}
