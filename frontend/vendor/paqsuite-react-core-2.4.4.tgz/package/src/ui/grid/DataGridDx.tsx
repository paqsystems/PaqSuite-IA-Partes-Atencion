import {
  forwardRef,
  useCallback,
  useImperativeHandle,
  useMemo,
  useRef,
  type ReactNode,
} from 'react';
import DataGrid, {
  Column,
  ColumnChooser,
  Export,
  FilterRow,
  GroupPanel,
  HeaderFilter,
  Pager,
  Paging,
  Selection,
  type DataGridRef,
} from 'devextreme-react/data-grid';
import dxDataGrid from 'devextreme/ui/data_grid';
import { exportDataGridExcel, type GridExportMode } from './exportDataGridExcel';
import { GridExportButton } from './GridExportButton';
import { GridRefreshButton } from './GridRefreshButton';
import { applyState, captureState, type GridState } from './gridState';
import { resolveGridPageSizes, type GridPageSizeParams } from './pageSizes';

export type DataGridColumn = { key: string; caption: string };

export type DataGridDxProps = {
  proceso: string;
  gridId: string;
  locale?: string;
  columns: DataGridColumn[];
  rows: Record<string, unknown>[];
  toolbarEnd?: ReactNode;
  exportEnabled?: boolean;
  onRefresh?: () => void;
  pageSizes?: GridPageSizeParams;
};

export type DataGridDxHandle = {
  applyState: (state: GridState) => void;
  captureState: () => GridState;
  refresh: () => void;
};

function getGridInstance(ref: DataGridRef | null): dxDataGrid | undefined {
  if (!ref) {
    return undefined;
  }
  const maybe = ref as DataGridRef & { instance?: () => dxDataGrid };
  if (typeof maybe.instance === 'function') {
    return maybe.instance();
  }
  return undefined;
}

/**
 * Wrapper DataGrid DevExtreme — composición GEN-11 (`proceso` + `gridId`).
 * Remount vía `key={gridId-locale}`. Export auto-append si `exportEnabled`.
 */
export const DataGridDx = forwardRef<DataGridDxHandle, DataGridDxProps>(function DataGridDx(
  { proceso, gridId, locale, columns, rows, toolbarEnd, exportEnabled = true, onRefresh, pageSizes },
  ref
) {
  const remountKey = `${gridId}-${locale ?? 'default'}`;
  const resolvedPageSizes = useMemo(() => resolveGridPageSizes(pageSizes), [pageSizes]);
  const gridRef = useRef<DataGridRef>(null);

  const handleExport = useCallback(
    (mode: GridExportMode) => {
      const instance = getGridInstance(gridRef.current);
      if (!instance) {
        return;
      }
      void exportDataGridExcel({ proceso, component: instance, mode });
    },
    [proceso]
  );

  useImperativeHandle(
    ref,
    () => ({
      applyState: (state) => {
        const instance = getGridInstance(gridRef.current);
        if (!instance) {
          return;
        }
        const current = (instance.state?.() ?? {}) as GridState;
        const target = {
          pageSize: Number(current.pageSize ?? resolvedPageSizes[0]),
          columns: (current.columns as GridState['columns']) ?? [],
        };
        applyState(target, state);
        instance.state?.(target as never);
      },
      captureState: () => {
        const instance = getGridInstance(gridRef.current);
        if (!instance) {
          return captureState({ pageSize: resolvedPageSizes[0], columns: [] });
        }
        const current = (instance.state?.() ?? {}) as GridState;
        return captureState({
          pageSize: Number(current.pageSize ?? resolvedPageSizes[0]),
          columns: (current.columns as GridState['columns']) ?? [],
        });
      },
      refresh: () => onRefresh?.(),
    }),
    [onRefresh, resolvedPageSizes]
  );

  return (
    <div data-testid="dataGridDx" data-grid-instance={remountKey}>
      <div style={{ display: 'flex', gap: 8, marginBottom: 8, flexWrap: 'wrap' }}>
        {onRefresh ? <GridRefreshButton onRefresh={onRefresh} /> : null}
        {toolbarEnd}
        {exportEnabled ? (
          <GridExportButton onExport={handleExport} disabled={rows.length === 0} />
        ) : null}
      </div>
      <DataGrid
        key={remountKey}
        ref={gridRef}
        dataSource={rows}
        keyExpr={columns[0]?.key}
        showBorders
        columnAutoWidth
        allowColumnReordering
        allowColumnResizing
        rowAlternationEnabled
        hoverStateEnabled
        elementAttr={{ 'data-testid': `dataGridDx-${gridId}` }}
      >
        <Selection mode="none" />
        <GroupPanel visible />
        <FilterRow visible />
        <HeaderFilter visible />
        <ColumnChooser enabled />
        <Paging defaultPageSize={resolvedPageSizes[0]} />
        <Pager
          visible
          showPageSizeSelector
          allowedPageSizes={[...resolvedPageSizes]}
          showInfo
        />
        <Export enabled={false} />
        {columns.map((column) => (
          <Column key={column.key} dataField={column.key} caption={column.caption} />
        ))}
      </DataGrid>
    </div>
  );
});
