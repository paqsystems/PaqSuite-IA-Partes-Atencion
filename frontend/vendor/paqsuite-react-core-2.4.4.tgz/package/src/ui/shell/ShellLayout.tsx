import { useState, type ReactNode } from 'react';
import Button from 'devextreme-react/button';
import { shellClassNames } from '../tokens';

export type ShellFooterInfo = {
  iso?: ReactNode;
  logo?: ReactNode;
  brandLabel?: ReactNode;
  user: ReactNode;
  empresa: ReactNode;
  version: ReactNode;
};

export type ShellLayoutProps = {
  brand: ReactNode;
  avatarSlot?: ReactNode;
  languageSlot?: ReactNode;
  menuSlot: ReactNode;
  children: ReactNode;
  footer: ShellFooterInfo;
  /** Preferencia GEN-07: colapsa el aside en desktop. */
  sidebarVisible?: boolean;
  /** Alterna visibilidad del sidebar (header hamburger / toolbar menú). */
  onToggleSidebarVisible?: () => void;
};

/**
 * Shell GEN-01: markup estructural + toggle DevExtreme (`Button`).
 * Drawer ≤767px vía clase CSS `pqShellMenuOpen`.
 * Hosts: import `@paqsuite/react-core/shell.css`.
 */
export function ShellLayout({
  brand,
  avatarSlot,
  languageSlot,
  menuSlot,
  children,
  footer,
  sidebarVisible = true,
  onToggleSidebarVisible,
}: ShellLayoutProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  const rootClassNames = [shellClassNames.root];
  if (menuOpen) {
    rootClassNames.push(shellClassNames.menuOpen);
  }
  if (!sidebarVisible) {
    rootClassNames.push('pqShellSidebarCollapsed');
  }

  return (
    <div className={rootClassNames.join(' ')} data-testid="shellLayout">
      <header className={shellClassNames.header} data-testid="shellHeader">
        <div className="pqShellHeaderStart">
          <Button
            icon="menu"
            stylingMode="text"
            className={shellClassNames.menuToggle}
            elementAttr={{
              'data-testid': 'shellMenuToggle',
              'aria-label': 'menu',
              class: shellClassNames.menuToggle,
            }}
            onClick={() => {
              onToggleSidebarVisible?.();
              setMenuOpen((open) => !open);
            }}
          />
          <div className={shellClassNames.brand}>{brand}</div>
        </div>
        <div className="pqShellHeaderEnd">
          {languageSlot}
          {avatarSlot}
        </div>
      </header>
      <aside className={shellClassNames.aside} data-testid="shellSidebar">
        {menuSlot}
      </aside>
      <main className={shellClassNames.main} data-testid="shellMain">
        {children}
      </main>
      <footer className={shellClassNames.footer} data-testid="shellFooter">
        <div className="pqShellFooterBrand">
          {footer.iso}
          {footer.logo}
          {footer.brandLabel ? <strong>{footer.brandLabel}</strong> : null}
        </div>
        <div className="pqShellFooterMeta">
          <span data-testid="shellFooterEmpresa">{footer.empresa}</span>
          <span data-testid="shellFooterUser">{footer.user}</span>
          <span data-testid="shellFooterVersion">{footer.version}</span>
        </div>
      </footer>
    </div>
  );
}
