import { isValidElement, type ReactNode } from 'react';
import { AuthLoginLayout } from './AuthLoginLayout';
import type { AuthHeroConfig } from './authHeroConfig';

/**
 * @deprecated Preferir `AuthLoginLayout` + `AuthHeroConfig` (TR-GEN-01).
 * Adapter temporal: mapea `brand`/`title` al layout hero+card.
 */
export type AuthPageLayoutProps = {
  brand: ReactNode;
  title: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  /** Tagline del producto; si falta, el hero solo muestra el título. */
  productTagline?: string;
  companyLogoUrl?: string | null;
  badge?: ReactNode;
  cardHint?: ReactNode;
  toolbar?: ReactNode;
};

function nodeToPlainText(node: ReactNode): string {
  if (typeof node === 'string' || typeof node === 'number') {
    return String(node);
  }
  if (Array.isArray(node)) {
    return node.map(nodeToPlainText).join('');
  }
  if (isValidElement<{ children?: ReactNode }>(node) && node.props.children != null) {
    return nodeToPlainText(node.props.children);
  }
  return '';
}

/**
 * Layout estructural auth. Delegado a `AuthLoginLayout`.
 * Controles interactivos van en `children` / `toolbar`.
 */
export function AuthPageLayout({
  brand,
  title,
  children,
  footer,
  productTagline = '',
  companyLogoUrl = null,
  badge,
  cardHint,
  toolbar,
}: AuthPageLayoutProps) {
  const hero: AuthHeroConfig = {
    productTitle: nodeToPlainText(brand) || 'PaqSuite',
    productTagline,
    companyLogoUrl,
  };

  return (
    <AuthLoginLayout
      hero={hero}
      badge={badge}
      cardTitle={title}
      cardHint={cardHint}
      toolbar={toolbar}
      footer={footer}
    >
      {children}
    </AuthLoginLayout>
  );
}
