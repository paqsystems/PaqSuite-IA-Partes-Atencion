import type { ReactNode } from 'react';
import type { AuthHeroConfig } from './authHeroConfig';

export type AuthLoginLayoutProps = {
  hero: AuthHeroConfig;
  /** Badge de plataforma; default «PaqSuite IA». */
  badge?: ReactNode;
  /** Título de la card («Iniciar sesión»). */
  cardTitle: ReactNode;
  /** Texto de ayuda bajo el título de la card. */
  cardHint?: ReactNode;
  /** Toolbar (idioma, config mobile, etc.). */
  toolbar?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
};

/**
 * Layout login hero + card (familia visual PedidosWeb / TR-GEN-01).
 * Controles interactivos van en `toolbar` / `children` (DevExtreme).
 */
export function AuthLoginLayout({
  hero,
  badge = 'PaqSuite IA',
  cardTitle,
  cardHint,
  toolbar,
  children,
  footer,
}: AuthLoginLayoutProps) {
  const logoUrl = hero.companyLogoUrl?.trim() || null;

  return (
    <main className="pqAuthLoginPage" data-testid="authLoginPage">
      <section className="pqAuthLoginHero" data-testid="authLoginHero">
        <div className="pqAuthLoginHeroContent">
          {logoUrl ? (
            <img
              className="pqAuthLoginLogo"
              src={logoUrl}
              alt=""
              data-testid="authCompanyLogo"
            />
          ) : null}
          <span className="pqAuthLoginBadge">{badge}</span>
          <h1 className="pqAuthLoginTitle">{hero.productTitle}</h1>
          {hero.productTagline ? (
            <p className="pqAuthLoginTagline">{hero.productTagline}</p>
          ) : null}
        </div>
      </section>

      <section className="pqAuthLoginPanel">
        <div className="pqAuthLoginCard" data-testid="authLoginCard">
          {toolbar ? (
            <div className="pqAuthLoginToolbar">
              <div className="pqAuthLoginToolbarEnd">{toolbar}</div>
            </div>
          ) : null}

          <div className="pqAuthLoginCardHeader">
            <h2 className="pqAuthLoginCardHeading">{cardTitle}</h2>
            {cardHint ? <p className="pqAuthLoginCardHint">{cardHint}</p> : null}
          </div>

          {children}

          {footer ? <footer className="pqAuthLoginFooter">{footer}</footer> : null}
        </div>
      </section>
    </main>
  );
}
