/**
 * Configuración build-time del hero de login (TR-GEN-01 / SPEC-001-01 §1.3).
 * Sin API runtime: el host resuelve env o i18n al montar.
 */

export type AuthHeroConfig = {
  productTitle: string;
  productTagline: string;
  companyLogoUrl: string | null;
};

export type ResolveAuthHeroConfigInput = {
  /** Título del producto (ej. VITE_AUTH_PRODUCT_TITLE). */
  productTitle?: string | null;
  /** Descripción / tagline (ej. VITE_AUTH_PRODUCT_TAGLINE). */
  productTagline?: string | null;
  /** URL de logo; vacío → null (no renderizar). */
  companyLogoUrl?: string | null;
  /** Fallback si falta productTitle. */
  fallbackTitle?: string;
  /** Fallback si falta productTagline. */
  fallbackTagline?: string;
};

function trimOrNull(value: string | null | undefined): string | null {
  if (value == null) {
    return null;
  }
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
}

/**
 * Normaliza título, tagline y logo opcionales para el hero auth.
 */
export function resolveAuthHeroConfig(
  input: ResolveAuthHeroConfigInput = {}
): AuthHeroConfig {
  const productTitle =
    trimOrNull(input.productTitle) ??
    trimOrNull(input.fallbackTitle) ??
    'PaqSuite';
  const productTagline =
    trimOrNull(input.productTagline) ??
    trimOrNull(input.fallbackTagline) ??
    '';
  const companyLogoUrl = trimOrNull(input.companyLogoUrl);

  return {
    productTitle,
    productTagline,
    companyLogoUrl,
  };
}

/**
 * Lee `import.meta.env` de Vite cuando está disponible (host frontend).
 * En tests/Node sin Vite, devolver objeto vacío y usar fallbacks.
 */
export function readViteAuthHeroEnv(): Pick<
  ResolveAuthHeroConfigInput,
  'productTitle' | 'productTagline' | 'companyLogoUrl'
> {
  try {
    const env = (import.meta as ImportMeta & { env?: Record<string, string | undefined> })
      .env;
    if (!env) {
      return {};
    }
    return {
      productTitle: env.VITE_AUTH_PRODUCT_TITLE,
      productTagline: env.VITE_AUTH_PRODUCT_TAGLINE,
      companyLogoUrl: env.VITE_AUTH_COMPANY_LOGO_URL,
    };
  } catch {
    return {};
  }
}
