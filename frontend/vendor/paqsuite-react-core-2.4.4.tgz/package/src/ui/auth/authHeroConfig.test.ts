import { describe, expect, it } from 'vitest';
import { resolveAuthHeroConfig } from './authHeroConfig';

describe('resolveAuthHeroConfig', () => {
  it('usa título y tagline desde input', () => {
    const config = resolveAuthHeroConfig({
      productTitle: 'Partes de Atención',
      productTagline: 'Gestión de partes y seguimiento operativo.',
      companyLogoUrl: 'https://cdn.example/logo.png',
    });

    expect(config).toEqual({
      productTitle: 'Partes de Atención',
      productTagline: 'Gestión de partes y seguimiento operativo.',
      companyLogoUrl: 'https://cdn.example/logo.png',
    });
  });

  it('omite logo vacío y aplica fallbacks', () => {
    const config = resolveAuthHeroConfig({
      productTitle: '  ',
      productTagline: null,
      companyLogoUrl: '',
      fallbackTitle: 'Mi Producto',
      fallbackTagline: 'Descripción del portal.',
    });

    expect(config.productTitle).toBe('Mi Producto');
    expect(config.productTagline).toBe('Descripción del portal.');
    expect(config.companyLogoUrl).toBeNull();
  });
});
