import type { ReactNode } from 'react';

export type AuthCardLayoutProps = {
  /** `authForgotPage` | `authResetPage` u otro testid estable. */
  testId: string;
  title: ReactNode;
  hint?: ReactNode;
  /** Logo opcional encima del título; vacío → omitir. */
  companyLogoUrl?: string | null;
  toolbar?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
};

/**
 * Card centrada sobre gradiente auth (forgot / reset — TR-GEN-01 §1.6).
 */
export function AuthCardLayout({
  testId,
  title,
  hint,
  companyLogoUrl,
  toolbar,
  children,
  footer,
}: AuthCardLayoutProps) {
  const logoUrl = companyLogoUrl?.trim() || null;

  return (
    <main className="pqAuthCenteredPage" data-testid={testId}>
      <div className="pqAuthCenteredCard">
        {toolbar ? (
          <div className="pqAuthLoginToolbar">
            <div className="pqAuthLoginToolbarEnd">{toolbar}</div>
          </div>
        ) : null}

        {logoUrl ? (
          <img
            className="pqAuthCenteredLogo"
            src={logoUrl}
            alt=""
            data-testid="authCompanyLogo"
          />
        ) : null}

        <h1 className="pqAuthCenteredHeading">{title}</h1>
        {hint ? <p className="pqAuthCenteredHint">{hint}</p> : null}

        {children}

        {footer ? <footer className="pqAuthCenteredFooter">{footer}</footer> : null}
      </div>
    </main>
  );
}
