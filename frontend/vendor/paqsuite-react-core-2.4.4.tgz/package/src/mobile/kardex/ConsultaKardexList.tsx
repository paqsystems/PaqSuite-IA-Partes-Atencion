import type { ReactNode } from 'react';
import Button from 'devextreme-react/button';
import List from 'devextreme-react/list';
import LoadPanel from 'devextreme-react/load-panel';
import type { KardexItem } from './types';

export type ConsultaKardexListProps = {
  items: KardexItem[];
  loading?: boolean;
  filtersSlot?: ReactNode;
  onItemTap: (item: KardexItem) => void;
  onRefresh?: () => void | Promise<void>;
  onLoadMore?: () => void | Promise<void>;
  hasMore?: boolean;
  emptyText?: string;
  t?: (key: string) => string;
};

/**
 * Presentador kardex GEN-22: lista vertical de tarjetas (List DX), tap → detalle host.
 */
export function ConsultaKardexList({
  items,
  loading = false,
  filtersSlot,
  onItemTap,
  onRefresh,
  onLoadMore,
  hasMore = false,
  emptyText,
  t,
}: ConsultaKardexListProps) {
  const translate = t ?? ((key: string) => key);
  const empty = emptyText ?? translate('consulta.kardex.empty');

  return (
    <div className="paqConsultaKardex" data-testid="consultaKardexList">
      {filtersSlot ? (
        <div className="paqConsultaKardexFilters" data-testid="consultaKardexFilters">
          {filtersSlot}
        </div>
      ) : null}

      {onRefresh ? (
        <Button
          icon="refresh"
          stylingMode="text"
          onClick={() => void onRefresh()}
          elementAttr={{ 'data-testid': 'consultaKardexRefresh' }}
        />
      ) : null}

      <LoadPanel visible={loading} showIndicator showPane={false} />

      <List
        dataSource={items}
        keyExpr="id"
        noDataText={empty}
        onItemClick={(event) => {
          const item = event.itemData as KardexItem | undefined;
          if (item) {
            onItemTap(item);
          }
        }}
        itemRender={(item: KardexItem) => (
          <article
            className="paqKardexCard"
            data-testid={`kardexCard-${item.id}`}
            data-status-tone={item.status?.tone ?? 'neutral'}
          >
            <header>
              <strong>{item.title}</strong>
              {item.subtitle ? <div>{item.subtitle}</div> : null}
              {item.status ? (
                <span data-testid="kardexCardStatus">{item.status.text}</span>
              ) : null}
            </header>
            <dl>
              {item.fields.slice(0, 4).map((field) => (
                <div key={`${item.id}-${field.label}`}>
                  <dt>{field.label}</dt>
                  <dd>{field.value}</dd>
                </div>
              ))}
            </dl>
          </article>
        )}
        elementAttr={{ 'data-testid': 'consultaKardexItems' }}
      />

      {hasMore && onLoadMore ? (
        <Button
          text={translate('consulta.kardex.loadMore')}
          onClick={() => void onLoadMore()}
          elementAttr={{ 'data-testid': 'consultaKardexLoadMore' }}
        />
      ) : null}
    </div>
  );
}
