import {
  genMobileExclusions,
  isExcludedByGenCatalog,
} from './genMobileExclusions';

export type PivotMenuItemLike = {
  routeName?: string | null;
  procedimiento?: string | null;
  menuKey?: string | null;
  /** Metadata Should: consultaId registrada en `pq_pivots_consultas`. */
  consultaId?: string | null;
  tipoProceso?: string | null;
  /** Catálogo de consultaIds pivot conocidos (host/seed). */
  knownPivotConsultaIds?: Iterable<string>;
};

function pivotsOnlyExclusions() {
  return genMobileExclusions.filter((entry) => entry.family === 'pivots');
}

/**
 * Identifica ítems de menú/procesos pivot para exclusión native (GEN-12 / C1-12-F05).
 * Criterio: ruta OR procedimientoContains `pivot` OR menuKey/tipo OR consultaId en catálogo.
 * Informe mixto grilla+pivot: si matchea, se excluye el **proceso entero**.
 */
export function isPivotMenuItem(item: PivotMenuItemLike): boolean {
  const route = item.routeName?.trim() ?? '';
  const procedimiento = item.procedimiento ?? null;
  const pivots = pivotsOnlyExclusions();

  if (route && isExcludedByGenCatalog(route, null, pivots)) {
    return true;
  }

  if (procedimiento && isExcludedByGenCatalog('/__pivot_probe__', procedimiento, pivots)) {
    return true;
  }

  const menuKey = item.menuKey?.toLowerCase() ?? '';
  if (menuKey.includes('pivot')) {
    return true;
  }

  const tipo = item.tipoProceso?.toLowerCase() ?? '';
  if (tipo.includes('pivot')) {
    return true;
  }

  const consultaId = item.consultaId?.trim();
  if (consultaId && item.knownPivotConsultaIds) {
    const known = new Set(
      Array.from(item.knownPivotConsultaIds, (id) => String(id).trim()).filter(Boolean)
    );
    if (known.has(consultaId)) {
      return true;
    }
  }

  return false;
}

/** Clave i18n al bloquear deep-link / menú pivot en native. */
export const mobileExclusionPivotI18nKey = 'mobile.exclusion.pivot';

export function resolveMobileExclusionI18nKey(
  pathname: string,
  procedimiento?: string | null
): string {
  if (isPivotMenuItem({ routeName: pathname, procedimiento })) {
    return mobileExclusionPivotI18nKey;
  }
  return 'menu.forbidden';
}
