import { describe, expect, it } from 'vitest';
import {
  buildMobileHealthUrl,
  evaluateMobileConfigSaveGate,
} from './mobileConfigRules';
import { resolveApiBaseUrl } from './resolveApiBaseUrl';

describe('evaluateMobileConfigSaveGate', () => {
  it('bloquea save sin tenant', () => {
    expect(evaluateMobileConfigSaveGate({ tenant: null, healthOk: true })).toEqual({
      canSave: false,
      messageKey: 'mobile.config.tenantRequired',
    });
    expect(evaluateMobileConfigSaveGate({ tenant: '  ', healthOk: true }).canSave).toBe(
      false
    );
  });

  it('bloquea save si health no OK', () => {
    expect(
      evaluateMobileConfigSaveGate({ tenant: 'demo', healthOk: false })
    ).toEqual({
      canSave: false,
      messageKey: 'mobile.config.testFail',
    });
  });

  it('permite save con tenant + health OK', () => {
    expect(
      evaluateMobileConfigSaveGate({ tenant: 'demo', healthOk: true })
    ).toEqual({ canSave: true });
  });
});

describe('buildMobileHealthUrl', () => {
  it('usa base /api/v1 + /health (C1-22-02)', () => {
    const base = resolveApiBaseUrl({
      override: 'http://10.0.2.2:8088',
      projectSlug: 'smoke',
    });
    expect(buildMobileHealthUrl(base)).toBe('http://10.0.2.2:8088/api/v1/health');
  });
});
