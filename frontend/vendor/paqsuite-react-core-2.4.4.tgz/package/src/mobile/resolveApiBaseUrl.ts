/**
 * Resuelve URL base API (C1-22-02): siempre termina en `/api/v1`.
 * Web multidominio: usar `applyWebApiBaseUrlFromEnv` / `bootstrapApiBaseUrl`.
 */

export type ResolveApiBaseUrlInput = {
  override: string | null;
  envBaseUrl?: string;
  projectSlug: string;
};

let cachedOverride: string | null = null;
let cachedResolvedBase: string | null = null;

/** True si el valor es URL http(s) absoluta. */
export function isAbsoluteHttpUrl(value: string): boolean {
  return /^https?:\/\//i.test(value.trim());
}

/** Normaliza cualquier URL a `.../api/v1` sin slash final extra. */
export function normalizeApiBaseUrl(raw: string): string {
  let value = raw.trim();
  if (!value) {
    return '';
  }

  value = value.replace(/\/+$/, '');

  if (/\/api\/v1$/i.test(value)) {
    return value;
  }

  if (/\/api$/i.test(value)) {
    return `${value}/v1`;
  }

  return `${value}/api/v1`;
}

/**
 * Orden: override → envBaseUrl → `https://backend.{projectSlug}.paqsystems.com/api/v1`.
 * Uso principal: mobile / Preferences. En web preferir `applyWebApiBaseUrlFromEnv`
 * (sin fallback de slug, para no romper Vite proxy local).
 */
export function resolveApiBaseUrl(input: ResolveApiBaseUrlInput): string {
  const fromOverride = input.override?.trim() || null;
  const fromEnv = input.envBaseUrl?.trim() || null;
  const fallback = `https://backend.${input.projectSlug}.paqsystems.com/api/v1`;
  const chosen = fromOverride || fromEnv || fallback;
  return normalizeApiBaseUrl(chosen);
}

/**
 * Web / build estático (Vercel, etc.): si `VITE_API_BASE_URL` es absoluta, cachea base
 * para `apiRequest`. Si está vacía o es relativa (`/api/v1`), deja same-origin
 * (proxy Vite local o reverse proxy).
 *
 * No usa fallback `backend.{slug}` — eso rompería `npm run dev` local.
 */
export function applyWebApiBaseUrlFromEnv(
  envBaseUrl?: string | null
): string | null {
  const raw = envBaseUrl?.trim() ?? '';
  if (!raw || !isAbsoluteHttpUrl(raw)) {
    setCachedResolvedApiBaseUrl(null);
    return null;
  }

  const resolved = normalizeApiBaseUrl(raw);
  setCachedResolvedApiBaseUrl(resolved);
  return resolved;
}

export function setCachedApiBaseUrlOverride(override: string | null): void {
  cachedOverride = override?.trim() || null;
  cachedResolvedBase = null;
}

export function getCachedApiBaseUrlOverride(): string | null {
  return cachedOverride;
}

export function setCachedResolvedApiBaseUrl(base: string | null): void {
  cachedResolvedBase = base ? normalizeApiBaseUrl(base) : null;
}

export function getCachedResolvedApiBaseUrl(): string | null {
  return cachedResolvedBase;
}

/**
 * Une path relativo (`/api/v1/...`) con la base resuelta (si hay cache).
 * Sin cache, devuelve el path tal cual (mismo origen web).
 */
export function resolveRequestUrl(path: string): string {
  if (/^https?:\/\//i.test(path)) {
    return path;
  }

  const base = cachedResolvedBase;
  if (!base) {
    return path;
  }

  const suffix = path.replace(/^\/api\/v1\/?/i, '').replace(/^\//, '');
  return `${base.replace(/\/+$/, '')}/${suffix}`;
}
