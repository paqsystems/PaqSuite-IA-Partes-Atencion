import { preferenceKeys } from './preferenceKeys';
import {
  preferencesGet,
  preferencesRemove,
  preferencesSet,
} from './preferencesStorage';
import {
  applyWebApiBaseUrlFromEnv,
  getCachedApiBaseUrlOverride,
  setCachedApiBaseUrlOverride,
  setCachedResolvedApiBaseUrl,
  resolveApiBaseUrl,
} from './resolveApiBaseUrl';
import { isNativeApp } from './isNativeApp';

export type NativeAuthSnapshot = {
  accessToken: string | null;
  tenant: string | null;
  sessionJson: string | null;
};

/** Lee token/tenant/sesión desde Preferences. */
export async function readNativeAuthSnapshot(): Promise<NativeAuthSnapshot> {
  const [accessToken, tenant, sessionJson] = await Promise.all([
    preferencesGet(preferenceKeys.accessToken),
    preferencesGet(preferenceKeys.tenant),
    preferencesGet(preferenceKeys.sessionJson),
  ]);

  return { accessToken, tenant, sessionJson };
}

/** Persiste token + tenant (+ blob opcional) tras login native. */
export async function writeNativeAuthSnapshot(input: {
  accessToken: string;
  tenant: string;
  sessionJson?: string | null;
}): Promise<void> {
  await preferencesSet(preferenceKeys.accessToken, input.accessToken);
  await preferencesSet(preferenceKeys.tenant, input.tenant);
  if (input.sessionJson !== undefined) {
    if (input.sessionJson === null) {
      await preferencesRemove(preferenceKeys.sessionJson);
    } else {
      await preferencesSet(preferenceKeys.sessionJson, input.sessionJson);
    }
  }
}

export async function clearNativeAuthSnapshot(): Promise<void> {
  await Promise.all([
    preferencesRemove(preferenceKeys.accessToken),
    preferencesRemove(preferenceKeys.tenant),
    preferencesRemove(preferenceKeys.sessionJson),
  ]);
}

export async function readApiBaseUrlOverride(): Promise<string | null> {
  return preferencesGet(preferenceKeys.apiBaseUrlOverride);
}

export async function writeApiBaseUrlOverride(value: string): Promise<void> {
  await preferencesSet(preferenceKeys.apiBaseUrlOverride, value);
  setCachedApiBaseUrlOverride(value);
}

export async function clearApiBaseUrlOverride(): Promise<void> {
  await preferencesRemove(preferenceKeys.apiBaseUrlOverride);
  setCachedApiBaseUrlOverride(null);
}

/**
 * Hidrata cache de URL desde Preferences + defaults del host.
 * Debe llamarse al boot native.
 */
export async function hydrateApiBaseUrlCache(input: {
  envBaseUrl?: string;
  projectSlug: string;
}): Promise<string> {
  const override = await readApiBaseUrlOverride();
  setCachedApiBaseUrlOverride(override);
  const resolved = resolveApiBaseUrl({
    override: override ?? getCachedApiBaseUrlOverride(),
    envBaseUrl: input.envBaseUrl,
    projectSlug: input.projectSlug,
  });
  setCachedResolvedApiBaseUrl(resolved);
  return resolved;
}

export type BootstrapApiBaseUrlInput = {
  /** Tipicamente `import.meta.env.VITE_API_BASE_URL`. */
  envBaseUrl?: string | null;
  /** Slug producto (`partesatencion`, `pedidosweb`, …). Obligatorio en native. */
  projectSlug: string;
  /**
   * Forzar rama native. Default: `isNativeApp()`.
   * Web: solo aplica URL absoluta de env (sin fallback slug).
   */
  isNative?: boolean;
};

/**
 * Bootstrap canónico de base API para hosts del SDK (web multidominio + mobile).
 *
 * - **Web:** `applyWebApiBaseUrlFromEnv` — absolute `VITE_API_BASE_URL` → cache;
 *   vacío/relativo → same-origin.
 * - **Native:** `hydrateApiBaseUrlCache` — Preferences override → env → fallback slug.
 *
 * Llamar **antes** del primer `apiRequest` (p. ej. al inicio de `main.tsx`).
 */
export async function bootstrapApiBaseUrl(
  input: BootstrapApiBaseUrlInput
): Promise<string | null> {
  const native = input.isNative ?? isNativeApp();
  if (native) {
    return hydrateApiBaseUrlCache({
      envBaseUrl: input.envBaseUrl ?? undefined,
      projectSlug: input.projectSlug,
    });
  }

  return applyWebApiBaseUrlFromEnv(input.envBaseUrl);
}

/**
 * Migración one-shot: si hay sesión en localStorage y no en Preferences, copiar.
 */
export async function migrateLocalStorageSessionIfNeeded(
  localStorageKey = 'paqAuthSession'
): Promise<boolean> {
  const existing = await preferencesGet(preferenceKeys.accessToken);
  if (existing) {
    return false;
  }

  if (typeof localStorage === 'undefined') {
    return false;
  }

  const raw = localStorage.getItem(localStorageKey);
  if (!raw) {
    return false;
  }

  try {
    const parsed = JSON.parse(raw) as {
      token?: string;
      tenancy?: string;
      user?: { usuario?: string };
    };
    if (!parsed.token) {
      return false;
    }
    await writeNativeAuthSnapshot({
      accessToken: parsed.token,
      tenant: '',
      sessionJson: raw,
    });
    return true;
  } catch {
    return false;
  }
}
