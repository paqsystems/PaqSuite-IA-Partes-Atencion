/**
 * Reglas puras de gate save para MobileConfigPanel (testeables sin DOM).
 */

export function evaluateMobileConfigSaveGate(input: {
  tenant: string | null | undefined;
  healthOk: boolean;
}): { canSave: boolean; messageKey?: string } {
  const tenant = input.tenant?.trim() || null;
  if (!tenant) {
    return { canSave: false, messageKey: 'mobile.config.tenantRequired' };
  }
  if (!input.healthOk) {
    return { canSave: false, messageKey: 'mobile.config.testFail' };
  }
  return { canSave: true };
}

/** Health = `{base}/health` con base ya normalizada a `/api/v1`. */
export function buildMobileHealthUrl(apiBaseUrl: string): string {
  const base = apiBaseUrl.replace(/\/+$/, '');
  return `${base}/health`;
}
