import { useMemo } from 'react';
import Button from 'devextreme-react/button';
import List from 'devextreme-react/list';
import type { MobileMenuItemLike } from './policy/mobileRoutePolicy';

export type MobileMenuShellVariant = 'list' | 'drawer' | 'tiles';

export type MobileMenuShellItem = MobileMenuItemLike & {
  id: string | number;
  text: string;
  nodeType?: 'process' | 'group' | string;
  menuKey?: string;
  children?: MobileMenuShellItem[];
};

export type MobileMenuShellProps = {
  items: MobileMenuShellItem[];
  onNavigate: (routeName: string) => void;
  variant?: MobileMenuShellVariant;
  t?: (key: string) => string;
};

type FlatItem = {
  id: string;
  text: string;
  routeName: string;
  menuKey?: string;
  depth: number;
};

function flattenProcessItems(
  nodes: MobileMenuShellItem[],
  depth = 0
): FlatItem[] {
  const out: FlatItem[] = [];
  for (const node of nodes) {
    if (node.children?.length) {
      out.push(...flattenProcessItems(node.children, depth + 1));
    }
    const route = node.routeName?.trim();
    if (route && node.nodeType !== 'group') {
      out.push({
        id: String(node.id),
        text: node.text,
        routeName: route,
        menuKey: node.menuKey,
        depth,
      });
    }
  }
  return out;
}

/**
 * Menú táctil mobile (GEN-22). Variantes list | drawer | tiles.
 * Default host smoke: drawer.
 */
export function MobileMenuShell({
  items,
  onNavigate,
  variant = 'drawer',
  t,
}: MobileMenuShellProps) {
  const translate = t ?? ((key: string) => key);
  const flat = useMemo(() => flattenProcessItems(items), [items]);

  if (variant === 'tiles') {
    return (
      <nav data-testid="mobileMenuShell" data-variant="tiles">
        <div className="paqMobileMenuTiles">
          {flat.map((item) => (
            <Button
              key={item.id}
              text={item.text}
              stylingMode="outlined"
              onClick={() => onNavigate(item.routeName)}
              elementAttr={{
                'data-testid': `mobileMenuItem-${item.menuKey ?? item.id}`,
              }}
            />
          ))}
        </div>
        {flat.length === 0 ? (
          <p data-testid="mobileMenuEmpty">{translate('menu.empty')}</p>
        ) : null}
      </nav>
    );
  }

  return (
    <nav data-testid="mobileMenuShell" data-variant={variant}>
      <List
        dataSource={flat}
        keyExpr="id"
        noDataText={translate('menu.empty')}
        onItemClick={(event) => {
          const item = event.itemData as FlatItem | undefined;
          if (item?.routeName) {
            onNavigate(item.routeName);
          }
        }}
        itemRender={(item: FlatItem) => (
          <span
            data-testid={`mobileMenuItem-${item.menuKey ?? item.id}`}
            style={{ paddingLeft: item.depth * 8 }}
          >
            {item.text}
          </span>
        )}
        elementAttr={{ 'data-testid': 'mobileMenuList' }}
      />
    </nav>
  );
}
