import {
  normalizeApiBaseUrl,
  resolveApiBaseUrl,
  resolveRequestUrl,
  setCachedResolvedApiBaseUrl,
  applyWebApiBaseUrlFromEnv,
  getCachedResolvedApiBaseUrl,
} from './resolveApiBaseUrl';
import {
  resetPreferencesMemory,
  setPreferencesAdapter,
  type PreferencesAdapter,
} from './preferencesStorage';
import { preferenceKeys } from './preferenceKeys';
import {
  hydrateApiBaseUrlCache,
  bootstrapApiBaseUrl,
  writeNativeAuthSnapshot,
  readNativeAuthSnapshot,
} from './nativeSessionStorage';
import { describe, expect, it, beforeEach } from 'vitest';
import { isNativeApp } from './isNativeApp';

describe('isNativeApp', () => {
  it('retorna false sin window (node)', () => {
    expect(isNativeApp()).toBe(false);
  });

  it('usa isNativePlatform cuando Capacitor está en globalThis', () => {
    const g = globalThis as typeof globalThis & {
      window?: Window & { Capacitor?: { isNativePlatform: () => boolean } };
    };
    const previousWindow = g.window;
    g.window = {
      Capacitor: { isNativePlatform: () => true },
    } as Window & { Capacitor?: { isNativePlatform: () => boolean } };
    expect(isNativeApp()).toBe(true);
    g.window = {
      Capacitor: {},
    } as Window & { Capacitor?: { isNativePlatform: () => boolean } };
    expect(isNativeApp()).toBe(false);
    g.window = previousWindow;
  });
});

describe('resolveApiBaseUrl', () => {
  it('siempre termina en /api/v1 (C1-22-02)', () => {
    expect(
      resolveApiBaseUrl({
        override: 'http://10.0.2.2:8088',
        projectSlug: 'smoke',
      })
    ).toBe('http://10.0.2.2:8088/api/v1');

    expect(normalizeApiBaseUrl('https://x.example.com/api/v1/')).toBe(
      'https://x.example.com/api/v1'
    );

    expect(
      resolveApiBaseUrl({
        override: null,
        envBaseUrl: 'https://backend.demo.paqsystems.com/api/v1',
        projectSlug: 'demo',
      })
    ).toBe('https://backend.demo.paqsystems.com/api/v1');

    expect(
      resolveApiBaseUrl({ override: null, projectSlug: 'acme' })
    ).toBe('https://backend.acme.paqsystems.com/api/v1');
  });

  it('prioriza override sobre env', () => {
    expect(
      resolveApiBaseUrl({
        override: 'http://192.168.1.10:8088/api/v1',
        envBaseUrl: 'https://backend.smoke.paqsystems.com/api/v1',
        projectSlug: 'smoke',
      })
    ).toBe('http://192.168.1.10:8088/api/v1');
  });

  it('resolveRequestUrl une path con base cacheada', () => {
    setCachedResolvedApiBaseUrl('http://10.0.2.2:8088/api/v1');
    expect(resolveRequestUrl('/api/v1/health')).toBe(
      'http://10.0.2.2:8088/api/v1/health'
    );
    setCachedResolvedApiBaseUrl(null);
    expect(resolveRequestUrl('/api/v1/health')).toBe('/api/v1/health');
  });
});

describe('applyWebApiBaseUrlFromEnv / bootstrapApiBaseUrl (web)', () => {
  beforeEach(() => {
    setCachedResolvedApiBaseUrl(null);
  });

  it('cachea solo si env es URL absoluta', () => {
    expect(
      applyWebApiBaseUrlFromEnv(
        'https://backend.partesatencion.paqsystems.com'
      )
    ).toBe('https://backend.partesatencion.paqsystems.com/api/v1');
    expect(getCachedResolvedApiBaseUrl()).toBe(
      'https://backend.partesatencion.paqsystems.com/api/v1'
    );
    expect(resolveRequestUrl('/api/v1/health')).toBe(
      'https://backend.partesatencion.paqsystems.com/api/v1/health'
    );
  });

  it('deja same-origin si env vacío o relativo', () => {
    expect(applyWebApiBaseUrlFromEnv(undefined)).toBeNull();
    expect(getCachedResolvedApiBaseUrl()).toBeNull();
    expect(applyWebApiBaseUrlFromEnv('/api/v1')).toBeNull();
    expect(resolveRequestUrl('/api/v1/health')).toBe('/api/v1/health');
  });

  it('bootstrap web no usa fallback de projectSlug', async () => {
    const resolved = await bootstrapApiBaseUrl({
      envBaseUrl: '',
      projectSlug: 'partesatencion',
      isNative: false,
    });
    expect(resolved).toBeNull();
    expect(getCachedResolvedApiBaseUrl()).toBeNull();
  });

  it('bootstrap web con URL absoluta de Vercel/Forge', async () => {
    const resolved = await bootstrapApiBaseUrl({
      envBaseUrl: 'https://backenddev.partesatencion.paqsystems.com/api/v1',
      projectSlug: 'partesatencion',
      isNative: false,
    });
    expect(resolved).toBe(
      'https://backenddev.partesatencion.paqsystems.com/api/v1'
    );
  });
});

describe('nativeSessionStorage', () => {
  beforeEach(() => {
    resetPreferencesMemory();
    const store = new Map<string, string>();
    const adapter: PreferencesAdapter = {
      get: async (key) => store.get(key) ?? null,
      set: async (key, value) => {
        store.set(key, value);
      },
      remove: async (key) => {
        store.delete(key);
      },
    };
    setPreferencesAdapter(adapter);
  });

  it('persiste token y tenant', async () => {
    await writeNativeAuthSnapshot({
      accessToken: 'tok-1',
      tenant: 'demo',
      sessionJson: '{"token":"tok-1"}',
    });
    const snap = await readNativeAuthSnapshot();
    expect(snap.accessToken).toBe('tok-1');
    expect(snap.tenant).toBe('demo');
    expect(snap.sessionJson).toContain('tok-1');
  });

  it('hidrata cache de API base desde Preferences', async () => {
    const store = new Map<string, string>();
    store.set(preferenceKeys.apiBaseUrlOverride, 'http://10.0.2.2:9000');
    setPreferencesAdapter({
      get: async (key) => store.get(key) ?? null,
      set: async (key, value) => {
        store.set(key, value);
      },
      remove: async (key) => {
        store.delete(key);
      },
    });

    const resolved = await hydrateApiBaseUrlCache({
      projectSlug: 'smoke',
      envBaseUrl: 'http://localhost:8088/api/v1',
    });
    expect(resolved).toBe('http://10.0.2.2:9000/api/v1');
  });
});
