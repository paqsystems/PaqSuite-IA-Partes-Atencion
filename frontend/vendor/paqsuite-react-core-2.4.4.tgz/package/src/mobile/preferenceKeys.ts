/** Claves Preferences Capacitor — TR-GEN-22-platform-config. */
export const preferenceKeys = {
  apiBaseUrlOverride: 'paqMobile.apiBaseUrlOverride',
  accessToken: 'paqAuth.accessToken',
  tenant: 'paqAuth.tenant',
  sessionJson: 'paqAuth.sessionJson',
  pushPermissionAsked: 'paqMobile.pushPermissionAsked',
} as const;

export type PreferenceKey = (typeof preferenceKeys)[keyof typeof preferenceKeys];
