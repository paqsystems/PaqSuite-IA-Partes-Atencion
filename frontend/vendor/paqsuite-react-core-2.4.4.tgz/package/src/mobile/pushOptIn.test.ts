import { describe, expect, it, vi, beforeEach } from 'vitest';
import {
  hasAskedPushPermission,
  markPushPermissionAsked,
  setMobilePushBridge,
  getMobilePushBridge,
  shouldAttemptPushOptIn,
} from './push/pushBridge';
import {
  resetPreferencesMemory,
  setPreferencesAdapter,
  preferencesGet,
  type PreferencesAdapter,
} from './preferencesStorage';
import { preferenceKeys } from './preferenceKeys';

describe('pushBridge', () => {
  beforeEach(() => {
    resetPreferencesMemory();
    const store = new Map<string, string>();
    const adapter: PreferencesAdapter = {
      get: async (key) => store.get(key) ?? null,
      set: async (key, value) => {
        store.set(key, value);
      },
      remove: async (key) => {
        store.delete(key);
      },
    };
    setPreferencesAdapter(adapter);
    setMobilePushBridge(null);
  });

  it('marca y lee flag de permiso preguntado', async () => {
    expect(await hasAskedPushPermission()).toBe(false);
    await markPushPermissionAsked();
    expect(await hasAskedPushPermission()).toBe(true);
    expect(await preferencesGet(preferenceKeys.pushPermissionAsked)).toBe('1');
  });

  it('postDeviceToken shape C1-22-05 vía bridge', async () => {
    const postDeviceToken = vi.fn(async () => undefined);
    setMobilePushBridge({
      requestPermissions: async () => 'granted',
      getToken: async () => 'device-tok',
      getPlatform: () => 'android',
    });

    const bridge = getMobilePushBridge();
    expect(bridge).not.toBeNull();
    const permission = await bridge!.requestPermissions();
    const token = await bridge!.getToken();
    expect(permission).toBe('granted');
    expect(token).toBe('device-tok');
    await postDeviceToken(token!, bridge!.getPlatform());
    expect(postDeviceToken).toHaveBeenCalledWith('device-tok', 'android');
  });

  it('shouldAttemptPushOptIn respeta enabled=false', () => {
    expect(shouldAttemptPushOptIn(false)).toBe(false);
  });
});
