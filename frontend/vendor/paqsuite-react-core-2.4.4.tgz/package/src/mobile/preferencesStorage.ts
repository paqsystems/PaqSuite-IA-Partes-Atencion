/**
 * Adaptador Preferences (Capacitor) con fallback localStorage/memoria.
 * El host native puede inyectar el adapter real vía `setPreferencesAdapter`.
 */

export type PreferencesAdapter = {
  get: (key: string) => Promise<string | null>;
  set: (key: string, value: string) => Promise<void>;
  remove: (key: string) => Promise<void>;
};

const memoryStore = new Map<string, string>();
let injectedAdapter: PreferencesAdapter | null = null;

function createLocalFallbackAdapter(): PreferencesAdapter {
  return {
    get: async (key) => {
      if (memoryStore.has(key)) {
        return memoryStore.get(key) ?? null;
      }
      if (typeof localStorage === 'undefined') {
        return null;
      }
      return localStorage.getItem(key);
    },
    set: async (key, value) => {
      memoryStore.set(key, value);
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(key, value);
      }
    },
    remove: async (key) => {
      memoryStore.delete(key);
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem(key);
      }
    },
  };
}

/** Inyecta adapter (tests / Capacitor Preferences). `null` = fallback. */
export function setPreferencesAdapter(adapter: PreferencesAdapter | null): void {
  injectedAdapter = adapter;
}

export function getPreferencesAdapter(): PreferencesAdapter {
  return injectedAdapter ?? createLocalFallbackAdapter();
}

export async function preferencesGet(key: string): Promise<string | null> {
  return getPreferencesAdapter().get(key);
}

export async function preferencesSet(key: string, value: string): Promise<void> {
  await getPreferencesAdapter().set(key, value);
}

export async function preferencesRemove(key: string): Promise<void> {
  await getPreferencesAdapter().remove(key);
}

/** Limpia memoria in-process (tests). */
export function resetPreferencesMemory(): void {
  memoryStore.clear();
}
