type CapacitorLike = {
  isNativePlatform?: () => boolean;
};

/**
 * Detecta runtime Capacitor native (GEN-22).
 * Usa `Capacitor.isNativePlatform()` si existe; si no, false (TR-GEN-22).
 */
export function isNativeApp(): boolean {
  if (typeof window === 'undefined') {
    return false;
  }

  const capacitor = (window as Window & { Capacitor?: CapacitorLike }).Capacitor;
  if (!capacitor || typeof capacitor.isNativePlatform !== 'function') {
    return false;
  }

  return capacitor.isNativePlatform();
}
