export type EmpresaPermiso = {
  id: string | number;
};

export type EmpresaGateResult = 'shell' | 'selector' | 'blockedNoCompany';

/**
 * Política post-credenciales: cuándo shell / selector / bloqueo N=0.
 * single nunca muestra selector; si N>=1 usa shell (primera); N=0 bloquea.
 */
export function resolveEmpresaGate(input: {
  tenancy: 'single' | 'multi';
  empresasConPermiso: EmpresaPermiso[];
}): EmpresaGateResult {
  const n = input.empresasConPermiso.length;
  if (n === 0) {
    return 'blockedNoCompany';
  }
  if (input.tenancy === 'single') {
    return 'shell';
  }
  if (n === 1) {
    return 'shell';
  }
  return 'selector';
}

/** Clave i18n canónica N=0 (C1 D1-S4). */
export const blockedNoCompanyI18nKey = 'shell.blockedNoCompany';

/** Rutas canónicas post-login (GEN-05). */
export const postLoginHomePath = '/dashboard';
export const postLoginSelectorPath = '/select-empresa';
