export type EmpresaAppearance = {
  theme?: string;
  tokens?: Record<string, string>;
};

export type ApplyEmpresaAppearanceTarget = {
  setTheme?: (theme: string) => void;
  setTokens?: (tokens: Record<string, string>) => void;
  clearAppearance?: () => void;
};

/**
 * Aplica apariencia A1 opcional; si falta, limpia / default del host (C1 D1-S2).
 */
export function applyEmpresaAppearance(
  appearance: EmpresaAppearance | null | undefined,
  target: ApplyEmpresaAppearanceTarget
): void {
  if (!appearance) {
    target.clearAppearance?.();
    return;
  }
  if (appearance.theme && target.setTheme) {
    target.setTheme(appearance.theme);
  }
  if (appearance.tokens && target.setTokens) {
    target.setTokens(appearance.tokens);
  }
}
