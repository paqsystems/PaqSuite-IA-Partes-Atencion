import List from 'devextreme-react/list';
import { blockedNoCompanyI18nKey } from './resolveEmpresaGate';

export type EmpresaSelectorItem = {
  id: string | number;
  nombreEmpresa: string;
  theme?: string;
};

export type EmpresaSelectorPageProps = {
  empresas: EmpresaSelectorItem[];
  logoUrl?: string;
  onSelect: (id: string | number) => void;
  blockedMessage?: string;
};

const searchThreshold = 8;

/**
 * Selector de empresa DevExtreme (`List`) — GEN-05.
 * `searchEnabled` nativo cuando N > 8.
 */
export function EmpresaSelectorPage({
  empresas,
  logoUrl,
  onSelect,
  blockedMessage,
}: EmpresaSelectorPageProps) {
  if (empresas.length === 0) {
    return (
      <div data-testid="empresaSelectorPage">
        {logoUrl ? <img src={logoUrl} alt="logo" /> : null}
        <p data-i18n-key={blockedNoCompanyI18nKey}>
          {blockedMessage ?? 'No tiene empresas habilitadas.'}
        </p>
      </div>
    );
  }

  return (
    <div data-testid="empresaSelectorPage">
      {logoUrl ? <img src={logoUrl} alt="logo" /> : null}
      <List
        dataSource={empresas}
        keyExpr="id"
        displayExpr="nombreEmpresa"
        searchEnabled={empresas.length > searchThreshold}
        searchExpr="nombreEmpresa"
        searchEditorOptions={{
          elementAttr: { 'data-testid': 'empresaSelectorSearch' },
        }}
        selectionMode="single"
        hoverStateEnabled
        focusStateEnabled
        pageLoadMode="scrollBottom"
        height={Math.min(420, 48 + empresas.length * 40)}
        itemRender={(item: EmpresaSelectorItem) => (
          <div data-testid="empresaSelectorItem">{item.nombreEmpresa}</div>
        )}
        onItemClick={(event) => {
          const id = event.itemData?.id;
          if (id !== undefined && id !== null) {
            onSelect(id);
          }
        }}
      />
    </div>
  );
}
