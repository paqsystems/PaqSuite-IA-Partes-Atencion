import { afterEach, describe, expect, it } from 'vitest';
import {
  clearCompanyChangeHandlers,
  notifyCompanyChange,
  registerOnCompanyChange,
} from './companyChange';

describe('companyChange registry', () => {
  afterEach(() => {
    clearCompanyChangeHandlers();
  });

  it('notifica handlers registrados', () => {
    const seen: Array<string | number> = [];
    const unregister = registerOnCompanyChange((id) => {
      seen.push(id);
    });
    notifyCompanyChange(9);
    expect(seen).toEqual([9]);
    unregister();
    notifyCompanyChange(10);
    expect(seen).toEqual([9]);
  });
});
