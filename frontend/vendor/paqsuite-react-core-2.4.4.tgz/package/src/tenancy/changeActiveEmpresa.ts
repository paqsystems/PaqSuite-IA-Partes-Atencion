import { notifyCompanyChange } from './companyChange';
import { setActiveEmpresaId } from './empresaStorage';
import { postLoginHomePath } from './resolveEmpresaGate';

export type ChangeActiveEmpresaInput = {
  companyId: string | number;
  onNavigate?: (path: string) => void;
  navigateTo?: string;
};

/**
 * Post-selección de empresa (GEN-05): persiste el id activo, notifica a los
 * handlers registrados (invalidar menú/caché) y navega opcionalmente al
 * home post-login (`/dashboard` por default).
 */
export function changeActiveEmpresa(input: ChangeActiveEmpresaInput): void {
  setActiveEmpresaId(input.companyId);
  notifyCompanyChange(input.companyId);
  input.onNavigate?.(input.navigateTo ?? postLoginHomePath);
}
