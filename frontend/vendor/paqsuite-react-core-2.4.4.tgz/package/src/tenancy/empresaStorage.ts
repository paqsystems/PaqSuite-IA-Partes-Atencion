export const activeCompanyStorageKey = 'paqActiveCompanyId';

type SimpleStorage = {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
};

function createMemoryStorage(): SimpleStorage {
  const memory = new Map<string, string>();
  return {
    getItem: (key) => (memory.has(key) ? (memory.get(key) as string) : null),
    setItem: (key, value) => {
      memory.set(key, value);
    },
    removeItem: (key) => {
      memory.delete(key);
    },
  };
}

/** Fallback en memoria para SSR/tests sin `localStorage`; en browser usa el real. */
const fallbackStorage = createMemoryStorage();

function resolveStorage(): SimpleStorage {
  if (typeof localStorage !== 'undefined') {
    return localStorage;
  }
  return fallbackStorage;
}

/** Empresa activa post-selección, persistida client-side (GEN-05). */
export function getActiveEmpresaId(): string | null {
  return resolveStorage().getItem(activeCompanyStorageKey);
}

export function setActiveEmpresaId(companyId: string | number): void {
  resolveStorage().setItem(activeCompanyStorageKey, String(companyId));
}

export function clearActiveEmpresaId(): void {
  resolveStorage().removeItem(activeCompanyStorageKey);
}
