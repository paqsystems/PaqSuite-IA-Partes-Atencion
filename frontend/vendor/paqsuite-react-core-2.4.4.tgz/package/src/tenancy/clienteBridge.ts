export const paqClienteCookieName = 'paqCliente';
export const paqClienteSessionKey = 'paqCliente';

export type ResolveClienteCodeInput = {
  isDevOrNonCanonicalUrl: boolean;
  queryCliente?: string | null;
  cookieCliente?: string | null;
  sessionCliente?: string | null;
};

/**
 * trim + uppercase (C1 D1-B5). Vacío → ''.
 */
export function normalizeClienteCode(value?: string | null): string {
  if (value === undefined || value === null) {
    return '';
  }
  return value.trim().toUpperCase();
}

/**
 * Orden: (dev force) → query → cookie → sessionStorage → DEMO (C1).
 */
export function resolveClienteCode(input: ResolveClienteCodeInput): string {
  if (input.isDevOrNonCanonicalUrl) {
    return normalizeClienteCode('DEMO');
  }

  const fromQuery = normalizeClienteCode(input.queryCliente);
  if (fromQuery) {
    return fromQuery;
  }

  const fromCookie = normalizeClienteCode(input.cookieCliente);
  if (fromCookie) {
    return fromCookie;
  }

  const fromSession = normalizeClienteCode(input.sessionCliente);
  if (fromSession) {
    return fromSession;
  }

  return normalizeClienteCode('DEMO');
}

/**
 * Detección DEV / URL no canónica (C1 D1-B1).
 */
export function isDevOrNonCanonicalHostname(
  hostname: string,
  isDevBuild = false
): boolean {
  if (isDevBuild) {
    return true;
  }

  const host = hostname.trim().toLowerCase();
  if (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '0.0.0.0' ||
    host === '10.0.2.2' ||
    host.endsWith('.local')
  ) {
    return true;
  }

  if (/^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(host)) {
    return true;
  }
  if (/^192\.168\.\d{1,3}\.\d{1,3}$/.test(host)) {
    return true;
  }
  if (/^172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}$/.test(host)) {
    return true;
  }

  return false;
}

export type ClientePersistence = {
  getCookie: (name: string) => string | null;
  setCookie: (name: string, value: string) => void;
  getSession: (key: string) => string | null;
  setSession: (key: string, value: string) => void;
};

/**
 * Persiste el código ganador en cookie + sessionStorage (no localStorage).
 */
export function persistClienteCode(
  cliente: string,
  persistence: ClientePersistence
): string {
  const normalized = normalizeClienteCode(cliente) || 'DEMO';
  persistence.setCookie(paqClienteCookieName, normalized);
  persistence.setSession(paqClienteSessionKey, normalized);
  return normalized;
}

export function readPersistedClienteCode(
  persistence: ClientePersistence
): { cookieCliente: string | null; sessionCliente: string | null } {
  return {
    cookieCliente: persistence.getCookie(paqClienteCookieName),
    sessionCliente: persistence.getSession(paqClienteSessionKey),
  };
}
