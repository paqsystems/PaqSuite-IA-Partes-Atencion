import { useMemo } from 'react';
import DropDownButton from 'devextreme-react/drop-down-button';
import Switch from 'devextreme-react/switch';

export type UserAvatarMenuProps = {
  userName: string;
  isNativeApp?: boolean;
  showPreferences?: boolean;
  showChat?: boolean;
  showHelp?: boolean;
  showOpenInNewTab?: boolean;
  /** Visible solo multi N>1; en `tenancy=single` (MONO) siempre false. */
  showChangeEmpresa?: boolean;
  openInNewTab?: boolean;
  onOpenInNewTabChange?: (value: boolean) => void;
  onChangePassword: () => void;
  onLogout: () => void;
  onChangeEmpresa?: () => void;
  onPreferences?: () => void;
  onChat?: () => void;
  onHelp?: () => void;
  /** Labels i18n del host (GEN-02 / GEN-08). */
  labels?: {
    changePassword?: string;
    changeEmpresa?: string;
    logout?: string;
    preferences?: string;
    chat?: string;
    help?: string;
    openInNewTab?: string;
  };
};

type AvatarMenuItem = {
  id: string;
  text: string;
  beginGroup?: boolean;
};

/**
 * Menú avatar DevExtreme (`DropDownButton`) — GEN-08.
 * Orden Must: Preferencias → Chat → Ayuda → Solapa → Empresa → Contraseña → Logout.
 * `openInNewTab` nunca se muestra en `isNativeApp`.
 */
export function UserAvatarMenu({
  userName,
  isNativeApp = false,
  showPreferences = false,
  showChat = false,
  showHelp = false,
  showOpenInNewTab = false,
  showChangeEmpresa = false,
  openInNewTab = false,
  onOpenInNewTabChange,
  onChangePassword,
  onLogout,
  onChangeEmpresa,
  onPreferences,
  onChat,
  onHelp,
  labels = {},
}: UserAvatarMenuProps) {
  const items = useMemo(() => {
    const list: AvatarMenuItem[] = [];

    if (showPreferences) {
      list.push({
        id: 'preferences',
        text: labels.preferences ?? 'Preferencias',
      });
    }
    if (showChat) {
      list.push({
        id: 'chat',
        text: labels.chat ?? 'Asistente IA',
        beginGroup: list.length > 0,
      });
    }
    if (showHelp) {
      list.push({ id: 'help', text: labels.help ?? 'Ayuda' });
    }
    if (showOpenInNewTab && !isNativeApp) {
      list.push({
        id: 'openInNewTab',
        text: labels.openInNewTab ?? 'Abrir en pestaña separada',
        beginGroup: true,
      });
    }
    if (showChangeEmpresa) {
      list.push({
        id: 'changeEmpresa',
        text: labels.changeEmpresa ?? 'Cambiar empresa',
        beginGroup: true,
      });
    }

    list.push({
      id: 'changePassword',
      text: labels.changePassword ?? 'Cambiar contraseña',
      beginGroup: true,
    });
    list.push({
      id: 'logout',
      text: labels.logout ?? 'Cerrar sesión',
      beginGroup: true,
    });

    return list;
  }, [
    isNativeApp,
    labels.changeEmpresa,
    labels.changePassword,
    labels.chat,
    labels.help,
    labels.logout,
    labels.openInNewTab,
    labels.preferences,
    showChangeEmpresa,
    showChat,
    showHelp,
    showOpenInNewTab,
    showPreferences,
  ]);

  function handleItemClick(id: string): void {
    switch (id) {
      case 'changePassword':
        onChangePassword();
        break;
      case 'logout':
        onLogout();
        break;
      case 'changeEmpresa':
        onChangeEmpresa?.();
        break;
      case 'preferences':
        onPreferences?.();
        break;
      case 'chat':
        onChat?.();
        break;
      case 'help':
        onHelp?.();
        break;
      default:
        break;
    }
  }

  return (
    <div data-testid="userAvatarMenu">
      <DropDownButton
        text={userName}
        items={items}
        keyExpr="id"
        displayExpr="text"
        splitButton={false}
        useSelectMode={false}
        elementAttr={{ 'data-testid': 'userAvatarMenuTrigger' }}
        dropDownOptions={{ width: 260 }}
        itemRender={(item: AvatarMenuItem) => {
          if (item.id === 'openInNewTab') {
            return (
              <div
                data-testid="userAvatarMenuItem-openInNewTab"
                style={{ display: 'flex', alignItems: 'center', gap: 8 }}
                onClick={(event) => event.stopPropagation()}
              >
                <Switch
                  value={openInNewTab}
                  onValueChanged={(event) => onOpenInNewTabChange?.(Boolean(event.value))}
                />
                <span>{item.text}</span>
              </div>
            );
          }
          return <span data-testid={`userAvatarMenuItem-${item.id}`}>{item.text}</span>;
        }}
        onItemClick={(event) => {
          const id = String(event.itemData?.id ?? '');
          if (id === 'openInNewTab') {
            return;
          }
          handleItemClick(id);
        }}
      />
    </div>
  );
}
