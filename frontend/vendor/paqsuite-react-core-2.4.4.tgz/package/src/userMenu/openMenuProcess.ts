export type OpenMenuProcessInput = {
  url: string;
  openInNewTab: boolean;
  isNativeApp: boolean;
  navigate: (url: string) => void;
};

/**
 * Resuelve navegación de un proceso de menú (GEN-08): preferencia
 * "pestañas separadas" solo aplica fuera de mobile (`isNativeApp` la ignora).
 */
export function openMenuProcess(input: OpenMenuProcessInput): void {
  if (input.openInNewTab && !input.isNativeApp) {
    if (typeof window !== 'undefined') {
      window.open(input.url, '_blank', 'noopener,noreferrer');
    }
    return;
  }
  input.navigate(input.url);
}
