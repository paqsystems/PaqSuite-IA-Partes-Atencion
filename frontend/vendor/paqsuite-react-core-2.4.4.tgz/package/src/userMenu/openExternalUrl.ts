/** Abre una URL externa en nueva pestaña; stub MVP restringido a https (GEN-08). */
export function openExternalUrl(url: string): void {
  if (!/^https:\/\//i.test(url)) {
    return;
  }
  if (typeof window === 'undefined') {
    return;
  }
  window.open(url, '_blank', 'noopener,noreferrer');
}
