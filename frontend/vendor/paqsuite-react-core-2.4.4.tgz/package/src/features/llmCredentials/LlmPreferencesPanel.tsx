import { useCallback, useEffect, useState } from 'react';
import DataGrid, { Column, Paging, Pager } from 'devextreme-react/data-grid';
import Button from 'devextreme-react/button';
import Popup from 'devextreme-react/popup';
import { confirm } from 'devextreme/ui/dialog';
import { deleteLlmCredential, listLlmCredentials } from './llmCredentialsClient';
import { LlmCredentialFormPopup } from './LlmCredentialFormPopup';
import type { LlmCredentialDto, LlmProviderCatalogItem } from './types';

export type LlmPreferencesPanelProps = {
  presentation: 'page' | 'modal';
  providerCatalog: LlmProviderCatalogItem[];
  visible?: boolean;
  onClose?: () => void;
  onCredentialsChanged?: () => void;
  entrySource?: 'avatar' | 'process' | 'other';
  returnTo?: string | (() => void);
  t?: (key: string) => string;
};

/**
 * Panel de Preferencias LLM (GEN-16): grilla DX, empty compacto, alta/edición
 * vía `LlmCredentialFormPopup`, confirm DELETE y botón Volver en `page`.
 */
export function LlmPreferencesPanel({
  presentation,
  providerCatalog,
  visible = true,
  onClose,
  onCredentialsChanged,
  entrySource = 'avatar',
  returnTo,
  t,
}: LlmPreferencesPanelProps) {
  const translate = t ?? ((key: string) => key);
  const [rows, setRows] = useState<LlmCredentialDto[]>([]);
  const [formMode, setFormMode] = useState<'create' | 'edit' | null>(null);
  const [editing, setEditing] = useState<LlmCredentialDto | null>(null);

  const load = useCallback(async () => {
    const result = await listLlmCredentials();
    if (result.kind === 'ok') {
      setRows(result.envelope.resultado.items ?? []);
    }
  }, []);

  useEffect(() => {
    if (visible) {
      void load();
    }
  }, [visible, load]);

  const handleSaved = useCallback(() => {
    setFormMode(null);
    setEditing(null);
    void load();
    onCredentialsChanged?.();
  }, [load, onCredentialsChanged]);

  const handleDelete = useCallback(
    async (row: LlmCredentialDto) => {
      const confirmed = await confirm(
        translate('llmPreferences.deleteConfirm.body'),
        translate('llmPreferences.deleteConfirm.title')
      );
      if (!confirmed) {
        return;
      }
      const result = await deleteLlmCredential(row.id);
      if (result.kind === 'ok') {
        void load();
        onCredentialsChanged?.();
      }
    },
    [load, onCredentialsChanged, translate]
  );

  const backActive = entrySource !== 'avatar' && returnTo !== undefined;
  const handleBack = useCallback(() => {
    if (!backActive || returnTo === undefined) {
      return;
    }
    if (typeof returnTo === 'function') {
      returnTo();
    }
  }, [backActive, returnTo]);

  const panel = (
    <div data-testid="llmPreferences.panel">
      {presentation === 'page' ? (
        <h2 style={{ margin: '0 0 10px', fontSize: '1.25rem' }}>
          {translate('llmPreferences.title')}
        </h2>
      ) : null}

      <div
        data-testid="llmPreferences.intro"
        style={{
          marginBottom: 14,
          padding: '10px 12px',
          borderRadius: 6,
          background: '#f8fafc',
          border: '1px solid #e2e8f0',
          color: '#64748b',
          fontSize: '0.78rem',
          lineHeight: 1.45,
        }}
      >
        <p style={{ margin: '0 0 6px', fontWeight: 600, color: '#475569' }}>
          {translate('llmPreferences.sectionTitle')}
        </p>
        <p style={{ margin: '0 0 6px' }}>{translate('llmPreferences.intro.subtitle')}</p>
        <p style={{ margin: '0 0 8px' }}>{translate('llmPreferences.intro.body')}</p>
        <p style={{ margin: '0 0 4px', fontWeight: 600, color: '#475569' }}>
          {translate('llmPreferences.intro.fieldsTitle')}
        </p>
        <ul style={{ margin: '0 0 8px', paddingLeft: 18 }}>
          <li>{translate('llmPreferences.intro.field.nombre')}</li>
          <li>{translate('llmPreferences.intro.field.proveedor')}</li>
          <li>{translate('llmPreferences.intro.field.modelo')}</li>
          <li>{translate('llmPreferences.intro.field.secreto')}</li>
          <li>{translate('llmPreferences.intro.field.baseUrl')}</li>
          <li>{translate('llmPreferences.intro.field.enabled')}</li>
        </ul>
        <p style={{ margin: '0 0 6px' }}>{translate('llmPreferences.intro.helpLink')}</p>
        <p style={{ margin: 0 }}>{translate('llmPreferences.intro.steps')}</p>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 12, alignItems: 'center' }}>
        {presentation === 'page' ? (
          <Button
            text={translate('llmPreferences.back')}
            disabled={!backActive}
            onClick={handleBack}
            elementAttr={{ 'data-testid': 'llmPreferences.back' }}
          />
        ) : null}
        <Button
          text={translate('llmPreferences.add')}
          type="default"
          stylingMode="contained"
          onClick={() => {
            setEditing(null);
            setFormMode('create');
          }}
          elementAttr={{ 'data-testid': 'llmPreferences.add' }}
        />
      </div>

      {rows.length === 0 ? (
        <div data-testid="llmPreferences.empty">
          <h4>{translate('llmPreferences.empty.title')}</h4>
          <p>{translate('llmPreferences.empty.body')}</p>
          <Button
            text={translate('llmPreferences.empty.cta')}
            onClick={() => setFormMode('create')}
          />
        </div>
      ) : (
        <DataGrid
          dataSource={rows}
          keyExpr="id"
          showBorders
          elementAttr={{ 'data-testid': 'llmPreferences.grid' }}
        >
          <Paging defaultPageSize={10} />
          <Pager visible showInfo />
          <Column dataField="nombre" caption={translate('llmPreferences.columns.nombre')} />
          <Column dataField="proveedor" caption={translate('llmPreferences.columns.proveedor')} />
          <Column dataField="modelo" caption={translate('llmPreferences.columns.modelo')} />
          <Column
            dataField="enabled"
            caption={translate('llmPreferences.columns.enabled')}
            dataType="boolean"
          />
          <Column
            caption={translate('llmPreferences.columns.actions')}
            cellRender={(cell) => {
              const row = cell.data as LlmCredentialDto;
              return (
                <div style={{ display: 'flex', gap: 4 }}>
                  <Button
                    icon="edit"
                    onClick={() => {
                      setEditing(row);
                      setFormMode('edit');
                    }}
                  />
                  <Button
                    icon="trash"
                    onClick={() => void handleDelete(row)}
                    elementAttr={{ 'data-testid': 'llmPreferences.deleteConfirm' }}
                  />
                </div>
              );
            }}
          />
        </DataGrid>
      )}

      {formMode ? (
        <LlmCredentialFormPopup
          visible
          mode={formMode}
          providerCatalog={providerCatalog}
          initial={editing}
          onCancel={() => {
            setFormMode(null);
            setEditing(null);
          }}
          onSaved={handleSaved}
          t={t}
        />
      ) : null}
    </div>
  );

  if (presentation === 'modal') {
    return (
      <Popup
        visible={visible}
        onHiding={onClose}
        showTitle
        title={translate('llmPreferences.title')}
        width={720}
        height="80%"
        wrapperAttr={{ 'data-testid': 'llmPreferences.modal' }}
      >
        {panel}
      </Popup>
    );
  }

  return panel;
}
