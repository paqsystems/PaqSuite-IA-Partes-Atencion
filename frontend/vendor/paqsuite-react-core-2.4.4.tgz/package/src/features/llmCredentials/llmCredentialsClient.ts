import { apiRequest, type ApiClientResult, type ApiRequestOptions } from '../../http/apiClient';
import type {
  LlmCredentialCreateBody,
  LlmCredentialDto,
  LlmCredentialPatchBody,
} from './types';

/** Path canónico GEN del CRUD de credenciales LLM (TR-GEN-16-api-credenciales §5). */
export const llmCredentialsBasePath = '/api/v1/llm-credentials';

/** Envelope de listado: el backend responde `{ items: [...] }` en `resultado`. */
export type LlmCredentialListResult = { items: LlmCredentialDto[] };

type RequestOverrides = Pick<ApiRequestOptions, 'platform' | 'signal' | 'headers'>;

/**
 * Sanitiza el body de PATCH: si `secreto` llega vacío / null, se omite la clave
 * para que el backend conserve el secreto vigente (regla D1 TR api-credenciales).
 */
export function buildLlmCredentialPatchBody(
  input: LlmCredentialPatchBody
): LlmCredentialPatchBody {
  const body: LlmCredentialPatchBody = { ...input };
  if (body.secreto === undefined || body.secreto === null || body.secreto === '') {
    delete body.secreto;
  }
  return body;
}

/** `GET /api/v1/llm-credentials` — incluye credenciales `enabled=false`. */
export function listLlmCredentials(
  options: RequestOverrides = {}
): Promise<ApiClientResult<LlmCredentialListResult>> {
  return apiRequest<LlmCredentialListResult>(llmCredentialsBasePath, {
    method: 'GET',
    ...options,
  });
}

/** `POST /api/v1/llm-credentials` — alta (201). */
export function createLlmCredential(
  body: LlmCredentialCreateBody,
  options: RequestOverrides = {}
): Promise<ApiClientResult<LlmCredentialDto>> {
  return apiRequest<LlmCredentialDto>(llmCredentialsBasePath, {
    method: 'POST',
    body: JSON.stringify(body),
    ...options,
  });
}

/** `PATCH /api/v1/llm-credentials/{id}` — omite `secreto` vacío para conservarlo. */
export function patchLlmCredential(
  id: number,
  body: LlmCredentialPatchBody,
  options: RequestOverrides = {}
): Promise<ApiClientResult<LlmCredentialDto>> {
  return apiRequest<LlmCredentialDto>(`${llmCredentialsBasePath}/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(buildLlmCredentialPatchBody(body)),
    ...options,
  });
}

/** `DELETE /api/v1/llm-credentials/{id}` — hard-delete de la fila. */
export function deleteLlmCredential(
  id: number,
  options: RequestOverrides = {}
): Promise<ApiClientResult<Record<string, unknown>>> {
  return apiRequest<Record<string, unknown>>(`${llmCredentialsBasePath}/${id}`, {
    method: 'DELETE',
    ...options,
  });
}
