import type { LlmProviderCatalogItem } from './types';

/**
 * Catálogo host de referencia GEN-16 (paridad PedidosWeb / Tango BYOK).
 * Los hosts pueden importarlo o extenderlo; el backend MUST aceptar los mismos `id`.
 */
export const defaultLlmProviderCatalog: LlmProviderCatalogItem[] = [
  {
    id: 'ollama',
    label: 'Ollama',
    helpUrl: 'https://ollama.com/download',
    requiresBaseUrl: true,
    models: ['llama3.1', 'llama3.2', 'mistral', 'qwen2.5', 'gemma2'],
    defaultSupportsVision: true,
  },
  {
    id: 'openai',
    label: 'OpenAI',
    helpUrl: 'https://platform.openai.com/api-keys',
    requiresBaseUrl: false,
    models: ['gpt-4.1', 'gpt-4.1-mini', 'gpt-4o', 'gpt-4o-mini', 'o1-mini'],
    defaultSupportsVision: true,
  },
  {
    id: 'anthropic',
    label: 'Anthropic',
    helpUrl: 'https://console.anthropic.com/',
    requiresBaseUrl: false,
    models: [
      'claude-3-5-sonnet-latest',
      'claude-3-5-haiku-latest',
      'claude-3-opus-latest',
    ],
    defaultSupportsVision: true,
  },
  {
    id: 'googleGemini',
    label: 'Google Gemini',
    helpUrl: 'https://aistudio.google.com/',
    requiresBaseUrl: false,
    models: ['gemini-2.0-flash', 'gemini-1.5-pro', 'gemini-1.5-flash'],
    defaultSupportsVision: true,
  },
  {
    id: 'azureOpenAi',
    label: 'Azure OpenAI',
    helpUrl: 'https://portal.azure.com/',
    requiresBaseUrl: true,
    models: ['gpt-4.1', 'gpt-4.1-mini', 'gpt-4o', 'gpt-4o-mini'],
    defaultSupportsVision: true,
  },
  {
    id: 'openRouter',
    label: 'OpenRouter',
    helpUrl: 'https://openrouter.ai/settings/keys',
    requiresBaseUrl: false,
    models: [
      'openai/gpt-4o-mini',
      'anthropic/claude-3.5-sonnet',
      'google/gemini-2.0-flash-001',
    ],
    defaultSupportsVision: true,
  },
  {
    id: 'groq',
    label: 'Groq',
    helpUrl: 'https://console.groq.com/keys',
    requiresBaseUrl: false,
    models: [
      'llama-3.1-8b-instant',
      'llama-3.3-70b-versatile',
      'mixtral-8x7b-32768',
    ],
    defaultSupportsVision: true,
  },
  {
    id: 'mistral',
    label: 'Mistral',
    helpUrl: 'https://console.mistral.ai/',
    requiresBaseUrl: false,
    models: [
      'mistral-large-latest',
      'mistral-small-latest',
      'codestral-latest',
    ],
    defaultSupportsVision: true,
  },
  {
    id: 'custom',
    label: 'Custom / OpenAI-compatible',
    helpUrl: 'https://platform.openai.com/docs/api-reference',
    requiresBaseUrl: true,
    models: ['local'],
    defaultSupportsVision: false,
  },
];
