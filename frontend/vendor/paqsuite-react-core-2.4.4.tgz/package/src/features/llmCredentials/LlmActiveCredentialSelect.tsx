import SelectBox from 'devextreme-react/select-box';
import type { LlmSelectionState } from './types';

export type LlmActiveCredentialSelectProps = {
  selection: LlmSelectionState;
  disabled?: boolean;
  /**
   * @deprecated El CTA «Ir a Preferencias» ya no se renderiza aquí
   * (evita duplicar el empty state / engranaje del chat). Se ignora.
   */
  onOpenPreferences?: () => void;
  /** Traductor i18n opcional; si falta, se usa la clave literal. */
  t?: (key: string) => string;
};

/**
 * SelectBox DevExtreme de la credencial LLM activa (GEN-16 selección).
 * Si no hay configuraciones habilitadas, no renderiza nada (el empty del chat
 * y el engranaje Preferencias cubren el alta).
 */
export function LlmActiveCredentialSelect({
  selection,
  disabled,
  t,
}: LlmActiveCredentialSelectProps) {
  const translate = t ?? ((key: string) => key);

  if (selection.configurationRequired || selection.credentials.length === 0) {
    return null;
  }

  return (
    <div data-testid="llmPreferences.activeSelectContainer">
      <SelectBox
        dataSource={selection.credentials}
        valueExpr="id"
        displayExpr="nombre"
        value={selection.activeResolved?.id ?? null}
        disabled={disabled}
        placeholder={translate('llmPreferences.activeLabel')}
        onValueChanged={(event) => {
          const next = event.value as number | null;
          void selection.setActiveCredentialId(next ?? null);
        }}
        elementAttr={{ 'data-testid': 'llmPreferences.activeSelect' }}
      />
    </div>
  );
}
