/**
 * Helper opcional para orquestar la apertura del modal de Preferencias LLM
 * desde Chat / Smart Capture. El host mantiene el estado `visible` y pasa
 * `onClose`; este helper solo normaliza el callback de apertura.
 */
export type OpenLlmPreferencesModalController = {
  open: () => void;
  close: () => void;
};

export function createLlmPreferencesModalController(
  setVisible: (visible: boolean) => void
): OpenLlmPreferencesModalController {
  return {
    open: () => setVisible(true),
    close: () => setVisible(false),
  };
}
