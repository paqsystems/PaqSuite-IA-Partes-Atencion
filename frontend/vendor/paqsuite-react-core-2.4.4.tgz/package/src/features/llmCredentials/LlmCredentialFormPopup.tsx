import {
  useId,
  useMemo,
  useState,
  type CSSProperties,
  type ReactNode,
} from 'react';
import Popup from 'devextreme-react/popup';
import TextBox from 'devextreme-react/text-box';
import SelectBox from 'devextreme-react/select-box';
import CheckBox from 'devextreme-react/check-box';
import Button from 'devextreme-react/button';
import Tooltip from 'devextreme-react/tooltip';
import {
  createLlmCredential,
  patchLlmCredential,
} from './llmCredentialsClient';
import {
  findProviderItem,
  providerLabel,
  resolveSupportsVision,
} from './formHelpers';
import type { LlmCredentialDto, LlmProviderCatalogItem } from './types';

export type LlmCredentialFormPopupProps = {
  visible: boolean;
  mode: 'create' | 'edit';
  providerCatalog: LlmProviderCatalogItem[];
  initial?: LlmCredentialDto | null;
  onCancel: () => void;
  onSaved: () => void;
  t?: (key: string) => string;
};

const tooltipContentStyle: CSSProperties = {
  fontSize: '0.78rem',
  lineHeight: 1.4,
  whiteSpace: 'normal',
  wordBreak: 'break-word',
  maxWidth: 260,
  padding: '2px 0',
};

function FieldLabelWithTooltip({
  label,
  tooltip,
  testId,
}: {
  label: string;
  tooltip: string;
  testId: string;
}) {
  const reactId = useId();
  const targetId = `llmFieldHelp-${reactId.replace(/:/g, '')}`;

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        marginBottom: 4,
        fontSize: '0.85rem',
        color: '#334155',
      }}
    >
      <span>{label}</span>
      <i
        id={targetId}
        className="dx-icon dx-icon-help"
        data-testid={testId}
        style={{ cursor: 'help', fontSize: 14, color: '#64748b', flexShrink: 0 }}
        tabIndex={0}
        role="img"
        aria-label={label}
      />
      <Tooltip
        target={`#${targetId}`}
        showEvent="mouseenter focusin"
        hideEvent="mouseleave focusout"
        hideOnOutsideClick
        maxWidth={280}
        position={{
          my: 'left top',
          at: 'right top',
          collision: 'fit flip',
          offset: '8 0',
        }}
      >
        <div style={tooltipContentStyle}>{tooltip}</div>
      </Tooltip>
    </div>
  );
}

function FieldBlock({
  label,
  tooltip,
  testId,
  children,
}: {
  label: string;
  tooltip: string;
  testId: string;
  children: ReactNode;
}) {
  return (
    <div>
      <FieldLabelWithTooltip label={label} tooltip={tooltip} testId={testId} />
      {children}
    </div>
  );
}

/**
 * Popup DevExtreme de alta / edición de credencial LLM (GEN-16, export M4).
 * El secreto nunca se precarga; vacío en PATCH conserva el actual.
 */
export function LlmCredentialFormPopup({
  visible,
  mode,
  providerCatalog,
  initial,
  onCancel,
  onSaved,
  t,
}: LlmCredentialFormPopupProps) {
  const translate = t ?? ((key: string) => key);
  const [nombre, setNombre] = useState(initial?.nombre ?? '');
  const [proveedor, setProveedor] = useState(initial?.proveedor ?? '');
  const [modelo, setModelo] = useState(initial?.modelo ?? '');
  const [secreto, setSecreto] = useState('');
  const [baseUrl, setBaseUrl] = useState(initial?.baseUrl ?? '');
  const [enabled, setEnabled] = useState(initial?.enabled ?? true);
  const [saving, setSaving] = useState(false);
  const [errorKey, setErrorKey] = useState<string | null>(null);

  const providerItem = useMemo(
    () => findProviderItem(providerCatalog, proveedor),
    [providerCatalog, proveedor]
  );
  const requiresBaseUrl = providerItem?.requiresBaseUrl ?? false;
  const supportsVision = resolveSupportsVision(providerItem, modelo);

  const modelOptions = useMemo(() => {
    const suggested = providerItem?.models ?? [];
    if (modelo && !suggested.includes(modelo)) {
      return [...suggested, modelo];
    }
    return suggested;
  }, [modelo, providerItem?.models]);

  const handleSave = async () => {
    setErrorKey(null);
    if (requiresBaseUrl && baseUrl.trim() === '') {
      setErrorKey('llmPreferences.baseUrlRequired');
      return;
    }
    setSaving(true);
    const common = {
      nombre,
      proveedor,
      modelo,
      baseUrl: baseUrl.trim() === '' ? null : baseUrl,
      supportsVision,
      enabled,
      requiresBaseUrl,
    };
    const result =
      mode === 'create'
        ? await createLlmCredential({ ...common, secreto })
        : await patchLlmCredential(initial!.id, { ...common, secreto });
    setSaving(false);
    if (result.kind === 'ok') {
      onSaved();
      return;
    }
    setErrorKey(
      result.kind === 'envelopeError'
        ? result.envelope.respuesta
        : 'infra.transport'
    );
  };

  return (
    <Popup
      visible={visible}
      onHiding={onCancel}
      showTitle
      title={translate('llmPreferences.title')}
      width={520}
      height="auto"
      wrapperAttr={{ 'data-testid': 'llmPreferences.form' }}
    >
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <FieldBlock
          label={translate('llmPreferences.fields.nombre')}
          tooltip={translate('llmPreferences.fields.nombre.tooltip')}
          testId="llmPreferences.nombre.help"
        >
          <TextBox
            value={nombre}
            onValueChanged={(event) => setNombre((event.value as string) ?? '')}
            placeholder={translate('llmPreferences.fields.nombre')}
            inputAttr={{
              autoComplete: 'off',
              name: 'llmCredentialNombre',
              'data-lpignore': 'true',
              'data-1p-ignore': 'true',
            }}
            elementAttr={{ 'data-testid': 'llmPreferences.nombre' }}
          />
        </FieldBlock>

        <FieldBlock
          label={translate('llmPreferences.fields.proveedor')}
          tooltip={translate('llmPreferences.fields.proveedor.tooltip')}
          testId="llmPreferences.proveedor.help"
        >
          <SelectBox
            dataSource={providerCatalog}
            valueExpr="id"
            displayExpr={(item: LlmProviderCatalogItem | null) =>
              item ? providerLabel(item, t) : ''
            }
            value={proveedor || null}
            searchEnabled
            onValueChanged={(event) => {
              const next = (event.value as string) ?? '';
              setProveedor(next);
              setModelo('');
              const nextItem = findProviderItem(providerCatalog, next);
              if (!nextItem?.requiresBaseUrl) {
                setBaseUrl('');
              }
            }}
            placeholder={translate('llmPreferences.fields.proveedor')}
            inputAttr={{
              autoComplete: 'off',
              name: 'llmCredentialProveedor',
              'data-lpignore': 'true',
              'data-1p-ignore': 'true',
            }}
            elementAttr={{ 'data-testid': 'llmPreferences.proveedor' }}
          />
          {providerItem?.helpUrl ? (
            <a
              href={providerItem.helpUrl}
              target="_blank"
              rel="noopener noreferrer"
              style={{ display: 'inline-block', marginTop: 6, fontSize: '0.8rem' }}
              title={translate('llmPreferences.helpLink.tooltip')}
              data-testid="llmPreferences.helpLink"
            >
              {translate('llmPreferences.helpLink')}
            </a>
          ) : null}
        </FieldBlock>

        <FieldBlock
          label={translate('llmPreferences.fields.modelo')}
          tooltip={translate('llmPreferences.fields.modelo.tooltip')}
          testId="llmPreferences.modelo.help"
        >
          <SelectBox
            dataSource={modelOptions}
            value={modelo || null}
            acceptCustomValue
            searchEnabled
            deferRendering={false}
            onValueChanged={(event) => setModelo((event.value as string) ?? '')}
            onCustomItemCreating={(event) => {
              const custom = event.text?.trim() ?? '';
              event.customItem = custom || null;
              return custom || null;
            }}
            placeholder={translate('llmPreferences.fields.modelo')}
            inputAttr={{
              autoComplete: 'off',
              name: 'llmCredentialModelo',
              'data-lpignore': 'true',
              'data-1p-ignore': 'true',
            }}
            elementAttr={{ 'data-testid': 'llmPreferences.modelo' }}
          />
        </FieldBlock>

        <FieldBlock
          label={translate('llmPreferences.fields.secreto')}
          tooltip={translate('llmPreferences.fields.secreto.tooltip')}
          testId="llmPreferences.secreto.help"
        >
          <TextBox
            value={secreto}
            mode="password"
            onValueChanged={(event) => setSecreto((event.value as string) ?? '')}
            placeholder={translate('llmPreferences.fields.secreto')}
            inputAttr={{
              autoComplete: 'new-password',
              name: 'llmCredentialApiKey',
              'data-lpignore': 'true',
              'data-1p-ignore': 'true',
              'data-form-type': 'other',
            }}
            elementAttr={{ 'data-testid': 'llmPreferences.secreto' }}
          />
        </FieldBlock>

        {mode === 'edit' && initial?.hasSecret ? (
          <span
            data-testid="llmPreferences.secretKeptHint"
            style={{ fontSize: '0.78rem', color: '#64748b' }}
          >
            {translate('llmPreferences.secretKeptHint')}
          </span>
        ) : null}

        {requiresBaseUrl ? (
          <FieldBlock
            label={translate('llmPreferences.fields.baseUrl')}
            tooltip={translate('llmPreferences.fields.baseUrl.tooltip')}
            testId="llmPreferences.baseUrl.help"
          >
            <TextBox
              value={baseUrl}
              onValueChanged={(event) => setBaseUrl((event.value as string) ?? '')}
              placeholder={translate('llmPreferences.fields.baseUrl')}
              inputAttr={{
                autoComplete: 'off',
                name: 'llmCredentialBaseUrl',
                'data-lpignore': 'true',
                'data-1p-ignore': 'true',
              }}
              elementAttr={{ 'data-testid': 'llmPreferences.baseUrl' }}
            />
          </FieldBlock>
        ) : null}

        <FieldBlock
          label={translate('llmPreferences.fields.supportsVision')}
          tooltip={translate('llmPreferences.fields.supportsVision.tooltip')}
          testId="llmPreferences.supportsVision.help"
        >
          <CheckBox value={supportsVision} disabled />
        </FieldBlock>

        <FieldBlock
          label={translate('llmPreferences.fields.enabled')}
          tooltip={translate('llmPreferences.fields.enabled.tooltip')}
          testId="llmPreferences.enabled.help"
        >
          <CheckBox
            value={enabled}
            onValueChanged={(event) => setEnabled((event.value as boolean) ?? true)}
          />
        </FieldBlock>

        {errorKey ? (
          <span data-testid="llmPreferences.formError" data-i18n-key={errorKey}>
            {translate(errorKey)}
          </span>
        ) : null}

        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <Button
            text={translate('llmPreferences.actions.cancel')}
            onClick={onCancel}
            elementAttr={{ 'data-testid': 'llmPreferences.cancel' }}
          />
          <Button
            text={translate('llmPreferences.actions.save')}
            type="default"
            stylingMode="contained"
            disabled={saving}
            onClick={() => void handleSave()}
            elementAttr={{ 'data-testid': 'llmPreferences.save' }}
          />
        </div>
      </div>
    </Popup>
  );
}
