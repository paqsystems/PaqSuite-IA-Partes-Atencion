import type { LlmProviderCatalogItem } from './types';

/**
 * Resolución de `supportsVision` al elegir modelo (TR-GEN-16-preferencias-ui §5):
 * 1) `supportsVisionByModel[modelo]` si está definido; 2) `defaultSupportsVision`;
 * 3) `false`.
 */
export function resolveSupportsVision(
  item: LlmProviderCatalogItem | undefined,
  modelo: string
): boolean {
  if (!item) {
    return false;
  }
  const byModel = item.supportsVisionByModel?.[modelo];
  if (typeof byModel === 'boolean') {
    return byModel;
  }
  return item.defaultSupportsVision ?? false;
}

/** Devuelve el ítem de catálogo del proveedor seleccionado (o undefined). */
export function findProviderItem(
  catalog: LlmProviderCatalogItem[],
  proveedor: string
): LlmProviderCatalogItem | undefined {
  const direct = catalog.find((item) => item.id === proveedor);
  if (direct) {
    return direct;
  }
  // Alias legacy GEN-16 smoke / Partes temprano → PedidosWeb/Tango id.
  if (proveedor === 'gemini') {
    return catalog.find((item) => item.id === 'googleGemini');
  }
  return undefined;
}

/** Label visible de un ítem de catálogo, con fallback a la clave/id. */
export function providerLabel(
  item: LlmProviderCatalogItem,
  t?: (key: string) => string
): string {
  if (item.labelKey && t) {
    return t(item.labelKey);
  }
  return item.label ?? item.id;
}
