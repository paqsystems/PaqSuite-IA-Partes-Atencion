import { apiRequest, type ApiClientResult } from '../../http/apiClient';
import { emissionsBasePath } from './emissionApiClient';
import type { EmissionReportRef } from './types';

export type EmissionDesignReportsResult = {
  items: EmissionReportRef[];
  designer: 'stub' | 'dx';
};

export type EmissionDesignLayoutResult = {
  item: {
    reportId: number;
    layoutMime: string;
    designer: string;
  };
};

export type EmissionDesignPrincipalResult = {
  item: {
    reportId: number;
    isPrincipal: boolean;
    designer: string;
  };
};

export type EmissionDesignCreateReportBody = {
  code: string;
  name: string;
  layoutDefinition?: string;
  layoutMime?: string;
  setPrincipal?: boolean;
};

export type EmissionDesignCreateReportResult = {
  item: EmissionReportRef;
  designer: string;
};

/** `GET .../design/processes/{processCode}/reports` — requiere emission.design (4709). */
export function getEmissionDesignReports(
  processCode: string
): Promise<ApiClientResult<EmissionDesignReportsResult>> {
  return apiRequest<EmissionDesignReportsResult>(
    `${emissionsBasePath}/design/processes/${encodeURIComponent(processCode)}/reports`,
    { method: 'GET' }
  );
}

/**
 * `POST .../design/processes/{processCode}/reports` — alta (Save As) de reporte del proceso.
 */
export function createEmissionDesignReport(
  processCode: string,
  body: EmissionDesignCreateReportBody
): Promise<ApiClientResult<EmissionDesignCreateReportResult>> {
  return apiRequest<EmissionDesignCreateReportResult>(
    `${emissionsBasePath}/design/processes/${encodeURIComponent(processCode)}/reports`,
    {
      method: 'POST',
      body: JSON.stringify(body),
    }
  );
}

/** `PUT .../design/reports/{reportId}/layout` — persiste layout (Fake y Fase C). */
export function updateEmissionReportLayout(
  reportId: number,
  body: { layoutDefinition?: string; layoutMime: string }
): Promise<ApiClientResult<EmissionDesignLayoutResult>> {
  return apiRequest<EmissionDesignLayoutResult>(
    `${emissionsBasePath}/design/reports/${reportId}/layout`,
    {
      method: 'PUT',
      body: JSON.stringify(body),
    }
  );
}

/** `POST .../design/reports/{reportId}/set-principal`. */
export function setEmissionReportPrincipal(
  reportId: number
): Promise<ApiClientResult<EmissionDesignPrincipalResult>> {
  return apiRequest<EmissionDesignPrincipalResult>(
    `${emissionsBasePath}/design/reports/${reportId}/set-principal`,
    { method: 'POST' }
  );
}

export const NOTIFICATION_SERVICE_ADMIN_PATH = '/admin/notification-service';
