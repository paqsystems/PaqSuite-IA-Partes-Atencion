/**
 * Tipos GEN-15 — Reportes / Emisiones (ciclo 2026-08).
 * SoT: TR-GEN-15-output-policy-motor + TR-GEN-15-ventana-emitir-orquestacion.
 */

export type EmissionDocumentaryChannel = 'pdf' | 'print' | 'excel' | 'csv' | 'zip';
/** @deprecated Usar EmissionDocumentaryChannel; `mail` ya no es canal documental. */
export type EmissionChannel = EmissionDocumentaryChannel | 'mail';

export type EmissionMode = 'consolidated' | 'segmented';

export type EmissionJobStatus =
  | 'pending'
  | 'running'
  | 'queued'
  | 'done'
  | 'failed'
  | 'failedCommunication'
  | 'cancelled';

export type EmissionOutputPolicyMode = 'AUTOMATIC' | 'MANDATORY' | 'INTERACTIVE' | 'HYBRID';

export type EmissionRecipientEditMode = 'NOT_EDITABLE' | 'ADD_ONLY' | 'FULL_EDIT';

export type EmissionOutputKind = 'documentary' | 'communication';

export type EmissionOutputPolicyItem = {
  channel: string;
  kind: EmissionOutputKind;
  mandatory: boolean;
  automatic: boolean;
  blocking: boolean;
};

export type EmissionOutputPolicy = {
  mode: EmissionOutputPolicyMode;
  outputs: EmissionOutputPolicyItem[];
  recipientEditMode?: EmissionRecipientEditMode | null;
};

export type EmissionReportRef = {
  id: number;
  code: string;
  name: string;
  isPrincipal: boolean;
};

export type EmissionRecipientDraft = {
  channel?: string;
  address?: string;
  userId?: string;
  role?: 'TO' | 'CC' | 'BCC';
};

export type CommunicationIntentDraft = {
  channelCode: string;
  recipients?: EmissionRecipientDraft[];
};

export type EmissionProcessListItem = {
  processCode: string;
  name: string;
  menuProcessCode?: string;
};

export type EmissionProcessDto = {
  processCode: string;
  channels: string[];
  modes: { consolidated: boolean; segmented: boolean };
  requiresPreview: boolean;
  outputPolicy: EmissionOutputPolicy;
  reports: EmissionReportRef[];
  menuProcessCode: string;
};

export type EmissionJobDto = {
  jobId: string;
  processCode: string;
  status: EmissionJobStatus;
  mode: EmissionMode;
  channel: string;
  fileName: string | null;
  messageKey: string | null;
  notificationId?: string | null;
  segmentKey?: string | null;
};

export type EmissionJobCreateRequest = {
  processCode: string;
  channel: EmissionDocumentaryChannel;
  mode: EmissionMode;
  reportId?: number;
  groupId?: string | null;
  /** GEN-23: distinto de groupId (segmentación). */
  grupoEmpresarioId?: number | null;
  previewSessionId?: string | null;
  mobile?: boolean;
  communicationIntents?: CommunicationIntentDraft[];
};

export type EmissionPreviewResult = {
  previewSessionId: string;
  contentUrl?: string;
  contentBase64?: string;
  mimeType: string;
  expiresAt: string;
};

export type EmissionCompletePayload = {
  jobId: string;
  processCode: string;
  status: 'done' | 'failed' | 'failedCommunication' | 'queued';
  /** Código de salida documental emitida (C1-15-30). */
  outputCode: string;
  mode: EmissionMode;
  fileName?: string | null;
  notificationIds?: string[];
};

/** Entradas que invalidan la sesión de preview (C1-15-10). */
export type PreviewInputs = {
  reportId?: number;
  mode: EmissionMode;
  groupId?: string | null;
  channel: string;
};

export const DOCUMENTARY_CHANNELS: EmissionDocumentaryChannel[] = [
  'pdf',
  'print',
  'excel',
  'csv',
  'zip',
];

export function isDocumentaryChannel(channel: string): channel is EmissionDocumentaryChannel {
  return (DOCUMENTARY_CHANNELS as string[]).includes(channel);
}
