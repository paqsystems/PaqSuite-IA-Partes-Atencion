/**
 * @vitest-environment jsdom
 *
 * Batería del flujo GEN-15 en `EmissionReportDesignerPage` (contrato Framework).
 * El widget DevExpress Reporting es del host: aquí se inyecta un fake que dispara
 * `onDxReportSaved` como el puente DX (Save As / Save).
 */
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { ReactNode } from 'react';
import type { ApiClientResult } from '../../http/apiClient';
import type { ReportDesignerContext } from './ReportDesignerHost';
import type { EmissionReportRef } from './types';

const { catalog, envelopeOk, PROCESS_CODE, PRINCIPAL_CODE, SAVE_AS_URL } = vi.hoisted(() => {
  const PROCESS_CODE = 'partes.informes.consultaDetallada';
  const PRINCIPAL_CODE = 'partes.consultaDetallada.principal';
  const SAVE_AS_URL = 'partes.consultaDetallada.nuevoDiseno';

  function envelopeOk<T>(resultado: T): ApiClientResult<T> {
    return {
      kind: 'ok',
      httpStatus: 200,
      envelope: { error: 0, respuesta: 'ok', resultado },
    };
  }

  const principalReport: EmissionReportRef = {
    id: 1,
    code: PRINCIPAL_CODE,
    name: 'Principal',
    isPrincipal: true,
  };

  const catalog = {
    reports: [] as EmissionReportRef[],
    nextReportId: 2,
    lastCreateBody: null as { code: string; name: string } | null,
    reset(): void {
      catalog.reports = [{ ...principalReport }];
      catalog.nextReportId = 2;
      catalog.lastCreateBody = null;
    },
  };

  return { catalog, envelopeOk, PROCESS_CODE, PRINCIPAL_CODE, SAVE_AS_URL };
});

vi.mock('./emissionApiClient', () => ({
  emissionsBasePath: '/api/v1/emissions',
  getEmissionProcesses: async () =>
    envelopeOk({
      items: [{ processCode: PROCESS_CODE, name: 'Consulta detallada', menuProcessCode: 'partes_consulta' }],
    }),
}));

vi.mock('./emissionDesignApi', () => ({
  NOTIFICATION_SERVICE_ADMIN_PATH: '/admin/notification-service',
  getEmissionDesignReports: async () =>
    envelopeOk({
      designer: 'dx' as const,
      items: catalog.reports.map((item) => ({ ...item })),
    }),
  createEmissionDesignReport: async (
    _processCode: string,
    body: { code: string; name: string; layoutDefinition?: string }
  ) => {
    catalog.lastCreateBody = { code: body.code, name: body.name };
    const item: EmissionReportRef = {
      id: catalog.nextReportId,
      code: body.code,
      name: body.name,
      isPrincipal: false,
    };
    catalog.nextReportId += 1;
    catalog.reports = [...catalog.reports, item];
    return envelopeOk({ item, designer: 'dx' });
  },
  updateEmissionReportLayout: async (reportId: number) =>
    envelopeOk({
      item: { reportId, layoutMime: 'application/xml', designer: 'dx' },
    }),
  setEmissionReportPrincipal: async (reportId: number) =>
    envelopeOk({
      item: { reportId, isPrincipal: true, designer: 'dx' },
    }),
}));

vi.mock('devextreme-react/load-panel', () => ({
  default: () => null,
}));

vi.mock('devextreme-react/button', () => ({
  default: (props: {
    text?: string;
    disabled?: boolean;
    onClick?: () => void;
    elementAttr?: Record<string, string>;
  }) => (
    <button
      type="button"
      data-testid={props.elementAttr?.['data-testid']}
      disabled={props.disabled === true}
      onClick={props.onClick}
    >
      {props.text}
    </button>
  ),
}));

type SelectItem = Record<string, unknown>;

vi.mock('devextreme-react/select-box', () => ({
  default: (props: {
    items?: SelectItem[];
    valueExpr?: string;
    displayExpr?: string;
    value?: string | number | null;
    placeholder?: string;
    onValueChanged?: (event: { value: string | number | null }) => void;
    elementAttr?: Record<string, string>;
  }) => {
    const valueExpr = props.valueExpr ?? 'id';
    const displayExpr = props.displayExpr ?? 'name';
    const items = props.items ?? [];
    const testId = props.elementAttr?.['data-testid'] ?? 'select';
    const codes =
      testId === 'emission.design.report'
        ? items.map((item) => String(item.code ?? '')).join('|')
        : undefined;

    return (
      <select
        data-testid={testId}
        data-placeholder={props.placeholder}
        data-report-codes={codes}
        value={props.value == null ? '' : String(props.value)}
        onChange={(event) => {
          const raw = event.target.value;
          if (raw === '') {
            props.onValueChanged?.({ value: null });
            return;
          }
          props.onValueChanged?.({
            value: valueExpr === 'id' ? Number(raw) : raw,
          });
        }}
      >
        <option value="">{props.placeholder ?? ''}</option>
        {items.map((item) => {
          const value = String(item[valueExpr] ?? '');
          const label = String(item[displayExpr] ?? value);
          return (
            <option key={value} value={value} data-code={String(item.code ?? '')}>
              {label}
            </option>
          );
        })}
      </select>
    );
  },
}));

import { EmissionReportDesignerPage } from './EmissionReportDesignerPage';

function FakeDesigner({ context }: { context: ReportDesignerContext }): ReactNode {
  const reportCode = context.reportCode ?? '';
  if (reportCode.includes('consultaDetallada') && !reportCode.includes('.')) {
    throw new Error('hyphenated-reportCode');
  }

  return (
    <div data-testid="emission.design.fakeDx">
      <span data-testid="emission.design.fakeReportCode">{reportCode}</span>
      <button
        type="button"
        data-testid="emission.design.fakeSaveAs"
        onClick={() => {
          void context.onDxReportSaved?.({
            url: SAVE_AS_URL,
            layoutDefinition: '<XtraReportsLayoutSerializer/>',
            isNew: true,
          });
        }}
      >
        Save As
      </button>
    </div>
  );
}

function renderDesignerPage(t?: (key: string) => string) {
  return render(
    <EmissionReportDesignerPage
      hasDesignPermission
      initialProcessCode={PROCESS_CODE}
      renderDesigner={(context) => <FakeDesigner context={context} />}
      t={t}
    />
  );
}

describe('EmissionReportDesignerPage — flujo diseñador GEN-15', () => {
  beforeEach(() => {
    catalog.reset();
  });

  afterEach(() => {
    cleanup();
    vi.restoreAllMocks();
  });

  it('N=1: lista el proceso y no monta DX hasta confirmar', async () => {
    render(
      <EmissionReportDesignerPage
        hasDesignPermission
        renderDesigner={(context) => <FakeDesigner context={context} />}
      />
    );

    await waitFor(() => {
      expect(screen.getByTestId('emission.design.process')).toBeTruthy();
    });
    expect(screen.getByTestId('emission.design.confirmProcess')).toBeTruthy();
    expect(screen.queryByTestId('emission.design.fakeDx')).toBeNull();
    expect(screen.queryByTestId('emission.design.closeDesigner')).toBeNull();
    expect(screen.queryByTestId('emission.design.host')).toBeNull();
  });

  it('flujo completo: confirmar, reportCode con puntos, Save As, aparece, Cerrar, reabrir', async () => {
    renderDesignerPage();

    await waitFor(() => {
      expect((screen.getByTestId('emission.design.confirmProcess') as HTMLButtonElement).disabled).toBe(
        false
      );
    });
    expect(screen.queryByTestId('emission.design.fakeDx')).toBeNull();

    fireEvent.click(screen.getByTestId('emission.design.confirmProcess'));

    await waitFor(() => {
      expect(screen.getByTestId('emission.design.closeDesigner')).toBeTruthy();
    });
    expect(screen.getByTestId('emission.design.closeDesigner').textContent).toContain('Cerrar');

    await waitFor(() => {
      expect(screen.getByTestId('emission.design.fakeDx')).toBeTruthy();
    });
    expect(screen.getByTestId('emission.design.host')).toBeTruthy();
    expect(screen.getByTestId('emission.design.fakeReportCode').textContent).toBe(PRINCIPAL_CODE);
    expect(screen.getByTestId('emission.design.report').getAttribute('data-report-codes')).toBe(
      PRINCIPAL_CODE
    );

    fireEvent.click(screen.getByTestId('emission.design.fakeSaveAs'));

    await waitFor(() => {
      expect(screen.getByTestId('emission.design.fakeReportCode').textContent).toBe(SAVE_AS_URL);
    });
    expect(catalog.lastCreateBody?.code).toBe(SAVE_AS_URL);
    const createdCode = catalog.lastCreateBody?.code ?? '';
    expect(screen.getByTestId('emission.design.report').getAttribute('data-report-codes')).toContain(
      createdCode
    );

    fireEvent.click(screen.getByTestId('emission.design.closeDesigner'));

    await waitFor(() => {
      expect(screen.queryByTestId('emission.design.fakeDx')).toBeNull();
    });
    expect(screen.queryByTestId('emission.design.host')).toBeNull();
    expect(screen.queryByTestId('emission.design.closeDesigner')).toBeNull();

    fireEvent.click(screen.getByTestId('emission.design.confirmProcess'));

    await waitFor(() => {
      expect(screen.getByTestId('emission.design.fakeDx')).toBeTruthy();
    });
    expect(screen.getByTestId('emission.design.closeDesigner')).toBeTruthy();
    const reopenedCodes =
      screen.getByTestId('emission.design.report').getAttribute('data-report-codes') ?? '';
    expect(reopenedCodes.split('|')).toContain(createdCode);
    expect(reopenedCodes.split('|')).toContain(PRINCIPAL_CODE);
  });

  it('con t() vacío el botón Cerrar diseñador sigue visible tras confirmar', async () => {
    renderDesignerPage(() => '');

    await waitFor(() => {
      expect((screen.getByTestId('emission.design.confirmProcess') as HTMLButtonElement).disabled).toBe(
        false
      );
    });
    fireEvent.click(screen.getByTestId('emission.design.confirmProcess'));

    await waitFor(() => {
      expect(screen.getByTestId('emission.design.closeDesigner')).toBeTruthy();
    });
    expect(screen.getByTestId('emission.design.closeDesigner').textContent).toBe('Cerrar diseñador');
  });

  it('un throw del widget DX no blanquea la página: queda Cerrar y el aviso', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);

    render(
      <EmissionReportDesignerPage
        hasDesignPermission
        initialProcessCode={PROCESS_CODE}
        renderDesigner={() => {
          throw new Error('dx widget');
        }}
      />
    );

    await waitFor(() => {
      expect((screen.getByTestId('emission.design.confirmProcess') as HTMLButtonElement).disabled).toBe(
        false
      );
    });
    fireEvent.click(screen.getByTestId('emission.design.confirmProcess'));

    await waitFor(() => {
      expect(screen.getByTestId('emission.design.hostCrash')).toBeTruthy();
    });
    expect(screen.getByTestId('emission.design.page')).toBeTruthy();
    expect(screen.getByTestId('emission.design.closeDesigner')).toBeTruthy();
    expect(screen.getByTestId('emission.design.process')).toBeTruthy();
  });

  it('cambiar el proceso confirmado desmonta el DX (C1-15-39)', async () => {
    renderDesignerPage();

    await waitFor(() => {
      expect((screen.getByTestId('emission.design.confirmProcess') as HTMLButtonElement).disabled).toBe(
        false
      );
    });
    fireEvent.click(screen.getByTestId('emission.design.confirmProcess'));
    await waitFor(() => {
      expect(screen.getByTestId('emission.design.fakeDx')).toBeTruthy();
    });

    fireEvent.change(screen.getByTestId('emission.design.process'), { target: { value: '' } });

    await waitFor(() => {
      expect(screen.queryByTestId('emission.design.fakeDx')).toBeNull();
    });
    expect(screen.queryByTestId('emission.design.closeDesigner')).toBeNull();
  });
});
