import { describe, expect, it } from 'vitest';
import { parseDxReportSavedArgs } from './parseDxReportSavedArgs';

describe('parseDxReportSavedArgs', () => {
  it('lee Url y serialize del objeto único', () => {
    const parsed = parseDxReportSavedArgs({
      Url: 'Nuevo diseño',
      Report: { serialize: () => '<XtraReportsLayoutSerializer/>' },
    });
    expect(parsed.url).toBe('Nuevo diseño');
    expect(parsed.layoutDefinition).toBe('<XtraReportsLayoutSerializer/>');
  });

  it('lee el segundo argumento estilo sender, args', () => {
    const parsed = parseDxReportSavedArgs([
      { sender: true },
      { url: 'Alt.v2', report: { serialize: () => '<xml/>' } },
    ]);
    expect(parsed.url).toBe('Alt.v2');
    expect(parsed.layoutDefinition).toBe('<xml/>');
  });
});
