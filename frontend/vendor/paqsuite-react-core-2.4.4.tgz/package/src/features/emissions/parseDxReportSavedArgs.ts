export type ParsedDxReportSaved = {
  url: string;
  layoutDefinition?: string;
};

function readUrlFromObject(value: Record<string, unknown>): string {
  const candidates = [value.Url, value.url, value.NewUrl, value.newUrl, value.reportUrl];
  for (const candidate of candidates) {
    if (typeof candidate === 'string' && candidate.trim() !== '') {
      return candidate.trim();
    }
  }
  return '';
}

function readLayoutFromObject(value: Record<string, unknown>): string | undefined {
  const report = value.Report ?? value.report;
  if (!report || typeof report !== 'object') {
    return undefined;
  }
  const serialize = (report as { serialize?: () => string }).serialize;
  if (typeof serialize !== 'function') {
    return undefined;
  }
  try {
    const xml = serialize();
    return typeof xml === 'string' && xml.trim() !== '' ? xml : undefined;
  } catch {
    return undefined;
  }
}

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== 'object') {
    return null;
  }
  return value as Record<string, unknown>;
}

/**
 * DevExpress ReportSaved a veces manda `(sender, args)` y a veces un solo objeto.
 */
export function parseDxReportSavedArgs(args: unknown): ParsedDxReportSaved {
  const queue: unknown[] = Array.isArray(args) ? [...args] : [args];
  let url = '';
  let layoutDefinition: string | undefined;

  for (const item of queue) {
    const record = asRecord(item);
    if (!record) {
      continue;
    }
    if (!url) {
      url = readUrlFromObject(record);
    }
    if (!layoutDefinition) {
      layoutDefinition = readLayoutFromObject(record);
    }
  }

  return { url, layoutDefinition };
}
