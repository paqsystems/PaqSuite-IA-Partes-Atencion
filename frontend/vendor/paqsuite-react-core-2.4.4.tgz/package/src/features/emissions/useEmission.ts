import { useCallback, useEffect, useRef, useState } from 'react';
import {
  createEmissionJob,
  createEmissionPreview,
  getEmissionJob,
  getEmissionProcess,
} from './emissionApiClient';
import {
  buildEmissionCompletePayload,
  canEmit as policyCanEmit,
  communicationOutputs,
  isPreviewStale,
  isTerminalJob,
  resolveAvailableChannels,
} from './emissionPolicy';
import type {
  CommunicationIntentDraft,
  EmissionCompletePayload,
  EmissionDocumentaryChannel,
  EmissionJobDto,
  EmissionMode,
  EmissionPreviewResult,
  EmissionProcessDto,
  EmissionRecipientDraft,
  PreviewInputs,
} from './types';
import { isDocumentaryChannel } from './types';

export type UseEmissionOptions = {
  processCode: string;
  isNative?: boolean;
  onComplete?: (payload: EmissionCompletePayload) => void;
  pollIntervalMs?: number;
};

export type EmissionSelection = {
  /** Canales documentales seleccionados (N POSTs). */
  channels: EmissionDocumentaryChannel[];
  /** Canales de comunicación (EMAIL, …) → communicationIntents. */
  communicationChannels: string[];
  mode: EmissionMode;
  reportId?: number;
  groupId?: string | null;
  grupoEmpresarioId?: number | null;
  recipients: EmissionRecipientDraft[];
};

export type UseEmissionState = {
  process: EmissionProcessDto | null;
  loading: boolean;
  submitting: boolean;
  selection: EmissionSelection;
  setSelection: (patch: Partial<EmissionSelection>) => void;
  preview: EmissionPreviewResult | null;
  previewStale: boolean;
  job: EmissionJobDto | null;
  jobs: EmissionJobDto[];
  errorKey: string | null;
  canEmit: boolean;
  communicationChannelItems: string[];
  documentaryChannelItems: string[];
  runPreview: () => Promise<void>;
  emit: () => Promise<void>;
  reset: () => void;
};

const defaultSelection: EmissionSelection = {
  channels: [],
  communicationChannels: [],
  mode: 'consolidated',
  recipients: [],
};

/**
 * Hook ventana Emitir (GEN-15 ciclo 2026-08):
 * N POSTs documentales; intents + recipients en el POST pdf; native sin preview.
 */
export function useEmission(options: UseEmissionOptions): UseEmissionState {
  const { processCode, isNative = false, onComplete, pollIntervalMs = 2000 } = options;
  const [process, setProcess] = useState<EmissionProcessDto | null>(null);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [selection, setSelectionState] = useState<EmissionSelection>(defaultSelection);
  const [preview, setPreview] = useState<EmissionPreviewResult | null>(null);
  const [previewInputs, setPreviewInputs] = useState<PreviewInputs | null>(null);
  const [job, setJob] = useState<EmissionJobDto | null>(null);
  const [jobs, setJobs] = useState<EmissionJobDto[]>([]);
  const [errorKey, setErrorKey] = useState<string | null>(null);
  const pollRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    void getEmissionProcess(processCode)
      .then((result) => {
        if (!active) {
          return;
        }
        setLoading(false);
        if (result.kind === 'ok') {
          const dto = result.envelope.resultado;
          setProcess(dto);
          const docs = resolveAvailableChannels(dto, isNative);
          const principal = dto.reports.find((item) => item.isPrincipal) ?? dto.reports[0];
          setSelectionState((prev) => ({
            ...prev,
            channels:
              prev.channels.length > 0
                ? prev.channels
                : docs.includes('pdf')
                  ? ['pdf']
                  : docs.slice(0, 1).filter(isDocumentaryChannel),
            reportId: prev.reportId ?? principal?.id,
          }));
        } else {
          setErrorKey('emission.error.processLoad');
        }
      })
      .catch(() => {
        if (!active) {
          return;
        }
        setLoading(false);
        setErrorKey('emission.error.processLoad');
      });
    return () => {
      active = false;
    };
  }, [processCode, isNative]);

  useEffect(
    () => () => {
      if (pollRef.current) {
        clearTimeout(pollRef.current);
      }
    },
    []
  );

  const primaryChannel = selection.channels[0] ?? '';
  const currentInputs: PreviewInputs = {
    reportId: selection.reportId,
    mode: selection.mode,
    groupId: selection.groupId ?? null,
    channel: primaryChannel,
  };
  const previewStale = isPreviewStale(previewInputs, currentInputs);
  const hasValidPreview = Boolean(preview && !previewStale);

  const setSelection = useCallback((patch: Partial<EmissionSelection>) => {
    setSelectionState((prev) => ({ ...prev, ...patch }));
  }, []);

  const runPreview = useCallback(async () => {
    if (isNative || !primaryChannel || !isDocumentaryChannel(primaryChannel)) {
      return;
    }
    setErrorKey(null);
    const result = await createEmissionPreview({
      processCode,
      channel: primaryChannel,
      mode: selection.mode,
      reportId: selection.reportId,
      groupId: selection.groupId ?? null,
    });
    if (result.kind === 'ok') {
      setPreview(result.envelope.resultado);
      setPreviewInputs(currentInputs);
    } else {
      setErrorKey(
        result.kind === 'envelopeError'
          ? `emission.error.${result.envelope.error}`
          : 'emission.error.transport'
      );
    }
  }, [processCode, selection, currentInputs, isNative, primaryChannel]);

  const pollJob = useCallback(
    (jobId: string) => {
      void getEmissionJob(jobId).then((result) => {
        if (result.kind !== 'ok') {
          setErrorKey('emission.error.jobPoll');
          return;
        }
        const dto = result.envelope.resultado;
        setJob(dto);
        setJobs((prev) => prev.map((item) => (item.jobId === dto.jobId ? dto : item)));
        if (isTerminalJob(dto.status)) {
          onComplete?.(buildEmissionCompletePayload(dto));
          return;
        }
        pollRef.current = setTimeout(() => pollJob(jobId), pollIntervalMs);
      });
    },
    [onComplete, pollIntervalMs]
  );

  const buildIntents = useCallback((): CommunicationIntentDraft[] => {
    return selection.communicationChannels.map((channelCode) => ({
      channelCode,
      recipients: selection.recipients.map((recipient) => ({
        ...recipient,
        channel: recipient.channel ?? channelCode,
      })),
    }));
  }, [selection.communicationChannels, selection.recipients]);

  const emit = useCallback(async () => {
    if (selection.channels.length === 0) {
      return;
    }
    setErrorKey(null);
    setSubmitting(true);
    setJobs([]);
    const intents = buildIntents();
    const created: EmissionJobDto[] = [];

    try {
      for (const channel of selection.channels) {
        const result = await createEmissionJob({
          processCode,
          channel,
          mode: selection.mode,
          reportId: selection.reportId,
          groupId: selection.groupId ?? null,
          grupoEmpresarioId: selection.grupoEmpresarioId ?? null,
          previewSessionId: isNative ? null : (preview?.previewSessionId ?? null),
          mobile: isNative,
          communicationIntents: channel === 'pdf' ? intents : undefined,
        });

        if (result.kind !== 'ok') {
          // C1-15-22: failedCommunication puede venir con error 50xx y item en resultado
          if (
            result.kind === 'envelopeError' &&
            result.envelope.error >= 5000 &&
            result.envelope.error <= 5099
          ) {
            const item = (result.envelope.resultado as { item?: EmissionJobDto } | undefined)?.item;
            if (item?.jobId) {
              created.push(item);
              setJob(item);
              setJobs([...created]);
              onComplete?.(buildEmissionCompletePayload(item));
              setErrorKey(`emission.error.${result.envelope.error}`);
              return;
            }
          }
          setErrorKey(
            result.kind === 'envelopeError'
              ? `emission.error.${result.envelope.error}`
              : 'emission.error.transport'
          );
          return;
        }

        const dto = result.envelope.resultado;
        created.push(dto);
        setJob(dto);
        setJobs([...created]);
        if (isTerminalJob(dto.status) && dto.status !== 'queued') {
          onComplete?.(buildEmissionCompletePayload(dto));
        } else if (dto.status === 'queued') {
          pollRef.current = setTimeout(() => pollJob(dto.jobId), pollIntervalMs);
        }
      }
    } finally {
      setSubmitting(false);
    }
  }, [
    processCode,
    selection,
    preview,
    isNative,
    buildIntents,
    onComplete,
    pollJob,
    pollIntervalMs,
  ]);

  const reset = useCallback(() => {
    setSelectionState(defaultSelection);
    setPreview(null);
    setPreviewInputs(null);
    setJob(null);
    setJobs([]);
    setErrorKey(null);
  }, []);

  const documentaryChannelItems = process ? resolveAvailableChannels(process, isNative) : [];
  const communicationChannelItems = process
    ? communicationOutputs(process.outputPolicy).map((item) => item.channel)
    : [];

  return {
    process,
    loading,
    submitting,
    selection,
    setSelection,
    preview,
    previewStale,
    job,
    jobs,
    errorKey,
    canEmit: policyCanEmit({
      channels: selection.channels,
      mode: selection.mode,
      groupId: selection.groupId,
      requiresPreview: process?.requiresPreview,
      hasValidPreview,
      isNative,
    }),
    communicationChannelItems,
    documentaryChannelItems,
    runPreview,
    emit,
    reset,
  };
}
