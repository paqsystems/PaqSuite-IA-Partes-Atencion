/**
 * Selección de proceso en el diseñador GEN-15 (C1-15-36..39).
 * Prohibido auto-skip / auto-confirm aunque N=1.
 */

export function shouldAutoConfirmProcessList(_itemCount: number): boolean {
  return false;
}

export function canMountDesigner(confirmedProcessCode: string | null | undefined): boolean {
  return typeof confirmedProcessCode === 'string' && confirmedProcessCode.length > 0;
}

/** Toolbar Cerrar / SelectBox de reportes: proceso confirmado, aunque el catálogo aún cargue. */
export function canShowDesignerChrome(confirmedProcessCode: string | null | undefined): boolean {
  return canMountDesigner(confirmedProcessCode);
}

/** Montar el widget DX solo con catálogo de reports resuelto (evita remount a mitad de init). */
export function canMountDesignerHost(
  confirmedProcessCode: string | null | undefined,
  reportCatalogReady: boolean
): boolean {
  return canMountDesigner(confirmedProcessCode) && reportCatalogReady === true;
}

export function resolveInitialSelectValue(
  initialProcessCode?: string | null,
  processCodeAlias?: string | null
): string | null {
  const preferred = initialProcessCode?.trim() || processCodeAlias?.trim() || '';
  return preferred.length > 0 ? preferred : null;
}

export function confirmSelectedProcess(selectedProcessCode: string | null): string | null {
  if (!selectedProcessCode) {
    return null;
  }
  return selectedProcessCode;
}

export function nextConfirmedAfterProcessChange(
  confirmedProcessCode: string | null,
  nextSelectedProcessCode: string | null
): string | null {
  if (confirmedProcessCode === null) {
    return null;
  }
  if (nextSelectedProcessCode !== confirmedProcessCode) {
    return null;
  }
  return confirmedProcessCode;
}
