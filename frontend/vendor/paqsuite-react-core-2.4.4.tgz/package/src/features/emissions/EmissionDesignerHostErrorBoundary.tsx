import { Component, type ErrorInfo, type ReactNode } from 'react';

export type EmissionDesignerHostErrorBoundaryProps = {
  resetKey?: string | null;
  fallbackLabel: string;
  children: ReactNode;
};

type EmissionDesignerHostErrorBoundaryState = {
  hasError: boolean;
  message: string;
};

/**
 * Aísla un throw del widget DX / renderDesigner para no blanquear toda la SPA.
 */
export class EmissionDesignerHostErrorBoundary extends Component<
  EmissionDesignerHostErrorBoundaryProps,
  EmissionDesignerHostErrorBoundaryState
> {
  public state: EmissionDesignerHostErrorBoundaryState = { hasError: false, message: '' };

  public static getDerivedStateFromError(error: unknown): EmissionDesignerHostErrorBoundaryState {
    const message = error instanceof Error ? error.message : String(error);
    return { hasError: true, message };
  }

  public componentDidUpdate(prevProps: EmissionDesignerHostErrorBoundaryProps): void {
    if (prevProps.resetKey !== this.props.resetKey && this.state.hasError) {
      this.setState({ hasError: false, message: '' });
    }
  }

  public componentDidCatch(_error: unknown, _errorInfo: ErrorInfo): void {
    return;
  }

  public render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div data-testid="emission.design.hostCrash" role="alert" style={{ padding: 12 }}>
          <p>{this.props.fallbackLabel}</p>
          {this.state.message ? <p style={{ opacity: 0.8, fontSize: 13 }}>{this.state.message}</p> : null}
        </div>
      );
    }
    return this.props.children;
  }
}
