import { describe, expect, it } from 'vitest';
import { isExcludedByGenCatalog } from '../../mobile/policy/genMobileExclusions';

describe('emission design mobile exclusion (GEN-15 Lote 6/8)', () => {
  it('bloquea rutas de diseñador documental', () => {
    expect(isExcludedByGenCatalog('/emissions/design')).toBe(true);
    expect(isExcludedByGenCatalog('/emissions/design/EMISSION_SMOKE')).toBe(true);
    expect(isExcludedByGenCatalog('/emission/design')).toBe(true);
  });

  it('bloquea por procedimiento emission.design', () => {
    expect(isExcludedByGenCatalog('/custom', 'emission.design')).toBe(true);
    expect(isExcludedByGenCatalog('/custom', 'EMISSION_DESIGN')).toBe(true);
  });
});
