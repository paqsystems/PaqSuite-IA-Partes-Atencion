import type { ReactNode } from 'react';
import { useCallback, useEffect, useState } from 'react';
import Button from 'devextreme-react/button';
import SelectBox from 'devextreme-react/select-box';
import LoadPanel from 'devextreme-react/load-panel';
import { getEmissionProcesses } from './emissionApiClient';
import {
  createEmissionDesignReport,
  getEmissionDesignReports,
  NOTIFICATION_SERVICE_ADMIN_PATH,
  setEmissionReportPrincipal,
  updateEmissionReportLayout,
} from './emissionDesignApi';
import { EmissionDesignerHostErrorBoundary } from './EmissionDesignerHostErrorBoundary';
import {
  canMountDesignerHost,
  canShowDesignerChrome,
  confirmSelectedProcess,
  nextConfirmedAfterProcessChange,
  resolveInitialSelectValue,
} from './emissionDesignProcessSelection';
import {
  catalogEmissionReportCode,
  catalogCodeFromDxUrl,
  isUnknownEmissionReportCode,
} from './normalizeEmissionReportCode';
import {
  ReportDesignerHost,
  type DxReportSavedEvent,
  type ReportDesignerContext,
} from './ReportDesignerHost';
import type { EmissionProcessListItem, EmissionReportRef } from './types';

export type EmissionReportDesignerPageProps = {
  /**
   * @deprecated Usar `initialProcessCode`. Solo preselecciona; no confirma (C1-15-38).
   */
  processCode?: string;
  /** Preselección visual; no auto-confirma. */
  initialProcessCode?: string;
  /** Host: permiso GEN `emission.design`. Sin él no se llama API (UI gated). */
  hasDesignPermission?: boolean;
  /** Host: procedimiento NOTIFICATION_SERVICE_ADMIN → muestra deep-link. */
  hasNotificationServiceAdmin?: boolean;
  isNative?: boolean;
  designerEndpoint?: string;
  /**
   * Fase C: inyección del diseñador DevExpress Reporting (JS).
   * El SDK no declara la dependencia pesada; el host la provee con licencia DX.
   */
  renderDesigner?: (context: ReportDesignerContext) => ReactNode;
  /** Navegación deep-link Admin NS (default: assign location). */
  navigate?: (path: string) => void;
  t?: (key: string) => string;
};

const LAYOUT_MIME_REPX = 'application/xml';

const designLabelFallbacks: Record<string, string> = {
  'emission.design.selectProcess': 'Elegir proceso',
  'emission.design.confirmProcess': 'Confirmar proceso',
  'emission.design.closeDesigner': 'Cerrar diseñador',
  'emission.design.setPrincipal': 'Marcar principal',
  'emission.design.noProcesses': 'No hay procesos emisibles activos',
  'emission.design.forbidden': 'Sin permiso emission.design (4709)',
  'emission.design.mobileExcluded': 'Diseñador de reportes no disponible en mobile',
  'emission.design.saveAsFailed': 'No se pudo registrar el Save As en el catálogo',
  'emission.design.dxHint': 'Motor documental DevExpress Reporting',
  'emission.design.fakeHint': 'Motor documental en modo stub/Fake',
  'emission.design.hostCrash': 'No se pudo abrir el diseñador. Cerrar y volver a confirmar el proceso.',
};

function asText(value: unknown): string {
  return typeof value === 'string' ? value : '';
}

function designLabel(translate: (key: string) => string, key: string): string {
  const fromHost = asText(translate(key));
  if (fromHost.trim() !== '' && fromHost !== key) {
    return fromHost;
  }
  return designLabelFallbacks[key] ?? (fromHost.trim() !== '' ? fromHost : key);
}

function displayNameFromReportUrl(url: string): string {
  const trimmed = url.trim();
  const last = trimmed.includes('.') ? trimmed.slice(trimmed.lastIndexOf('.') + 1) : trimmed;
  return last.replace(/[-_]+/g, ' ').trim() || trimmed;
}

/**
 * Diseñador documental GEN-15 (desktop). Export canónico ciclo 2026-08.
 * Flujo: lista procesos → confirmar → reports → DX. Sin ABM plantillas mail en `15`.
 * Save As (DX): crea fila en catálogo del proceso y refresca el SelectBox.
 */
export function EmissionReportDesignerPage({
  processCode,
  initialProcessCode,
  hasDesignPermission = false,
  hasNotificationServiceAdmin = false,
  isNative = false,
  designerEndpoint,
  renderDesigner,
  navigate,
  t,
}: EmissionReportDesignerPageProps) {
  const translate = t ?? ((key: string) => key);
  const [loading, setLoading] = useState(false);
  const [errorKey, setErrorKey] = useState<string | null>(null);
  const [processItems, setProcessItems] = useState<EmissionProcessListItem[]>([]);
  const [selectedProcessCode, setSelectedProcessCode] = useState<string | null>(
    resolveInitialSelectValue(initialProcessCode, processCode)
  );
  const [confirmedProcessCode, setConfirmedProcessCode] = useState<string | null>(null);
  const [reports, setReports] = useState<EmissionReportRef[]>([]);
  const [designerMode, setDesignerMode] = useState<'stub' | 'dx'>('stub');
  const [selectedReportId, setSelectedReportId] = useState<number | null>(null);
  const [reportCatalogReady, setReportCatalogReady] = useState(false);

  useEffect(() => {
    if (isNative || !hasDesignPermission) {
      return;
    }
    let active = true;
    setLoading(true);
    void getEmissionProcesses()
      .then((result) => {
        if (!active) {
          return;
        }
        setLoading(false);
        if (result.kind === 'ok') {
          setProcessItems(result.envelope.resultado.items ?? []);
          return;
        }
        if (result.kind === 'envelopeError' && result.envelope.error === 4709) {
          setErrorKey('emission.design.forbidden');
          return;
        }
        setErrorKey(
          result.kind === 'envelopeError'
            ? `emission.error.${result.envelope.error}`
            : 'emission.error.transport'
        );
      })
      .catch(() => {
        if (!active) {
          return;
        }
        setLoading(false);
        setErrorKey('emission.error.transport');
      });
    return () => {
      active = false;
    };
  }, [hasDesignPermission, isNative]);

  useEffect(() => {
    if (isNative || !hasDesignPermission || !confirmedProcessCode) {
      setReportCatalogReady(false);
      return;
    }
    let active = true;
    setLoading(true);
    setReportCatalogReady(false);
    void getEmissionDesignReports(confirmedProcessCode)
      .then((result) => {
        if (!active) {
          return;
        }
        setLoading(false);
        if (result.kind === 'ok') {
          const payload = result.envelope.resultado;
          const items = Array.isArray(payload.items) ? payload.items : [];
          setReports(items);
          setDesignerMode(payload.designer === 'dx' ? 'dx' : 'stub');
          const principal = items.find((item) => item.isPrincipal) ?? items[0];
          setSelectedReportId(principal?.id ?? null);
          setReportCatalogReady(true);
          return;
        }
        if (result.kind === 'envelopeError' && result.envelope.error === 4709) {
          setErrorKey('emission.design.forbidden');
          setReportCatalogReady(false);
          return;
        }
        setErrorKey(
          result.kind === 'envelopeError'
            ? `emission.error.${result.envelope.error}`
            : 'emission.error.transport'
        );
        setReportCatalogReady(false);
      })
      .catch(() => {
        if (!active) {
          return;
        }
        setLoading(false);
        setErrorKey('emission.error.transport');
        setReportCatalogReady(false);
      });
    return () => {
      active = false;
    };
  }, [confirmedProcessCode, hasDesignPermission, isNative]);

  const handleDxReportSaved = useCallback(
    async (event: DxReportSavedEvent) => {
      if (!confirmedProcessCode) {
        return;
      }
      const code = catalogCodeFromDxUrl(event.url);
      if (!code) {
        setErrorKey('emission.design.saveAsFailed');
        return;
      }

      const isNew = isUnknownEmissionReportCode(
        code,
        reports.map((item) => catalogEmissionReportCode(item.code))
      );

      if (isNew) {
        setLoading(true);
        const createResult = await createEmissionDesignReport(confirmedProcessCode, {
          code,
          name: displayNameFromReportUrl(event.url.trim() || code),
          layoutDefinition: event.layoutDefinition,
          layoutMime: event.layoutDefinition ? LAYOUT_MIME_REPX : undefined,
        });
        setLoading(false);
        if (createResult.kind !== 'ok') {
          setErrorKey(
            createResult.kind === 'envelopeError'
              ? `emission.error.${createResult.envelope.error}`
              : 'emission.design.saveAsFailed'
          );
          return;
        }
        const created = createResult.envelope.resultado.item;
        setReports((prev) => {
          const without = prev.filter((item) => item.code !== created.code && item.id !== created.id);
          return [...without, created];
        });
        setSelectedReportId(created.id);
        setErrorKey(null);
        return;
      }

      if (selectedReportId === null || !event.layoutDefinition) {
        return;
      }

      const updateResult = await updateEmissionReportLayout(selectedReportId, {
        layoutDefinition: event.layoutDefinition,
        layoutMime: LAYOUT_MIME_REPX,
      });
      if (updateResult.kind !== 'ok') {
        setErrorKey(
          updateResult.kind === 'envelopeError'
            ? `emission.error.${updateResult.envelope.error}`
            : 'emission.error.transport'
        );
      }
    },
    [confirmedProcessCode, reports, selectedReportId]
  );

  if (isNative) {
    return (
      <div
        data-testid="emission.design.excludedNative"
        data-i18n-key="emission.design.mobileExcluded"
      >
        {translate('emission.design.mobileExcluded')}
      </div>
    );
  }

  if (!hasDesignPermission) {
    return (
      <div data-testid="emission.design.forbidden" data-i18n-key="emission.design.forbidden">
        {translate('emission.design.forbidden')}
      </div>
    );
  }

  const processConfirmed = canShowDesignerChrome(confirmedProcessCode);
  const designerReady = canMountDesignerHost(confirmedProcessCode, reportCatalogReady);
  const endpoint =
    designerEndpoint ??
    (confirmedProcessCode
      ? `/api/v1/emissions/design/processes/${encodeURIComponent(confirmedProcessCode)}/reports`
      : '');

  const selectedReport = reports.find((item) => item.id === selectedReportId) ?? null;

  const context: ReportDesignerContext = {
    reportId: selectedReportId,
    processCode: confirmedProcessCode ?? '',
    designerEndpoint: endpoint,
    reportCode: catalogEmissionReportCode(selectedReport?.code) || null,
    knownReportCodes: reports.map((item) => catalogEmissionReportCode(item.code)),
    onDxReportSaved: handleDxReportSaved,
  };

  const openNotificationAdmin = () => {
    const path = NOTIFICATION_SERVICE_ADMIN_PATH;
    if (navigate) {
      navigate(path);
      return;
    }
    if (typeof window !== 'undefined') {
      window.location.assign(path);
    }
  };

  const markPrincipal = () => {
    if (selectedReportId === null) {
      return;
    }
    void setEmissionReportPrincipal(selectedReportId).then((result) => {
      if (result.kind !== 'ok') {
        setErrorKey(
          result.kind === 'envelopeError'
            ? `emission.error.${result.envelope.error}`
            : 'emission.error.transport'
        );
        return;
      }
      setReports((prev) =>
        prev.map((item) => ({
          ...item,
          isPrincipal: item.id === selectedReportId,
        }))
      );
    });
  };

  const resolvedRenderDesigner =
    renderDesigner ??
    (designerMode === 'dx'
      ? (designerContext: ReportDesignerContext) => (
          <div
            data-testid="emission.design.dxHostRequired"
            data-i18n-key="emission.design.dxHostRequired"
          >
            {translate('emission.design.dxHostRequired')}
            <span data-testid="emission.design.dxEndpoint">{designerContext.designerEndpoint}</span>
          </div>
        )
      : undefined);

  const showEmptyCatalog = !loading && processItems.length === 0 && errorKey === null;

  return (
    <div data-testid="emission.design.page" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <LoadPanel
        visible={loading}
        shading={false}
        position={{ of: '[data-testid="emission.design.page"]' }}
      />
      <div
        data-testid="emission.design.toolbar"
        style={{
          display: 'flex',
          gap: 8,
          flexWrap: 'wrap',
          alignItems: 'center',
          position: 'sticky',
          top: 0,
          zIndex: 20,
          background: 'var(--dx-color-main-bg, #fff)',
          paddingBottom: 8,
        }}
      >
        <SelectBox
          items={processItems}
          valueExpr="processCode"
          displayExpr="name"
          value={selectedProcessCode}
          placeholder={designLabel(translate, 'emission.design.selectProcess')}
          onValueChanged={(event) => {
            const nextValue = (event.value as string) ?? null;
            setSelectedProcessCode(nextValue);
            const nextConfirmed = nextConfirmedAfterProcessChange(confirmedProcessCode, nextValue);
            if (nextConfirmed === confirmedProcessCode) {
              return;
            }
            setConfirmedProcessCode(null);
            setReports([]);
            setSelectedReportId(null);
            setReportCatalogReady(false);
          }}
          elementAttr={{ 'data-testid': 'emission.design.process' }}
          width={280}
        />
        <Button
          text={designLabel(translate, 'emission.design.confirmProcess')}
          disabled={!selectedProcessCode}
          onClick={() => {
            setConfirmedProcessCode(confirmSelectedProcess(selectedProcessCode));
          }}
          elementAttr={{ 'data-testid': 'emission.design.confirmProcess' }}
        />
        {processConfirmed ? (
          <Button
            text={designLabel(translate, 'emission.design.closeDesigner')}
            type="default"
            stylingMode="contained"
            onClick={() => {
              setConfirmedProcessCode(null);
              setReports([]);
              setSelectedReportId(null);
              setReportCatalogReady(false);
              setErrorKey(null);
            }}
            elementAttr={{ 'data-testid': 'emission.design.closeDesigner' }}
          />
        ) : null}
        {designerReady ? (
          <>
            <SelectBox
              items={reports}
              valueExpr="id"
              displayExpr="name"
              value={selectedReportId}
              onValueChanged={(event) => setSelectedReportId((event.value as number) ?? null)}
              elementAttr={{ 'data-testid': 'emission.design.report' }}
              width={280}
            />
            <Button
              text={designLabel(translate, 'emission.design.setPrincipal')}
              disabled={selectedReportId === null}
              onClick={markPrincipal}
              elementAttr={{ 'data-testid': 'emission.design.setPrincipal' }}
            />
          </>
        ) : null}
        {hasNotificationServiceAdmin ? (
          <Button
            text={translate('emission.design.openNotificationAdmin')}
            stylingMode="outlined"
            onClick={openNotificationAdmin}
            elementAttr={{ 'data-testid': 'emission.design.openNotificationAdmin' }}
          />
        ) : null}
      </div>

      {showEmptyCatalog ? (
        <p data-testid="emission.design.noProcesses" data-i18n-key="emission.design.noProcesses">
          {translate('emission.design.noProcesses')}
        </p>
      ) : null}

      {errorKey ? (
        <p data-i18n-key={errorKey}>{designLabel(translate, errorKey)}</p>
      ) : null}

      {designerReady ? (
        <>
          <p
            data-testid="emission.design.engineHint"
            data-i18n-key={designerMode === 'dx' ? 'emission.design.dxHint' : 'emission.design.fakeHint'}
          >
            {designerMode === 'dx'
              ? designLabel(translate, 'emission.design.dxHint')
              : designLabel(translate, 'emission.design.fakeHint')}
          </p>
          <EmissionDesignerHostErrorBoundary
            resetKey={confirmedProcessCode}
            fallbackLabel={designLabel(translate, 'emission.design.hostCrash')}
          >
            <ReportDesignerHost
              context={context}
              isNative={false}
              renderDesigner={resolvedRenderDesigner}
              t={translate}
            />
          </EmissionDesignerHostErrorBoundary>
        </>
      ) : null}
    </div>
  );
}
