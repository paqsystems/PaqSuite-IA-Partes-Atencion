import type {
  EmissionCompletePayload,
  EmissionDocumentaryChannel,
  EmissionJobDto,
  EmissionOutputPolicy,
  EmissionOutputPolicyItem,
  EmissionProcessDto,
  PreviewInputs,
} from './types';
import { isDocumentaryChannel } from './types';

/** Canales documentales en mobile (rama corta). Sin print/zip; sin mail. */
export const mobileEmissionChannels: EmissionDocumentaryChannel[] = ['pdf', 'excel'];

/** Filtra canales documentales del proceso según plataforma. */
export function resolveAvailableChannels(
  process: Pick<EmissionProcessDto, 'channels' | 'outputPolicy'>,
  isNative: boolean
): string[] {
  const fromPolicy = documentaryOutputs(process.outputPolicy).map((item) => item.channel);
  const base = fromPolicy.length > 0 ? fromPolicy : process.channels.filter(isDocumentaryChannel);
  if (!isNative) {
    return base;
  }
  return base.filter((channel) => (mobileEmissionChannels as string[]).includes(channel));
}

export function documentaryOutputs(policy: EmissionOutputPolicy): EmissionOutputPolicyItem[] {
  return policy.outputs.filter((item) => item.kind === 'documentary');
}

export function communicationOutputs(policy: EmissionOutputPolicy): EmissionOutputPolicyItem[] {
  return policy.outputs.filter((item) => item.kind === 'communication');
}

/** INTERACTIVE / HYBRID abren ventana; AUTOMATIC / MANDATORY pueden omitirla. */
export function shouldOpenEmissionDialog(policy: EmissionOutputPolicy): boolean {
  return policy.mode === 'INTERACTIVE' || policy.mode === 'HYBRID';
}

/** El preview solo aplica en desktop y cuando el proceso lo requiere. */
export function shouldOfferPreview(
  process: Pick<EmissionProcessDto, 'requiresPreview'>,
  isNative: boolean
): boolean {
  return !isNative && process.requiresPreview;
}

/**
 * Preview vigente: cualquier cambio de reporte/modo/grupo/canal lo invalida.
 */
export function isPreviewStale(previous: PreviewInputs | null, current: PreviewInputs): boolean {
  if (!previous) {
    return true;
  }
  return (
    previous.reportId !== current.reportId ||
    previous.mode !== current.mode ||
    (previous.groupId ?? null) !== (current.groupId ?? null) ||
    previous.channel !== current.channel
  );
}

/** Habilita Emitir: al menos un canal documental seleccionado. */
export function canEmit(input: {
  channels: string[];
  mode: string;
  groupId?: string | null;
  requiresPreview?: boolean;
  hasValidPreview?: boolean;
  isNative?: boolean;
}): boolean {
  if (input.channels.length === 0) {
    return false;
  }
  if (input.mode === 'segmented' && !input.groupId) {
    return false;
  }
  if (input.requiresPreview && !input.isNative && !input.hasValidPreview) {
    return false;
  }
  return true;
}

/** Estados terminales que disparan `onComplete` (incl. failedCommunication). */
export function isTerminalJob(status: string): boolean {
  return (
    status === 'done' ||
    status === 'failed' ||
    status === 'failedCommunication' ||
    status === 'queued'
  );
}

export function buildEmissionCompletePayload(job: EmissionJobDto): EmissionCompletePayload {
  const status =
    job.status === 'done' ||
    job.status === 'failed' ||
    job.status === 'failedCommunication' ||
    job.status === 'queued'
      ? job.status
      : 'queued';

  const payload: EmissionCompletePayload = {
    jobId: job.jobId,
    processCode: job.processCode,
    status,
    outputCode: job.channel,
    mode: job.mode,
    fileName: job.fileName,
  };

  if (job.notificationId) {
    payload.notificationIds = [job.notificationId];
  }

  return payload;
}

/** Destinatarios: ADD_ONLY no permite quitar sugeridos fijados. */
export function mergeRecipientsAddOnly(
  fixed: string[],
  proposed: string[]
): string[] {
  const extras = proposed.filter((address) => !fixed.includes(address));
  return [...fixed, ...extras];
}
