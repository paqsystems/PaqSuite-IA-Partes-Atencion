import type { ReactNode } from 'react';

/** Evento DX ReportSaved / Save As bridged desde el host. */
export type DxReportSavedEvent = {
  /** URL/código con el que DX persistió el layout (reportUrl). */
  url: string;
  /** Layout serializado (REPX XML) si el host pudo leerlo. */
  layoutDefinition?: string;
  /** true si el url no estaba en el catálogo conocido del proceso. */
  isNew: boolean;
};

export type ReportDesignerContext = {
  reportId: number | null;
  processCode: string;
  /** URL del endpoint backend del diseñador (host DevExpress Reporting). */
  designerEndpoint: string;
  /** Código de storage DX del reporte seleccionado. */
  reportCode?: string | null;
  /** Códigos ya dados de alta en el proceso (para detectar Save As). */
  knownReportCodes?: string[];
  /**
   * Host DX: notifica Save / Save As. El Framework crea o actualiza el catálogo GEN
   * y refresca el SelectBox de reportes.
   */
  onDxReportSaved?: (event: DxReportSavedEvent) => void | Promise<void>;
};

export type ReportDesignerHostProps = {
  context: ReportDesignerContext;
  /** Excluido en native (C1-15-19 / CA-02): el diseñador no se monta en mobile. */
  isNative?: boolean;
  /**
   * Render prop para inyectar el diseñador real. `@paqsuite/react-core` no
   * declara la dependencia pesada del diseñador (DevExpress Reporting): el host
   * la provee. Si no se inyecta, se muestra un placeholder (Fake Fase A).
   */
  renderDesigner?: (context: ReportDesignerContext) => ReactNode;
  fallback?: ReactNode;
  t?: (key: string) => string;
};

/**
 * Wrapper bajo nivel del diseñador. Preferir `EmissionReportDesignerPage` (export canónico).
 */
export function ReportDesignerHost({
  context,
  isNative = false,
  renderDesigner,
  fallback,
  t,
}: ReportDesignerHostProps) {
  const translate = t ?? ((key: string) => key);

  if (isNative) {
    return (
      <div
        data-testid="emission.design.excludedNative"
        data-i18n-key="emission.design.mobileExcluded"
      >
        {translate('emission.design.mobileExcluded')}
      </div>
    );
  }

  if (!renderDesigner) {
    return (
      <div data-testid="emission.design.placeholder">
        {fallback ?? translate('emission.design.notConfigured')}
      </div>
    );
  }

  return (
    <div data-testid="emission.design.host" style={{ width: '100%', height: '100%' }}>
      {renderDesigner(context)}
    </div>
  );
}
