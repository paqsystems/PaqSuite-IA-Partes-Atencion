import { apiRequest, type ApiClientResult, type ApiRequestOptions } from '../../http/apiClient';

export const notificationServiceBasePath = '/api/v1/notification-service';

type RequestOverrides = Pick<ApiRequestOptions, 'platform' | 'signal' | 'headers'>;

export function listNotificationTypes(options: RequestOverrides = {}) {
  return apiRequest<{ items: Array<Record<string, unknown>> }>(`${notificationServiceBasePath}/types`, {
    method: 'GET',
    ...options,
  });
}

export function listNotificationTemplates(options: RequestOverrides = {}) {
  return apiRequest<{ items: Array<Record<string, unknown>> }>(
    `${notificationServiceBasePath}/templates`,
    { method: 'GET', ...options }
  );
}

export function listNotificationGroups(options: RequestOverrides = {}) {
  return apiRequest<{ items: Array<Record<string, unknown>> }>(
    `${notificationServiceBasePath}/recipient-groups`,
    { method: 'GET', ...options }
  );
}

export function listNotificationSuppressions(options: RequestOverrides = {}) {
  return apiRequest<{ items: Array<Record<string, unknown>> }>(
    `${notificationServiceBasePath}/suppressions`,
    { method: 'GET', ...options }
  );
}

export function listNotificationChannels(options: RequestOverrides = {}) {
  return apiRequest<{ items: Array<Record<string, unknown>> }>(
    `${notificationServiceBasePath}/channels`,
    { method: 'GET', ...options }
  );
}

export function listNotifications(options: RequestOverrides = {}) {
  return apiRequest<{ items: Array<Record<string, unknown>>; page: number; pageSize: number; total: number }>(
    `${notificationServiceBasePath}/notifications`,
    { method: 'GET', ...options }
  );
}

export function getNotificationConsumption(
  from: string,
  to: string,
  options: RequestOverrides = {}
): Promise<ApiClientResult<{ tenantId: string; estimatedCost: number | null; actualCost: number | null }>> {
  const query = new URLSearchParams({ from, to }).toString();
  return apiRequest(`${notificationServiceBasePath}/consumption?${query}`, {
    method: 'GET',
    ...options,
  });
}

export function cancelNotification(notificationId: string, options: RequestOverrides = {}) {
  return apiRequest<Record<string, unknown>>(
    `${notificationServiceBasePath}/notifications/${notificationId}/cancel`,
    { method: 'POST', ...options }
  );
}

export function retryNotificationDelivery(deliveryId: string, options: RequestOverrides = {}) {
  return apiRequest<Record<string, unknown>>(
    `${notificationServiceBasePath}/deliveries/${deliveryId}/retry`,
    { method: 'POST', ...options }
  );
}

export function resendNotification(notificationId: string, options: RequestOverrides = {}) {
  return apiRequest<Record<string, unknown>>(
    `${notificationServiceBasePath}/notifications/${notificationId}/resend`,
    { method: 'POST', ...options }
  );
}
