import { useCallback, useEffect, useState } from 'react';
import DataGrid, { Column, Paging, Pager } from 'devextreme-react/data-grid';
import Button from 'devextreme-react/button';
import {
  cancelNotification,
  getNotificationConsumption,
  listNotifications,
  resendNotification,
  retryNotificationDelivery,
} from './notificationServiceApi';

export type NotificationServiceMonitorPageProps = {
  t?: (key: string) => string;
};

export function NotificationServiceMonitorPage({ t }: NotificationServiceMonitorPageProps) {
  const translate = t ?? ((key: string) => key);
  const [rows, setRows] = useState<Array<Record<string, unknown>>>([]);
  const [estimatedCost, setEstimatedCost] = useState<number | null>(null);
  const [actualCost, setActualCost] = useState<number | null>(null);

  const load = useCallback(async () => {
    const list = await listNotifications();
    if (list.kind === 'ok') {
      setRows(list.envelope.resultado.items ?? []);
    }
    const to = new Date().toISOString();
    const from = new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString();
    const consumption = await getNotificationConsumption(from, to);
    if (consumption.kind === 'ok') {
      setEstimatedCost(consumption.envelope.resultado.estimatedCost);
      setActualCost(consumption.envelope.resultado.actualCost);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div data-testid="notificationService.monitor.root">
      <h2>{translate('notificationService.monitor.title')}</h2>
      <div style={{ display: 'flex', gap: 24, marginBottom: 12 }}>
        <div data-testid="notificationService.monitor.estimatedCost">
          {translate('notificationService.monitor.estimatedCost')}: {estimatedCost ?? '—'}
        </div>
        <div data-testid="notificationService.monitor.actualCost">
          {translate('notificationService.monitor.actualCost')}: {actualCost ?? '—'}
        </div>
      </div>
      <DataGrid dataSource={rows} keyExpr="notificationId" showBorders>
        <Paging defaultPageSize={20} />
        <Pager visible />
        <Column dataField="notificationId" />
        <Column dataField="typeCode" />
        <Column dataField="status" />
        <Column dataField="estimatedCost" />
        <Column dataField="actualCost" />
        <Column
          type="buttons"
          width={180}
          buttons={[
            {
              hint: translate('notificationService.monitor.cancel'),
              icon: 'close',
              onClick: (e) => {
                const id = String((e.row?.data as { notificationId: string }).notificationId);
                void cancelNotification(id).then(() => load());
              },
              elementAttr: { 'data-testid': 'notificationService.monitor.cancel' },
            },
            {
              hint: translate('notificationService.monitor.retry'),
              icon: 'refresh',
              onClick: (e) => {
                const deliveries = (e.row?.data as { deliveries?: Array<{ deliveryId: string }> }).deliveries;
                const deliveryId = deliveries?.[0]?.deliveryId;
                if (deliveryId) {
                  void retryNotificationDelivery(deliveryId).then(() => load());
                }
              },
              elementAttr: { 'data-testid': 'notificationService.monitor.retry' },
            },
            {
              hint: translate('notificationService.monitor.resend'),
              icon: 'message',
              onClick: (e) => {
                const id = String((e.row?.data as { notificationId: string }).notificationId);
                void resendNotification(id).then(() => load());
              },
              elementAttr: { 'data-testid': 'notificationService.monitor.resend' },
            },
          ]}
        />
      </DataGrid>
      <Button visible={false} elementAttr={{ 'data-testid': 'notificationService.monitor.retry' }} />
    </div>
  );
}
