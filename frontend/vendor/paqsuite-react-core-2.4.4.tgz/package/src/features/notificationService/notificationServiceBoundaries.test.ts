import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';

const here = dirname(fileURLToPath(import.meta.url));

function read(relativePath: string): string {
  return readFileSync(resolve(here, relativePath), 'utf8');
}

describe('Notification Service FE boundaries (GEN-30 E)', () => {
  it('no exporta bandeja 30 ni helper de polling', () => {
    const index = read('../../index.ts');
    expect(index).toContain('NotificationServiceAdminPage');
    expect(index).toContain('NotificationServiceMonitorPage');
    expect(index).not.toMatch(/NotificationServiceInbox/);
    expect(index).not.toMatch(/waitUntilDelivered/);
  });

  it('Admin tiene testid raíz y save, y no pide secrets AWS', () => {
    const admin = read('./NotificationServiceAdminPage.tsx');
    expect(admin).toContain('data-testid="notificationService.admin.root"');
    expect(admin).toContain('notificationService.admin.save');
    expect(admin.toLowerCase()).not.toContain('secretaccesskey');
    expect(admin.toLowerCase()).not.toContain('aws_secret');
    expect(admin.toLowerCase()).not.toContain('accesskeyid');
  });

  it('Monitor separa estimatedCost de actualCost', () => {
    const monitor = read('./NotificationServiceMonitorPage.tsx');
    expect(monitor).toContain('data-testid="notificationService.monitor.estimatedCost"');
    expect(monitor).toContain('data-testid="notificationService.monitor.actualCost"');
    expect(monitor).not.toMatch(/setActualCost\(.*estimatedCost/);
  });
});
