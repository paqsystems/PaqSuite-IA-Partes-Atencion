import { useCallback, useEffect, useState } from 'react';
import DataGrid, { Column, Paging, Pager } from 'devextreme-react/data-grid';
import TabPanel, { Item } from 'devextreme-react/tab-panel';
import Button from 'devextreme-react/button';
import {
  listNotificationChannels,
  listNotificationGroups,
  listNotificationSuppressions,
  listNotificationTemplates,
  listNotificationTypes,
} from './notificationServiceApi';

const PURPOSE_ROWS = [
  { purpose: 'security' },
  { purpose: 'transactional' },
  { purpose: 'operational' },
  { purpose: 'informational' },
  { purpose: 'commercial' },
];

const LANGUAGE_ROWS = [
  { locale: 'es' },
  { locale: 'en' },
  { locale: 'pt' },
  { locale: 'fr' },
  { locale: 'it' },
];

export type NotificationServiceAdminPageProps = {
  t?: (key: string) => string;
};

export function NotificationServiceAdminPage({ t }: NotificationServiceAdminPageProps) {
  const translate = t ?? ((key: string) => key);
  const [types, setTypes] = useState<Array<Record<string, unknown>>>([]);
  const [templates, setTemplates] = useState<Array<Record<string, unknown>>>([]);
  const [groups, setGroups] = useState<Array<Record<string, unknown>>>([]);
  const [suppressions, setSuppressions] = useState<Array<Record<string, unknown>>>([]);
  const [channels, setChannels] = useState<Array<Record<string, unknown>>>([]);

  const load = useCallback(async () => {
    const [typesResult, templatesResult, groupsResult, suppressionsResult, channelsResult] = await Promise.all([
      listNotificationTypes(),
      listNotificationTemplates(),
      listNotificationGroups(),
      listNotificationSuppressions(),
      listNotificationChannels(),
    ]);
    if (typesResult.kind === 'ok') setTypes(typesResult.envelope.resultado.items ?? []);
    if (templatesResult.kind === 'ok') setTemplates(templatesResult.envelope.resultado.items ?? []);
    if (groupsResult.kind === 'ok') setGroups(groupsResult.envelope.resultado.items ?? []);
    if (suppressionsResult.kind === 'ok') setSuppressions(suppressionsResult.envelope.resultado.items ?? []);
    if (channelsResult.kind === 'ok') setChannels(channelsResult.envelope.resultado.items ?? []);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div data-testid="notificationService.admin.root">
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
        <h2 style={{ margin: 0, flex: 1 }}>{translate('notificationService.admin.title')}</h2>
        <Button
          text={translate('notificationService.admin.save')}
          type="default"
          onClick={() => undefined}
          elementAttr={{ 'data-testid': 'notificationService.admin.save' }}
        />
      </div>
      <TabPanel>
        <Item title={translate('notificationService.admin.types')}>
          <DataGrid dataSource={types} keyExpr="typeCode" showBorders>
            <Paging defaultPageSize={20} />
            <Pager visible />
            <Column dataField="typeCode" caption={translate('notificationService.admin.typeCode')} />
            <Column dataField="purpose" caption={translate('notificationService.admin.purpose')} />
            <Column dataField="resolverMode" caption={translate('notificationService.admin.resolverMode')} />
          </DataGrid>
        </Item>
        <Item title={translate('notificationService.admin.templates')}>
          <DataGrid dataSource={templates} keyExpr="templateId" showBorders>
            <Paging defaultPageSize={20} />
            <Column dataField="typeCode" />
            <Column dataField="channelCode" />
            <Column dataField="sourceLevel" caption={translate('notificationService.admin.sourceLevel')} />
            <Column dataField="status" />
          </DataGrid>
        </Item>
        <Item title={translate('notificationService.admin.groups')}>
          <DataGrid dataSource={groups} keyExpr="groupId" showBorders>
            <Column dataField="groupCode" />
            <Column dataField="groupId" />
          </DataGrid>
        </Item>
        <Item title={translate('notificationService.admin.suppressions')}>
          <DataGrid dataSource={suppressions} keyExpr="suppressionId" showBorders>
            <Column dataField="channelCode" />
            <Column dataField="address" />
            <Column dataField="purpose" />
          </DataGrid>
        </Item>
        <Item title={translate('notificationService.admin.channels')}>
          <DataGrid dataSource={channels} keyExpr="channelCode" showBorders>
            <Column dataField="channelCode" />
            <Column dataField="modeled" />
            <Column dataField="executable" />
          </DataGrid>
        </Item>
        <Item title={translate('notificationService.admin.policies')}>
          <DataGrid dataSource={PURPOSE_ROWS} keyExpr="purpose" showBorders>
            <Column dataField="purpose" caption={translate('notificationService.admin.purpose')} />
          </DataGrid>
        </Item>
        <Item title={translate('notificationService.admin.languages')}>
          <p>{translate('notificationService.admin.languagesHint')}</p>
          <DataGrid dataSource={LANGUAGE_ROWS} keyExpr="locale" showBorders>
            <Column dataField="locale" caption={translate('notificationService.admin.locale')} />
          </DataGrid>
        </Item>
      </TabPanel>
    </div>
  );
}
