import type { ParametroListItem } from './types';

export function parametroCaptionI18nKey(programa: string, clave: string): string {
  return `parametros.${programa}.${clave}.caption`;
}

export function parametroTooltipI18nKey(programa: string, clave: string): string {
  return `parametros.${programa}.${clave}.tooltip`;
}

/** Valor textual / enum: `parametros.{programa}.{clave}.value.{raw}` (caso excepcional GEN-10). */
export function parametroTextValorI18nKey(
  programa: string,
  clave: string,
  rawValor: string,
): string {
  return `parametros.${programa}.${clave}.value.${rawValor}`;
}

function translateOrFallback(key: string, fallback: string, t: (key: string) => string): string {
  const translated = t(key);
  return translated !== key && translated.trim() !== '' ? translated : fallback;
}

/**
 * Caption i18n `parametros.{programa}.{clave}.caption` con fallback al CAPTION de API (SPEC-001-02 / GEN-10).
 */
export function resolveParametroCaption(
  item: Pick<ParametroListItem, 'programa' | 'clave' | 'caption'>,
  t: (key: string) => string,
): string {
  return translateOrFallback(
    parametroCaptionI18nKey(item.programa, item.clave),
    item.caption,
    t,
  );
}

/**
 * Tooltip i18n `parametros.{programa}.{clave}.tooltip` con fallback al TOOLTIP de API.
 */
export function resolveParametroTooltip(
  item: Pick<ParametroListItem, 'programa' | 'clave' | 'tooltip'>,
  t: (key: string) => string,
): string | null {
  const key = parametroTooltipI18nKey(item.programa, item.clave);
  const translated = t(key);
  if (translated !== key && translated.trim() !== '') {
    return translated;
  }
  const fallback = item.tooltip?.trim() ?? '';
  return fallback.length > 0 ? fallback : null;
}

/**
 * Texto de un valor `S` (incl. enum): i18n por clave+valor con fallback al raw persistido.
 * El valor enviado al PATCH sigue siendo el código/raw, no el label.
 */
export function resolveParametroTextValor(
  programa: string,
  clave: string,
  rawValor: string,
  t: (key: string) => string,
): string {
  return translateOrFallback(
    parametroTextValorI18nKey(programa, clave, rawValor),
    rawValor,
    t,
  );
}

export function formatParametroValorDisplay(
  valor: string | number | boolean | null | undefined,
  tipoValor: string,
  t: (key: string) => string,
  item?: Pick<ParametroListItem, 'programa' | 'clave'> | null,
): string {
  if (tipoValor === 'B') {
    return valor === true ? t('parametros.value.yes') : t('parametros.value.no');
  }
  if (valor === null || valor === undefined || valor === '') {
    return t('parametros.value.empty');
  }
  if (tipoValor === 'S' && item && typeof valor === 'string') {
    return resolveParametroTextValor(item.programa, item.clave, valor, t);
  }
  return String(valor);
}

export function mapEnvelopeErrorToI18nKey(respuesta: string | undefined): string {
  switch (respuesta) {
    case 'parametros.validationFailed':
      return 'parametros.modal.error.validationFailed';
    case 'parametros.notFound':
      return 'parametros.modal.error.notFound';
    case 'parametros.tipoValorUnsupported':
      return 'parametros.modal.error.tipoValorUnsupported';
    case 'parametros.valorTipoMismatch':
      return 'parametros.modal.error.valorTipoMismatch';
    case 'parametros.enumInvalid':
      return 'parametros.modal.error.enumInvalid';
    default:
      return 'parametros.modal.error.validationFailed';
  }
}
