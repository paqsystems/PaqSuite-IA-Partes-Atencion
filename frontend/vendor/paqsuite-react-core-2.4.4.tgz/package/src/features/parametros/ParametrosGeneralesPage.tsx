import { useCallback, useEffect, useMemo, useState } from 'react';
import DataGrid, { Column, FilterRow, Paging, Sorting } from 'devextreme-react/data-grid';
import Button from 'devextreme-react/button';
import type { BuildPlatformHeadersInput } from '../../http/headers';
import { processClassNames } from '../../ui/tokens';
import { listParametros } from './parametrosApi';
import {
  formatParametroValorDisplay,
  resolveParametroCaption,
  resolveParametroTooltip,
} from './parametroDisplay';
import { ParametroEditPopup } from './ParametroEditPopup';
import type { ParametroListItem } from './types';

export type ParametrosGeneralesPageProps = {
  programa: string;
  t?: (key: string) => string;
  platform?: BuildPlatformHeadersInput;
  accessToken?: string | null;
};

type ParametroDisplayRow = ParametroListItem & {
  captionDisplay: string;
  tooltipDisplay: string | null;
  valorDisplay: string;
};

/**
 * ABM desktop de parámetros GEN (listado + modal tipado). Excluido de Capacitor.
 */
export function ParametrosGeneralesPage({
  programa: programaProp,
  t,
  platform,
  accessToken,
}: ParametrosGeneralesPageProps) {
  const programa = programaProp.trim();
  const translate = t ?? ((key: string) => key);

  const [rows, setRows] = useState<ParametroListItem[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState<ParametroListItem | null>(null);

  const requestOptions = useMemo(
    () => ({
      platform,
      headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : undefined,
    }),
    [accessToken, platform],
  );

  const load = useCallback(async () => {
    if (!programa) {
      setRows([]);
      return;
    }
    setLoading(true);
    setLoadError(null);
    try {
      const result = await listParametros(programa, requestOptions);
      if (result.kind === 'ok') {
        setRows(result.envelope.resultado.items ?? []);
      } else if (result.kind === 'envelopeError') {
        setLoadError(result.envelope.respuesta || 'parametros.loadError');
        setRows([]);
      } else {
        setLoadError(result.i18nKey || 'parametros.loadError');
        setRows([]);
      }
    } finally {
      setLoading(false);
    }
  }, [programa, requestOptions]);

  useEffect(() => {
    void load();
  }, [load]);

  const gridId = useMemo(() => `parametros.${programa || 'unknown'}`, [programa]);

  const displayRows = useMemo((): ParametroDisplayRow[] => {
    const mapped = rows.map((row) => ({
      ...row,
      captionDisplay: resolveParametroCaption(row, translate),
      tooltipDisplay: resolveParametroTooltip(row, translate),
      valorDisplay: formatParametroValorDisplay(row.valor, row.tipoValor, translate, row),
    }));
    mapped.sort((a, b) =>
      a.captionDisplay.localeCompare(b.captionDisplay, undefined, { sensitivity: 'base' }),
    );
    return mapped;
  }, [rows, translate]);

  return (
    <section className={processClassNames.page} data-testid="parametros.root">
      <div className={processClassNames.header}>
        <div>
          <h1 className={processClassNames.title}>{translate('parametros.title')}</h1>
          <p className="pqProcessSubtitle">{translate('parametros.subtitle')}</p>
        </div>
        <div className={processClassNames.toolbar} data-testid="parametros.refresh">
          <Button
            text={translate('parametros.list.refresh')}
            icon="refresh"
            stylingMode="outlined"
            disabled={loading}
            onClick={() => void load()}
          />
        </div>
      </div>

      {loadError ? (
        <div role="alert" className="pqProcessAlert">
          {translate(loadError)}
        </div>
      ) : null}

      <div
        className={`${processClassNames.content} pqParametrosGrid`}
        data-testid="parametros.grid"
        data-grid-id={gridId}
      >
        <DataGrid
          dataSource={displayRows}
          keyExpr="clave"
          showBorders
          hoverStateEnabled
          columnAutoWidth={false}
          wordWrapEnabled
          rowAlternationEnabled
          noDataText={translate('parametros.empty')}
          height="100%"
        >
          <FilterRow visible />
          <Sorting mode="multiple" />
          <Paging enabled={false} />
          <Column
            dataField="captionDisplay"
            caption={translate('parametros.list.parametro')}
            defaultSortOrder="asc"
            minWidth={280}
            width="55%"
            cellRender={(cell) => {
              const row = cell.data as ParametroDisplayRow;
              return (
                <div className="pqParametrosCaptionCell">
                  <span className="pqParametrosCaptionText">{row.captionDisplay}</span>
                  {row.tooltipDisplay ? (
                    <span className="pqParametrosCaptionHint">{row.tooltipDisplay}</span>
                  ) : null}
                </div>
              );
            }}
          />
          <Column
            dataField="valorDisplay"
            caption={translate('parametros.list.valor')}
            allowSorting={false}
            minWidth={140}
            width="30%"
          />
          <Column
            type="buttons"
            caption={translate('parametros.list.accion')}
            width={96}
            buttons={[
              {
                hint: translate('parametros.modal.title'),
                icon: 'edit',
                onClick: (e) => {
                  const row = e.row?.data as ParametroListItem;
                  setEditing(row);
                },
                elementAttr: { 'data-testid': 'parametros.edit' },
              },
            ]}
          />
        </DataGrid>
      </div>

      {editing ? (
        <ParametroEditPopup
          visible
          item={editing}
          requestOptions={requestOptions}
          onCancel={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            void load();
          }}
          t={translate}
        />
      ) : null}
    </section>
  );
}
