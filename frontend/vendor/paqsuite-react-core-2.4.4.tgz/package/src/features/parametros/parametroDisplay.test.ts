import { describe, expect, it } from 'vitest';
import {
  formatParametroValorDisplay,
  mapEnvelopeErrorToI18nKey,
  resolveParametroCaption,
  resolveParametroTextValor,
  resolveParametroTooltip,
} from './parametroDisplay';

const t = (key: string) => {
  const catalog: Record<string, string> = {
    'parametros.value.yes': 'Sí',
    'parametros.value.no': 'No',
    'parametros.value.empty': '—',
    'parametros.Partes.PartesDuracionTramoMin.caption': 'Slot duration (minutes)',
    'parametros.Partes.PartesDuracionTramoMin.tooltip': 'Minimum duration multiple',
    'parametros.Auth.PasswordComplejidad.value.segura': 'secure',
    'parametros.Auth.PasswordComplejidad.value.simple': 'simple',
  };
  return catalog[key] ?? key;
};

describe('formatParametroValorDisplay', () => {
  it('bool null/false → No; true → Sí', () => {
    expect(formatParametroValorDisplay(null, 'B', t)).toBe('No');
    expect(formatParametroValorDisplay(false, 'B', t)).toBe('No');
    expect(formatParametroValorDisplay(true, 'B', t)).toBe('Sí');
  });

  it('null no-bool → empty dash', () => {
    expect(formatParametroValorDisplay(null, 'S', t)).toBe('—');
    expect(formatParametroValorDisplay(null, 'I', t)).toBe('—');
  });

  it('texto/enum S usa i18n de valor', () => {
    expect(
      formatParametroValorDisplay('segura', 'S', t, {
        programa: 'Auth',
        clave: 'PasswordComplejidad',
      }),
    ).toBe('secure');
  });
});

describe('mapEnvelopeErrorToI18nKey', () => {
  it('mapea claves de capacidad', () => {
    expect(mapEnvelopeErrorToI18nKey('parametros.enumInvalid')).toBe(
      'parametros.modal.error.enumInvalid',
    );
    expect(mapEnvelopeErrorToI18nKey('parametros.notFound')).toBe('parametros.modal.error.notFound');
  });
});

describe('resolveParametroCaption / tooltip / text valor', () => {
  const item = {
    programa: 'Partes',
    clave: 'PartesDuracionTramoMin',
    caption: 'Duración tramo (minutos)',
    tooltip: 'Fallback API tooltip',
  };

  it('usa i18n cuando existe y fallback a API', () => {
    expect(resolveParametroCaption(item, t)).toBe('Slot duration (minutes)');
    expect(resolveParametroTooltip(item, t)).toBe('Minimum duration multiple');
    expect(
      resolveParametroCaption(
        { programa: 'Auth', clave: 'MinutosWeb', caption: 'Inactividad web (minutos)' },
        t,
      ),
    ).toBe('Inactividad web (minutos)');
    expect(resolveParametroTextValor('Auth', 'PasswordComplejidad', 'segura', t)).toBe('secure');
    expect(resolveParametroTextValor('Auth', 'PasswordComplejidad', 'otro', t)).toBe('otro');
  });
});
