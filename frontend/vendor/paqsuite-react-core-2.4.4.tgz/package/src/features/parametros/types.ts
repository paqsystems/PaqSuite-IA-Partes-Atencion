export type ParametroTipoValor = 'S' | 'T' | 'I' | 'D' | 'B' | 'F';

export type ParametroListItem = {
  programa: string;
  clave: string;
  tipoValor: ParametroTipoValor;
  valor: string | number | boolean | null;
  caption: string;
  tooltip: string | null;
  precisionFecha?: 'date' | 'datetime';
  meta?: { enum?: string[] };
};

export type ParametroPatchBody = {
  programa: string;
  valor: string | number | boolean | null;
};
