import { apiRequest, type ApiClientResult, type ApiRequestOptions } from '../../http/apiClient';
import type { ParametroListItem, ParametroPatchBody } from './types';

export const parametrosBasePath = '/api/v1/parametros';

export type RequestOverrides = Pick<ApiRequestOptions, 'platform' | 'signal' | 'headers'>;

export function listParametros(
  programa: string,
  options: RequestOverrides = {}
): Promise<ApiClientResult<{ items: ParametroListItem[] }>> {
  const query = new URLSearchParams({ programa });
  return apiRequest<{ items: ParametroListItem[] }>(`${parametrosBasePath}?${query.toString()}`, {
    method: 'GET',
    ...options,
  });
}

export function patchParametro(
  clave: string,
  body: ParametroPatchBody,
  options: RequestOverrides = {}
): Promise<ApiClientResult<{ item: ParametroListItem }>> {
  return apiRequest<{ item: ParametroListItem }>(`${parametrosBasePath}/${encodeURIComponent(clave)}`, {
    method: 'PATCH',
    body: JSON.stringify(body),
    ...options,
  });
}
