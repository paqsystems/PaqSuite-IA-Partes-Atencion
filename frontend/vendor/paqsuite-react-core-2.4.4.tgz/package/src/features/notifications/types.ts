/**
 * Tipos GEN-17 — notificaciones in-app (TR-GEN-17-notificaciones-entrega §5).
 * Pool por usuario/instalación; ignora `X-Company-Id`.
 */

export type NotificationStatus = 'unread' | 'read';

export type NotificationDto = {
  id: string;
  title: string;
  body: string;
  status: NotificationStatus;
  source?: string | null;
  linkUrl?: string | null;
  createdAt: string;
  readAt?: string | null;
};

export type NotificationListQuery = {
  status?: NotificationStatus;
  page?: number;
  pageSize?: number;
};

export type NotificationListResult = {
  items: NotificationDto[];
  page: number;
  pageSize: number;
};

export type NotificationDeviceToken = {
  token: string;
  platform: 'android' | 'ios';
};
