export const fastPollMs = 5_000;
/** Intervalo en reposo (y backoff ante error). */
export const slowPollMs = 60_000;
export const recentActivityWindowMs = 60_000;
/** Tras N fallos consecutivos se pausa el polling hasta volver a enfocar la pestaña. */
export const maxConsecutivePollErrors = 3;

export type PollingContext = {
  /** Documento visible y con foco (si oculto → pausar). */
  visible: boolean;
  unreadCount: number;
  /** ms desde la última actividad del usuario. */
  msSinceActivity: number;
  /** Fallos consecutivos del fetch; >0 usa backoff lento. */
  consecutiveErrors?: number;
};

/**
 * Intervalo de polling adaptativo (TR-GEN-17-notificaciones §Cierres, C1-17-05):
 * pestaña oculta → `null` (pausar);
 * errores consecutivos ≥ max → `null` (dejar de reintentar hasta visibility);
 * con errores menores → 60 s;
 * visible con unread>0 o actividad reciente → 5 s;
 * en otro caso → 60 s.
 */
export function resolvePollingInterval(context: PollingContext): number | null {
  if (!context.visible) {
    return null;
  }
  const errors = context.consecutiveErrors ?? 0;
  if (errors >= maxConsecutivePollErrors) {
    return null;
  }
  if (errors > 0) {
    return slowPollMs;
  }
  if (context.unreadCount > 0 || context.msSinceActivity < recentActivityWindowMs) {
    return fastPollMs;
  }
  return slowPollMs;
}
