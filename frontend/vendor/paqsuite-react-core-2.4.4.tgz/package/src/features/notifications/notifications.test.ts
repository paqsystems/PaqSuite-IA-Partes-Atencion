import { describe, expect, it } from 'vitest';
import {
  fastPollMs,
  maxConsecutivePollErrors,
  resolvePollingInterval,
  slowPollMs,
} from './pollingInterval';
import { buildNotificationsQuery } from './notificationsClient';

describe('resolvePollingInterval', () => {
  it('pausa (null) con pestaña oculta', () => {
    expect(
      resolvePollingInterval({ visible: false, unreadCount: 5, msSinceActivity: 0 })
    ).toBeNull();
  });

  it('5 s con unread > 0', () => {
    expect(
      resolvePollingInterval({ visible: true, unreadCount: 3, msSinceActivity: 999_999 })
    ).toBe(fastPollMs);
  });

  it('5 s con actividad reciente', () => {
    expect(
      resolvePollingInterval({ visible: true, unreadCount: 0, msSinceActivity: 1_000 })
    ).toBe(fastPollMs);
  });

  it('60 s en reposo sin unread', () => {
    expect(
      resolvePollingInterval({ visible: true, unreadCount: 0, msSinceActivity: 120_000 })
    ).toBe(slowPollMs);
  });

  it('60 s con errores consecutivos por debajo del umbral', () => {
    expect(
      resolvePollingInterval({
        visible: true,
        unreadCount: 0,
        msSinceActivity: 0,
        consecutiveErrors: 1,
      })
    ).toBe(slowPollMs);
  });

  it('pausa tras umbral de errores consecutivos', () => {
    expect(
      resolvePollingInterval({
        visible: true,
        unreadCount: 0,
        msSinceActivity: 0,
        consecutiveErrors: maxConsecutivePollErrors,
      })
    ).toBeNull();
  });
});

describe('buildNotificationsQuery', () => {
  it('vacío sin filtros', () => {
    expect(buildNotificationsQuery()).toBe('');
  });

  it('serializa status y paginación', () => {
    const query = buildNotificationsQuery({ status: 'unread', page: 2, pageSize: 50 });
    expect(query).toContain('status=unread');
    expect(query).toContain('page=2');
    expect(query).toContain('pageSize=50');
  });
});
