import { useCallback, useEffect, useRef, useState } from 'react';
import { getUnreadCount, listNotifications } from './notificationsClient';
import { resolvePollingInterval } from './pollingInterval';
import type { NotificationDto } from './types';

export type UseNotificationsPollingState = {
  notifications: NotificationDto[];
  unreadCount: number;
  refresh: () => Promise<void>;
};

export type UseNotificationsPollingOptions = {
  /** Callback al detectar incremento de unread (toast del host). */
  onNewUnread?: (delta: number) => void;
};

/**
 * Polling adaptativo de notificaciones (TR-GEN-17): 5 s / 60 s, pausa con
 * pestaña oculta (C1-17-05). Ante errores consecutivos usa backoff 60 s y
 * deja de reintentar tras el umbral hasta que la pestaña vuelva a foco.
 */
export function useNotificationsPolling(
  options: UseNotificationsPollingOptions = {}
): UseNotificationsPollingState {
  const { onNewUnread } = options;
  const [notifications, setNotifications] = useState<NotificationDto[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const lastActivityRef = useRef<number>(Date.now());
  const previousUnreadRef = useRef<number>(0);
  const consecutiveErrorsRef = useRef(0);

  const refresh = useCallback(async () => {
    try {
      const [listResult, countResult] = await Promise.all([
        listNotifications(),
        getUnreadCount(),
      ]);

      let anyOk = false;

      if (listResult.kind === 'ok') {
        anyOk = true;
        setNotifications(listResult.envelope.resultado.items ?? []);
      }
      if (countResult.kind === 'ok') {
        anyOk = true;
        const next = countResult.envelope.resultado.unreadCount ?? 0;
        if (next > previousUnreadRef.current) {
          onNewUnread?.(next - previousUnreadRef.current);
        }
        previousUnreadRef.current = next;
        setUnreadCount(next);
      }

      if (anyOk) {
        consecutiveErrorsRef.current = 0;
      } else {
        consecutiveErrorsRef.current += 1;
      }
    } catch {
      consecutiveErrorsRef.current += 1;
    }
  }, [onNewUnread]);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    let cancelled = false;

    const isVisible = () =>
      typeof document === 'undefined' || document.visibilityState !== 'hidden';

    const schedule = () => {
      if (cancelled) {
        return;
      }
      const interval = resolvePollingInterval({
        visible: isVisible(),
        unreadCount: previousUnreadRef.current,
        msSinceActivity: Date.now() - lastActivityRef.current,
        consecutiveErrors: consecutiveErrorsRef.current,
      });
      if (interval === null) {
        return;
      }
      timer = setTimeout(() => {
        void refresh().finally(schedule);
      }, interval);
    };

    void refresh().finally(schedule);

    const onVisibility = () => {
      if (!isVisible()) {
        return;
      }
      if (timer) {
        clearTimeout(timer);
        timer = undefined;
      }
      // Reenfocar: permitir reintentos tras pausa por errores.
      consecutiveErrorsRef.current = 0;
      void refresh().finally(schedule);
    };
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', onVisibility);
    }

    return () => {
      cancelled = true;
      if (timer) {
        clearTimeout(timer);
      }
      if (typeof document !== 'undefined') {
        document.removeEventListener('visibilitychange', onVisibility);
      }
    };
  }, [refresh]);

  return { notifications, unreadCount, refresh };
}
