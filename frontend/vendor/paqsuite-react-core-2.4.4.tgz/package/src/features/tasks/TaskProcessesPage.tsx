import { useCallback, useEffect, useState } from 'react';
import DataGrid, { Column, Paging, Pager } from 'devextreme-react/data-grid';
import Switch from 'devextreme-react/switch';
import { listTaskProcesses, setTaskProcessActive } from './tasksClient';
import type { TaskProcessDto } from './types';

export type TaskProcessesPageProps = {
  t?: (key: string) => string;
};

/**
 * Catálogo de procesos programables (GEN-13). Grilla DX de solo lectura del
 * contrato técnico + switch `isActive`. Sin formularios de alta (regla §3).
 */
export function TaskProcessesPage({ t }: TaskProcessesPageProps) {
  const translate = t ?? ((key: string) => key);
  const [rows, setRows] = useState<TaskProcessDto[]>([]);

  const load = useCallback(async () => {
    const result = await listTaskProcesses();
    if (result.kind === 'ok') {
      setRows(result.envelope.resultado.items ?? []);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const handleToggle = useCallback(
    async (row: TaskProcessDto, isActive: boolean) => {
      const result = await setTaskProcessActive(row.id, isActive);
      if (result.kind === 'ok') {
        void load();
      }
    },
    [load]
  );

  return (
    <div data-testid="tareasProgramadas.procesos.root">
      <h2>{translate('tareasProgramadas.procesos.title')}</h2>
      <DataGrid
        dataSource={rows}
        keyExpr="id"
        showBorders
        columnAutoWidth
        elementAttr={{ 'data-testid': 'tareasProgramadas.procesos.grid' }}
      >
        <Paging defaultPageSize={25} />
        <Pager visible showInfo />
        <Column dataField="processCode" caption={translate('tareasProgramadas.procesos.code')} />
        <Column dataField="processName" caption={translate('tareasProgramadas.procesos.name')} />
        <Column dataField="moduleCode" caption={translate('tareasProgramadas.procesos.module')} />
        <Column
          dataField="isActive"
          caption={translate('tareasProgramadas.procesos.active')}
          cellRender={(cell) => {
            const row = cell.data as TaskProcessDto;
            return (
              <Switch
                value={row.isActive}
                onValueChanged={(event) => void handleToggle(row, (event.value as boolean) ?? false)}
                elementAttr={{ 'data-testid': 'tareasProgramadas.procesos.toggleActive' }}
              />
            );
          }}
        />
      </DataGrid>
    </div>
  );
}
