import DataGrid, { Column, Paging, Pager } from 'devextreme-react/data-grid';
import Button from 'devextreme-react/button';
import type { ExcelImportRowErrorDto } from './types';

export type ExcelImportErrorsGridProps = {
  rowErrors: ExcelImportRowErrorDto[];
  onExport: () => void;
  t?: (key: string) => string;
};

/**
 * Grilla DX de errores de fila + Exportar (GEN-14).
 * MUST: solo columnas **nº de fila** y **texto del error** (sin datos de celda/columna).
 * El mensaje se muestra también en `title` (tooltip) por si es largo.
 * El DTO puede seguir trayendo `column`/`params` para API/export; la UI no los lista.
 */
export function ExcelImportErrorsGrid({ rowErrors, onExport, t }: ExcelImportErrorsGridProps) {
  const translate = t ?? ((key: string) => key);
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 8 }}>
        <Button
          text={translate('excelImport.exportErrors')}
          icon="exportxlsx"
          onClick={onExport}
          disabled={rowErrors.length === 0}
          elementAttr={{ 'data-testid': 'excelImport.exportErrors' }}
        />
      </div>
      <DataGrid
        dataSource={rowErrors}
        showBorders
        columnAutoWidth
        wordWrapEnabled
        elementAttr={{ 'data-testid': 'excelImport.errorsGrid' }}
      >
        <Paging defaultPageSize={25} />
        <Pager visible showInfo />
        <Column
          dataField="rowNumber"
          caption={translate('excelImport.column.rowNumber')}
          width={100}
          allowSorting
        />
        <Column
          dataField="messageKey"
          caption={translate('excelImport.column.message')}
          cellRender={(cell) => {
            const messageKey = (cell.value as string) ?? '';
            const column = String((cell.data as ExcelImportRowErrorDto | undefined)?.column ?? '');
            const params = {
              column,
              ...((cell.data as ExcelImportRowErrorDto | undefined)?.params ?? {}),
            };
            let messageText = translate(messageKey);
            for (const [paramKey, paramValue] of Object.entries(params)) {
              if (paramValue === undefined || paramValue === null) {
                continue;
              }
              messageText = messageText.split(`{{${paramKey}}}`).join(String(paramValue));
            }
            // Si el host no interpola {{column}}, anexar la columna para claves GEN.
            if (
              column &&
              !messageText.includes(column) &&
              (messageKey === 'excelImport.row.required' ||
                messageKey === 'excelImport.row.invalidType')
            ) {
              messageText = `${messageText} (${column})`;
            }
            return (
              <span
                title={messageText}
                data-testid="excelImport.errorsGrid.message"
                style={{
                  display: 'block',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap',
                  maxWidth: '100%',
                }}
              >
                {messageText}
              </span>
            );
          }}
        />
      </DataGrid>
    </div>
  );
}
