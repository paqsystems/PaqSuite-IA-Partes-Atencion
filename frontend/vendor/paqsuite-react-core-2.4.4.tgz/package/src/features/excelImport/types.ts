/**
 * Tipos GEN-14 — Importaciones Excel (TR-GEN-14-motor-api-staging §5 y
 * TR-GEN-14-ui-embebida §5).
 */

export type ExcelImportBatchStatus =
  | 'pending'
  | 'validating'
  | 'validated'
  | 'invalid'
  | 'queued'
  | 'processing'
  | 'done'
  | 'partial'
  | 'failed'
  | 'cancelled';

export type ExcelImportBatchDto = {
  batchId: string;
  processCode: string;
  status: ExcelImportBatchStatus;
  mode: 'sync' | 'async' | null;
  allowPartial: boolean;
  sheetName: string;
  fileName: string;
  fileSizeBytes: number;
  totalRows: number;
  validRows: number;
  errorRows: number;
  processedRows: number | null;
  failedRows: number | null;
  messageKey: string | null;
  data?: Record<string, unknown> | null;
};

export type ExcelImportRowErrorDto = {
  rowNumber: number;
  column: string;
  messageKey: string;
  params?: Record<string, unknown>;
};

/** Payload Must entregado al host en `onComplete` (TR ui-embebida §5). */
export type ExcelImportCompletePayload = {
  batchId: string;
  processCode: string;
  status: 'done' | 'partial' | 'failed' | 'queued';
  mode: 'sync' | 'async';
  totalRows: number;
  processedRows: number;
  failedRows: number;
  data?: Record<string, unknown> | null;
};

/** Estado de la máquina FE del modal (TR ui-embebida §Cierres). */
export type ExcelImportUiState =
  | 'idle'
  | 'fileSelected'
  | 'validating'
  | 'validated'
  | 'invalid'
  | 'processing'
  | 'completed';
