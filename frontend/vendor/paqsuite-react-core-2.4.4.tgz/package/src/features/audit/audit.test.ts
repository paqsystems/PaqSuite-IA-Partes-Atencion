import { describe, expect, it } from 'vitest';
import {
  auditRoutePath,
  auditSourcePermission,
} from './auditSourcePermission';
import { buildAuditEventsQuery } from './auditEventsClient';

describe('auditSourcePermission', () => {
  it('mapea source → permiso/proceso', () => {
    expect(auditSourcePermission('tasks')).toBe('audit-events-tasks');
    expect(auditSourcePermission('emission')).toBe('audit-events-emission');
  });

  it('arma la ruta del tema', () => {
    expect(auditRoutePath('chat')).toBe('/audit-events/chat');
  });
});

describe('buildAuditEventsQuery', () => {
  it('incluye source siempre y mineOnly cuando aplica', () => {
    const query = buildAuditEventsQuery({ source: 'tasks', mineOnly: true });
    expect(query).toContain('source=tasks');
    expect(query).toContain('mineOnly=true');
  });

  it('omite mineOnly cuando es false', () => {
    const query = buildAuditEventsQuery({ source: 'tasks', mineOnly: false });
    expect(query).toContain('source=tasks');
    expect(query).not.toContain('mineOnly');
  });
});
