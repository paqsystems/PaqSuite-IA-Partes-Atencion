/**
 * Mapa `source` ↔ código de permiso/proceso (TR-GEN-17-bitacora-consulta-ui).
 * Ítem de menú por tema: `audit-events-{source}`; el permiso usa el mismo código.
 */

export const auditEventsRootProcessCode = 'audit-events';
export const auditEventsPurgePermission = 'audit-events-purge';

/** Devuelve el código de permiso/proceso del tema (`audit-events-{source}`). */
export function auditSourcePermission(source: string): string {
  return `${auditEventsRootProcessCode}-${source}`;
}

/** Segmento de URL = valor API del `source` (C1-17-08). */
export function auditRoutePath(source: string): string {
  return `/audit-events/${source}`;
}
