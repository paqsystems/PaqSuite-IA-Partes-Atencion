import { useCallback, useEffect, useId, useMemo, useRef, useState } from 'react';
import Button from 'devextreme-react/button';
import TextArea from 'devextreme-react/text-area';
import FileUploader, { type FileUploaderRef } from 'devextreme-react/file-uploader';
import type { KeyDownEvent as TextAreaKeyDownEvent } from 'devextreme/ui/text_area';
import type { ApiClientResult } from '../../http/apiClient';
import { LlmActiveCredentialSelect } from '../llmCredentials/LlmActiveCredentialSelect';
import { useLlmCredentialSelection } from '../llmCredentials/useLlmCredentialSelection';
import { resolveActiveCredential } from '../llmCredentials/resolveActiveCredential';
import type { LlmCredentialDto, LlmSelectionState } from '../llmCredentials/types';
import {
  maxSmartCaptureImageBytes,
  maxSmartCaptureImages,
  validateImageAddition,
} from '../smartCapture/imageValidation';
import { ChatAssistantThread } from './ChatAssistantThread';
import { buildChatAssistantTurnRequest } from './buildChatAssistantTurnRequest';
import { postChatAssistantTurn } from './postChatAssistantTurn';
import { preventFileOpenOnDrop } from './preventFileOpenOnDrop';
import type {
  ChatAssistantImage,
  ChatAssistantThreadMessage,
  ChatAssistantTurnResultV1,
} from './types';

export type ChatAssistantPageProps = {
  welcomeKey?: string;
  welcomeText?: string;
  turnUrl?: string;
  onOpenPreferences: () => void;
  onTurnCompleted?: (result: ChatAssistantTurnResultV1) => void;
  onTurnError?: (result: ApiClientResult<ChatAssistantTurnResultV1>) => void;
  credentials?: LlmCredentialDto[];
  activeCredentialId?: number | null;
  onActiveCredentialChange?: (credentialId: number | null) => void;
  /**
   * Incrementar tras cerrar Preferencias / CRUD de credenciales para
   * revalidar el SelectBox activo (modo no controlado).
   */
  credentialsRevision?: number;
  t?: (key: string) => string;
};

const maxMessageLength = 2000;

async function fileToChatImage(file: File): Promise<ChatAssistantImage> {
  const buffer = await file.arrayBuffer();
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.length; i += 1) {
    binary += String.fromCharCode(bytes[i]!);
  }
  const contentBase64 = typeof btoa === 'function' ? btoa(binary) : '';
  return { fileName: file.name, mimeType: file.type, contentBase64 };
}

/**
 * Pantalla Chat Asistente IA (GEN-21). Selección de credencial interna
 * (hook) o modo controlado si el host pasa las tres props del bloque
 * (C1-21-06). Envío único vía `postChatAssistantTurn` (C1-21-05); empty §3.4
 * sin LLM; hilo de burbujas (sin citas de corpus en UI).
 */
export function ChatAssistantPage(props: ChatAssistantPageProps) {
  const {
    welcomeKey,
    welcomeText,
    turnUrl,
    onOpenPreferences,
    onTurnCompleted,
    onTurnError,
    credentials,
    activeCredentialId,
    onActiveCredentialChange,
    credentialsRevision = 0,
    t,
  } = props;
  const translate = t ?? ((key: string) => key);

  const isControlled =
    credentials !== undefined &&
    activeCredentialId !== undefined &&
    onActiveCredentialChange !== undefined;

  const internalSelection = useLlmCredentialSelection();

  const controlledSelection = useMemo<LlmSelectionState>(() => {
    const resolved = resolveActiveCredential(credentials ?? [], activeCredentialId ?? null);
    return {
      credentials: resolved.enabledCredentials,
      activeCredentialId: activeCredentialId ?? null,
      activeResolved: resolved.activeResolved,
      configurationRequired: resolved.configurationRequired,
      canAttachImages: resolved.canAttachImages,
      loading: false,
      setActiveCredentialId: async (id) => {
        onActiveCredentialChange?.(id);
      },
      refresh: async () => {},
    };
  }, [credentials, activeCredentialId, onActiveCredentialChange]);

  const selection = isControlled ? controlledSelection : internalSelection;

  useEffect(() => {
    if (isControlled || credentialsRevision === 0) {
      return;
    }
    void internalSelection.refresh();
  }, [credentialsRevision, isControlled, internalSelection.refresh]);

  // Sin esto, soltar una imagen fuera del FileUploader (o si DX no cancela el default)
  // reemplaza la SPA por la imagen en el navegador.
  useEffect(() => {
    window.addEventListener('dragover', preventFileOpenOnDrop);
    window.addEventListener('drop', preventFileOpenOnDrop);
    return () => {
      window.removeEventListener('dragover', preventFileOpenOnDrop);
      window.removeEventListener('drop', preventFileOpenOnDrop);
    };
  }, []);

  const [message, setMessage] = useState('');
  const [images, setImages] = useState<ChatAssistantImage[]>([]);
  const [thread, setThread] = useState<ChatAssistantThreadMessage[]>([]);
  const [sending, setSending] = useState(false);
  const [dropZoneActive, setDropZoneActive] = useState(false);
  const fileUploaderRef = useRef<FileUploaderRef>(null);
  const reactId = useId().replace(/:/g, '');
  const dropZoneDomId = `chatAssistantDropZone-${reactId}`;
  const pickImagesDomId = `chatAssistantPickImages-${reactId}`;

  const resetFileUploader = useCallback(() => {
    fileUploaderRef.current?.instance()?.reset();
  }, []);

  const removeAttachedImage = useCallback(
    (index: number) => {
      setImages((current) => current.filter((_, imageIndex) => imageIndex !== index));
      resetFileUploader();
    },
    [resetFileUploader]
  );

  const canSend = !sending && message.trim() !== '' && selection.activeResolved?.id !== undefined;

  const handleSend = useCallback(async () => {
    const credentialId = selection.activeResolved?.id;
    if (credentialId === undefined || message.trim() === '' || sending) {
      return;
    }
    const body = buildChatAssistantTurnRequest({
      credentialId,
      message,
      images: selection.canAttachImages ? images : undefined,
      supportsVision: selection.canAttachImages,
    });
    setThread((current) => [...current, { role: 'user', text: message }]);
    setMessage('');
    setImages([]);
    resetFileUploader();
    setSending(true);
    const result = await postChatAssistantTurn(body, { url: turnUrl });
    setSending(false);
    if (result.kind === 'ok') {
      const data = result.envelope.resultado;
      setThread((current) => [
        ...current,
        { role: 'assistant', text: data.reply, citations: data.citations },
      ]);
      onTurnCompleted?.(data);
    } else {
      setThread((current) => [
        ...current,
        { role: 'assistant', text: translate('chatAssistant.turnError') },
      ]);
      onTurnError?.(result);
    }
  }, [
    images,
    message,
    onTurnCompleted,
    onTurnError,
    resetFileUploader,
    selection,
    translate,
    sending,
    turnUrl,
  ]);

  const handleComposerKeyDown = useCallback(
    (event: TextAreaKeyDownEvent) => {
      const nativeEvent = event.event;
      if (!nativeEvent) {
        return;
      }
      // Enter = nueva línea (default). Shift+Enter = enviar.
      if (nativeEvent.key !== 'Enter' || !nativeEvent.shiftKey) {
        return;
      }
      if (nativeEvent.altKey || nativeEvent.ctrlKey || nativeEvent.metaKey) {
        return;
      }
      nativeEvent.preventDefault();
      if (canSend) {
        void handleSend();
      }
    },
    [canSend, handleSend]
  );

  const welcome = welcomeKey
    ? translate(welcomeKey)
    : welcomeText ?? translate('chatAssistant.welcome.default');

  return (
    <div data-testid="chatAssistant.page" className="chat-assistant-page">
      <header style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <h2>{translate('chatAssistant.title')}</h2>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center' }}>
          {!selection.configurationRequired ? (
            <>
              <span>{translate('chatAssistant.activeConfigLabel')}</span>
              <div data-testid="chatAssistant.activeConfig">
                <LlmActiveCredentialSelect selection={selection} t={t} />
              </div>
            </>
          ) : null}
          <Button
            icon="preferences"
            hint={translate('chatAssistant.preferences')}
            onClick={onOpenPreferences}
            elementAttr={{ 'data-testid': 'chatAssistant.preferences' }}
          />
        </div>
      </header>

      {selection.configurationRequired ? (
        <div data-testid="chatAssistant.emptyState">
          <h3>{translate('chatAssistant.emptyState.title')}</h3>
          <p>{translate('chatAssistant.emptyState.body')}</p>
          <Button
            text={translate('chatAssistant.emptyState.cta')}
            type="default"
            stylingMode="contained"
            onClick={onOpenPreferences}
            elementAttr={{ 'data-testid': 'chatAssistant.emptyCta' }}
          />
        </div>
      ) : (
        <>
          <p>{welcome}</p>
          <ChatAssistantThread messages={thread} t={t} />
          <div
            data-testid="chatAssistant.composer"
            style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 8 }}
          >
            <TextArea
              value={message}
              maxLength={maxMessageLength}
              height={120}
              valueChangeEvent="input"
              onValueChanged={(event) => setMessage((event.value as string) ?? '')}
              onKeyDown={handleComposerKeyDown}
              elementAttr={{ 'data-testid': 'chatAssistant.message' }}
            />

            {selection.canAttachImages ? (
              <div data-testid="chatAssistant.attachImages">
                <p
                  style={{
                    margin: '0 0 6px',
                    fontSize: '0.85rem',
                    fontWeight: 600,
                    color: '#475569',
                  }}
                >
                  {translate('chatAssistant.dropZone.title')}
                </p>
                <div
                  id={dropZoneDomId}
                  data-testid="chatAssistant.dropZone"
                  onDragOver={(event) => {
                    event.preventDefault();
                  }}
                  onDrop={(event) => {
                    event.preventDefault();
                    setDropZoneActive(false);
                  }}
                  style={{
                    minHeight: 112,
                    border: `2px dashed ${dropZoneActive ? '#2563eb' : '#94a3b8'}`,
                    borderRadius: 8,
                    padding: '16px 12px',
                    background: dropZoneActive ? '#eff6ff' : '#f8fafc',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 8,
                    textAlign: 'center',
                    transition: 'background 0.15s ease, border-color 0.15s ease',
                  }}
                >
                  <i
                    className="dx-icon dx-icon-image"
                    style={{ fontSize: 28, color: dropZoneActive ? '#2563eb' : '#64748b' }}
                    aria-hidden
                  />
                  <strong style={{ fontSize: '0.95rem', color: '#334155' }}>
                    {translate('chatAssistant.dropZone.primary')}
                  </strong>
                  <span style={{ fontSize: '0.8rem', color: '#64748b' }}>
                    {translate('chatAssistant.dropZone.or')}
                  </span>
                  <Button
                    elementAttr={{ id: pickImagesDomId }}
                    text={translate('chatAssistant.attachImages')}
                    stylingMode="outlined"
                    type="normal"
                  />
                  <span style={{ fontSize: '0.75rem', color: '#64748b' }}>
                    {translate('chatAssistant.attachImages.hint')}
                  </span>
                </div>
                <FileUploader
                  ref={fileUploaderRef}
                  visible={false}
                  multiple
                  uploadMode="useForm"
                  accept="image/*"
                  showFileList={false}
                  dropZone={`#${dropZoneDomId}`}
                  dialogTrigger={`#${pickImagesDomId}`}
                  onDropZoneEnter={() => setDropZoneActive(true)}
                  onDropZoneLeave={() => setDropZoneActive(false)}
                  onValueChanged={(event) => {
                    setDropZoneActive(false);
                    void (async () => {
                      const files = (event.value as File[]) ?? [];
                      if (files.length === 0) {
                        return;
                      }
                      const additions: ChatAssistantImage[] = [];
                      for (const file of files) {
                        if (file.size > maxSmartCaptureImageBytes) {
                          continue;
                        }
                        additions.push(await fileToChatImage(file));
                      }
                      setImages((current) => {
                        const next = [...current];
                        for (const image of additions) {
                          if (validateImageAddition(next.length, 0) !== null) {
                            break;
                          }
                          next.push(image);
                        }
                        return next.slice(0, maxSmartCaptureImages);
                      });
                      resetFileUploader();
                    })();
                  }}
                />
                {images.length > 0 ? (
                  <ul
                    data-testid="chatAssistant.attachedList"
                    style={{
                      listStyle: 'none',
                      margin: '8px 0 0',
                      padding: 0,
                      fontSize: '0.8rem',
                      color: '#475569',
                    }}
                  >
                    {images.map((image, index) => (
                      <li
                        key={`${image.fileName}-${index}-${image.contentBase64.slice(0, 12)}`}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 6,
                          minHeight: 32,
                        }}
                      >
                        <span
                          style={{
                            flex: 1,
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          }}
                          title={image.fileName}
                        >
                          {image.fileName}
                        </span>
                        <Button
                          icon="close"
                          stylingMode="text"
                          hint={translate('chatAssistant.attachedImages.remove')}
                          onClick={() => removeAttachedImage(index)}
                          elementAttr={{
                            'data-testid': `chatAssistant.attachedRemove.${index}`,
                            'aria-label': translate('chatAssistant.attachedImages.remove'),
                          }}
                        />
                      </li>
                    ))}
                  </ul>
                ) : null}
              </div>
            ) : null}

            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: 12,
                flexWrap: 'wrap',
              }}
            >
              <span
                data-testid="chatAssistant.counter"
                style={{ fontSize: '0.85rem', color: '#64748b' }}
              >
                {`${message.length}/${maxMessageLength}`}
              </span>
              <div style={{ flexShrink: 0 }}>
                <Button
                  icon="send"
                  type="default"
                  stylingMode="contained"
                  hint={
                    sending
                      ? translate('chatAssistant.sending')
                      : translate('chatAssistant.send.hint')
                  }
                  disabled={!canSend}
                  onClick={() => void handleSend()}
                  elementAttr={{ 'data-testid': 'chatAssistant.send' }}
                />
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
