/**
 * Evita que el navegador navegue a un archivo soltado (imagen a pantalla completa).
 */

export function isFileDragEvent(event: Pick<DragEvent, 'dataTransfer'>): boolean {
  const types = event.dataTransfer?.types;
  if (!types) {
    return false;
  }
  return Array.from(types).includes('Files');
}

export function preventFileOpenOnDrop(event: DragEvent): void {
  if (!isFileDragEvent(event)) {
    return;
  }
  event.preventDefault();
}
