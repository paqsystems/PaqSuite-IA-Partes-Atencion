import { describe, expect, it, vi } from 'vitest';
import { buildChatAssistantTurnRequest } from './buildChatAssistantTurnRequest';
import {
  isValidExternalHelpUrl,
  openExternalHelp,
  resolveExternalHelpUrl,
} from './externalHelp';
import { isFileDragEvent, preventFileOpenOnDrop } from './preventFileOpenOnDrop';

describe('buildChatAssistantTurnRequest', () => {
  it('incluye contractVersion 1 y omite imágenes sin visión', () => {
    const request = buildChatAssistantTurnRequest({
      credentialId: 2,
      message: 'hola',
      images: [{ fileName: 'a.png', mimeType: 'image/png', contentBase64: 'AAAA' }],
      supportsVision: false,
    });
    expect(request.contractVersion).toBe(1);
    expect(request.images).toBeUndefined();
  });

  it('conserva imágenes con visión', () => {
    const request = buildChatAssistantTurnRequest({
      credentialId: 2,
      message: 'hola',
      images: [{ fileName: 'a.png', mimeType: 'image/png', contentBase64: 'AAAA' }],
      supportsVision: true,
    });
    expect(request.images).toHaveLength(1);
  });
});

describe('isValidExternalHelpUrl', () => {
  it('acepta http/https', () => {
    expect(isValidExternalHelpUrl('https://ayuda.example.com')).toBe(true);
    expect(isValidExternalHelpUrl('http://ayuda.example.com')).toBe(true);
  });

  it('rechaza esquemas peligrosos / vacío', () => {
    expect(isValidExternalHelpUrl('javascript:alert(1)')).toBe(false);
    expect(isValidExternalHelpUrl('')).toBe(false);
    expect(isValidExternalHelpUrl(null)).toBe(false);
    expect(isValidExternalHelpUrl(undefined)).toBe(false);
  });
});

describe('resolveExternalHelpUrl', () => {
  it('prioriza la prop del host', () => {
    expect(resolveExternalHelpUrl('https://a.com', () => 'https://b.com')).toBe('https://a.com');
  });

  it('usa el resolver del host si no hay prop', () => {
    expect(resolveExternalHelpUrl(null, () => 'https://b.com')).toBe('https://b.com');
  });

  it('null si no hay fuente', () => {
    expect(resolveExternalHelpUrl(undefined)).toBeNull();
  });
});

describe('openExternalHelp', () => {
  it('missing cuando no hay URL', () => {
    expect(openExternalHelp(null)).toEqual({ opened: false, reason: 'missing' });
  });

  it('invalid cuando el esquema no es http(s)', () => {
    expect(openExternalHelp('javascript:alert(1)')).toEqual({ opened: false, reason: 'invalid' });
  });

  it('usa el adaptador Capacitor cuando está presente', () => {
    let openedUrl = '';
    const result = openExternalHelp('https://a.com', {
      openExternalUrl: (url) => {
        openedUrl = url;
      },
    });
    expect(result.opened).toBe(true);
    expect(openedUrl).toBe('https://a.com');
  });

  it('resolveExternalHelpUrl ignora cualquier query del navegador (solo prop/resolver)', () => {
    // C1-21-07-URL: el helper nunca lee window.location.search
    expect(resolveExternalHelpUrl(undefined, () => 'https://host-config.example')).toBe(
      'https://host-config.example'
    );
    expect(resolveExternalHelpUrl(null, () => null)).toBeNull();
  });
});

describe('preventFileOpenOnDrop', () => {
  it('detecta arrastre de archivos', () => {
    expect(isFileDragEvent({ dataTransfer: { types: ['Files'] } as DataTransfer })).toBe(true);
    expect(isFileDragEvent({ dataTransfer: { types: ['text/plain'] } as DataTransfer })).toBe(
      false
    );
    expect(isFileDragEvent({ dataTransfer: null })).toBe(false);
  });

  it('cancela el default solo con Files (evita abrir la imagen en el navegador)', () => {
    const preventDefault = vi.fn();
    preventFileOpenOnDrop({
      dataTransfer: { types: ['Files'] },
      preventDefault,
    } as unknown as DragEvent);
    expect(preventDefault).toHaveBeenCalledOnce();

    const ignored = vi.fn();
    preventFileOpenOnDrop({
      dataTransfer: { types: ['text/uri-list'] },
      preventDefault: ignored,
    } as unknown as DragEvent);
    expect(ignored).not.toHaveBeenCalled();
  });
});
