import type { ChatAssistantThreadMessage } from './types';

export type ChatAssistantThreadProps = {
  messages: ChatAssistantThreadMessage[];
  t?: (key: string) => string;
};

/**
 * Hilo de burbujas usuario / asistente (C1-21-11).
 * Las `citations` del corpus **nunca** se muestran en UI (regla 21-chat-asistente-sin-citas-ui).
 */
export function ChatAssistantThread({ messages, t }: ChatAssistantThreadProps) {
  const translate = t ?? ((key: string) => key);
  return (
    <div data-testid="chatAssistant.thread" className="chat-assistant-thread">
      {messages.map((entry, index) => (
        <div key={index} data-role={entry.role} className={`chat-bubble chat-bubble--${entry.role}`}>
          <div className="chat-bubble__text">{entry.text}</div>
          {entry.pending ? <span>{translate('chatAssistant.sending')}</span> : null}
        </div>
      ))}
    </div>
  );
}
