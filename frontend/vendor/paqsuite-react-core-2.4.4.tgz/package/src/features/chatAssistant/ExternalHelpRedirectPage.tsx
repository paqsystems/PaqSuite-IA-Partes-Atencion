import { useEffect, useState } from 'react';
import {
  openExternalHelp,
  resolveExternalHelpUrl,
  type OpenExternalHelpAdapters,
} from './externalHelp';

export type ExternalHelpRedirectPageProps = {
  /** URL fija del host (preferida). Nunca se lee `?url=` del navegador. */
  propUrl?: string | null;
  /** Resolver del host si no hay prop. */
  resolver?: () => string | null | undefined;
  adapters?: OpenExternalHelpAdapters;
  t?: (key: string) => string;
};

/**
 * Ruta Should `/external-help` (TR-GEN-21-ayuda-externa, C1-21-07-URL).
 * Resuelve el destino solo desde config/prop del host; sin redirector abierto.
 */
export function ExternalHelpRedirectPage(props: ExternalHelpRedirectPageProps) {
  const { propUrl, resolver, adapters, t } = props;
  const translate = t ?? ((key: string) => key);
  const [status, setStatus] = useState<'opening' | 'opened' | 'unavailable'>('opening');
  const [reason, setReason] = useState<'missing' | 'invalid' | undefined>();

  useEffect(() => {
    const resolved = resolveExternalHelpUrl(propUrl, resolver);
    const result = openExternalHelp(resolved, adapters);
    if (result.opened) {
      setStatus('opened');
      return;
    }
    setReason(result.reason);
    setStatus('unavailable');
    // eslint-disable-next-line react-hooks/exhaustive-deps -- adapters/resolver identity no debe reabrir
  }, [propUrl]);

  if (status === 'unavailable') {
    return (
      <div data-testid="userMenu.helpUnavailable" className="external-help-unavailable">
        <p>{translate('userMenu.helpUnavailable')}</p>
        {reason ? (
          <p data-testid="externalHelp.reason" style={{ opacity: 0.7 }}>
            {reason}
          </p>
        ) : null}
      </div>
    );
  }

  return (
    <div data-testid="externalHelp.redirect" className="external-help-redirect">
      <p>{translate(status === 'opened' ? 'externalHelp.opened' : 'externalHelp.opening')}</p>
    </div>
  );
}
