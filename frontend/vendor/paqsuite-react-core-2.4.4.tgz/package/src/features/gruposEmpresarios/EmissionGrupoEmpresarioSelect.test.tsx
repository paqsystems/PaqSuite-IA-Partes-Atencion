import { describe, expect, it, vi } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import { EmissionGrupoEmpresarioSelect } from './EmissionGrupoEmpresarioSelect';

const listMock = vi.fn();

vi.mock('./gruposEmpresariosApi', () => ({
  listGrupoEmpresarioOpciones: (...args: unknown[]) => listMock(...args),
}));

describe('EmissionGrupoEmpresarioSelect', () => {
  it('no renderiza si enabled=false', () => {
    listMock.mockResolvedValue({
      kind: 'ok',
      envelope: { error: 0, respuesta: 'ok', resultado: { items: [] } },
    });
    const html = renderToStaticMarkup(
      <EmissionGrupoEmpresarioSelect value={null} onValueChange={() => undefined} enabled={false} />
    );
    expect(html).toBe('');
  });

  it('con enabled=true monta el wrapper y sentinel empresa activa', () => {
    listMock.mockResolvedValue({
      kind: 'ok',
      envelope: { error: 0, respuesta: 'ok', resultado: { items: [{ id: 3, nombre: 'Norte' }] } },
    });
    const html = renderToStaticMarkup(
      <EmissionGrupoEmpresarioSelect value={null} onValueChange={() => undefined} enabled />
    );
    expect(html).toContain('gruposEmpresariosEmissionEmpresaActiva');
    expect(html).toContain('>1<');
  });
});
