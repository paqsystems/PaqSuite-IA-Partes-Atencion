import { describe, expect, it } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import { GruposEmpresariosMembersGrid } from './GruposEmpresariosMembersGrid';

describe('GruposEmpresariosMembersGrid', () => {
  it('expone testid y no monta export/layouts GEN-11', () => {
    const html = renderToStaticMarkup(
      <GruposEmpresariosMembersGrid
        rows={[{ id: 1, nombreEmpresa: 'Demo' }]}
        selectedIds={[1]}
        onSelectionChange={() => undefined}
      />
    );

    expect(html).toContain('gruposEmpresariosMembersGrid');
    expect(html.toLowerCase()).not.toContain('export');
    expect(html.toLowerCase()).not.toContain('columnchooser');
    expect(html.toLowerCase()).not.toContain('grouppanel');
  });
});
