import { useCallback, useEffect, useState } from 'react';
import DataGrid, { Column, Paging, Pager } from 'devextreme-react/data-grid';
import Button from 'devextreme-react/button';
import { confirm } from 'devextreme/ui/dialog';
import { apiRequest } from '../../http/apiClient';
import {
  deleteGrupoEmpresario,
  listGruposEmpresarios,
} from './gruposEmpresariosApi';
import { GrupoEmpresarioFormPopup } from './GrupoEmpresarioFormPopup';
import type { MemberEmpresaRow } from './GruposEmpresariosMembersGrid';
import type { GrupoEmpresarioListItem } from './types';

export type GruposEmpresariosPageProps = {
  t?: (key: string) => string;
};

/**
 * ABM desktop de grupos empresarios (listado + Popup). Excluido de Capacitor.
 */
export function GruposEmpresariosPage({ t }: GruposEmpresariosPageProps) {
  const translate = t ?? ((key: string) => key);
  const [rows, setRows] = useState<GrupoEmpresarioListItem[]>([]);
  const [empresas, setEmpresas] = useState<MemberEmpresaRow[]>([]);
  const [formMode, setFormMode] = useState<'create' | 'edit' | null>(null);
  const [editing, setEditing] = useState<GrupoEmpresarioListItem | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoadError(null);
    const [listResult, empresasResult] = await Promise.all([
      listGruposEmpresarios(),
      apiRequest<{ items: MemberEmpresaRow[] }>('/api/v1/empresas', { method: 'GET' }),
    ]);

    if (listResult.kind === 'ok') {
      setRows(listResult.envelope.resultado.items ?? []);
    } else {
      setLoadError(listResult.envelope.respuesta || 'gruposEmpresarios.loadError');
    }

    if (empresasResult.kind === 'ok') {
      setEmpresas(empresasResult.envelope.resultado.items ?? []);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const handleDelete = useCallback(
    async (row: GrupoEmpresarioListItem) => {
      const confirmed = await confirm(
        translate('gruposEmpresarios.form.deleteConfirm'),
        translate('gruposEmpresarios.form.delete')
      );
      if (!confirmed) {
        return;
      }
      const result = await deleteGrupoEmpresario(row.id);
      if (result.kind === 'ok') {
        void load();
      }
    },
    [load, translate]
  );

  return (
    <div data-testid="gruposEmpresariosPage">
      <div style={{ display: 'flex', gap: 8, marginBottom: 12, alignItems: 'center' }}>
        <h2 style={{ margin: 0, flex: 1 }}>{translate('gruposEmpresarios.title')}</h2>
        <Button
          text={translate('gruposEmpresarios.title')}
          type="default"
          icon="plus"
          onClick={() => {
            setEditing(null);
            setFormMode('create');
          }}
          elementAttr={{ 'data-testid': 'gruposEmpresariosAdd' }}
        />
      </div>

      {loadError ? <div role="alert">{translate(loadError)}</div> : null}
      {rows.length === 0 && !loadError ? (
        <div>{translate('gruposEmpresarios.empty')}</div>
      ) : null}

      <div data-testid="gruposEmpresariosList">
        <DataGrid dataSource={rows} keyExpr="id" showBorders hoverStateEnabled>
          <Paging defaultPageSize={20} />
          <Pager visible showPageSizeSelector />
          <Column dataField="nombre" caption={translate('gruposEmpresarios.list.nombre')} />
          <Column
            dataField="cantidadMiembros"
            caption={translate('gruposEmpresarios.list.cantidadMiembros')}
          />
          <Column dataField="activo" caption={translate('gruposEmpresarios.list.activo')} />
          <Column
            type="buttons"
            width={100}
            buttons={[
              {
                hint: translate('gruposEmpresarios.form.save'),
                icon: 'edit',
                onClick: (e) => {
                  const row = e.row?.data as GrupoEmpresarioListItem;
                  setEditing(row);
                  setFormMode('edit');
                },
              },
              {
                hint: translate('gruposEmpresarios.form.delete'),
                icon: 'trash',
                onClick: (e) => {
                  const row = e.row?.data as GrupoEmpresarioListItem;
                  void handleDelete(row);
                },
              },
            ]}
          />
        </DataGrid>
      </div>

      {formMode ? (
        <GrupoEmpresarioFormPopup
          visible
          mode={formMode}
          initial={editing}
          empresas={empresas}
          onCancel={() => {
            setFormMode(null);
            setEditing(null);
          }}
          onSaved={() => {
            setFormMode(null);
            setEditing(null);
            void load();
          }}
          t={translate}
        />
      ) : null}
    </div>
  );
}
