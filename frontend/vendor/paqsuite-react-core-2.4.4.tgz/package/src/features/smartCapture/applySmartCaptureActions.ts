import type { SmartCaptureTurnAction } from './types';

export type SmartCaptureActionAdapters = {
  applyAction: (action: SmartCaptureTurnAction) => Promise<void> | void;
  /** false → no muta; el hilo puede mostrar causa */
  canApply?: (action: SmartCaptureTurnAction) => boolean;
};

/**
 * Aplica acciones del turno en orden. No adivina opciones: el host decide
 * vía adapters. Si `canApply` retorna false, omite la mutación.
 */
export async function applySmartCaptureActions(
  actions: SmartCaptureTurnAction[],
  adapters: SmartCaptureActionAdapters
): Promise<void> {
  for (const action of actions) {
    if (adapters.canApply && !adapters.canApply(action)) {
      continue;
    }
    await adapters.applyAction(action);
  }
}
