/**
 * Tipos del contrato de turno Smart Capture v1 (TR-GEN-03-contrato-turno §5).
 */

export type SmartCaptureModality = 'texto' | 'audio' | 'imagen';

export type SmartCaptureImage = {
  fileName: string;
  mimeType: string;
  contentBase64: string;
};

export type PendingChoice = {
  kind: string;
  options: Array<{ id: string | number; label: string; [key: string]: unknown }>;
  deferred: Array<{
    cause: string;
    payload: Record<string, unknown>;
    [key: string]: unknown;
  }>;
};

export type SmartCaptureTurnRequestV1 = {
  contractVersion: 1;
  message: string;
  modality: SmartCaptureModality;
  credentialId: number;
  draftContext: Record<string, unknown>;
  pendingChoice: PendingChoice | null;
  images: SmartCaptureImage[];
};

export type SmartCaptureTurnAction = {
  action: string;
  payload: Record<string, unknown>;
  resultado: string;
};

export type SmartCaptureTurnResultV1 = {
  replyText: string;
  actions: SmartCaptureTurnAction[];
  pendingChoice: PendingChoice | null;
  configurationRequired: boolean;
};

/** Payload emitido por el panel al host vía `onSend` (sin HTTP). */
export type SmartCaptureSendPayload = {
  message: string;
  modality: SmartCaptureModality;
  images: SmartCaptureImage[];
  credentialId: number | null;
};
