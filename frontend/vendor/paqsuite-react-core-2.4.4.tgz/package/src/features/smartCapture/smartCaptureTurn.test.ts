import { describe, expect, it } from 'vitest';
import { resolveModality } from './resolveModality';
import { buildSmartCaptureTurnRequest } from './buildSmartCaptureTurnRequest';
import {
  maxSmartCaptureImageBytes,
  maxSmartCaptureImages,
  validateImageAddition,
} from './imageValidation';
import type { SmartCaptureImage } from './types';

const image: SmartCaptureImage = {
  fileName: 'a.png',
  mimeType: 'image/png',
  contentBase64: 'AAAA',
};

describe('resolveModality', () => {
  it('precedencia imagen > audio > texto', () => {
    expect(resolveModality({ hasImages: true, usedDictation: true })).toBe('imagen');
    expect(resolveModality({ hasImages: false, usedDictation: true })).toBe('audio');
    expect(resolveModality({ hasImages: false, usedDictation: false })).toBe('texto');
  });
});

describe('buildSmartCaptureTurnRequest', () => {
  it('incluye contractVersion 1 y conserva imágenes con visión', () => {
    const request = buildSmartCaptureTurnRequest({
      message: 'hola',
      modality: 'imagen',
      credentialId: 5,
      draftContext: { foo: 1 },
      pendingChoice: null,
      images: [image],
      supportsVision: true,
    });
    expect(request.contractVersion).toBe(1);
    expect(request.images).toHaveLength(1);
    expect(request.credentialId).toBe(5);
  });

  it('omite imágenes cuando el modelo no soporta visión', () => {
    const request = buildSmartCaptureTurnRequest({
      message: 'hola',
      modality: 'texto',
      credentialId: 5,
      draftContext: {},
      pendingChoice: null,
      images: [image],
      supportsVision: false,
    });
    expect(request.images).toEqual([]);
  });
});

describe('validateImageAddition', () => {
  it('rechaza superar el máximo de imágenes', () => {
    expect(validateImageAddition(maxSmartCaptureImages, 10)).toBe('imagesLimit');
  });

  it('rechaza imágenes > 2 MiB', () => {
    expect(validateImageAddition(0, maxSmartCaptureImageBytes + 1)).toBe('imageTooLarge');
  });

  it('acepta dentro de límites', () => {
    expect(validateImageAddition(0, 1024)).toBeNull();
  });
});
