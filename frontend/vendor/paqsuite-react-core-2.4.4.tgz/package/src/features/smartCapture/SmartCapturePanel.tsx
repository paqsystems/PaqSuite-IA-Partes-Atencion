import { useCallback, useEffect, useId, useRef, useState } from 'react';
import Button from 'devextreme-react/button';
import TextArea from 'devextreme-react/text-area';
import SelectBox from 'devextreme-react/select-box';
import FileUploader, { type FileUploaderRef } from 'devextreme-react/file-uploader';
import type { KeyDownEvent as TextAreaKeyDownEvent } from 'devextreme/ui/text_area';
import { preventFileOpenOnDrop } from '../chatAssistant/preventFileOpenOnDrop';
import { resolveModality } from './resolveModality';
import { useWebSpeechDictation } from './useWebSpeechDictation';
import {
  maxSmartCaptureImageBytes,
  maxSmartCaptureImages,
  validateImageAddition,
} from './imageValidation';
import type {
  PendingChoice,
  SmartCaptureImage,
  SmartCaptureSendPayload,
} from './types';

export type SmartCaptureCredential = {
  id: number;
  nombre: string;
  enabled: boolean;
  supportsVision: boolean;
};

export type SmartCaptureThreadMessage = { role: 'user' | 'assistant'; text: string };

export type SmartCapturePanelProps = {
  enabled: boolean;
  hintKey?: string;
  hintText?: string;
  dialogMaxHeightPx?: number;
  credentials: SmartCaptureCredential[];
  activeCredentialId: number | null;
  onActiveCredentialChange: (id: number | null) => void;
  onOpenPreferences: () => void;
  onSend: (payload: SmartCaptureSendPayload) => void | Promise<void>;
  threadMessages?: SmartCaptureThreadMessage[];
  onThreadChange?: (messages: SmartCaptureThreadMessage[]) => void;
  /** Eco del último `pendingChoice` del turno (opciones numeradas clickeables). */
  pendingChoice?: PendingChoice | null;
  /** Índice 1-based (mismo contrato que escribir "1"/"2" en el prompt). */
  onSelectPendingOption?: (oneBasedIndex: number) => void | Promise<void>;
  onDiscardThread?: () => void;
  t?: (key: string) => string;
};

type TextAttachment = {
  id: string;
  fileName: string;
  content: string;
};

function isImageFile(file: File): boolean {
  if (file.type.startsWith('image/')) {
    return true;
  }
  // Algunos OS omiten mime; aceptar por extensión habitual.
  return /\.(jpe?g|png|gif|webp|bmp|svg)$/i.test(file.name);
}

function isPlainTextFile(file: File): boolean {
  if (file.type === 'text/plain' || file.type === 'text/markdown') {
    return true;
  }
  return /\.(txt|md)$/i.test(file.name);
}

const maxSmartCaptureMessageLength = 2000;
const maxSmartCaptureTextFileBytes = 100 * 1024;
const maxSmartCaptureTextAttachments = 4;

async function fileToImage(file: File): Promise<SmartCaptureImage> {
  const buffer = await file.arrayBuffer();
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.length; i += 1) {
    binary += String.fromCharCode(bytes[i]!);
  }
  const contentBase64 = typeof btoa === 'function' ? btoa(binary) : '';
  return { fileName: file.name, mimeType: file.type || 'application/octet-stream', contentBase64 };
}

async function readPlainTextFile(file: File): Promise<string> {
  return file.text();
}

/**
 * Panel embebido Smart Capture (GEN-03): colapsable, fila DX (SelectBox BYOK,
 * Preferencias, adjuntos, dictado, enviar), gates sin LLM / sin visión / sin
 * Web Speech, hilo local en memoria. El host compone `draftContext` y
 * `pendingChoice`; el panel solo emite `onSend`.
 */
export function SmartCapturePanel({
  enabled,
  hintKey,
  hintText,
  dialogMaxHeightPx = 280,
  credentials,
  activeCredentialId,
  onActiveCredentialChange,
  onOpenPreferences,
  onSend,
  threadMessages,
  onThreadChange,
  pendingChoice = null,
  onSelectPendingOption,
  onDiscardThread,
  t,
}: SmartCapturePanelProps) {
  const translate = t ?? ((key: string) => key);
  const [expanded, setExpanded] = useState(false);
  const [message, setMessage] = useState('');
  const [images, setImages] = useState<SmartCaptureImage[]>([]);
  const [textAttachments, setTextAttachments] = useState<TextAttachment[]>([]);
  const [internalThread, setInternalThread] = useState<SmartCaptureThreadMessage[]>([]);
  const [imageError, setImageError] = useState<string | null>(null);
  const [dropZoneActive, setDropZoneActive] = useState(false);
  const [sending, setSending] = useState(false);
  const usedDictationRef = useRef(false);
  const fileUploaderRef = useRef<FileUploaderRef>(null);
  const reactId = useId().replace(/:/g, '');
  const dropZoneDomId = `smartCaptureDropZone-${reactId}`;
  const pickImagesDomId = `smartCapturePickImages-${reactId}`;

  const dictation = useWebSpeechDictation((text) => {
    usedDictationRef.current = true;
    setMessage((current) => (current ? `${current} ${text}` : text));
  });

  useEffect(() => {
    window.addEventListener('dragover', preventFileOpenOnDrop);
    window.addEventListener('drop', preventFileOpenOnDrop);
    return () => {
      window.removeEventListener('dragover', preventFileOpenOnDrop);
      window.removeEventListener('drop', preventFileOpenOnDrop);
    };
  }, []);

  const thread = threadMessages ?? internalThread;
  const enabledCredentials = credentials.filter((credential) => credential.enabled);
  const activeCredential = enabledCredentials.find(
    (credential) => credential.id === activeCredentialId
  );
  const configurationRequired = !activeCredential;
  const canAttachImages = activeCredential?.supportsVision === true;
  const hasAttachments = images.length > 0 || textAttachments.length > 0;

  const resetFileUploader = useCallback(() => {
    fileUploaderRef.current?.instance()?.reset();
  }, []);

  const removeAttachedImage = useCallback(
    (index: number) => {
      setImages((current) => current.filter((_, imageIndex) => imageIndex !== index));
      setImageError(null);
      resetFileUploader();
    },
    [resetFileUploader]
  );

  const removeTextAttachment = useCallback(
    (id: string) => {
      setTextAttachments((current) => current.filter((item) => item.id !== id));
      setImageError(null);
      resetFileUploader();
    },
    [resetFileUploader]
  );

  const clearComposer = useCallback(() => {
    setMessage('');
    setImages([]);
    setTextAttachments([]);
    setImageError(null);
    usedDictationRef.current = false;
    resetFileUploader();
  }, [resetFileUploader]);

  const pushThread = useCallback(
    (messages: SmartCaptureThreadMessage[]) => {
      if (onThreadChange) {
        onThreadChange(messages);
      } else {
        setInternalThread(messages);
      }
    },
    [onThreadChange]
  );

  // Enviar habilitado con texto en prompt O al menos un adjunto (imagen / .txt).
  const canSend =
    !sending &&
    !configurationRequired &&
    (message.trim().length > 0 || hasAttachments);

  const handleSend = useCallback(async () => {
    if (!canSend) {
      return;
    }
    const trimmed = message.trim();
    const textFromFiles = textAttachments
      .map((item) => item.content.trim())
      .filter((item) => item !== '')
      .join('\n\n');
    let outboundMessage = trimmed;
    if (textFromFiles !== '') {
      outboundMessage = trimmed !== '' ? `${trimmed}\n\n${textFromFiles}` : textFromFiles;
    }
    // Guard GEN exige message no vacío: solo imágenes → prompt por defecto.
    if (outboundMessage === '' && images.length > 0) {
      outboundMessage = translate('smartCapture.defaultImagePrompt');
    }
    outboundMessage = outboundMessage.slice(0, maxSmartCaptureMessageLength);
    if (outboundMessage === '') {
      return;
    }

    const outboundImages = canAttachImages ? images : [];
    const modality = resolveModality({
      hasImages: outboundImages.length > 0,
      usedDictation: usedDictationRef.current,
    });
    const threadLabel =
      trimmed !== ''
        ? trimmed
        : hasAttachments
          ? `${translate('smartCapture.attachedImages.summary')} (${images.length + textAttachments.length})`
          : outboundMessage;
    pushThread([...thread, { role: 'user', text: threadLabel }]);
    setSending(true);
    try {
      await onSend({
        message: outboundMessage,
        modality,
        images: outboundImages,
        credentialId: activeCredentialId,
      });
      clearComposer();
    } finally {
      setSending(false);
    }
  }, [
    activeCredentialId,
    canAttachImages,
    canSend,
    clearComposer,
    hasAttachments,
    images,
    message,
    onSend,
    pushThread,
    textAttachments,
    thread,
    translate,
  ]);

  const handleComposerKeyDown = useCallback(
    (event: TextAreaKeyDownEvent) => {
      const nativeEvent = event.event;
      if (!nativeEvent) {
        return;
      }
      // Enter = nueva línea (default). Shift+Enter = enviar (misma UX que chat documental).
      if (nativeEvent.key !== 'Enter' || !nativeEvent.shiftKey) {
        return;
      }
      if (nativeEvent.altKey || nativeEvent.ctrlKey || nativeEvent.metaKey) {
        return;
      }
      nativeEvent.preventDefault();
      if (canSend) {
        void handleSend();
      }
    },
    [canSend, handleSend]
  );

  if (!enabled) {
    return null;
  }

  const hint = hintKey ? translate(hintKey) : hintText;

  return (
    <div data-testid="smartCapture.panel" style={{ border: '1px solid var(--dx-border, #ddd)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: 8 }}>
        <Button
          icon={expanded ? 'chevronup' : 'chevrondown'}
          stylingMode="text"
          onClick={() => setExpanded((value) => !value)}
          hint={translate(expanded ? 'smartCapture.tooltip.collapse' : 'smartCapture.tooltip.expand')}
          elementAttr={{ 'data-testid': 'smartCapture.expand' }}
        />
        <span>{translate('smartCapture.label.assistant')}</span>
        {expanded ? (
          <Button
            text={translate('smartCapture.discardThread')}
            stylingMode="text"
            onClick={() => {
              pushThread([]);
              clearComposer();
              onDiscardThread?.();
            }}
            elementAttr={{ 'data-testid': 'smartCapture.discardThread' }}
          />
        ) : null}
      </div>

      {expanded ? (
        <div style={{ padding: 8, display: 'flex', flexDirection: 'column', gap: 8 }}>
          {hint ? <p>{hint}</p> : null}

          <div
            data-testid="smartCapture.thread"
            style={{ maxHeight: dialogMaxHeightPx, overflowY: 'auto' }}
          >
            {thread.map((entry, index) => (
              <div
                key={index}
                data-role={entry.role}
                style={{ whiteSpace: 'pre-line', marginBottom: 6 }}
              >
                {entry.text}
              </div>
            ))}
          </div>

          {pendingChoice && pendingChoice.options.length > 0 ? (
            <div
              data-testid="smartCapture.pendingChoice"
              style={{ display: 'flex', flexDirection: 'column', gap: 6 }}
            >
              {pendingChoice.options.map((option, index) => (
                <Button
                  key={`${String(option.id)}-${index}`}
                  text={`${index + 1} — ${option.label}`}
                  stylingMode="outlined"
                  type="normal"
                  onClick={() => void onSelectPendingOption?.(index + 1)}
                  elementAttr={{
                    'data-testid': `smartCapture.pendingChoice.${index + 1}`,
                  }}
                />
              ))}
            </div>
          ) : null}

          {configurationRequired ? (
            <Button
              text={translate('smartCapture.cta.goToPreferences')}
              type="default"
              stylingMode="contained"
              onClick={onOpenPreferences}
              elementAttr={{ 'data-testid': 'smartCapture.goToPreferences' }}
            />
          ) : (
            <>
              <TextArea
                value={message}
                maxLength={maxSmartCaptureMessageLength}
                valueChangeEvent="input"
                onValueChanged={(event) => setMessage((event.value as string) ?? '')}
                onKeyDown={handleComposerKeyDown}
                autoResizeEnabled
                elementAttr={{ 'data-testid': 'smartCapture.prompt' }}
              />

              <div data-testid="smartCapture.attachImages">
                <p
                  style={{
                    margin: '0 0 6px',
                    fontSize: '0.85rem',
                    fontWeight: 600,
                    color: '#475569',
                  }}
                >
                  {translate('smartCapture.dropZone.title')}
                </p>
                <div
                  id={dropZoneDomId}
                  data-testid="smartCapture.dropZone"
                  onDragOver={(event) => {
                    event.preventDefault();
                  }}
                  onDrop={(event) => {
                    event.preventDefault();
                    setDropZoneActive(false);
                  }}
                  style={{
                    minHeight: 112,
                    border: `2px dashed ${dropZoneActive ? '#2563eb' : '#94a3b8'}`,
                    borderRadius: 8,
                    padding: '16px 12px',
                    background: dropZoneActive ? '#eff6ff' : '#f8fafc',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 8,
                    textAlign: 'center',
                    transition: 'background 0.15s ease, border-color 0.15s ease',
                  }}
                >
                  <i
                    className="dx-icon dx-icon-image"
                    style={{ fontSize: 28, color: dropZoneActive ? '#2563eb' : '#64748b' }}
                    aria-hidden
                  />
                  <strong style={{ fontSize: '0.95rem', color: '#334155' }}>
                    {translate('smartCapture.dropZone.primary')}
                  </strong>
                  <span style={{ fontSize: '0.8rem', color: '#64748b' }}>
                    {translate('smartCapture.dropZone.or')}
                  </span>
                  <Button
                    elementAttr={{ id: pickImagesDomId }}
                    text={translate('smartCapture.tooltip.attachImages')}
                    stylingMode="outlined"
                    type="normal"
                  />
                  <span style={{ fontSize: '0.75rem', color: '#64748b' }}>
                    {translate(
                      canAttachImages
                        ? 'smartCapture.attachImages.hint'
                        : 'smartCapture.attachImages.hintTextOnly'
                    )}
                  </span>
                </div>
                <FileUploader
                  ref={fileUploaderRef}
                  visible={false}
                  multiple
                  uploadMode="useForm"
                  accept={canAttachImages ? 'image/*,.txt,.md,text/plain' : '.txt,.md,text/plain'}
                  showFileList={false}
                  dropZone={`#${dropZoneDomId}`}
                  dialogTrigger={`#${pickImagesDomId}`}
                  onDropZoneEnter={() => setDropZoneActive(true)}
                  onDropZoneLeave={() => setDropZoneActive(false)}
                  onValueChanged={(event) => {
                    setDropZoneActive(false);
                    void (async () => {
                      const files = (event.value as File[]) ?? [];
                      if (files.length === 0) {
                        return;
                      }
                      const imageAdditions: SmartCaptureImage[] = [];
                      const textAdditions: TextAttachment[] = [];
                      let hadError = false;
                      for (const file of files) {
                        if (isPlainTextFile(file)) {
                          if (file.size > maxSmartCaptureTextFileBytes) {
                            setImageError('smartCapture.error.textFileTooLarge');
                            hadError = true;
                            break;
                          }
                          if (
                            textAttachments.length + textAdditions.length >=
                            maxSmartCaptureTextAttachments
                          ) {
                            setImageError('smartCapture.error.textFilesLimit');
                            hadError = true;
                            break;
                          }
                          const text = (await readPlainTextFile(file)).trim();
                          if (text === '') {
                            continue;
                          }
                          textAdditions.push({
                            id: `${file.name}-${file.size}-${Date.now()}-${textAdditions.length}`,
                            fileName: file.name,
                            content: text.slice(0, maxSmartCaptureMessageLength),
                          });
                          continue;
                        }
                        if (!isImageFile(file)) {
                          setImageError('smartCapture.error.unsupportedType');
                          hadError = true;
                          continue;
                        }
                        if (!canAttachImages) {
                          setImageError('smartCapture.error.visionRequired');
                          hadError = true;
                          continue;
                        }
                        const error = validateImageAddition(
                          images.length + imageAdditions.length,
                          file.size
                        );
                        if (error) {
                          setImageError(`smartCapture.error.${error}`);
                          hadError = true;
                          break;
                        }
                        imageAdditions.push(await fileToImage(file));
                      }
                      if (textAdditions.length > 0) {
                        setTextAttachments((current) =>
                          [...current, ...textAdditions].slice(0, maxSmartCaptureTextAttachments)
                        );
                      }
                      if (imageAdditions.length > 0) {
                        setImages((current) =>
                          [...current, ...imageAdditions].slice(0, maxSmartCaptureImages)
                        );
                      }
                      if (
                        !hadError &&
                        (textAdditions.length > 0 || imageAdditions.length > 0)
                      ) {
                        setImageError(null);
                      }
                      resetFileUploader();
                    })();
                  }}
                />
                {hasAttachments ? (
                  <ul
                    data-testid="smartCapture.attachedList"
                    style={{
                      listStyle: 'none',
                      margin: '8px 0 0',
                      padding: 0,
                      fontSize: '0.8rem',
                      color: '#475569',
                    }}
                  >
                    {textAttachments.map((attachment) => (
                      <li
                        key={attachment.id}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 6,
                          minHeight: 32,
                        }}
                      >
                        <span
                          style={{
                            flex: 1,
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          }}
                          title={attachment.fileName}
                        >
                          {attachment.fileName}
                        </span>
                        <Button
                          icon="trash"
                          stylingMode="text"
                          hint={translate('smartCapture.attachedFiles.remove')}
                          onClick={() => removeTextAttachment(attachment.id)}
                          elementAttr={{
                            'data-testid': `smartCapture.attachedTextRemove.${attachment.id}`,
                            'aria-label': translate('smartCapture.attachedFiles.remove'),
                          }}
                        />
                      </li>
                    ))}
                    {images.map((image, index) => (
                      <li
                        key={`${image.fileName}-${index}-${image.contentBase64.slice(0, 12)}`}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 6,
                          minHeight: 32,
                        }}
                      >
                        <span
                          style={{
                            flex: 1,
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          }}
                          title={image.fileName}
                        >
                          {image.fileName}
                        </span>
                        <Button
                          icon="trash"
                          stylingMode="text"
                          hint={translate('smartCapture.attachedFiles.remove')}
                          onClick={() => removeAttachedImage(index)}
                          elementAttr={{
                            'data-testid': `smartCapture.attachedRemove.${index}`,
                            'aria-label': translate('smartCapture.attachedFiles.remove'),
                          }}
                        />
                      </li>
                    ))}
                  </ul>
                ) : null}
              </div>

              <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                <SelectBox
                  dataSource={enabledCredentials}
                  valueExpr="id"
                  displayExpr="nombre"
                  value={activeCredentialId}
                  hint={translate('smartCapture.tooltip.llmProvider')}
                  onValueChanged={(event) =>
                    onActiveCredentialChange((event.value as number | null) ?? null)
                  }
                  elementAttr={{ 'data-testid': 'smartCapture.selectBox' }}
                />
                <Button
                  icon="preferences"
                  hint={translate('smartCapture.tooltip.preferences')}
                  onClick={onOpenPreferences}
                  elementAttr={{ 'data-testid': 'smartCapture.preferences' }}
                />
                {dictation.supported ? (
                  <Button
                    icon="mic"
                    hint={translate('smartCapture.tooltip.dictate')}
                    onClick={() => (dictation.listening ? dictation.stop() : dictation.start())}
                    elementAttr={{ 'data-testid': 'smartCapture.dictate' }}
                  />
                ) : null}
                <Button
                  icon="send"
                  type="default"
                  stylingMode="contained"
                  hint={translate('smartCapture.tooltip.send')}
                  disabled={!canSend}
                  onClick={() => void handleSend()}
                  elementAttr={{ 'data-testid': 'smartCapture.send' }}
                />
              </div>
              {imageError ? (
                <span data-i18n-key={imageError}>{translate(imageError)}</span>
              ) : null}
            </>
          )}
        </div>
      ) : null}
    </div>
  );
}
