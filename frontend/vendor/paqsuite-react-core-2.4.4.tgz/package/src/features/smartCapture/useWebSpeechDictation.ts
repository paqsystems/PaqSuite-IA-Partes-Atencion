import { useCallback, useRef, useState } from 'react';

type MinimalRecognition = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
};

type RecognitionCtor = new () => MinimalRecognition;

/** Detecta el constructor de Web Speech (`SpeechRecognition` / webkit). */
export function getSpeechRecognitionCtor(): RecognitionCtor | null {
  if (typeof window === 'undefined') {
    return null;
  }
  const win = window as unknown as {
    SpeechRecognition?: RecognitionCtor;
    webkitSpeechRecognition?: RecognitionCtor;
  };
  return win.SpeechRecognition ?? win.webkitSpeechRecognition ?? null;
}

export type WebSpeechDictation = {
  supported: boolean;
  listening: boolean;
  start: () => void;
  stop: () => void;
};

/**
 * Dictado por Web Speech (GEN-03). Si no hay soporte, `supported=false` y el
 * panel oculta el control. Al reconocer, vuelca el texto vía `onTranscript`.
 */
export function useWebSpeechDictation(
  onTranscript: (text: string) => void,
  locale = 'es-ES'
): WebSpeechDictation {
  const ctor = getSpeechRecognitionCtor();
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef<MinimalRecognition | null>(null);

  const start = useCallback(() => {
    if (!ctor) {
      return;
    }
    const recognition = new ctor();
    recognition.lang = locale;
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onresult = (event) => {
      const first = event.results[0]?.[0]?.transcript;
      if (first) {
        onTranscript(first);
      }
    };
    recognition.onend = () => setListening(false);
    recognition.onerror = () => setListening(false);
    recognitionRef.current = recognition;
    setListening(true);
    recognition.start();
  }, [ctor, locale, onTranscript]);

  const stop = useCallback(() => {
    recognitionRef.current?.stop();
    setListening(false);
  }, []);

  return { supported: ctor !== null, listening, start, stop };
}
