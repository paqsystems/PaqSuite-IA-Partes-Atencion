import type {
  PendingChoice,
  SmartCaptureImage,
  SmartCaptureModality,
  SmartCaptureTurnRequestV1,
} from './types';

export type BuildSmartCaptureTurnInput = {
  message: string;
  modality: SmartCaptureModality;
  credentialId: number;
  draftContext: Record<string, unknown>;
  pendingChoice: PendingChoice | null;
  images: SmartCaptureImage[];
  supportsVision: boolean;
};

/**
 * Arma el request v1 del turno Smart Capture. Defensa en profundidad de visión:
 * si `supportsVision=false` → `images = []` (TR-GEN-03-contrato-turno §5).
 */
export function buildSmartCaptureTurnRequest(
  input: BuildSmartCaptureTurnInput
): SmartCaptureTurnRequestV1 {
  return {
    contractVersion: 1,
    message: input.message,
    modality: input.modality,
    credentialId: input.credentialId,
    draftContext: input.draftContext,
    pendingChoice: input.pendingChoice,
    images: input.supportsVision ? input.images : [],
  };
}
