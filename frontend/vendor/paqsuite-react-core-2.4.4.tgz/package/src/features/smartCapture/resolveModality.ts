import type { SmartCaptureModality } from './types';

export type ModalityInputs = {
  hasImages: boolean;
  usedDictation: boolean;
};

/**
 * Calcula la `modality` única del turno con precedencia
 * `imagen` > `audio` > `texto` (C1, TR-GEN-03).
 */
export function resolveModality({ hasImages, usedDictation }: ModalityInputs): SmartCaptureModality {
  if (hasImages) {
    return 'imagen';
  }
  if (usedDictation) {
    return 'audio';
  }
  return 'texto';
}
