import { apiRequest, type ApiClientResult } from '../../http/apiClient';
import type { SmartCaptureTurnRequestV1, SmartCaptureTurnResultV1 } from './types';

/**
 * Envía un turno Smart Capture al endpoint de dominio del host (la URL la
 * define el host; TR-GEN-03-contrato-turno §5). Devuelve el resultado
 * discriminado de `apiRequest` (`ApiClientResult`).
 */
export function postSmartCaptureTurn(
  url: string,
  body: SmartCaptureTurnRequestV1,
  options?: { signal?: AbortSignal }
): Promise<ApiClientResult<SmartCaptureTurnResultV1>> {
  return apiRequest<SmartCaptureTurnResultV1>(url, {
    method: 'POST',
    body: JSON.stringify(body),
    signal: options?.signal,
  });
}
