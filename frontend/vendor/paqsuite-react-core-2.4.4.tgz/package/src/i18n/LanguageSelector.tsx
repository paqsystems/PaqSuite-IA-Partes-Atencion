import SelectBox from 'devextreme-react/select-box';
import { supportedLocales, type LocaleCode } from './localeCatalog';
import { syncDevExtremeLocale } from './syncDevExtremeLocale';

export type LanguageSelectorProps = {
  locale: LocaleCode;
  onLocaleChange: (locale: LocaleCode) => void;
  disabled?: boolean;
  /** Default `languageSelector` (TR-GEN-02). En auth: `authLanguageSelect`. */
  testId?: string;
};

const localeItems = supportedLocales.map((code) => ({
  code,
  label:
    code === 'es'
      ? 'Español'
      : code === 'en'
        ? 'English'
        : code === 'pt'
          ? 'Português'
          : code === 'fr'
            ? 'Français'
            : 'Italiano',
}));

/**
 * Selector de idioma DevExtreme (`SelectBox`) — contrato GEN-02.
 */
export function LanguageSelector({
  locale,
  onLocaleChange,
  disabled,
  testId = 'languageSelector',
}: LanguageSelectorProps) {
  return (
    <SelectBox
      data-testid={testId}
      elementAttr={{ 'data-testid': testId }}
      dataSource={localeItems}
      displayExpr="label"
      valueExpr="code"
      value={locale}
      disabled={disabled}
      width={140}
      searchEnabled={false}
      onValueChanged={(event) => {
        const next = event.value as LocaleCode;
        if (!next || next === locale) {
          return;
        }
        syncDevExtremeLocale(next);
        onLocaleChange(next);
      }}
    />
  );
}
