import { locale, loadMessages } from 'devextreme/localization';
import enMessages from 'devextreme/localization/messages/en.json';
import esMessages from 'devextreme/localization/messages/es.json';
import frMessages from 'devextreme/localization/messages/fr.json';
import itMessages from 'devextreme/localization/messages/it.json';
import ptMessages from 'devextreme/localization/messages/pt.json';
import { isSupportedLocale } from './localeCatalog';

let messagesLoaded = false;

function ensureMessagesLoaded(): void {
  if (messagesLoaded) {
    return;
  }
  loadMessages(esMessages);
  loadMessages(enMessages);
  loadMessages(ptMessages);
  loadMessages(frMessages);
  loadMessages(itMessages);
  messagesLoaded = true;
}

/**
 * Sincroniza locale DevExtreme con el catálogo GEN-02 (`es|en|pt|fr|it`).
 * Idempotente: carga mensajes una vez y aplica `locale(código)`.
 */
export function syncDevExtremeLocale(rawLocale: string): void {
  ensureMessagesLoaded();
  const code = (isSupportedLocale(rawLocale) ? rawLocale : null) ?? 'es';
  locale(code);
}
